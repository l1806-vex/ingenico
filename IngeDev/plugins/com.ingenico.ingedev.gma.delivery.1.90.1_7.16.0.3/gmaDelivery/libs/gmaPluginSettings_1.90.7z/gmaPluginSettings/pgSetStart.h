
#ifndef PG_SETTINGS_START_H_INCLUDED
#define PG_SETTINGS_START_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define PG_SET_ERR_CREATE_FILE   (-1)
#define PG_SET_ERR_READ_FILE     (-2)
#define PG_SET_ERR_NO_APP        (-3)

/**
 * Load the config file from the DFS, if no file exist
 * create a default one
 */
int16 pgSetStartAppInitialize(uint8 setPluginId);

/**
 * Check if there is an application to be wakeup.
 * If there is, return the appId and logicalId of the application
 * 
 * @return RET_OK there is an application to be started
 * @return any other value, there is no application to be wakeup.
 */
int16 pgSetCheckApptoStart(uint16 *appId, uint8 *logicaId);

/**
 * Set an application to be wakeup. Will show a menu with all the logical
 * applications present in the terminal. The user choose one and this application
 * will be set in the file.
 */
int16 pgSetSetAppName(void);

#ifdef __cplusplus
}
#endif

#endif



#ifndef GMA_PG_SETT_FILE_H_INCLUDED
#define GMA_PG_SETT_FILE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define GMA_PG_SETT_ITEM_APPSTARTNAME     (1)
#define GMA_PG_SETT_ITEM_SLEEPMODESTATUS  (2)
#define GMA_PG_SETT_ITEM_SLEEPMODETIMEOUT (3)
#define GMA_PG_SETT_ITEM_BEEPSTATUS       (4)
#define GMA_PG_SETT_ITEM_CONTRAST         (5)
#define GMA_PG_SETT_ITEM_BACKLIGHTSTATUS  (6)
#define GMA_PG_SETT_ITEM_BACKLIGHTTIMEOUT (7)
#define GMA_PG_SETT_ITEM_MENUSTATUS       (8)
#define GMA_PG_SETT_ITEM_PASSWORD         (9)
#define GMA_PG_SETT_ITEM_BLKSTRIPESTATUS  (10)
#define GMA_PG_SETT_ITEM_REDUCTIONSTATUS  (11)
#define GMA_PG_SETT_ITEM_REDUCTION        (12)

#define GMA_PG_SETT_ITEM_SIZE_APPSTARTNAME     (GMA_APP_LIST_LOGICAL_APP_NAME_LENGTH+1)
#define GMA_PG_SETT_ITEM_SIZE_SLEEPMODESTATUS  (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_SLEEPMODETIMEOUT (sizeof(uint16))
#define GMA_PG_SETT_ITEM_SIZE_BEEPSTATUS       (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_CONTRAST         (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_BACKLIGHTSTATUS  (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_BACKLIGHTTIMEOUT (sizeof(uint16))
#define GMA_PG_SETT_ITEM_SIZE_MENUSTATUS       (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_PASSWORD         (4+1)
#define GMA_PG_SETT_ITEM_SIZE_BLKSTRIPESTATUS  (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_REDUCTIONSTATUS  (sizeof(uint8))
#define GMA_PG_SETT_ITEM_SIZE_REDUCTION        (sizeof(uint8))

#define PG_SET_ERR_CREATE_FILE   (-1)
#define PG_SET_ERR_READ_FILE     (-2)
#define PG_SET_ERR_NO_APP        (-3)


/**
 * 
 */
int16 gmaPgSettSetGetValue(void *value, uint16 itemId, uint8 set);

/**
 * 
 */
int16 gmaPgSettReadFile(void);

/**
 * 
 */
int16 gmaPgSettWriteFile(void);

#ifdef __cplusplus
}
#endif

#endif


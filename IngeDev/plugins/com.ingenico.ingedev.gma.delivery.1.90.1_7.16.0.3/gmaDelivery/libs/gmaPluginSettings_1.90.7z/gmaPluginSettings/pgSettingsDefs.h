
#ifndef PG_SETTINGS_DEFS_H_INCLUDED
#define PG_SETTINGS_DEFS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define SETT_NOTIF_SLEEP_MODE_1 (1)
#define SETT_NOTIF_SLEEP_MODE_2 (2)
#define SETT_NOTIF_WAKE_APP     (3)

#define SETT_MENU_DATETIME      (1)
#define SETT_MENU_START_APP     (2)
#define SETT_MENU_SLEEP_MODE    (3)
#define SETT_MENU_SETTINGS      (4)
#define SETT_MENU_CRASH_INFO    (5)
#define SETT_MENU_SECURITY      (6)
#define SETT_MENU_DEBUG         (7)
#define SETT_MENU_TOUCH         (8)

#ifdef __cplusplus
}
#endif

#endif


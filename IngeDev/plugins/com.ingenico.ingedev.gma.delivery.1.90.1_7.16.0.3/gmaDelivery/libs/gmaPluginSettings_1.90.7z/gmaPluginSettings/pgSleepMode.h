
#ifndef PG_SLEEP_MODE_INCLUDED
#define PG_SLEEP_MODE_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define DEFAULT_ACTIVE FALSE
#define DEFAULT_SLEEP_TIME 120 //in seconds
#define SM_EVENT_ID 5


/**
 * 
 */
typedef struct
{
   uint8 active;
   uint32 timeToSleep;
} sleepModeCfg_t;


/**
 * Configure the sleep mode
 */
int16 pgSMConfiguration (void);

/**
 * Initialize the sleep mode plugin
 */
int16 pgSMInitialize (uint8 pgPluginId);

/**
 * The terminal enter in active state
 */
int16 pgSMAppStart(void);

/**
 * The terminal enter in idle state
 */
int16 pgSMAppEnd(void);

/**
 * Check if the terminal is inactive for the sufficient time to enter in sleep
 * mode.
 */
int16 pgSMCheckSleepTime(void);

/**
 * 
 */
void pgSMtreatNotifSleepMode1(void);

/**
 * Enter in sleep mode
 */
int16 pgSMtreatNotifSleepMode2 (void);

#ifdef __cplusplus
}
#endif

#endif



#ifndef PG_SETTINGS_STRING_H_INCLUDED
#define PG_SETTINGS_STRING_H_INCLUDED

#include "resources.h"

#ifdef __cplusplus
extern "C" {
#endif

char * pgSettingsGetStr(uint16 id);

#ifdef __cplusplus
}
#endif

#endif



#ifndef PG_SETTINGS_TOUCH_H_INCLUDED
#define PG_SETTINGS_TOUCH_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/** 
 * Original source code by MCR0255(2008-12-29)
 */
	
/**
 * Processes a Touch screen calibration by using regular HMI peripheral.
 * This function forces the closing of the gmaCustom Hmi handles to 
 * allow a succesful calibration.
 *
 * @param bAlone (bool:TRUE/FALSE)
 *               - TRUE if you want to force Closing gmaCustom Hmi handles and open 
 *                 them for it's own.
 *               - FALSE if you want the function to use the gmaCustom Hmi handles.
 * 
 * @return RET_OK Success.
 * @return ERR_INTERNAL Failure.
 */
int16 pgSettTouchScreenCalibration(void);	

#ifdef __cplusplus
}
#endif

#endif // PG_SETTINGS_TOUCH_H_INCLUDED


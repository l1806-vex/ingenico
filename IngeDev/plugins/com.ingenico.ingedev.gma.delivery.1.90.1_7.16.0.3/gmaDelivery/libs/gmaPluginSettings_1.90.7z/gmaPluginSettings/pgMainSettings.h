
#ifndef GMA_PG_MAIN_SETTINGS_H_INCLUDED
#define GMA_PG_MAIN_SETTINGS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Plugin registration (Callback settlement)
 * -> This function must be called before everything
 */
int16 pgRegistryPluginSettings(void);

#ifdef __cplusplus
}
#endif

#endif


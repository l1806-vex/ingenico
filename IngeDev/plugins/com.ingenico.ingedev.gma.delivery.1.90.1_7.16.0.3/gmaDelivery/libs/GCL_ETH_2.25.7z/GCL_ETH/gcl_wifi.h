#ifndef _GLC_WiFi_H_INCLUDED
#define _GLC_WiFi_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>
#include <LNetCtrl.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_wifi.h
 *
 * GCL WiFi type
 */

/**
 * \addtogroup WIFI_ Wifi communication
 *
 * Will open a socket connection using the WiFi.
 *
 * @{
 */

#define GCL_MAX_SSID (32)
#define GCL_MAX_WEP_KEY 14

#define GCL_WIFI_FUNC_netNiOpen           (1)
#define GCL_WIFI_FUNC_netCfgIdentify      (2)
#define GCL_WIFI_FUNC_CHANNEL_NOT_FOUND   (3)
#define GCL_WIFI_FUNC_netNiConfigSet      (4)
#define GCL_WIFI_FUNC_netNiCtrl_P_VERSION (5)
#define GCL_WIFI_FUNC_netNiCtrl_P_MODE    (6)
#define GCL_WIFI_FUNC_netNiCtrl_P_RATE    (7)
#define GCL_WIFI_FUNC_netNiCtrl_P_DESIREDSSID (8)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEP     (9)
#define GCL_WIFI_FUNC_netNiCtrl_P_AUTH    (10)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEPAK   (11)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEPKE_1 (12)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEPKE_2 (13)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEPKE_3 (14)
#define GCL_WIFI_FUNC_netNiCtrl_P_WEPKE_4 (15)
#define GCL_WIFI_FUNC_netNiCtrl_P_OWNSSID (16)
#define GCL_WIFI_FUNC_netNiCtrl_P_OWNCHAN (17)
#define GCL_WIFI_FUNC_netNiCtrl_P_BEACON  (18)
#define GCL_WIFI_FUNC_netNiStart          (19)
#define GCL_WIFI_FUNC_dnsGetHostByName    (20)
#define GCL_WIFI_FUNC_SOCKET_CONNECT      (40)
#define GCL_WIFI_FUNC_SOCKET_SEND         (41)
#define GCL_PPP_WIFI_SOCKET_RECEIVE       (42)

/**
 * store the information of the last error occurred in the gclWIFI.
 * Note that if the pppFunc is GCL_WIFI_FUNC_SOCKET_CONNECT, GCL_WIFI_FUNC_SOCKET_SEND
 * or GCL_PPP_WIFI_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclWifiErrorInfo_st gclWifiErrorInfo_t;

/**
 * store the information of the last error occurred in the gclWIFI.
 * Note that if the pppFunc is GCL_WIFI_FUNC_SOCKET_CONNECT, GCL_WIFI_FUNC_SOCKET_SEND
 * or GCL_PPP_WIFI_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclWifiErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_WIFI_FUNC_XXX defines
	 */
	uint16 wifiFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclWifiErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclWifiGetLastErrorInfo(gclWifiErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclWifiGetLastErrorInfo
 */
void gclWifierrorReset(void);

/**
 * \brief Structure with the WiFi configuration
 */
typedef struct
{
   uint8    connectionId;  //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ////////////////////////socket
   char     *ipAddress;    //!< IP address in dotted decimal notation
   char     *tcpPort;      //!< TCP port in decimal notation
   char     *hostName;     //!< host name if IP not provided, will use DNS to get the IP
   ////////////////////////dhcp
   uint8    useDhcp;       //!< if one the DHCP will be used to retrieve the local configuration
   char     *dhcpHostName; //!< the name to send to the DHCP server
   uint32   leaseTime;     //!< suggested lease time (0xFFFFFFFF to don't use this option)
                           //!< (0 for default value = 180 seconds)
   // to set if no DHCP
   char     *defaultLocalIpAddress; //!< Local IP address if DHCP not used
   char     *defaultDefGateway;     //!< IP address of the gateway
   char     *defaultDns1IpAddress;  //!< IP address of the DNS server one
   char     *defaultDns2IpAddress;  //!< IP address of the DNS server two
   char     *domainName;            //!< domain name

   //Wifi specific
   int      WiFiMode;         //!< use NET_PRISM_MODE_ADHOC or NET_PRISM_MODE_INFRASTRUCTURE

   uint32   allowedSpeedRate; //!< bit 0 = 1Mbps, bit 1 = 2Mbps, bit 2 = 5.5Mbps, bit 3 = 11 Mbps
                              //!< use 0x0f if all speeds are allowed
   char     *desiredSSID;     //!< SSID of the peer (ADHOC) or SSID of the access point

   uint32   wepEncryption;    //!< 0 = no encryption, 1 = use WEP encryption

   //Specific if wep encryption is used
   uint32   authMode;         //!< 0 or NET_PRISM_AUTH_OPENSYSTEM or NET_PRISM_AUTH_SHAREDKEY
   uint32   defaultWepKey;    //!< 0, 1 2 or 3 for default wep key number or 0xffffffff for all keys

   uint16   key0Type;         //!< type of the wep key : NET_PRISM_WEP_TYPE_64 or NET_PRISM_WEP_TYPE_128 or 0xFFFF if not used
   char     *key0Value;       //!< key value in ascii

   uint16   key1Type;         //!< type of the wep key : NET_PRISM_WEP_TYPE_64 or NET_PRISM_WEP_TYPE_128 or 0xFFFF if not used
   char     *key1Value;       //!< key value in ascii

   uint16   key2Type;         //!< type of the wep key : NET_PRISM_WEP_TYPE_64 or NET_PRISM_WEP_TYPE_128 or 0xFFFF if not used
   char     *key2Value;       //!< key value in ascii

   uint16   key3Type;         //!< type of the wep key : NET_PRISM_WEP_TYPE_64 or NET_PRISM_WEP_TYPE_128 or 0xFFFF if not used
   char     *key3Value;       //!< key value in ascii

   //Specific to ADHOC mode
   char     *ownSSID;         //!< own SSID
   uint32   ownChannel;       //!< own channel

   ////////////////////////
   uint8    retries; //!<  connection attempts = retries + 1
   ////////////////////////
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection
   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
   ///////////
} gclWiFi_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific WiFi configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!< specific socket configuration
   /////////////////////////////////////////////////////////////////////////////
   netNi_t           ni; //!< the handle of the LNET
   /////
   netNiConfig_t     config; //!< Lnet configuration struct
   //
   uint8    useDhcp; //!< if DHCP will be used
   char     dhcpHostName[GCL_MAX_HOST_NAME + 1]; //!< host name of the DHCP server
   char     domainName[GCL_MAX_HOST_NAME + 1]; //!< dmain name
   /////
   uint32   ipAddressLocal; //!< local ip address
   /////
   uint32   defaultGateway;   //!< address of the default gateway
   uint32   dns1IpAddress;    //!< IP address of the DNS server one
   uint32   dns2IpAddress;    //!< IP address of the DNS server two

   //Wifi specific
   int      WiFiMode;         //!< use NET_PRISM_MODE_ADHOC or NET_PRISM_MODE_INFRASTRUCTURE

   uint32   allowedSpeedRate; //!< bit 0 = 1Mbps, bit 1 = 2Mbps, bit 2 = 5.5Mbps, bit 3 = 11 Mbps

   uint8    desiredSSID[GCL_MAX_SSID + 1];  //!< SSID of the peer (ADHOC) or SSID of the access point

   uint32   wepEncryption;    //!< 0 = no encryption, 1 = use WEP encryption

   //Specific if wep encryption is used
   uint32   authMode;         //!< 0 or NET_PRISM_AUTH_OPENSYSTEM or NET_PRISM_AUTH_SHAREDKEY
   uint32   defaultWepKey;    //!< 0, 1 2 or 3 for default wep key number or 0xffffffff for all keys
   netNiOptPrismWepKeyEntry1_t key0; //!< Structure that contains key 0 (type is -1 if key is not used)
   netNiOptPrismWepKeyEntry1_t key1; //!< Structure that contains key 1 (type is -1 if key is not used)
   netNiOptPrismWepKeyEntry1_t key2; //!< Structure that contains key 2 (type is -1 if key is not used)
   netNiOptPrismWepKeyEntry1_t key3; //!< Structure that contains key 3 (type is -1 if key is not used)

   //Specific to ADHOC mode
   uint8    ownSSID[GCL_MAX_SSID + 1];      //!< own SSID
   uint32   ownChannel;       //!< own channel

   //specific used (not available with the set function)
   uint8    beaconUsed;       //!< 0 if Beacon period is not used, 1 else
   uint32   beaconPeriod;     //!< value of Beacon period

   uint8    currentSSID[GCL_MAX_SSID + 1]; //!< SSID of current connected access point

   char     rfu[49]; //!< rfu

} gclWiFiConfig_t;


/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclWiFiId(char *zcOut);

/**
 * This function will add a WIFI WEP connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param WiFiConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclWiFiSet(gclWiFi_t *WiFiConfig, gclFunctionList_t *List,
                 uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclWiFiDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclWiFiSend(gclConfig_t *gcl, uint8* buffer, uint32 size);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclWiFiReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size,
                    uint32 maxsize);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif



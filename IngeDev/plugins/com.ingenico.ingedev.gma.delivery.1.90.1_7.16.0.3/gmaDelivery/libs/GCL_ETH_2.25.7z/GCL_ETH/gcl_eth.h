#ifndef _GLC_ETH_H_INCLUDED
#define _GLC_ETH_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_eth.h
 *
 * GCL Ethernet connection
 */

/**
 * \addtogroup ETH_ ethernet communication
 *
 * Will open a socket connection using the Ethernet.
 *
 * @{
 */
 
#define GCL_ETH_FUNC_netNiOpen         (1)
#define GCL_ETH_FUNC_netCfgIdentify    (2)
#define GCL_ETH_FUNC_CHANNEL_NOT_FOUND (3)
#define GCL_ETH_FUNC_netNiConfigSet    (4)
#define GCL_ETH_FUNC_netNiStart        (5)
#define GCL_ETH_FUNC_dnsGetHostByName  (6)
#define GCL_ETH_FUNC_SOCKET_CONNECT    (40)
#define GCL_ETH_FUNC_SOCKET_SEND       (41)
#define GCL_ETH_FUNC_SOCKET_RECEIVE    (42)


/**
 * store the information of the last error occurred in the gclETH.
 * Note that if the ethFunc is GCL_ETH_FUNC_SOCKET_CONNECT, GCL_ETH_FUNC_SOCKET_SEND
 * or GCL_ETH_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclEthErrorInfo_st gclEthErrorInfo_t;

/**
 * store the information of the last error occurred in the gclETH.
 * Note that if the ethFunc is GCL_ETH_FUNC_SOCKET_CONNECT, GCL_ETH_FUNC_SOCKET_SEND
 * or GCL_ETH_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclEthErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_ETH_FUNC_XXX defines
	 */
	uint16 ethFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclEthErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a ETH error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclEthGetLastErrorInfo(gclEthErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclEthGetLastErrorInfo
 */
void gclEthSerrorReset(void);

/**
 * \brief Structure with the ethernet configuration
 */
typedef struct
{
   uint8    connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ////////////////////////socket
   char     *ipAddress; //!< IP address in dotted decimal notation
   char     *tcpPort;   //!< TCP port in decimal notation
   char     *hostName;  //!< host name if IP not provided, will use DNS to get the IP
   ////////////////////////dhcp
   uint8    useDhcp;       //!< if one the DHCP will be used to retrieve the local configuration
   char     *dhcpHostName; //!< the name to send to the DHCP server
   uint32   leaseTime;     //!< suggested lease time (0xFFFFFFFF to don't use this option)
                           //!< (0 for default value = 180 seconds)
   // to set if no DHCP
   char     *defaultLocalIpAddress; //!< Local IP address if DHCP not used
   char     *defaultDefGateway;     //!< IP address of the gateway
   char     *defaultDns1IpAddress;  //!< IP address of the DNS server one
   char     *defaultDns2IpAddress;  //!< IP address of the DNS server two
   char     *domainName;            //!< domain name
   ////////////////////////
   uint8    retries; //!< connection attempts = retries + 1
   ////////////////////////
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection

   char *subNetworkMask; //!< Sub network mask
   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
   ///////////
} gclEth_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific ethernet configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!< specific socket configuration
   /////////////////////////////////////////////////////////////////////////////
   netNi_t           ni; //!< the handle of the LNET
   /////
   netNiConfig_t     config; //!< Lnet configuration struct
   //
   uint8    useDhcp; //!< if DHCP will be used
   char     dhcpHostName[GCL_MAX_HOST_NAME + 1]; //!< host name of the DHCP server
   char     domainName[GCL_MAX_HOST_NAME + 1]; //!< dmain name
   /////
   uint32   ipAddressLocal; //!< local ip address
   /////
   uint32   defaultGateway; //!< address of the default gateway
   uint32   dns1IpAddress; //!< IP address of the DNS server one
   uint32   dns2IpAddress; //!< IP address of the DNS server two
   
   char     rfu[49]; //!< rfu

} gclEthConfig_t;


/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclEthId(char *zcOut);

/**
 * This function will add an Ethernet connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param EthConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclEthSet(gclEth_t *EthConfig, gclFunctionList_t *List,
                uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is ethernet connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclEthPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is Ethernet connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclEthDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is Ethernet connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclEthConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is Ethernet connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclEthHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is Ethernet connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclEthSend(gclConfig_t *gcl, uint8* buffer, uint32 size);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is socket connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclEthReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size,
                    uint32 maxsize);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


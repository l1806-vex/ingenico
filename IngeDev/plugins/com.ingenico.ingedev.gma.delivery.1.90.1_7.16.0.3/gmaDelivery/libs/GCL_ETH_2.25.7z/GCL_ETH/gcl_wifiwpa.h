
#ifndef GCL_WIFIWPA_H_INCLUDED
#define GCL_WIFIWPA_H_INCLUDED

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 *  @file gcl_wifiwpa.h
 *
 * GCL WiFi WPA type
 */

/**
 * \addtogroup WIFIWPA_ Wifi WPA communication
 *
 * Will open a socket connection using the WiFi WPA.
 *
 * @{
 */

#define GCL_WIFI_PROTO_WPA (1<<0)
#define GCL_WIFI_PROTO_RSN (1<<1)

#define GCL_WIFI_KMGM_WPA_PSK   (1<<0)
#define GCL_WIFI_KMGM_WPA_EAP   (1<<1)
#define GCL_WIFI_KMGM_IEEE8021X (1<<2)

#define GCL_WIFI_AUTH_OPEN   (1<<0)
#define GCL_WIFI_AUTH_SHARED (1<<1)
#define GCL_WIFI_AUTH_LEAP   (1<<2)

#define GCL_WIFI_PAIR_CCMP (1<<0)
#define GCL_WIFI_PAIR_TKIP (1<<1)
#define GCL_WIFI_PAIR_NONE (1<<2)

#define GCL_WIFI_EAP_MD5      (1<<0)
#define GCL_WIFI_EAP_MSCHAPV2 (1<<1)
#define GCL_WIFI_EAP_OTP      (1<<2)
#define GCL_WIFI_EAP_PEAP     (1<<3)
#define GCL_WIFI_EAP_GTC      (1<<4)
#define GCL_WIFI_EAP_TLS      (1<<5)
#define GCL_WIFI_EAP_TTLS     (1<<6)

#ifndef GCL_MAX_SSID
#define GCL_MAX_SSID (32)
#endif

#define OFFSETOF(s,x)  ((uint16)( ( (uint8 *)(&((s *)0)->x)) - (uint8 *)0))
#define SIZEOFFIELD(s,x)  sizeof(((s *)0)->x)

#define GCL_WIFI_WPA_FUNC_netNiOpen          (1)
#define GCL_WIFI_WPA_FUNC_netCfgIdentify     (2)
#define GCL_WIFI_WPA_FUNC_CHANNEL_NOT_FOUND  (3)
#define GCL_WIFI_WPA_FUNC_netNiConfigSet     (4)
#define GCL_WIFI_WPA_FUNC_netNiCtrl_WPA_CONF (5)
#define GCL_WIFI_WPA_FUNC_netNiStart         (6)
#define GCL_WIFI_WPA_FUNC_dnsGetHostByName   (7)
#define GCL_WIFI_WPA_FUNC_SOCKET_CONNECT     (40)
#define GCL_WIFI_WPA_FUNC_SOCKET_SEND        (41)
#define GCL_WIFI_WPA_FUNC_SOCKET_RECEIVE     (42)

/**
 * store the information of the last error occurred in the gclWIFIWPA.
 * Note that if the pppFunc is GCL_WIFI_WPA_FUNC_SOCKET_CONNECT, GCL_WIFI_WPA_FUNC_SOCKET_SEND
 * or GCL_WIFI_WPA_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclWifiWpaComErrorInfo_st gclWifiWpaErrorInfo_t;

/**
 * store the information of the last error occurred in the gclWIFIWPA.
 * Note that if the pppFunc is GCL_WIFI_WPA_FUNC_SOCKET_CONNECT, GCL_WIFI_WPA_FUNC_SOCKET_SEND
 * or GCL_WIFI_WPA_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclWifiWpaComErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_WIFI_WPA_FUNC_XXX defines
	 */
	uint16 wifiFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclWifiWpaErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a WIFI WPA error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclWifiWpaGetLastErrorInfo(gclWifiWpaErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclWifiWpaGetLastErrorInfo
 */
void gclWifiWpaSerrorReset(void);

/**
 * \brief Structure with the WiFi configuration
 */
typedef struct
{
	uint8    connectionId;  //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ////////////////////////socket
   char     *ipAddress;    //!< IP address in dotted decimal notation
   char     *tcpPort;      //!< TCP port in decimal notation
   char     *hostName;     //!< host name if IP not provided, will use DNS to get the IP
   ////////////////////////dhcp
   uint8    useDhcp;       //!< if one the DHCP will be used to retrieve the local configuration
   char     *dhcpHostName; //!< the name to send to the DHCP server
   uint32   leaseTime;     //!< suggested lease time (0xFFFFFFFF to don't use this option)
                           //!< (0 for default value = 180 seconds)
   // to set if no DHCP
   char     *defaultLocalIpAddress; //!< Local IP address if DHCP not used
   char     *defaultDefGateway;     //!< IP address of the gateway
   char     *defaultDns1IpAddress;  //!< IP address of the DNS server one
   char     *defaultDns2IpAddress;  //!< IP address of the DNS server two
   char     *domainName;            //!< domain name
   
   

	//Wifi specific
	char *ssid; //!< SSID of the access point
	/**
	 * 0-> do not scan this ssid with specific Probe Request Frames (default).
	 * 1-> scan with SSID specific Probe request frames. (This can be used to find APs that
	 * do not accept broadcast SSID or use multiple SSIDs; this will add latency to acanning,
	 * so enable this only when needed).
	 */
	uint8 scanSsid;
	/**
	 * ored combinations of the following values
	 * - 0 -> OS default: GCL_WIFI_PROTO_WPA + GCL_WIFI_PROTO_RSN 
	 * - GCL_WIFI_PROTO_WPA -> WPA/IEEE 802.11i/D3.0
	 * - GCL_WIFI_PROTO_RSN -> WPA2/IEEE 802.11i
	 */
	uint8 proto;
	/**
	 * one of the following values:
	 * - 0 -> OS default, GCL_WIFI_KMGM_WPA_PSK + GCL_WIFI_KMGM_WPA_EAP  
	 * - GCL_WIFI_KMGM_WPA_PSK
	 * - GCL_WIFI_KMGM_WPA_EAP
	 * - GCL_WIFI_KMGM_IEEE8021X
	 */
	uint8 keyMgmt;
	/**
	 * One of the following values:
	 * - 0: OS default (automatic selection, Open system with leap enabled if leap is
	 * allowed as one of the EAP methods).
	 * - GCL_WIFI_AUTH_OPEN: Open System Authentication (required for WPA/WPA2)
	 * - GCL_WIFI_AUTH_SHARED: Shared key authentication (required WEP keys)
	 * - GCL_WIFI_AUTH_LEAP: LEAP/network EAP (only used with LEAP)
	 */
	uint8 authAlg;
	/**
	 * One or ored combination of the following defines/values:
	 * 
	 * - 0: OS default (CCMP or TKIP)
	 * - GCL_WIFI_PAIR_CCMP: CCMP=AES in counter mode with CBC-MAC
	 * - GCL_WIFI_PAIR_TKIP: TKIP=Temporal Key Integrity Protocol
	 * - GCL_WIFI_PAIR_NONE: Use only group keys, deprecated, should not be
	 * used if APs support pairwise keys.
	 */
	uint8 pairwise;
	
	/**
	 * One of the options accept by \ref pairwise. 
	 */
	uint8 group;
	
	/**
	 * The key to be used in the WPA-PSK mode (\ref keyMgmt).
	 * Can be a 64 hex-digits (32 bytes) or a passphrase from 8 to 
	 * 63 caracters (inclusive).
	 */
	char *psk;
	
	/**
	 * Ored of the following entries:
	 * - 0: OS default, all methods allowed
	 * - GCL_WIFI_EAP_MD5: EAP-MD5 (unsecure and does not generate keying material
	 *   cannot be used with WPA; to be used as a phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - GCL_WIFI_EAP_MSCHAPV2: EAP-MSCHAPV2 (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - GCL_WIFI_EAP_OTP: EAP-OTP (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - GCL_WIFI_EAP_PEAP: EAP-PEAP (with tunneled EAP authentication).
	 * - GCL_WIFI_EAP_GTC: EAP-GTC (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - GCL_WIFI_EAP_TLS: EAP-TLS (client and server certificate)
	 * - GCL_WIFI_EAP_TTLS: EAP-TTLC (with tunneled EAP or PAP/CHAP/MSCHAP/MSCHAPV2 authentication).
	 * 
	 * 
	 */
	uint16 eap;
	
	/**
	 * Identity string for eap, null or "" if not used
	 */
	char *identity;
	
	/**
	 * Anonymous identity string for EAP (to be used as the unencrypted 
	 * identity with EAP types that support different tunneled identity, e.g., 
	 * EAP-TTLS). 
	 * Null or "" if not used.
	 */
	char *anonymous_identity;
	/**
	 * password string for EAP
	 * 
	 * Null or "" if not used.
	 */
	char *password;
	/**
	 * Certificate file (PEM/DER). This file can be one or more trusted CA certificates. 
	 * If ca_cert was not included, server certificate will not be verified.
	 * 
	 * If the len(ca_cert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char *ca_cert;
	/**
	 * Client certificate file (PEM/PER).
	 * 
	 * If the len(client_cert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char *client_cert;
	/**
	 * Client private key (PEM/DER/PFX). When PKCS#12/PFX file (.p12 or .pfx)
	 * is used, \ref client_cert should be not used, as the client certificate will
	 * be readed together with the *private_key.
	 * 
	 * If the len(ca_cert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char *private_key;
	/**
	 * password for the \ref private_key
	 */
	char *private_key_password;
	
	/**
	 * Substring to be matched against the subject of the 
	 * authentication server certificate. If this
	 * string is set, the server certificate is only accepted 
	 * if it contains this string in the subject. The subject 
	 * string is in following format:
	 * 
	 * /C=US/ST=CA/L=San Francisco/CN=Test AS/emailAddress=as\@example.com
	 * 
	 * - Null or "" if not used.
	 */
	char *subject_match;
	/**
	 * Phase1 (outer authentication, i.e., TLS tunnel)
	 *  parameters (string with field-value pairs, e.g., 
	 * "peapver=0" or "peapver=1 peaplabel=1") 'peapver' 
	 * can be used to force which PEAP version (0 or 1) 
	 * is used. 'peaplabel=1' can be used to force new 
	 * label, "client PEAP encryption", to be used during key 
	 * derivation when PEAPv1 or newer. Most existing PEAPv1 
	 * implementation seem to be using the old label, "client EAP encryption",
	 *  and wpa_supplicant is now using that as the default value.
	 * 'peap_outer_success=0' can be used to terminate PEAP authentication on tunneled EAPSuccess.
	 * This is required with some RADIUS servers that implement draft-josefsson-pppexteap-
	 * tls-eap-05.txt (e.g.,Lucent NavisRadius v4.4.0 with PEAP in "IETF Draft 5" mode)
	 * include_tls_length=1 can be used to force wpa_supplicant to include TLS Message Length
	 * field in all TLS messages even if they are not fragmented. sim_min_num_chal=3 can be used
	 * to configure EAP-SIM to require three challenges (by default, it accepts 2 or 3)
	 * 
	 * - Null or "" if not used.
	 */
	char *phase1;
	/**
	 * Phase2 (inner authentication with TLS tunnel) parameters (string with field-value pairs, e.g.,
	 * "auth=MSCHAPV2" for EAP-PEAP or "autheap=MSCHAPV2 autheap=MD5" for EAPTTLS)
	 * Following certificate/private key fields are used in inner Phase2 authentication when using
	 * EAP-TTLS or EAP-PEAP.
	 * 
	 * - Null or "" if not used.
	 */
	char *phase2;
	/**
	 * CA certificate file. This file can have one or more trusted CA certificates. If ca_cert2 is not
	 * included, server certificate will not be verified. This is insecure and the CA file should always
	 * be configured
	 * 
	 * If the len(ca_cert2) < 32, the entry will be treated as a file name and the
	 * ca_cert2 will be readed from this file.
	 
	 * - Null or "" if not used.
	 */
	char *ca_cert2;
	/**
	 * Client certificate file. To be used in phase2 authentication if required.
	 * 
	 * If the len(client_cert2) < 32, the entry will be treated as a file name and the
	 * client_cert2 will be readed from this file.
	 * 
	 * - Null or "" if not used.
	 */
	char *client_cert2;
	/**
	 * Client private key. To be used in the phase2 authentication process if required
	 *
	 * If the len(private_key2) < 32, the entry will be treated as a file name and the
	 * private_key2 will be readed from this file.
	 * 
	 * - Null or "" if not used.
	 */
	char *private_key2;
	/**
	 * password for the \ref private_key2
	 * 
	 * - Null or "" if not used.
	 */
	char *private_key2_passwd;
	/**
	 * Substring to be matched against the subject of the authentication server certificate in phase2.
	 * see \ref subject_match.
	 * 
	 * - Null or "" if not used.
	 */
	char *subject_match2;
		
	////////////////////////
   uint8    retries; //!< connection attempts = retries + 1
   ////////////////////////
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection
   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
}gclWiFiWpa_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific WiFiWpa configuration
 */
typedef struct
{
	/////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!< specific socket configuration
   /////////////////////////////////////////////////////////////////////////////
   netNi_t           ni; //!< the handle of the LNET
   /////
   netNiConfig_t     config; //!< Lnet configuration struct
   //
   uint8    useDhcp; //!< if DHCP will be used
   char     dhcpHostName[GCL_MAX_HOST_NAME + 1]; //!< host name of the DHCP server
   char     domainName[GCL_MAX_HOST_NAME + 1]; //!< dmain name
   /////
   uint32   ipAddressLocal; //!< local ip address
   /////
   uint32   defaultGateway;   //!< address of the default gateway
   uint32   dns1IpAddress;    //!< IP address of the DNS server one
   uint32   dns2IpAddress;    //!< IP address of the DNS server two
   uint8    currentSSID[GCL_MAX_SSID + 1]; //!< SSID of current connected access point
	///
	char wifiWpaStrCfg[4]; //!< wifi configuration string (variable size)
}gclWiFiWpaConfig_t;

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclWiFiWpaId(char *zcOut);

/**
 * This function will add an WIFI connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param WiFiConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclWiFiWpaSet(gclWiFiWpa_t *WiFiConfig, gclFunctionList_t *List,
                 uint32 userDataSize, void *userData);
                 
/**
 * this function has to be called by the preDial callback when the
 * connection type is WIFI WPA connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiWpaPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is WIFI WPA connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclWiFiWpaDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is WIFI WPA connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiWpaConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is WIFI WPA connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclWiFiWpaHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is WIFI WPA connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclWiFiWpaSend(gclConfig_t *gcl, uint8 *buffer, uint32 size);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is WIFI WEP connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclWiFiWpaReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size, uint32 maxsize);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


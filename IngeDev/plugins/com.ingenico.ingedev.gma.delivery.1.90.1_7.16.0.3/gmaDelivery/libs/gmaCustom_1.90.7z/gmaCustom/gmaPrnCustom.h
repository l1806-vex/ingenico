#ifndef GMA_PRN_CUSTOM_H_INCLUDED
#define GMA_PRN_CUSTOM_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


int16 gmaPrnPrintLine (char* line);
int16 gmaPrnLineFeed (uint8 numOfLines);

#ifdef __cplusplus
}
#endif


#endif

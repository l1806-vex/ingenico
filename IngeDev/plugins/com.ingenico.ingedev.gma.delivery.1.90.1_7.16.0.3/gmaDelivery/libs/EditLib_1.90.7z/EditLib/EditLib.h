/**
 * EditLib.h
 *
 * Data acquisition library.
 * 
 * TiagoTM, June, 22, 2004
 * Reginaldo Delfino, February, 18, 2005
 */

#ifndef EDIT_LIB_H
#define EDIT_LIB_H

#include <miltypes.h>

#ifdef __cplusplus
extern "C" {
#endif


/** @file editLib.h
 *
 * Library for help edition.
 */

#define EDT_OK             (RET_OK) /*!< return OK */

#define EDT_ERR_BASE       (-1)  /*!< edit lib error base */
#define EDT_ERR_CANCEL     (EDT_ERR_BASE)   /*!< the user has pressed the CANCEL key on the terminal */
#define EDT_ERR_TIMEOUT    (EDT_ERR_BASE-1) /*!< Timeout */
#define EDT_ERR_INVALID    (EDT_ERR_BASE-2) /*!< Invalid format */
#define EDT_ERR_INTERNAL   (EDT_ERR_BASE-3) /*!< Internal error */
#define EDT_ERR_ABORT      (EDT_ERR_BASE-4) /*!< The user calls the function \ref edtAbort */

/**
 * Editing direction (left-to-right or right-to-left).
 */
enum edtDirection_e {
   EDT_LEFT_TO_RIGHT, /*!< editing from left to right */
   EDT_RIGHT_TO_LEFT  /*!< editing from right to left */
};

/**
 * Alpha numeric editing mode
 */
enum edtAlphaMode_e {
   EDT_SPECIAL_KEY,  /*!< use a special key to signal alpha mode */
   EDT_FAST_TYPE     /*!< alpha mode comes from typping quickly the same key */
};

/**
 * Max editable length.
 */
#define EDT_MAX_LENGTH  (128)

/**
 * Structure with the parameters defining an editing instance.
 */
typedef struct edtParams_s edtParams_t;
/**
 * Structure with the parameters defining an editing instance.
 */
struct edtParams_s
{
   int16 x;             /*!< row of edit */
   int16 y;             /*!< column of edit */
   char *result;        /*!< where the edition result will be stored */
   /**
    * edition mask:
    * mask is:
    *
    * -  #: Digit (drawn if necessary)
    * -  0: Digit (always drawn)
    * -  A/a: Alphanumeric character (always drawn)
    * -  ?: Invert the �always draw� status of the following character.
    * -  *: Password character. Will be replaced on the screen by an asterisk.
    * - \\: The next character will be considered a literal, and not a macro.
    *
    *
    * To allow for arbitrary large inputs, this field does not have
    * a fixed length, instead it has a variable length and, as with 
    * all other GMA messages, its length must be a multiple of 32-bits 
    * (4 bytes).
    *
    * Mask examples:
    *
    * $ ##.###.##0,00
    * 
    * The above mask will show the following on the screen:
    * 
    * $   .   .  0,00
    * 
    * If you want to show the separators only if necessary, 
    * use the ? mask as following:
    * 
    * $ ##?.###?.##0,00
    * 
    * This mask will show:
    * 
    * $         0,00
    * 
    */
   const char *mask;
   uint16 minLength;    /*!< min length of resulting buffer */
   char whiteSpace;     /*!< char used as whitespace */
   enum edtDirection_e direction;   /*!< editing direction */
   uint32 timeout;      /*!< intra-char timeout */
   enum edtAlphaMode_e  alphaMode;   /*!< alpha mode (see edtAlphaMode_e) */
   uint32 alphaParam;   /*!< alpha timeout or special key */
   /**
    * Callback called when each key is pressed. Used to validate the key entry.
    * the first parameter is the edited string, the second parameter is the 
    * length of the string and the third parameter is the actual typed caracter.
    * 
    * If the callback function returns true the key is accepted, if the
    * function returns false the key is rejected and the terminal beeps to
    * warn the user.
    */
   uint8  (*edtCbFunction)(char*, uint16 , char);
   /**
    * If the value of this item is one than when you first press a key in the
    * edition process the result variable is erased. The idea is show the old value
    * in the begin, and when you press a key to start the edition process the
    * value is erased and you start the edition process as there is no previous value.
    * If the value of this item is 0 then no erase process happens
    */
   uint8 delWhenEditStart;
};

/**
 * edtEditMasked: Edit text using a mask
 * 
 * Edit text using a mask. This is the core function of EDT library.
 * 
 * @param hmiHandle: hmi display handle
 * @param touchHandle touch hmi handle 
 * @param params: user input params
 * 
 * @return RET_OK edition was successful
 * @return EDT_ERR_INVALID if the mask has problems 
 * @return EDT_ERR_INVALID if the result cannot be formatted according to the mask
 * @return EDT_ERR_TIMEOUT if the user doesn't type anything for param->timeout
 * @return EDT_ERR_CANCEL if the user has pressed the CANCEL key on the terminal
 * @return EDT_ERR_INTERNAL an internal error has occured
 * 
 */
int16 edtEditMasked(uint32 hmiHandle, uint32 touchHandle, edtParams_t *params);


/**
 * edtFormat: formats a text
 * 
 * @param mask: format mask
 * @param direction: alignment
 * 
 * @param source: string to be formatted
 * @param destination: where the formatted string will be placed
 * 
 * @return RET_OK edition was successful
 * @return EDT_ERR_INVALID if the mask has problems 
 * @return EDT_ERR_INVALID if the source cannot be formatted according to the mask
 * 
 */
int16 edtFormat(const char *mask, enum edtDirection_e direction, 
		char *source, char *destination);

/**
 * edtFormatParams: formats a text according to user input params
 * 
 * @param params: user input params
 * @param destination: where the formatted string will be placed
 * 
 * @return RET_OK successful
 * @return EDT_ERR_INVALID if the mask has problems 
 * @return EDT_ERR_INVALID if the source cannot be formatted according to the mask
 * 
 */
 int16 edtFormatParams(edtParams_t *params, char *destination);

/** 
 * Change the alpha-numeric substitution sequence.
 * "sequence" is an array of pointers for char (char*[]) each item
 * must be a zero-terminated string with the numeric key as the first item
 * and the alpha values following. The last item must be NULL.
 * The default is:
 *
 * char *edtSDefaultAlphaSequence[] = {
 *    "0 ",
 *    "1",
 *    "2ABC",
 *    "3DEF",
 *    "4GHI",
 *    "5JKL",
 *    "6MNO",
 *    "7PQRS",
 *    "8TUV",
 *    "9WXYZ",
 *    NULL
 * };
 *
 * If "sequence" == NULL will revert to the default.
 */
int16 edtSetAlphaSequence(const char **sequence);

/**
 * \ingroup D
 * Set the number maximum of column used in edition.
 * \param [in] u16MaxCol: number maximum of column
 * \return RET_OK             successful
 * \return EDT_ERR_INVALID    invalid parameter
 * 
 * 
 */
int16 edtSetMaxColumn (const uint16 u16MaxCol);

/**
 * \ingroup D
 * Enable or desenable the the beep error (default desenable)
 * \param [in] u8Ative:  TRUE - beep error enable /
 *         
 * \return RET_OK             successful
 * \return EDT_ERR_INVALID    invalid parameter
 */
int16 edtBeepErrorActive ( const uint8 u8Ative );

/**
 * Abort the edition process.
 */
int16 edtAbort (void);

#ifdef __cplusplus
}
#endif

#endif


#ifndef EDIT_LIB_TOUCH_H_INCLUDED
#define EDIT_LIB_TOUCH_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Init
 */

int16 edtDrawButtonsInit(uint16 posXbase, uint16 posYbase, uint32 hmiHandle);

/**
 * 
 */
int16 edtDrawButtonsTouch(void);

/**
 * 
 */
int16 edtCheckButtonPress(uint16 posX, uint16 posY);

#ifdef __cplusplus
}
#endif

#endif

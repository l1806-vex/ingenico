
#ifndef EDIT_LIB_TOUCH_DRAW_H_INCLUDED
#define EDIT_LIB_TOUCH_DRAW_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


typedef struct edtLibTouchEntry_st edtLibTouchEntry_t;

struct edtLibTouchEntry_st
{
	char key;
	uint8 font;
	uint8 width;
	uint8 height;
	
	int16 ret;
	uint16 posX;
	
	uint16 posY;
	
	uint8 *bitmap;
};

/**
 * 
 */
int16 edtDrawInit(uint32 hmiHandle);

/**
 * 
 */
int16 edtLibTouchDraw(edtLibTouchEntry_t *entry, uint8 entryNum);

/**
 * 
 */
int16 edtLibTouchGetTouch(uint16 x, uint16 y, edtLibTouchEntry_t *entry, uint8 entryNum);

#ifdef __cplusplus
}
#endif

#endif

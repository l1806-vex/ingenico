#ifndef GMA_CUSTOM_UTIL_H_INCLUDED
#define GMA_CUSTOM_UTIL_H_INCLUDED



#include "resources.h"
#include "gmaStrlcpy.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file gmaCustomUtil.h
 * 
 * Custom Lib utils
 */

/**
 * Terminal types
 */
typedef enum
{
   TERM_ERROR,
   TERM_5100,
   TERM_EAGLE,
   TERM_6550,
   TERM_8200,
   TERM_8500,
   TERM_8550,
   TERM_7910,
   TERM_6780,
   TERM_6770,
   TERM_3070,
   TERM_9530,
   TERM_UNKNOWN
} gmaUtilTermType;

#define GMA_UTIL_KEYBOARD_5100 (0)
#define GMA_UTIL_KEYBOARD_8200 (1)
#define GMA_UTIL_KEYBOARD_6550 (2)
#define GMA_UTIL_KEYBOARD_9530 (3)
#define GMA_NO_KEYBOARD        (10)


#define SLEEPMODE_TIMEOUT 1000


/**
 * Init the library, must be called prior to other
 * function from this library. This function will
 * open the hmi Handle to detect if the terminal
 * has a color screen. THere is no way to detect if the
 * terminal has touch screen without open the hmiHandle
 */
void gmaCustomUtilInit(void);

/**
 * Change the specific keys for this terminal
 */
void gmaCustomUtilSetSpecKeys(void);


/**
 * Check if there is a keyboard in the terminal
 */
uint8 gmaUtilHasKeyboard(void);

/**
 * Return the terminal type.
 *
 * one of the following values
 *
 * - TERM_5100
 * - TERM_EAGLE
 * - TERM_6550
 * - TERM_8200
 * - TERM_8500
 * - TERM_8550
 * - TERM_UNKNOWN
 */
gmaUtilTermType gmaUtilGetTermType(void);

/**
 * Terminal is color or no color
 */
uint8 gmaUtilTermColor(void);

/**
 * Get the keyboard type of the terminal
 */
uint32 gmaUtilGetKeyboardType(void);

/**
 * The terminal is touch screen
 */ 
uint8 gmaUtilTermTouchScreen(void);

/**
 * Check if the terminal will use big menu icon and big date time font
 */
uint8 gmaUtilUseBigFont(void);

/**
 * Get the display height in pixels
 */
uint16 gmaUtilGetDispHeight(void);

/**
 *Get the display width in pixels
 */
uint16 gmaUtilGetDispWidth(void);

/**
 * Get the display height in pixels (Reduction Calculated)
 */
uint16 gmaUtilGetDispHeightR(void);

/**
 *Get the display width in pixels (Reduction Calculated)
 */
uint16 gmaUtilGetDispWidthR(void);

/**
 * Get the width of the touch screen area
 */
uint16 gmaUtilGetTouchWidth(void);

/**
 * Get the height of the touch screen area
 */
uint16 gmaUtilGetTouchHeight(void);

/**
 * 
 */
uint8 gmaUtilStripeStatusGet(void);

/**
 * 
 */
uint8 gmaUtilStripeStatusSet(uint8 enabled);

/**
 * 
 */
uint8 gmaUtilReductionStatusGet(void);

/**
 * 
 */
uint8 gmaUtilReductionStatusSet(uint8 enable);

/**
 * 
 */
uint16 gmaUtilReductionSet(uint16 value);

/**
 * 
 */
uint16 gmaUtilReductionGet(void);

/**
 * Set the GMA resource language
 */
int16 gmaSetLanguage(uint16 language);

/**
 * Get a string in the GMA resource
 * Warning: This function is not re-entrant.
 *          DO NOT call this function as parameter more than one time or use 
 *          the result string after a second call.  
 */
char * gmaGetStringResource(uint16 id);

#ifdef __cplusplus
}
#endif


#endif


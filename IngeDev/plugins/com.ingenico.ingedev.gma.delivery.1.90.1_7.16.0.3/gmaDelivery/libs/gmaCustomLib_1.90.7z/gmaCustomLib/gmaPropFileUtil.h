
#ifndef GMA_PROP_FILE_UTILS_H_INCLUDED
#define GMA_PROP_FILE_UTILS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

typedef void * gmaPropFileUtilHandle;

/**
 * Open the file
 * 
 * @param type -> 0 for read 1 for write
 */
int16 gmaPropFileUtilOpen(gmaPropFileUtilHandle *handle, char *fileName, uint8 type);

int16 gmaPropFileUtilClose(gmaPropFileUtilHandle handle);

int16 gmaPropFileUtilRead(gmaPropFileUtilHandle handle, uint8 *data, uint16 *size);

int16 gmaPropFileUtilWrite(gmaPropFileUtilHandle handle, uint8 *data, uint16 size);

#ifdef __cplusplus
}
#endif

#endif


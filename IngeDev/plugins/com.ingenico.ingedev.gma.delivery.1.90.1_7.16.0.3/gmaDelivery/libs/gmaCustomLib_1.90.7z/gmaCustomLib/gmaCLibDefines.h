
#ifndef GMA_CUSTOM_LIB_DEFINES_H_INCLUDED
#define GMA_CUSTOM_LIB_DEFINES_H_INCLUDED

// include from GMALIB

#include "gmaDefines.h"


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file gmaCLibDefines.h
 * 
 * Some structures to send information to the GMA
 * specific from the World custom implementation.
 */

#define GMA_STRUCT_CUSTOM_BASE (0x2000)

#define GMA_STRUCT_PG_CUS_TOUCH_ACTION (GMA_STRUCT_CUSTOM_BASE + 0) //!< struct to set a media data to be touchable
#define GMA_STRUCT_CUS_MENU_RESOURCE (GMA_STRUCT_CUSTOM_BASE + 1) //!< struct to inform the GMA if it will show the application menu resource.

/**
 * Used to inform that a touch region will simulate a key when pressed.
 */
#define GMA_KEY_ACTION_TOUCH_KEY       (10)


/**
 * Set a media data to be touchable
 */
typedef struct gmaStructCPGtouchAction_st gmaStructCPGtouchAction_t;

/**
 * Set a media data to be touchable
 */
struct gmaStructCPGtouchAction_st
{
	gmaStructHeader_t header; //!< struct header
	uint8 logicalId; //!< plugin Id of the plug-in that sends the message
	uint8 mediaId;   //!< mediaId Id of the media to set the action
	/**
	 * which action to take when the icon is touched. The action can be:
	 * - GMA_KEY_ACTION_FUNCTION: In this case the function will be set by the paramenter entry,
	 * the following parameters are supported in this case: GMA_KEY_FUNC_MENU, GMA_KEY_FUNC_PAPER_FEED,
	 * GMA_KEY_FUNC_TECHNICAL.
	 * - GMA_KEY_ACTION_NOTIFY: In this case a key pressed notification message will be sent
	 *  to the plug-in that send the mediaId touched. The parameter will be the key value send in the message.
	 * 
	 */
	uint16 action; 
	uint16 parameter; //!< parameter, see the action documentation
};

/**
 * Structure send to the GMA in a application reply message to 
 * set the GMA to uses the menu resource of the application
 * when the application menu is selected.
 */
typedef struct gmaStructCmenuResourse_st gmaStructCmenuResourse_t;

/**
 * Structure send to the GMA in a application reply message to 
 * set the GMA to uses the menu resource of the application
 * when the application menu is selected.
 */
struct gmaStructCmenuResourse_st
{
	gmaStructHeader_t header; //!< struct header
	uint8 logicalId;          //!< logicalId of the application, or 0 for all logical applications from the physical application
	uint8 useResMenu;         //!< 1-> resource menu will be used. 0-> resource menu will not be used.
	uint16 rfu;
};


#ifdef __cplusplus
}
#endif

#endif


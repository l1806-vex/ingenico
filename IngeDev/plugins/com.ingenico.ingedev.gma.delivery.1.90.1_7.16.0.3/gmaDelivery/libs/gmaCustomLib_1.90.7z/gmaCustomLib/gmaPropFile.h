
#ifndef GMA_PROP_FILE_H_INCLUDED
#define GMA_PROP_FILE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

typedef void * gmaPropHandle;

#define GMA_PROP_FILE_OPEN_ERROR (-1)
#define GMA_PROP_FILE_CORRUPTED (-2)
#define GMA_PROP_FILE_ITEM_NOT_FOUND (-3)
#define GMA_PROP_NO_RESOURCE       (-4)
#define GMA_PROP_NO_MORE_ITEMS     (-5)

/**
 * Library Initializitation
 */
int16 gmaPropOpInit(void);

/**
 * Open a file and prepare the library to read or save informations on this file...
 * The file will be only trully resaved when you call the \ref gmaPropFileUpdate or
 * close the file with the function \ref gmaPropClose
 * 
 * @param fileName the name of the properties file
 * 
 * @param handle a pointer to received the handle to the openned file
 * 
 * @return RET_OK open the file without problems
 * 
 * @return GMA_PROP_FILE_OPEN_ERROR error openning the file, you need
 * to call the \ref gmaPropClose to close the propHandle. The reason
 * for this error can be file non existent, in this case you can 
 * call the functions gmaPropWrite and then save to create the file
 * 
 * @return GMA_PROP_FILE_CORRUPTED file corrupted
 */
int16 gmaPropOpen(char *fileName, gmaPropHandle *handle);

/**
 * read an entry in the properties file.
 * 
 * @param handle the handle of the property file get from the function \ref gmaPropOpen
 * @param itemName the property item to be readed
 * @param data a pointer to a buffer to receive the parameter
 * 
 * @return RET_OK
 * @return GMA_PROP_FILE_ITEM_NOT_FOUND the itemName doesn't exist in the property file
 */
int16 gmaPropRead(gmaPropHandle handle, char *itemName, char **data); 

/**
 * Used to retrieve the list of itemNames in the file
 * you need to call this function first with Init equal 1 to get the
 * first itemName and then call the function with Init equal 0 until get all
 * the itemNames.
 * 
 * @param handle the handle of the property file get from the function \ref gmaPropOpen
 * 
 * @param Init if 1 indicated that you will get the first key, for get the rest use 0
 * 
 * @param itemName a pointer to a pointer that will point to the itemName
 * 
 * @return RET_OK
 * 
 * @return GMA_PROP_NO_MORE_ITEMS no more available items
 */
int16 gmaPropFileGetItems(gmaPropHandle handle, uint8 Init, char **itemName);

/**
 * Write or change an entry in the property file (not in the file itself, only in memory,
 * need to call \ref gmaPropFileSave to update the file)
 * 
 * @param handle the handle of the property file get from the function \ref gmaPropOpen
 * 
 * @param itemName the property item to be added/changed
 * 
 * @param data the item data to be changed or added
 * 
 * @return RET_OK
 */
int16 gmaPropWrite(gmaPropHandle handle, char *itemName, char *data);

/**
 * Force the file to be updated with the memory contents
 */
int16 gmaPropFileSave(gmaPropHandle handle);

/**
 * Make a file update with the memory contents and close the file
 */
int16 gmaPropClose(gmaPropHandle handle);

#ifdef __cplusplus
}
#endif

#endif

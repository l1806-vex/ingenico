#ifndef GMA_CUSTOM_DISPLAY_H_INCLUDED
#define GMA_CUSTOM_DISPLAY_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaCustomDisp.h
 * 
 * Functions to open and close the HMI and touch handles
 * 
 */ 

/**
 * Closes the HMI and touch handle
 */
void gmaCusCloseHmiHandle(void);

/**
 * Opens the HMI and touch handles
 */
void gmaCusOpenHmiHandle(void);

/**
 * Configures the HMI_INPUT_CONFIG_KEYCLICK_ENABLED in a encapsulated way to
 * allow it's calling in the case of the Custom hmi is already opened.
 */
void gmaCusConfig(void);

/**
 * returns the HMI handle
 */
uint32 gmaCusGetHmiHandle(void);

/**
 * returns the touch handle
 */
uint32 gmaCusGetTouchHandle(void);

/**
 * Set the HMI handle when the application
 * already has the handle
 */
void gmaCusSetHmiHandle(uint32 hmiHandleValue);

/**
 * Set the touch handle when the application
 * already has the handle
 */
void gmaCusSetTouchHandle(uint32 touchHandleValue);

/**
 * Get the Canvas and the GC of the HMI
 */
void gmaCusGetCanvas(Canvas **pCv, GC **pGc);

/**
 * Get the beep status from the message.
 * The GMA sends to the plug-ins the status of
 * the beep (Active or not).
 */
void gmaCusDecodeBeepStatus(amgMsg_t *msg);

/**
 * 
 */
void gmaCusSetBeepStatus(uint8 bs);


#ifdef __cplusplus
}
#endif

#endif


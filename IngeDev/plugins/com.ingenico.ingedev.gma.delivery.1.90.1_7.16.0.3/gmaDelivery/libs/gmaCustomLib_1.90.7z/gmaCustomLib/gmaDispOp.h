
#ifndef GMA_DISP_OP_H_INCLUDED
#define GMA_DISP_OP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaDispOp.h
 * 
 * Functions to change the actual optic font to be used.
 */

/**
 * Set the font to be used in following optic calls
 */
int16 gmaDopSetFontNum(GC *gc, uint8 fontNum);

/**
 * Set the font to be used in following optic calls 
 */
int16 gmaDopSetFont(GC *gc, const void *newFont);

#ifdef __cplusplus
}
#endif


#endif


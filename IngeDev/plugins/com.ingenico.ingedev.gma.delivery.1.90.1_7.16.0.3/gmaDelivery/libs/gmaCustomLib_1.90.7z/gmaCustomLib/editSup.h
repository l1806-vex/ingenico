
#ifndef EDITSUP_H_INCLUDED
#define EDITSUP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file editsup.h
 * Functions to show menus and help the edit process.
 */

#define MNUSTS_DATA_NUM_DATA       (1) //!< numeric edition
#define MNUSTS_DATA_STR            (2) //!< string edition
#define MNUSTS_DATA_IP             (3) //!< IP address data edition
#define MNUSTS_DATA_TIME           (4) //!< TIME edition
#define MNUSTS_DATA_DATE           (5) //!< DATE edition
#define MNUSTS_DATA_NUM_STR        (6) //!< string with numerals only
#define MNUSTS_DATA_STR_NO_DEL     (7) //!< string edition, but field not entirely deleted
#define MNUSTS_DATA_PSWD           (8) //!< password edition
#define MNUSTS_DATA_NUM_STR_NO_DEL (9) //!< string edition with numerals only, but field not entirely deleted

#define MNUSTS_REASON_DISPLAY (0) //!< the reason for calling is actualize the item for display
#define MNUSTS_REASON_EDIT    (1) //!< the reason is the item was edited
#define MNUSTS_REASON_COND    (2) //!< the reason is check pre-conditions



/**
 * Option edit struct used in the numeric edition
 * when you want to show to the user a list of options.
 * Normally you make a vector of this items with the
 * last one with a null msg pointer
 */ 
typedef struct mnustsEdtOption_st mnustsEdtOption_t;

/**
 * Edit configuration entry
 */
typedef struct mnustsEditSts_st mnustsEditSts_t;

/**
 * Option edit struct used in the numeric edition
 * when you want to show to the user a list of options.
 * Normally you make a vector of this items with the
 * last one with a null msg pointer
 */ 
struct mnustsEdtOption_st
{
   char *msg; //!< option text
   uint32 value; //!< numeric value associated with this item
};

/**
 * Edit configuration entry
 */
struct mnustsEditSts_st
{
   void *data; //!< a poiter to the data that will be edited
   /**
    * Type of the data, can be:
    * - \ref MNUSTS_DATA_NUM_DATA
    * - \ref MNUSTS_DATA_STR
    * - \ref MNUSTS_DATA_IP
    * - \ref MNUSTS_DATA_TIME
    * - \ref MNUSTS_DATA_DATE
    */
   const uint8 dataType;
   /**
    * sizeof of the item pointed by \ref data
    */
   const uint8 size;
   /**
    * Text to be shown in the edit string
    */
   const char *msg;
   /**
    * If the dataType is MNUSTS_DATA_NUM_DATA a list of
    * options can be shown instead of a numeric entry.
    * The opt field will point to a vector of \ref mnustsEdtOption_t structures
    * if the list of options is desired. If not used put NULL in the opt field.
    * As said, this item works only if the dataType is MNUSTS_DATA_NUM_DATA.
    */
   const mnustsEdtOption_t *opt;
   /**
    * Callback function to be called before shown the item to
    * actualize the value if necessary, and after the edition to 
    * save the value 
    * If not necessary put NULL
    */
   int16 (*cbActualize)(uint8 reason, const mnustsEditSts_t *edtItem);
};

/**
 * Return the value of the edit item when the item is numeric
 */
uint32 mnustsGetValueFromItem(const mnustsEditSts_t *edtItem);


/**
 * Start an edit screen with a list of items pointed by edtData
 * 
 * @param edtData a poiter to a vector of items to be edited. The terminator
 * of the vector is a item will NULL elements.
 * @param hmiHandle the hmi handle previously open.
 */
int16 mnustsRunEdt(const mnustsEditSts_t *edtData, uint32 hmiHandle, uint32 touchHandle);


/**
 * Start the edition of a specific edit item pointed by edtData. This function
 * is called from the \ref mnustsRunEdt function.
 * 
 * @param edtData point to the edit item to be edited.
 * @param hmiHandle the hmi handle previously open.
 */
int16 mnustsEditItem(const mnustsEditSts_t *edtData, uint32 hmiHandle, uint32 touchHandle);

#ifdef __cplusplus
}
#endif


#endif

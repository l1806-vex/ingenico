
#ifndef GMA_PROP_FILE_PARSE_H_INCLUDE
#define GMA_PROP_FILE_PARSE_H_INCLUDE

#include "gmaPropFile.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*gmaParseFuncPtr)(uint8 mode, char *value, uint16 offset, uint8 size);
	
enum gmaParseValueType_en
{
	PARSE_NUMERIC_VALUE=1,
	PARSE_STRING_VALUE=2,
	CUSTOM_PARSE_VALUE=3
};

#define GMA_PARSE_MODE_WRITE (1)
#define GMA_PARSE_MODE_READ (2)

typedef enum gmaParseValueType_en gmaParseValueType_n;

typedef struct gmaPropParseDef_st gmaPropParseDef_t;

struct gmaPropParseDef_st
{
	char *itemName;
	uint16 offset;
	uint8 size;
	uint8 type;
	gmaParseFuncPtr func;
};

int16 gmaParseFillStruct(gmaPropParseDef_t *def, gmaPropHandle handle, void *ptr);
	
int16 gmaParseReadStruct(gmaPropParseDef_t *def, gmaPropHandle handle, void *ptr);
	
uint32 gmaParseGetValue(void *ptr, uint16 offset, uint8 size);

void gmaParseSetValue(void *ptr, uint16 offset, uint8 size, uint32 value);


#ifdef __cplusplus
}
#endif


#endif


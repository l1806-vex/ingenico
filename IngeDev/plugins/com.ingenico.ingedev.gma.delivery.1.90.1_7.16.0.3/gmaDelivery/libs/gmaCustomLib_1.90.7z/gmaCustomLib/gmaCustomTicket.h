#ifndef GMA_CUSTOM_TICKET_H_INCLUDED
#define GMA_CUSTOM_TICKET_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaCustomTicket.h
 * 
 * Functions to display a ticket (and print it latter).
 * @author TiagoTM
 */

#include <miltypes.h>
 
/**
 * Begin the composition of the ticket.
 */
int16 ticketBegin(void);

/** Modes for each line of the ticket */
enum ticketMode_t
{
   TICKET_MODE_NORMAL,        /**< Regular line. */
   TICKET_MODE_TITLE,         /**< Title line. */
   TICKET_MODE_SUBTITLE,      /**< Sub-title. */
   TICKET_MODE_SEPARATOR      /**< Separator */
};

/**
 * Maximum number of chars that can be allocated in a ticket.
 */
#define TICKET_MAX_SIZE       (2048)

/**
 * Maximum number of lines of a ticket.
 */
#define TICKET_MAX_LINES      (50)

/**
 * Same as ticketBoth(TICKET_MODE_SEPARATOR, NULL).
 */
int16 ticketSeparator(void);

/**
 * Same as ticketBoth(TICKET_MODE_NORMAL, NULL).
 */
int16 ticketBlankLine(void);

/**
 * Add a line to the printer ticket.
 * 
 * @param mode Line mode. See \ref ticketMode_t
 * @param text The text to add for this line.
 */
int16 ticketPrinter(enum ticketMode_t mode, const char *text);

/**
 * Add a line to the display ticket.
 * 
 * @param mode Line mode. See \ref ticketMode_t
 * @param text The text to add for this line.
 */
int16 ticketDisplay(enum ticketMode_t mode, const char *text);

/**
 * Add a line to both display and printer tickets.
 * 
 * @param mode Line mode. See \ref ticketMode_t
 * @param text The text to add for this line.
 */
int16 ticketBoth(enum ticketMode_t mode, const char *text);

/**
 * Show the ticket.
 * After this function no more calls to ticketPrint() will be accepted.
 */
int16 ticketRun(void);

/**
 * 
 */
int16 gmaCusPrnPrintLine (char* line);

/**
 * @note All the style parameters can be zero to use the default.
 * 
 * @param szLine Pointer to string to be printed.
 * @param size Font size to use (PRN_SEQ_DWIDTH, PRN_SEQ_DOUBLE, etc).
 * @param style Font style (PRN_SEQ_ITALIC, PRN_SEQ_BOLD).
 * @param align Alignment (PRN_SEQ_CENTRE, PRN_SEQ_RIGHT).
 */
int16 gmaCusPrint(const char * szLine, uint8 size, uint8 style, uint8 align);

#ifdef __cplusplus
}
#endif


#endif


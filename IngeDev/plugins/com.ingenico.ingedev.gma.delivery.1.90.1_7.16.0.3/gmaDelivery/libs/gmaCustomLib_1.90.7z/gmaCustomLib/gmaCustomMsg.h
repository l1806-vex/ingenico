
#ifndef GMA_CUSTOM_MESSAGE_H_INCLUDED
#define GMA_CUSTOM_MESSAGE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaCustomMsg.h
 * 
 * Some function to send information to the GMA
 * specific from the World custom implementation.
 */

/**
 * Set a mediadata to be touchable
 * 
 * @param pluginId the plugin that call this function
 * 
 * @param mediaId the id of the media to be touchable
 * @param action the action to be take when the media is touched.
 * The action can have the following values: 
 * - GMA_KEY_ACTION_FUNCTION: In this case the function will be set by the paramenter entry,
 * the following parameters are supported in this case: GMA_KEY_FUNC_MENU, GMA_KEY_FUNC_PAPER_FEED,
 * GMA_KEY_FUNC_TECHNICAL.
 * - GMA_KEY_ACTION_NOTIFY: In this case a key pressed notification message will be sent
 *  to the plug-in that send the mediaId touched. The parameter will be the key value send in the message.
 * 
 * - GMA_KEY_ACTION_TOUCH_KEY: In this case the GMA will simulate a key press. The code of the key is in the parameter
 * 
 * If the action value is zero, than the icon will not react for a touch anymore.
 * 
 * @param parameter the parameter, see the action documentation
 */
int16 gmaCstMsgSendTouchAction(uint8 pluginId, uint8 mediaId, 
                               uint16 action, uint16 parameter);


/**
 * Set the GMA to uses the menu resource of the application
 * when the application menu is selected. The resource menu 
 * items will be shown depending on the logicalId of the 
 * applications. If the logicalId of the logical application is 0 or 0xFF
 * all the menus items will be shown.
 * note that if in the answer to the power on, you don't call
 * the function \ref gmaMsgAddLogicalAppInfo, an logical
 * application will be automatically created with logicalId equals
 * 0xFF.
 * If the logical Id is different from 0 and 0xFF the menu items with the
 * id in the range
 * between (logicalId-1)*100 to logicalId*100 will be shown. <br>
 * When the GMA manages the menu of the application and if the application
 * is set as the startup application through the settings plugin, then
 * at startup the application is activated as if the menu with item #0 was
 * selected. Therefore, when writing the application menu it is advised to
 * set the ID considered as the "default" one to the value 0. 
 * 
 * @param logicalId the logical Id. 0 or 0xFF (0xFF for GMA from version 1.64) for all logical 
 * applications in the current physical application
 * @param status 1-> the GMA will use the resource menu of the application. 0-> not use the resource menu
 */
int16 gmaCstMsgResourceMenuStatus(uint8 logicalId, uint8 status);

#ifdef __cplusplus
}
#endif


#endif


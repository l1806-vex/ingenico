
#ifndef MENUSUP_H_INCLUDED
#define MENUSUP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file menusup.h
 * Functions to show menus and help the edit process.
 */

/**
 * Structure to hold a menu configuration.
 */
typedef struct gsmstsMenuStruct_st gsmstsMenuStruct_t;

/**
 * Structure to hold the menu item configuration
 * If the menu item is selected in the menu, two actions
 * are possible, show a sub menu pointed by subMenu or
 * call a function pointed by funcPtr. The decision is
 * make looking which of the pointers are valid (not NULL).
 */
typedef struct gsmstsMenuItens_st  gsmstsMenuItens_t;

/**
 * Structure to hold a menu configuration.
 */
struct gsmstsMenuStruct_st
{
   char *menuTitle; //!< the menu title
   /**
    * a pointer to a vector of menu items data.
    * The last item data should have NULL fields
    */
   const gsmstsMenuItens_t *itens; 
   
} ;

/**
 * Structure to hold the menu item configuration
 * If the menu item is selected in the menu, two actions
 * are possible, show a sub menu pointed by subMenu or
 * call a function pointed by funcPtr. The decision is
 * make looking which of the pointers are valid (not NULL).
 */
struct gsmstsMenuItens_st
{
   char *itemStr; //!< menu item title
   /**
    * Function to be called when the item is selected, if this item is NULL
    * a sub menu pointed by \ref subMenu will be shown.
    */
   int16 (*funcPtr)(void);
   /**
    * Submenu to be shown when the item is selected, if this item is NULL a 
    * function pointed by \ref funcPtr will be shown
    */
   const gsmstsMenuStruct_t *subMenu;
};

/**
 * Set the hmiHandle to be used by the library. Used only in the menuLib version
 * Not in the LAF library version.
 * Check the version of the library been used.
 * 
 * @param _hmiHandle the handle to be used by the library
 */
void mnustsSetHmiHandle(uint32 _hmiHandle, uint32 touchHandle);

/**
 * show a menu with a configuration defined in the menu item.
 * 
 * @param menu the configuration of the menu to be shown
 */
int16 rmMenuRunMenu(const gsmstsMenuStruct_t *menu);

/**
 * This function must be called prior to the other functions of this module
 * to initialize internal variables with the screen size.
 */
int16 mnustsIdentifyTerminal(void);

/**
 * Get the display width
 */
uint16 mnustsGetDisplayWidth(void);

/**
 * Get the number of lines in the display
 */
uint8 mnustsGetNlines(void);

#ifdef __cplusplus
}
#endif


#endif

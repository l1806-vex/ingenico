
/**************************************************************************
                              Property of INGENICO
 *************************************************************************/
/*+
 *  PROJECT        :    GCLV2 (GCMV2)
 *  MODULE         :    GCL_PPP
 *  FILEMANE       :    gcl_PPPOE.h
 *  PURPOSE        :
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  2005-05-19   RRB        creation
 *
 * ------------------------------------------------------------------------
 *  DESCRIPTION    :    PPP over PSTN communication library for GCL
 *
-*/

#ifndef GCL_PPPOE_H_INCLUDED
#define GCL_PPPOE_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_PPPOE.h
 *
 *
 */

/**
 * \addtogroup PPP_ PPP
 *
 * @{
 */


/**
 * \addtogroup PPPOE_ PPP over ethernet communication
 *
 * A PPP connection over the Ethernet.
 *
 * @{
 */


#define GCL_PPPOE_FUNC_netNiOpen         (1)
#define GCL_PPPOE_FUNC_netCfgIdentify    (2)
#define GCL_PPPOE_FUNC_CHANNEL_NOT_FOUND (3)
#define GCL_PPPOE_FUNC_netNiConfigSet    (4)
#define GCL_PPPOE_FUNC_netNiStart        (5)
#define GCL_PPPOE_FUNC_netNiConfigGet    (6)
#define GCL_PPPOE_FUNC_dnsGetHostByName  (7)
#define GCL_PPPOE_FUNC_SOCKET_CONNECT    (40)
#define GCL_PPPOE_FUNC_SOCKET_SEND       (41)
#define GCL_PPPOE_FUNC_SOCKET_RECEIVE    (42)

/**
 * store the information of the last error occurred in the gclPPPOE.
 * Note that if the pppFunc is GCL_PPP_OE_FUNC_SOCKET_CONNECT, GCL_PPP_OE_FUNC_SOCKET_SEND
 * or GCL_PPP_OE_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclPPPOEErrorInfo_st gclPPPOEErrorInfo_t;

/**
 * store the information of the last error occurred in the gclPPPOE.
 * Note that if the pppFunc is GCL_PPP_OE_FUNC_SOCKET_CONNECT, GCL_PPP_OE_FUNC_SOCKET_SEND
 * or GCL_PPP_OE_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclPPPOEErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_PPPOE_FUNC_XXX defines
	 */
	uint16 pppFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclPPPOEErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclPPPOEGetLastErrorInfo(gclPPPOEErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclPPPOEGetLastErrorInfo
 */
void gclPPPOESerrorReset(void);

/**
 * \brief Structure with the GSM configuration
 */
typedef struct
{
   uint8    connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ////////////////////////
   //
   uint32   lcpFlags; //!< defines the LCP configuration, see the LNET documentation for more details.
   //
   char     *loginName; //!< login name for the PPP authentication
   char     *password; //!< password for PPP authentication
   // socket connection
   char     *ipAddress; //!< IP address of the host
   char     *tcpPort; //!< port
   char     *hostName; //!< host name if IP address not provide
   //
   uint8    retries; //!< connection attempts = retries + 1
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication Timeout
   uint32   loginTimeout;        //!< login Timeout
   uint32   retryDelay;          //!< the delay before retying connection

   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
	/**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
} gclPPPOE_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific GPRS configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!<  socket configuration, IP, port, etc...
   /////////////////////////////////////////////////////////////////////////////
   gclPPPNi_t        PPPNi; //!< LNET configuration data

   char              rfu[50]; //!< RFU

} gclPPPOEConfig_t;

/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclPPPOEId(char *zcOut);


/**
 * This function will add an PPPOE connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param PPPOEConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclPPPOESet(gclPPPOE_t *PPPOEConfig, gclFunctionList_t *List,
                  uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPOEPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclPPPOEDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPOEConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPOEHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclPPPOESend(gclConfig_t *gcl, uint8 *buffer, uint32 size);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is PPPOE connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclPPPOEReceive(gclConfig_t *gcl, uint8 *buffer,
                      uint32 *size, uint32 maxsize);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif

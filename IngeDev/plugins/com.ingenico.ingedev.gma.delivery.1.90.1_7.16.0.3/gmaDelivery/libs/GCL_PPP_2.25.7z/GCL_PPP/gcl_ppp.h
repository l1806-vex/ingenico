
/**************************************************************************
                              Property of INGENICO
 *************************************************************************/
/*+
 *  PROJECT        :    GCLV2 (GCMV2)
 *  MODULE         :    GCL_PPP
 *  FILEMANE       :    gcl_ppp.h
 *  PURPOSE        :
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  2005-05-19   RRB        creation
 *
 * ------------------------------------------------------------------------
 *  DESCRIPTION    :    PPP over PSTN communication library for GCL
 *
-*/

#ifndef GCL_PPP_H_INCLUDED
#define GCL_PPP_H_INCLUDED

#include "gcl.h"
#include "gcl_ppp.h"
#include <LNetSocket.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_PPP.h
 *
 *
 */

/**
 * \addtogroup PPP_ PPP
 *
 * @{
 */


/**
 * \addtogroup PPPOM_ PPP over modem communication
 *
 * a PPP connection over an asynchronous modem connection.
 *
 * @{
 */

#define GCL_PPP_FUNC_comCfgAccess1         (1)
#define GCL_PPP_FUNC_comCfgAccess2         (2)
#define GCL_PPP_FUNC_comOpen               (3)
#define GCL_PPP_FUNC_comSetModemParameters (4)
#define GCL_PPP_FUNC_comClose              (5)
#define GCL_PPP_FUNC_netNiOpen             (6)
#define GCL_PPP_FUNC_netCfgIdentify        (7)
#define GCL_PPP_FUNC_CHANNEL_NOT_FOUND     (8)
#define GCL_PPP_FUNC_netNiConfigSet        (9)
#define GCL_PPP_FUNC_netNiStart            (10)
#define GCL_PPP_FUNC_netNiConfigGet        (11)
#define GCL_PPP_FUNC_dnsGetHostByName      (12)
#define GCL_PPP_FUNC_SOCKET_CONNECT        (40)
#define GCL_PPP_FUNC_SOCKET_SEND           (41)
#define GCL_PPP_FUNC_SOCKET_RECEIVE        (42)


/**
 * store the information of the last error occurred in the gclPPP.
 * Note that if the pppFunc is GCL_PPP_FUNC_SOCKET_CONNECT, GCL_PPP_FUNC_SOCKET_SEND
 * or GCL_PPP_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclPPPErrorInfo_st gclPPPErrorInfo_t;

/**
 * store the information of the last error occurred in the gclPPP.
 * Note that if the pppFunc is GCL_PPP_FUNC_SOCKET_CONNECT, GCL_PPP_FUNC_SOCKET_SEND
 * or GCL_PPP_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclPPPErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_PPP_FUNC_XXX defines
	 */
	uint16 pppFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclPPPErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclPPPGetLastErrorInfo(gclPPPErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclPPPGetLastErrorInfo
 */
void gclPPPSerrorReset(void);

/**
 * \brief Structure with the PPP over modem configuration
 */
typedef struct
{
   uint8    connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ////////////////////////
   char     *prefix; //!< preffix of the telephone
   char     *phoneNumber; //!< telephone number that will be dialed
   //
   uint8    detectLine; //!< if the line will be checked before dial
   uint8    detectDialTone; //!< if the dial tone will be checked before dial

   uint8    useToneDialing; //!< if use tone to dial

   enum comModemModulation_t AsyncModemType; //!< define the modem modulation, see the Unicapt documentation for more details
   enum comErrorCorrection_t errorCorrection; //!< define the error correction type, see the Unicapt documentation for more details
   enum comDataCompression_t dataCompression; //!< define the data compression type, see the Unicapt documentation for more details

   enum comT35_t             countryCode; //!< define the country code, see the Unicapt documentation for more details
   //
   uint32   lcpFlags; //!< defines the LCP configuration, see the LNET documentation for more details.
   //
   char     *loginName; //!< login name for the PPP authentication
   char     *password; //!< password for PPP authentication
   // socket connection
   char     *ipAddress; //!< IP address of the host
   char     *tcpPort; //!< port
   char     *hostName; //!< host name if IP address not provide
   //
   uint8    retries; //!< connection attempts = retries + 1
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication Timeout
   uint32   loginTimeout;        //!< login Timeout
   uint32   retryDelay;          //!< the delay before retying connection

   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
   /**
    * 
    */
   enum comBps_t              minBps;          /**< Minimum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/
   enum comBps_t              maxBps;          /**< Maximum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/

} gclPPP_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific PPP over modem configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t     cSock;//!<  socket configuration, IP, port, etc...
   /////////////////////////////////////////////////////////////////////////////
   gclPPPNi_t           PPPNi;//!< LNET configuration data
   /////////////////////////////////////////////////////////////////////////////
   char                 sDialNumber[GCL_MAX_PHONE_SIZE + 1]; //!< telephone number
   /////
   comModemParameter_t  modemParameters; //!< modem configuration parameters
   //* country code
   enum comT35_t        countryCode; //!< country code

   char                 rfu[50]; //!< RFU

} gclPPPConfig_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclPPPId(char *zcOut);

/**
 * This function will add an PPP over modem connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param PPPConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclPPPSet(gclPPP_t *PPPConfig, gclFunctionList_t *List,
                uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclPPPDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPHangUp(gclConfig_t* gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclPPPSend(gclConfig_t* gcl, uint8* buffer, uint32 size);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is PPP over modem connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclPPPReceive(gclConfig_t* gcl, uint8* buffer,
                    uint32* size, uint32 maxsize);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif

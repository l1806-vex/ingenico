#ifndef GCL_ERROR_H_INCLUDED
#define GCL_ERROR_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_error.h
 * GCL core error info functions
 * 
 */

/**
 * \addtogroup GCL_CORE  Core of the Gcl
 * 
 * @{
 */

/**
 * \addtogroup GCL_CORE_ERROR  Error info
 * 
 * @{
 * 
 * Callback functions for error information
 * 
 */

/**
 * callback definition to be called when an error occur inside the GCL library.
 * 
 * @param conType Connection type, for example GCL_SERIAL, GCL_PPP, GCL_GSM, etc...
 * 
 * @param pos function in which the error occur, see the include file of the connection
 *  in which the error happens.
 * 
 * @param ret the error returned by the function
 * 
 * @param ext1 extended information about the error. See the connection type documentation 
 * for more details
 * 
 * @param ext2 extended information about the error.  See the connection type documentation 
 * for more details
 */
typedef void (*gclErrorCB_t)(uint16 conType, uint16 pos, int16 ret, uint16 ext1, uint16 ext2);

/**
 * Set callback to be called when an error occur in any GCL library. For debug purpose
 * 
 * @param errorCb the callback to be called when an error occur in one of the GCL libraries. 
 */
void gclSetErrorCallback(gclErrorCB_t errorCb);

/**
 * Function used internally by the GCL to inform errors
 */
void gclErrorInformError(uint16 conType, uint16 pos, int16 ret, uint16 ext1, uint16 ext2);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

 
#endif


#ifndef _GLC_SOCKUTIL_H_INCLUDED
#define _GLC_SOCKUTIL_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file gcl_sockutil.h
 *
 *
 */

/**
 * \addtogroup SOCKUTIL_ Socket util functions
 *
 *
 * @{
 */

#define GCL_SOCK_UTIL_FUNC_SEND         (1)
#define GCL_SOCK_UTIL_FUNC_RECEIVE      (2)


#define GCL_SOCK_UTIL_FUNC_socket       (10)    
#define GCL_SOCK_UTIL_FUNC_connect      (11)
#define GCL_SOCK_UTIL_FUNC_setsockopt1  (12)
#define GCL_SOCK_UTIL_FUNC_setsockopt2  (13)
#define GCL_SOCK_UTIL_FUNC_setsockopt3  (14)

#define GCL_SOCK_UTIL_FUNC_psyTaskCreate   (100)
#define GCL_SOCK_UTIL_FUNC_psyEventReceive (101)

/**
 * store the information of the last error occurred in the gclPPP.
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclSockUtilErrorInfo_st gclSockUtilErrorInfo_t;

/**
 * store the information of the last error occurred in the gclSockutil module.
 */
struct gclSockUtilErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_PPP_FUNC_XXX defines
	 */
	uint16 sockFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
	/**
	 * Socket error if it applies.
	 */
	int socketError;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclSockUtilErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclSockUtilGetLastErrorInfo(gclSockUtilErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclSockUtilGetLastErrorInfo
 */
void gclSockUtilErrorReset(void);

/**
 * This function has to be called by the SEND callback if the connection type
 * is socket connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclSockUtilSend(gclConfig_t *gcl, uint8* buffer, uint32 size);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is socket connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclSockUtilReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size, uint32 maxsize);


/**
 * Function called by the connect callback. This function will create
 * the socket connection task and wait for this completion. It can
 * also be stopped by a call to gclStop.
 * 
 * @param gcl (I) the configuration of the connection
 * @param sockParams (I) the socket configuration
 */
int16 gclSocketConnectUtil(gclConfig_t *gcl, gclConnectSock_t *sockParams);

/**
 * Called to close the socket and wait for the socket connection
 * task to be killed.
 * 
 * @param gcl (I) the configuration of the connection 
 */
int16 gclSocketHangupUtil(gclConfig_t *gcl);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


/*
 *   Generic Communication Library
 *   INGENICO South America
 */

/** @file gcl.h
 * GCL core functions
 *
 */

/**
 * \addtogroup GCL_CORE  Core of the Gcl
 *
 * @{
 */

/**
 * @addtogroup core_defs Core Structures and defines
 *
 * These are the core structures and defines.
 */

#ifndef _GCL_H_INCLUDED
#define _GCL_H_INCLUDED

#include <unicapt.h>
#include <LNet.h>

#ifdef __cplusplus
extern "C" {
#endif

#define GCL_VERSION "2.25_0"


/*
 *   Configuration defines
 */

//Debug code generation
//#define DBG_ON             //to activate the debug for all libraries
//#define DBG_PORT DEBUG_PRN //to change the default (DEBUG_COM1) in debuglib.h

/** @addtogroup core_defs
 *  @{
 */
#ifndef GCL_MAX_CONF
#define GCL_MAX_CONF             (11)   //!< max number of connections added
                                       //!<can be set by Ingedev
#endif

#define GCL_EVENT_SYNC       (EVENT_6) //!< sync EVENT GCL

#define GCL_MAX_PHONE_SIZE       (32)   //!< max size for phone number field
#define GCL_MAX_PREFIX_SIZE      (4)    //!< max size for preffix field
#define GCL_MAX_QUEUE            (16)   //!< max size of message queue
#define GCL_MAX_BUFFER           (1024) //!< size of send/receive buffer
#define GCL_MAX_TASK_STACK_SIZE  (4096) //!< stack size for GCL task

#define GCL_MAX_LOGIN_NAME       (40) //!< the max login name
#define GCL_MAX_PASSWORD         (40) //!< the max size for password
#define GCL_MAX_HOST_NAME        (32) //!< the max size for the host name

#define GCL_MAX_DEVICE_NAME      (10)

#ifndef NI_PPP_LCP_MSCHAP
#define NI_PPP_LCP_MSCHAP BIT_MASK(6)
#endif

#define GCL_MAX_TERMINATORS_SIZE (5) //!< maximum size of the terminator vector.

/** @} */

/** @addtogroup gcl_states GCL core states
 * @{
 *
 * The core of the library has a state machine;
 * in almost all states a function set by the application is called,
 * if this function returns no error, the state machine goes
 * to the next state until it reaches the CONNECTED state.
 * In that state the library waits for application's requests:
 * send data, receive data or terminate the connection.
 *
 * Here we describe these states and what happens when GCL
 * connection reaches this particular state (note that
* some states have no meaning in some communication channels;
 * for example, LOGIN for HDLC).
 *
 * Below there is a figure with the states of the GCL
 *
 * \image html states.gif "GCL States"
 *
 */

/**
 * The gcl State machines is in that state before the gclStart is called.
 * After call the gclStart the state machine goes to GCL_NOTCONNECTED.
 * You can retrieve the current gcl state by calling the function
 * @see gclStart
 * @see gclTaskGetState
 */
#define GCL_NOTSTARTED    (0)
/**
 * The gclStart function is called, waiting the
 * function gclStartConnection.
 * @see gclStartConnection
 */
#define GCL_NOTCONNECTED  (1)
/**
 * The gcl state machine goes to this state when it is connected
 * and ready to send and receive data. The state machine will go to
 * the state GCL_SEND when the gclSend function is called and will go to
 * state GCL_RECEIVE when the gclReceive function is called. When the gclStop
 * function is called the state machines goes to GCL_KILL.
 *
 * @see gclSend
 * @see gclReceive
 * @see gclStop
 */
#define GCL_CONNECTED     (2)
/**
 * In this state the communication channel will be open,
 * if everything is ok the state machine goes to GCL_DIAL,
 * otherwise the state machine goes to GCL_ERROR.
 */
#define GCL_PREDIAL       (3)
/**
 * In this state the parameters of the communication channel
 * will be setup if no error occurs the state machine goes to
 * CONNECT. If some error occurs the state machine goes to ERROR.
 */
#define GCL_DIAL          (4)
/**
 * Waits until the physical channel communications is ready to
 * send and receive data.  If everything goes right the state
 * machine goes to LOGIN. If some error occurs the state machine goes to ERROR.
 */
#define GCL_CONNECT       (5)
/**
 * Authenticates the client with the host. If there is no error the state
 * machine goes to CONNECTED otherwise the state machine goes to ERROR.
 */
#define GCL_LOGIN         (6)
/**
 * The state machine goes to this state when it is in CONNECTED
 * state and receives an application request to send data.
 * After sending the data it moves back to CONNECTED state.
 */
#define GCL_SEND          (7)
/**
 * The state machine goes to this state when it's in CONNECTED
 * state and receives an application request to receive data.
 * When data was received the state machine goes to CONNECTED.
 */
#define GCL_RECEIVE       (8)
/**
 * Close the communication channel opened by PREDIAL.
 */
#define GCL_HANGUP        (9)
/**
 * If there is other connection in the connection list
 * the state machine goes to PREDIAL try to make the next
 * connection. If there isn't other connection the state
 * machine goes to HANGUP and then NOTCONNECTED
 */
#define GCL_NEXTCONN      (10)
/**
 * The state machine goes to state HANGUP to close the
 * communication channel. Then if there are more tries
 * set for this connection goes to PREDIAL and try again
 * with the same parameters. If there is not more tries for
 * this connection the state machine goes to NEXTCONN
 */
#define GCL_RETRY         (11)
/**
 * When in this state the GCL will go to GCL_NOTCONNECTED and the
 * GCL task will be closed.
 */
#define GCL_QUIT          (13)
/**
 * Analyses the error, if it is not fatal the state
 * machine goes to RETRY. If it is a fatal error the
 * state machine goes to FATAL_ERROR.
 */
#define GCL_ERROR         (14)
#define GCL_NULL          (15)
/**
 * When in this state the state machine
 * will go to HANGUP and then NOTCONNECTED.
 */
#define GCL_FATAL_ERROR   (16)
 /**
  * When in this state the state machine will go to GCL_HANGUP than GCL_QUIT.
  */
#define GCL_KILL          (17)

/**
 * Ping state: when in this state the GCL send an event to the main Task
 */
#define GCL_PING          (18)

/**
 * GCL start connection state
 */
#define GCL_START_CONNECTION (19)




/** @} */



/*
 *   Possible returns from callbacks
 *      GCL_RET_OK   proceed with
 */
#define GCL_RET_OK         (RET_OK)
#define GCL_RET_NOK         (-1)


/** @addtogroup ErrosDefs List of GCL errors
 *  @{
 *
 * List of all errors generated by GCL
 */

/*
 *   Error codes.
 */
#define GCL_ERROR_BASE   (LIBRARY_ERROR_START - 10*ERROR_SLOT_SIZE) //!< The base error for the GCL
#define GCL_ERR_CONN_LIST_FULL   (GCL_ERROR_BASE-1) //!< The list of connection is full
#define GCL_ERR_CONN_LIST_EMPTY  (GCL_ERROR_BASE-2) //!< The list of connection is empty
/**
 * \brief An error occured while the GCL created the task
 */
#define GCL_ERR_TASK_CREATE      (GCL_ERROR_BASE-3)
/**
 * \brief Error openning the handle of the desired communication
 * channel
 */
#define GCL_ERR_OPEN_DEVICE      (GCL_ERROR_BASE-4)
/**
 * \brief this error will be returned when calling the gclStartConnection
 * and the GCL is already connected
 */
#define GCL_ERR_CONFIG           (GCL_ERROR_BASE-6)
#define GCL_ERR_DIAL             (GCL_ERROR_BASE-7)
/**
 * \brief This error will be returned when calling gclSend and gclReceive
 * and the GCL is not connected
 */
#define GCL_ERR_NOT_CONNECTED    (GCL_ERROR_BASE-8)
/**
 * \brief This error will be return by a function that needs the GCL to be
 * started by the function gclStart and this funcion is not called
 * yet
 *
 * @see gclStart
 */
#define GCL_ERR_NOT_STARTED      (GCL_ERROR_BASE-9)
/**
 * \brief The function returns becouse a timeout occurs.
 */
#define GCL_ERR_TIMEOUT          (GCL_ERROR_BASE-10)
/**
 * \brief This error should be returned by the receive callback
 * when the receive callback receives more bytes then the buffer can
 * handle.
 */
#define GCL_ERR_BUF_OVERFLOW     (GCL_ERROR_BASE-11)
/**
 * \brief This error should be returned by the send callback
 * when the receive callback get an internal error
 */
#define GCL_ERR_SEND             (GCL_ERROR_BASE-13)
/**
 * \brief This error should be returned by the receive callback
 * when the receive callback get an internal error
 */
#define GCL_ERR_RECEIVE          (GCL_ERROR_BASE-14)
/**
 * GCL already started.
 */
#define GCL_ERR_ALREADY_STARTED (GCL_ERROR_BASE -15)
/**
 * \brief This error should be returned by the LOGIN callback if
 * a error occurs (login error).
 */
#define GCL_ERR_LOGIN            (GCL_ERROR_BASE-16)
/**
 * \brief This error is returned when the carrier is not detected
 * during a modem connection, or the carrier is lost during the
 * communication
 */
#define GCL_ERR_NO_CARRIER       (GCL_ERROR_BASE-18)
/**
 * \brief This error is returned when no dialtone is detected
 * during the connection attempt
 */
#define GCL_ERR_NO_DIALTONE      (GCL_ERROR_BASE-19)
/**
 * \brief This error is returned when the host doesn't answer
 * the call.
 */
#define GCL_ERR_NO_ANSWER        (GCL_ERROR_BASE-20)
/**
 * \brief This error is returned when the gclStop function is called
 * during the connection attempt.
 */
#define GCL_ERR_CANCEL_BY_USER   (GCL_ERROR_BASE-21)
/**
 * \brief The line is busy
 */
#define GCL_ERR_BUSY             (GCL_ERROR_BASE-22)
/**
 * \brief An internal error occurs
 */
#define GCL_ERR_INTERNAL_ERR     (GCL_ERROR_BASE-23)

#define GCL_ERR_QUEUE_FULL       (GCL_ERROR_BASE-25)
#define GCL_ERR_QUEUE_EMPTY      (GCL_ERROR_BASE-26)
//#define GCL_ERR_HANGUP           (GCL_ERROR_BASE-27)
/**
 * \brief The gclStop function couldn't close the task
 */
#define GCL_ERR_TASK_CLOSE       (GCL_ERROR_BASE-28)
/**
 * \brief The gclStarConnection returns this error when the GCL
 * is already connected
 */
#define GCL_ERR_CONNECTED        (GCL_ERROR_BASE-29)
/**
 * \brief The line connected to the modem is in use
 */
#define GCL_ERR_LINE_IN_USE      (GCL_ERROR_BASE-31)
/**
 * \brief The line was detected in use but is free when tested
 */
#define GCL_ERR_LINE_FREE        (GCL_ERROR_BASE-32)
/**
 * \brief The line is detected as not connected
 */
#define GCL_ERR_LINE_UNPLUGGED   (GCL_ERROR_BASE-33)
/**
 * \brief The line status is not exactly known
 */
#define GCL_ERR_LINE_IN_USE_OR_UNPLUGGED  (GCL_ERROR_BASE-34)
/**
 * \brief The call is delayed (blacklist management depend on country code)
 */
#define GCL_ERR_DELAYED          (GCL_ERROR_BASE-35)
/**
 * \brief The phone number is blacklisted (blacklist management depend on country code)
 */
#define GCL_ERR_BLACKLISTED      (GCL_ERROR_BASE-36)
/**
 * \brief The blacklist is full and has been resetted (blacklist management depend on country code)
 */
#define GCL_ERR_BLACKLIST_FULL   (GCL_ERROR_BASE-37)
/**
 * \brief The connection was refused. Normally a PPP connection
 */
#define GCL_ERR_CONN_REFUSED     (GCL_ERROR_BASE-40) // PPP or ETH
/**
 * \brief error while trying to get the local IP. Normally error
 * in the function netNiConfigGet.
 */
#define GCL_ERR_GET_IP           (GCL_ERROR_BASE-41) // PPP
/**
 * \brief error in the function socket
 */
#define GCL_ERR_OPEN_SOCKET      (GCL_ERROR_BASE-42) // PPP or ETH
/**
 * \brief error in the socket connection attempt.
 */
#define GCL_ERR_SOCKET_CONNECT   (GCL_ERROR_BASE-43) // PPP or ETH - SOCK
/**
 * \brief This error should be returned by the task if
 * the send or receive callback is not defined
 */
#define GCL_ERR_CALLBACK_NOT_DEFINED   (GCL_ERROR_BASE-44) //

#define GCL_ERR_PARAMETER        (GCL_ERROR_BASE - 45)
/**
 * \brief error when trying to get the host IP by the DNS. Normally error in the
 * function dnsGetHostByName.
 */
#define GCL_ERR_DNS              (GCL_ERROR_BASE-50) // ETH
/**
 * Error creating the GCL connection task
 */
#define GCL_ERR_ETH_TASK         (GCL_ERROR_BASE-51) // ETH
#define GCL_ERR_ETH_NOT_STARTED  (GCL_ERROR_BASE-52) // ETH

/**
 * No LNET installed in the terminal
 */
#define GCL_ERR_NO_LNET_INSTALLED (GCL_ERROR_BASE-53)

/**
 * No extended error available
 */
#define GCL_ERR_NO_ERROR_INFO_AVAILABLE (GCL_ERROR_BASE-54)

/**
 * \brief User error base for the GCL. It is used by the SSL library.
 */
#define GCL_ERR_USER             (GCL_ERROR_BASE-100)

/** @} */


/** @addtogroup core_defs
 *  @{
 */


#define GCL_HDLC     0  //!< connection type modem HDLC
#define GCL_ASYN     1  //!< connection type modem assynchronous
#define GCL_SERIAL   2  //!< connection type serial
#define GCL_PPP      4  //!< connection type PPP over modem
#define GCL_PPPCOM   5  //!< connection type PPP over serial
#define GCL_ETH      6  //!< connection type Ethernet
#define GCL_GSM      7  //!< connection type GSM
#define GCL_PPPOE    8  //!< connection type PPP over ethernet
#define GCL_GPRS     9  //!< connection type GPRS
#define GCL_PPPGSM   10 //!< connection type PPP over GSM
#define GCL_SOCK     11 //!< connection type socket (tcp/ip) connection
#define GCL_WIFI     12 //!< connection type WIFI WEP
#define GCL_V42      13 //!< connection type V42 (async modem with a specific V42 usage)
#define GCL_USB      14 //!< connection type USB
#define GCL_CDMA     15 //!< connection type CDMA
#define GCL_WIFI_WPA 16 //!< connection type WIFI WPA

#define GCL_PGSUP      40 //!< used only by the error callback to identify a PGSUP error.
#define GCL_SSL        41 //!< used only by the error callback to identify a SSL error.
#define GCL_SOCK_UTIL  42 //!< used only by the error callback to identify a SOCKET UTIL error



typedef struct
{
   int16    status;
   uint16   length;
   uint8    data[64];
} gclGResult_t;

/**
 *   \brief typedef gclConfig_t
 *
 *    see @see gclConfig_s
 */
typedef struct gclConfig_s gclConfig_t;

/**
 * \brief structure used to store the connection configuration
 *
 * This structure store all the configuration...
 */
struct gclConfig_s
{
   /* phone configuration */
   uint8    connectionId; //!< number identifying the connection
   /**
    * \brief Identify the connection type.
    */
   uint8    connectionType;
   /* general config */
   uint8    retries;       //!< number of retries (connection attempts equals retries + 1)
   uint8    retryCount;    //!< Actual connection retry
   uint32   connectTimeout;//!< The connection timeout in 1/100 of seconds
   uint32   retryDelay;    //!< the delay before retying connection
   /**
    * \brief The timeout of the send and receive function
    */
   uint32   communicationTimeout;
   uint32   loginTimeout;  //!< The timeout of the login in 1/100 of seconds
   uint32   extraDataLength; //!< Extra data length
   /**
    * \brief pointer to store more connection configurations
    *
    * This pointer is used to store more configurations
    * related to the connection that there isn't in this structure
    * Ex. IP address for TCP/IP connections.
    */
   void     *extraData;
   uint32   userDataLength; //!< user data length
   /**
    * \brief Pointer to user data
    *
    * Can be used to store user data to be user during the
    * connection attempt. The data can be retrieved using the
    * function gclGetUserData
    */
   void     *userData;
   /**
    * \brief pointer to gcl extension (SSL)
    *
    * This pointer is used to retrieve the data used by the gcl extension
    * attached to the connection that there isn't in this structure
    */
   void     *gclExtension;
   void     *gclpgExtension;

   /* Unicapt32 information */
   uint32   comHandle; //!< Store the communication handle

   /* callback functions */
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_PREDIAL
    */
   int16    (*predial)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_DIAL
    */
   int16    (*dial)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_RETRY
    */
   int16    (*retry)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_CONNECT
    */
   int16    (*connect)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_LOGIN
    */
   int16    (*login)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_ERROR
    */
   int16    (*error)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_HANGUP
    */
   int16    (*hangup)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_SEND
    */
   int16    (*send)(gclConfig_t*, uint8*, uint32);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        \ref GCL_RECEIVE
    */
   int16    (*recv)(gclConfig_t*, uint8*, uint32*, uint32);
   /**
    * \brief Callback that is called when the user call the function
    *        \ref gclDirectSend. This function will implement the send using the
    *         current communication type.
    */
   int16    (*apiSend)(gclConfig_t*, uint8*, uint32);
   /**
    * \brief Callback that is called when the user call the function
    *        \ref gclDirectReceive. This function will implement the receive using the
    *         current communication type.
    *
    */
   int16    (*apiReceive)(gclConfig_t *, uint8*, uint32*, uint32);
};

/**
 * Structure with the callbacks of the GCL states
 */
typedef struct
{
   int16 (*predial)(gclConfig_t *); //!< callback called in the \ref GCL_PREDIAL state
   int16 (*dial)(gclConfig_t *); //!< callback called in the \ref GCL_DIAL state
   int16 (*retry)(gclConfig_t *); //!< callback called in the \ref GCL_RETRY state
   int16 (*connect)(gclConfig_t *); //!< callback called in the \ref GCL_CONNECT state
   int16 (*login)(gclConfig_t *); //!< callback called in the \ref GCL_LOGIN state
   int16 (*error)(gclConfig_t *); //!< callback called in the \ref GCL_ERROR state
   int16 (*hangup)(gclConfig_t *); //!< callback called in the \ref GCL_HANGUP state
   int16 (*send)(gclConfig_t *, uint8 *, uint32); //!< callback called in the \ref GCL_SEND state
   int16 (*recv)(gclConfig_t *, uint8 *, uint32 *, uint32); //!< callback called in the \ref GCL_RECEIVE state

} gclFunctionList_t;


/**
 * Send and receive callback
 */
typedef struct
{
   int16 (*send)(gclConfig_t *, uint8 *, uint32); //!< callback called in the \ref GCL_SEND state
   int16 (*recv)(gclConfig_t *, uint8 *, uint32 *, uint32); //!< callback called in the \ref GCL_RECEIVE state
} gclFunctionSendReceive_t;

/**
 * Structure that holds the address/port to a socket connection
 */
typedef struct
{
   uint32   ipAddress;                       //!< Ip address
   uint16   tcpPort;                         //!< TCP port
   char     hostName[GCL_MAX_HOST_NAME + 1]; //!< host name if no IP provided
   char     tcpNoDelay;                      //!< set to 1 for using TCP_NODELAY
   uint8    soLinger;                        //!< if use the SO_LINGER option
} gclConnectSock_t;


/**
 * Structure with the PPP connection configuration
 */
typedef struct
{
   uint32         ni; //!< handle of the LNET (function netniopen)
   //
   netNiConfig_t  config; //!< structure with the configuration of the LNET
   //
   char           loginName[GCL_MAX_LOGIN_NAME + 1]; //!< login name
   char           password[GCL_MAX_PASSWORD + 1]; //!< password
   /////
   uint32         ipAddressLocal; //!< IP local (get via DHCP or set by the user)
   uint32         dns1IpAddress; //!< first DNS server address
   uint32         dns2IpAddress; //!< second DNS server address

} gclPPPNi_t;
/**
 * @}
 */


/** Functions **/


/**
 * @defgroup core Core Functions
 *
 * These are the core functions of the GCL. They are in charge of
 */

/**
 * /@addtogroup core
 * @{
 */

/**
 * @ingroup core
 *
 * @brief This function returns the version Id of the library
 *
 * @param zcOut pointer to store the GCL version Id.
 *
 * @return always RET_OK
 */
int16 gclId(char *zcOut);


/**
 * @ingroup core
 *
 *   @brief Library initialization.
 *
 *   - Create the GCL task that will deal with the connection
 *   - Setup the communication with the Task
 *
 * @return RET_OK if no errors occurs
 * @return GCL_ERR_TASK_CREATE if the gcl task can not be created.
 * @return GCL_ERR_ALREADY_STARTED if the task is already created.
 *
 */
int16 gclStart (void);

/**
 * @ingroup core
 *
 *   @brief Reset (clear) the list of connections and all other internal
 *   control variables.
 *
 *   - Empty Connection List
 *   - Clear the internals
 *
 * @return always RET_OK
 */
int16 gclReset (void);


/**
 * @ingroup core
 *
 * The default implementation for the retry (\ref GCL_RETRY) callback. This function manages
 * if there is more attempts in the actual connection and if there is more
 * connections added.
 *
 * @param gcl (I) the configuration of the connection.
 *
 * @return always RET_OK
 */
int16 gclConnectRetry(gclConfig_t *gcl);
#define gclModemRetry gclConnectRetry //!< to have compatibility with old version

/**
 * @ingroup core
 *
 * The default implementation to the error (\ref GCL_ERROR) callback.
 * The error callback choose between try the next connection attempt or
 * cancel the attempts. The default implementation always try the next
 * attempt.
 *
 * @param gcl (I) the configuration of the connection.
 *
 * @return always RET_OK
 */
int16 gclConnectError(gclConfig_t *gcl);

/**
 * Get the user data from the actual connection and
 * copy the data to the location given by the application.
 *
 * @param userData (O) point to a buffer to receive the user data
 * @param userDataLength (O) point to a uint32 to receive the user data size
 *
 * @return always RET_OK
 */
int16 gclGetUserData(void *userData, uint32 *userDataLength);

/**
 *   Add a connection to the list of possible connections.
 *   Connections are tried in order of insertion.
 *   - Copy data to internal list
 * This function is not intended to be called directly by the user.
 * Normally the user call a specific communication library function
 * that then call this function to specifically add the connection.
 *
 * @param conn configuration of the connection to be added to the connection list
 *
 * @return RET_OK if no errors occurs
 * @return GCL_ERR_CONN_LIST_FULL if the connection list is full
 */
int16 gclAddConnection (gclConfig_t *conn);

/**
 * @ingroup core
 *
 *   Read the last connection of the list of possible connections.
 *   - Copy data to list
 *
 * @param conn (O) a pointer to the gclConfig_t struct. The function will fill this
 *   struct with the parameters of the last connection added to the connection list.
 *
 * @return RET_OK no errors
 * @return GCL_ERR_CONN_LIST_EMPTY the connection list is empty
 */
int16 gclReadLastConnection(gclConfig_t *conn);

/**
 * @ingroup core
 *
 *   rewrite the last connection of the list of possible connections.
 *
 * @param conn (I) the function will copy the data in this struct over
 *   the last connection in the connection list.
 *
 * @return RET_OK no errors
 * @return GCL_ERR_CONN_LIST_EMPTY the connection list is empty
 */
int16 gclWriteLastConnection(gclConfig_t *conn);

/**
 * @ingroup core
 *
 * return the actual number of added connections in the
 * list of possible connection
 *
 * @return the number of added connections.
 */
int16 gclGetNumConnections(void);

/**
 * @ingroup core
 *
 *   Start the connection.
 *   - Set currentConnection = 0
 *   - Start connection flow on Task
 *   - Wait till gclGetCurrentStep() == GCL_STEP_DIALING
 *      or lastError != RET_OK
 *
 * @return RET_OK no errors
 * @return GCL_ERR_CONN_LIST_EMPTY the connection list is empty
 * @return GCL_ERR_NOT_STARTED the \ref gclStart function was not called.
 * @return GCL_ERR_CONNECTED the GCL is already connected or in a connection attempt.
 */
int16 gclStartConnection(void);

/**
 * @ingroup core
 *
 * @brief Return the current state of the task.
 *
 * @return the current state of the task. One of the \ref gcl_states.
 */
int16 gclTaskGetState(void);

/**
 * Check if the gcl task is alive.
 *
 *   @return TRUE is the task is alive or FALSE if not
 */
uint8 gclTaskIsAlive(void);

/**
 * @ingroup core
 *
 *   Get a point to the current gclConfig of the actual connection.
 *   @return
 *          RET_OK if ok,
 *
 *          RET_NOK if current configIndex is invalid
 *   (for instance, if there are not connections configured)
 */
 int16 gclCurrentConfig(gclConfig_t **gcl);

/**
 * @ingroup core
 *
 *   Gathers information about the running connection
 *   @param [out] configIndex   index of current gclConfig being used, if
 *       you don't wand this parameter use NULL
 *   @param  [out] retryCount   number of retries for current config, if
 *       you don't wand this parameter use NULL
 *   @param  [out] connectionId   contents of field connectionId, if
 *       you don't wand this parameter use NULL
 *   @param  [out] connectionType  contents the type of the actual connection
 *   @return
 *          RET_OK if ok,
 *
 *          RET_NOK if current configIndex is invalid
 *   (for instance, if there are not connections configured)
 */
int16 gclCurrentConfigState(uint8 *configIndex, uint8 *retryCount,
                            uint8 *connectionId, uint8 *connectionType);

/**
 *   Set the global error code
 *   @param errorCode is the error to be save in the global last error variable
 *   @return returns the global lastError
 */
int16 gclSetError(int16 errorCode);

/**
 *   Return information about last error.
 *   @return returns the global lastError
 */
int16 gclLastError(void);

/**
 *   Send a message through the current open connection
 *   - Call the gcl send state, than the send callback will be called and
 *       this buffer is passed to the send callback
 *   - Wait until the send completion
 *
 *   @param buffer pointer to the buffer to be send
 *   @param size the number of bytes in the buffer
 *
 *   @return
 *      GCL_NOTCONNECTED if the GCL is not in the GCL_CONNECTED state
 *      return the error returned by the send callback
 */
int16 gclSend(const uint8 *buffer, uint32 size);

/**
 * Receives a message using the current open connection
 *
 *  - Call receive state. The receive callback will be called with the
 *      parameters passed.
 *  - Wait for reception completion
 *
 *  @return GCL_NOTCONNECTED if the GCL is not in the GCL_CONNECTED state
 *  @return the error returned by the receive callback
 */
int16 gclReceive(uint8 *buffer, uint32 maxLen, uint32 *actuallyRead);

/**
 * Receives a message using the current open connection
 *
 *  - Call receive state. The receive callback will be called with the
 *      parameters passed.
 *  - Assynchronous function. User must wait for EVENT_6 (GCL_EVENT_SYNC).
 *  - To get the error when the receive is done, call the function
 * \ref gclLastError.
 *
 *  @return GCL_NOTCONNECTED if the GCL is not in the GCL_CONNECTED state
 */
int16 gclReceiveAsyn(uint8 *buffer, uint32 maxLen);

/**
 * Change the send and receive callback. Validy only when the GCL is connected.
 *
 * @param funcList the new send and receive callbacks.
 */
int16 gclChangeSendRecCBs(gclFunctionSendReceive_t *funcList);


/**
 * Set terminators for the receive callback. This function must be called before
 * a call to gclReceive.
 * Note that not all communication types can use terminators.
 * The following communications types support terminators in the default receive callback:
 * - GCL_SERIAL
 * - GCL_ASYN
 * - GCL_HDLC
 * - GCL_GSM
 * - GCL_USB
 *
 * @param terminators a pointer to the terminator vector
 * @param size the size of the terminators vector
 *
 * @return RET_OK no problems
 * @return GCL_ERR_BUF_OVERFLOW size to big for internal buffer
 */
int16 gclSetTerminators(uint8 *terminators, uint8 size);

/**
 * Get the terminators preciously set. Used internally by the receive callbacks.
 *
 * @param terminators a pointer to receive a pointer to the terminators vector.
 * @param size a pointer to receive the actual size of the terminator vector
 */
int16 gclGetTerminators(uint8 **terminators, uint8 *size);

/**
 * Check if a byte is one of the terminators
 *
 * @param byte the byte to be checked
 *
 * @return RET_OK the byte is one of the terminators
 * @return -1 the byte is not one of the terminators
 */
int16 gclCheckTerminators(uint8 byte);

/**
 * Change the communication timeout. This function must be called before
 * a call to gclReceive.
 *
 * @param commTimeout the new communication timeout
 */
int16 gclChageCommTimeout(uint32 commTimeout);

/**
 * get the received length when the function \ref gclReceiveAsyn was used.
 */
uint32 gclGetLengthRecv(void);

/**
 * This function encapsulate the UNICAPT32 send function for the current
 * communication type.
 *
 * @param gcl the actual configuration of the connection
 * @param data a pointer to the data to be sent
 * @param dataSize the size of the data to be sent
 *
 * @return RET_OK no errors
 * @return GCL_ERR_CONFIG the gcl was not configured
 * @return the returned error of the callback function
 *
 */
int16 gclDirectSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * This function encapsulate the UNICAPT32 receive function for the current
 * communication type
 *
 * @param gcl (I) the actual configuration of the connection
 * @param data (O) a pointer to a buffer to receive the data
 * @param actuallyRead (O) a pointer to a uint32 that will receive the number of
 *            bytes received
 * @param maxLen (I) the size of the buffer
 *
 * @return RET_OK no errors
 * @return GCL_ERR_CONFIG the gcl was not configured
 * @return the returned error of the callback function
 *
 */
int16 gclDirectReceive(gclConfig_t *gcl, uint8 *data,uint32 *actuallyRead, uint32 maxLen );

/**
 * function that will wait the connection. This function is called after the
 * \ref gclStartConnection, and will return after the connection was done or
 * after all the connections attempts.
 *
 * @return RET_OK no errors and the connection is stablished
 * @return GCL_ERR_CONN_LIST_EMPTY no connection was configured
 * @return GCL_ERR_NOT_STARTED the gcl was not started, call the \ref gclStart function and
 *     the \ref gclStartConnection function.
 * @return an specific connection error (\ref gclLastError) set by one of the
 *     connections callbacks.
 */
int16 gclWaitConnection(void);

/**
 *   Try to hangup the currently open connection.
 *   This function may be called when there is no connection
 *   open with no side-effects.
 *
 * @param timeout Time in 1/100s to wait the disconnection.
 *
 * @return
 *   RET_OK if no errors occurs
 *
 *   GCL_ERR_TIMEOUT if timeout
 */
int16 gclHangup(uint32 timeout);

/**
 *   Check if there is a pending hangup
 *   @return the value of s_ForceHangup. It is 0 if there is no pending hangup,
 * or a value different from 0 if there is a pending hangup.
 */
uint8 gclPendingHangup(void);

/**
 *   Hangup connection and close communication task.
 *
 * @return RET_OK no errors
 * @return GCL_ERR_TASK_CLOSE problems to close the task.
 */
int16 gclStop(void);


/**
 * Send a ping message to the GCL task and wait for it
 * be executed. Used for synchronization purpose
 */
int16 gclWaitPing(void);


/**
 *   Post a message to the task queue.
 *   @return RET_OK if no errors occurs
 *   @return GCL_ERR_QUEUE_FULL if the internal message Queue is full.
 */
int16 gclPostMessage(uint16 msg);

/**
 *   Clear the message queue.
 *
 * @return always RET_OK
 */
int16 gclClearMessages(void);


/**
 * Null function to be put in an unused callback.
 *
 * @return always RET_OK
 */
int16 gclNULLFunction(gclConfig_t* gcl);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


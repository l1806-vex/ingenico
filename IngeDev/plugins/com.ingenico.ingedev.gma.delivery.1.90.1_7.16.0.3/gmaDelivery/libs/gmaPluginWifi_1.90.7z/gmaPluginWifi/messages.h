#ifndef MESSAGES_H_INCLUDED
#define MESSAGES_H_INCLUDED

//////////////////////////////////////////
// DEFINES

#ifdef __cplusplus
extern "C" {
#endif

/// Messages from Idle
#define POM_MSG_CONFIG_WIFI		      3
#define POM_MSG_CONFIG_TEST            2
#define POM_MSG_ETHERNET_STATUS        1
#define POM_MSG_STARTUP                7
#define POM_MSG_START                  4
#define POM_MSG_STOP                   5

/////////////////////////////////////////
//  Messages to Idle
#define POM_MSG_ETHERNET_STATUS_CHANGE 6

/////////////////////////////////////////
// Message from user application
#define POM_MSG_USER_CONNECTION_STATUS 9//7
#define POM_MSG_USER_IP_CONFIG         8


//////////////////////////////////////////
// Structs

// Struct of a message to answer the PowerOn Message
typedef struct _pomAnswerToMsgPowerOn
{
    uint16 receiverPid;   /* identification number of the called appli */
    uint32 callerTaskId;  /* Identification Number of caller task      */
    uint32 msgType;       /* Message type :0 = msg from an application */
                          /*           other = synchronization message */
    uint32 msgLength;     /* length of the message                     */
    uint32 status;        /* return status                             */
} pomAnswerToMsgPowerOn_t;

typedef struct _pomMsgFromAppl
{
    uint16 receiverPid;   /* identification number of the called appli */
    uint32 callerTaskId;  /* Identification Number of caller task      */
    uint32 msgType;       /* Message type :0 = msg from an application */
                          /*           other = synchronization message */
    uint32 msgLength;     /* length of the message                     */
    uint8  identification;/* type of msg from app                      */
} pomMsgFromAppl_t;

/*struct _pomMsgEthStatusMsg{
    uint8  msgStatus;     // Ethernet status                           //
    uint32 IpLocal;       // Local Ip Address                          //
};*/

/*typedef struct _pomMsgEthStatus
{
    uint16 receiverPid;   // identification number of the called appli //
    uint32 callerTaskId;  // Identification Number of caller task      //
    uint32 msgType;       // Message type :0 = msg from an application //
                          //           other = synchronization message //
    uint32 msgLength;     // length of the message                     //

    struct _pomMsgEthStatusMsg msg;
}pomMsgEthStatus_t;*/


/**
 * This is the message format that Idle expects for the status information.
 */
typedef struct ghtmAnswerStatusSignal_t ghtmAnswerStatusSignal_t;
struct ghtmAnswerStatusSignal_t
{
   uint8  type;	               ///< Always 1
   int8   connectionStatus;	   ///< 0 if connected, negative number on error
   uint8  signalStrenght;	      ///< Signal strength in range [0,31]
   uint8  bitErrorRate;	         ///< Always zero
   uint8  gprsStatus;	         ///< Always zero
};

/**
 * \brief Send a status message to Idle's VQueue.
 * \return RET_OK if message was sent ok
 * \return ERR_INVALID_HANDLE if \c STARTUP message from Idle wasn't received.
 * \return Error codes from psyVQueueSend.
 */
int16 pomSendStatusMessage(void);



struct _pomMsgWIFIStatusMsg{
    uint8  msgStatus;     // Ethernet status                           //
    uint32 IpLocal;       // Local IP Address                          //
};

typedef struct _pomMsgWIFIStatus
{
    uint16 receiverPid;   // identification number of the called appli //
    uint32 callerTaskId;  // Identification Number of caller task      //
    uint32 msgType;       // Message type :0 = msg from an application //
                          //           other = synchronization message //
    uint32 msgLength;     // length of the message                     //

    struct _pomMsgWIFIStatusMsg msg;
}pomMsgWIFIStatus_t;

#ifdef __cplusplus
}
#endif

#endif

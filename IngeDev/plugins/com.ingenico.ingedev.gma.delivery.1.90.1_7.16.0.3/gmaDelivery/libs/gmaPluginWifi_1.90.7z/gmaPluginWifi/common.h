#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED

#include "miltypes.h"
#include "unicapt.h"

#ifdef __cplusplus
extern "C" {
#endif

int pprintf(const char * fmt, ...);
uint8 getkey(void);
void openPeripheral(void);
void closePeripheral(void);
void ComDebugOpen(void);
void ComDebugClose(void);
void comPrintf(const char * fmt, ...);
int pprintt(uint8 line,const char * fmt, ...);
void clearLines(void);
void msaSetReverseMode( char bReverso );
void pprinttRev(uint8 line,char reverso,char *string1);
uint32 cmmGetHmiHandle(void);
uint32 cmmGetTouchHandle(void);
int pprintfw(const char * fmt, ...);

// #####################################################################################
// MENU WRAPPER AREA (LAF)
// The functions bellow allow simplify using the menu (LAF/Non-LAF) functions
uint32 mwGetHmiHandle(void);
uint32 mwGetTouchHandle(void);
int16 mwReset(uint32 hmiHandle, uint32 touchHandle);
int16 mwSetTitle(const char *title);
int16 mwAddItem(const char *caption, uint8 enabled, int16 value);
int16 mwRun(int16 startingSelection);
// #####################################################################################

#ifdef __cplusplus
}
#endif

#endif

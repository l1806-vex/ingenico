
#ifndef POMMSG_H_INCLUDED
#define POMMSG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

void pomMsgConfigWIFI(pomMsgFromAppl_t *msgFromApp);

//void pomMsgConfigTest(pomMsgFromAppl_t *msgFromApp);

void pomMsgEthernetStatus(pomMsgFromAppl_t *msgFromApp);

void pomMsgWarningStart(pomMsgFromAppl_t *msgFromApp);

void pomMsgWarningStop(pomMsgFromAppl_t *msgFromApp);

void pomMsgUsrConnectStatus(pomMsgFromAppl_t *msgFromApp);

void pomSetWIFIConfig(void);

//void pomMsgUsrIpConfig(pomMsgFromAppl_t *msgFromApp);

#ifdef __cplusplus
}
#endif

#endif

#ifndef POM_CONFWPA_H_INCLUDED
#define POM_CONFWPA_H_INCLUDED

#include "lnet.h"
#include "LNetCtrl.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup WIFIWPA_ Wifi WPA communication
 *
 * Processes confguration and build configuration strings to allow 
 * using of WiFi WPA.
 *
 * @{
 */

#define WPA_CFG_PROTO_WPA		(1<<0)
#define WPA_CFG_PROTO_RSN		(1<<1)
#define WPA_CFG_PROTO_WPA2		(1<<2)

#define WPA_CFG_KMGM_WPA_PSK	(1<<0)
#define WPA_CFG_KMGM_WPA_EAP	(1<<1)
#define WPA_CFG_KMGM_IEEE8021X	(1<<2)

#define WPA_CFG_AUTH_OPEN		(1<<0)
#define WPA_CFG_AUTH_SHARED		(1<<1)
#define WPA_CFG_AUTH_LEAP		(1<<2)

#define WPA_CFG_PAIR_CCMP		(1<<0)
#define WPA_CFG_PAIR_TKIP		(1<<1)
#define WPA_CFG_PAIR_NONE		(1<<2)

#define WPA_CFG_EAP_MD5			(1<<0)
#define WPA_CFG_EAP_MSCHAPV2	(1<<1)
#define WPA_CFG_EAP_OTP			(1<<2)
#define WPA_CFG_EAP_PEAP		(1<<3)
#define WPA_CFG_EAP_GTC			(1<<4)
#define WPA_CFG_EAP_TLS			(1<<5)
#define WPA_CFG_EAP_TTLS		(1<<6)

typedef struct
{
	char ssid[32+1]; //!< SSID of the access point
	/**
	 * 0-> do not scan this ssid with specific Probe Request Frames (default).
	 * 1-> scan with SSID specific Probe request frames. (This can be used to find APs that
	 * do not accept broadcast SSID or use multiple SSIDs; this will add latency to acanning,
	 * so enable this only when needed).
	 */
	uint8 scanSsid;
	/**
	 * ored combinations of the following values
	 * - 0 -> OS default: WPA_CFG_PROTO_WPA + WPA_CFG_PROTO_RSN 
	 * - WPA_CFG_PROTO_WPA -> WPA/IEEE 802.11i/D3.0
	 * - WPA_CFG_PROTO_RSN -> WPA2/IEEE 802.11i
	 */
	
	uint8 priority;
	/**
	 * 
	 */
	
	uint8 proto;
	/**
	 * one of the following values:
	 * - 0 -> OS default, WPA_CFG_KMGM_WPA_PSK + WPA_CFG_KMGM_WPA_EAP  
	 * - WPA_CFG_KMGM_WPA_PSK
	 * - WPA_CFG_KMGM_WPA_EAP
	 * - WPA_CFG_KMGM_IEEE8021X
	 */
	uint8 keyMgmt;
	/**
	 * One of the following values:
	 * - 0: OS default (automatic selection, Open system with leap enabled if leap is
	 * allowed as one of the EAP methods).
	 * - WPA_CFG_AUTH_OPEN: Open System Authentication (required for WPA/WPA2)
	 * - WPA_CFG_AUTH_SHARED: Shared key authentication (required WEP keys)
	 * - WPA_CFG_AUTH_LEAP: LEAP/network EAP (only used with LEAP)
	 */
	uint8 authAlg;
	/**
	 * One or ored combination of the following defines/values:
	 * 
	 * - 0: OS default (CCMP or TKIP)
	 * - WPA_CFG_PAIR_CCMP: CCMP=AES in counter mode with CBC-MAC
	 * - WPA_CFG_PAIR_TKIP: TKIP=Temporal Key Integrity Protocol
	 * - WPA_CFG_PAIR_NONE: Use only group keys, deprecated, should not be
	 * used if APs support pairwise keys.
	 */
	uint8 pairwise;

	/**
	 * One of the options accept by \ref pairwise. 
	 */
	uint8 group;

	/**
	 * The key to be used in the WPA-PSK mode (\ref keyMgmt).
	 * Can be a 64 hex-digits (32 bytes) or a passphrase from 8 to 
	 * 63 caracters (inclusive).
	 */
	char psk[63+1];

	/**
	 * Ored of the following entries:
	 * - 0: OS default, all methods allowed
	 * - WPA_CFG_EAP_MD5: EAP-MD5 (unsecure and does not generate keying material
	 *   cannot be used with WPA; to be used as a phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - WPA_CFG_EAP_MSCHAPV2: EAP-MSCHAPV2 (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - WPA_CFG_EAP_OTP: EAP-OTP (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - WPA_CFG_EAP_PEAP: EAP-PEAP (with tunneled EAP authentication).
	 * - WPA_CFG_EAP_GTC: EAP-GTC (cannot be used separately with WPA; to be used as a 
	 * phase 2 method with EAP-PEAP or EAP-TTLS)
	 * - WPA_CFG_EAP_TLS: EAP-TLS (client and server certificate)
	 * - WPA_CFG_EAP_TTLS: EAP-TTLC (with tunneled EAP or PAP/CHAP/MSCHAP/MSCHAPV2 authentication).
	 * 
	 * 
	 */
	uint16 eap;

	/**
	 * Identity string for eap, null or "" if not used
	 */
	char identity[50+1];

	/**
	 * Anonymous identity string for EAP (to be used as the unencrypted 
	 * identity with EAP types that support different tunneled identity, e.g., 
	 * EAP-TTLS). 
	 * Null or "" if not used.
	 */
	char anIdentity[50+1]; // anonymous_identity
	/**
	 * password string for EAP
	 * 
	 * Null or "" if not used.
	 */
	char password[32+1];
	/**
	 * Certificate file (PEM/DER). This file can be one or more trusted CA certificates. 
	 * If ca_cert was not included, server certificate will not be verified.
	 * 
	 * If the len(ca_cert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char ca_cert[32+1];
	/**
	 * Client certificate file (PEM/PER).
	 * 
	 * If the len(clientCert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char clientCert[32+1];
	/**
	 * Client private key (PEM/DER/PFX). When PKCS#12/PFX file (.p12 or .pfx)
	 * is used, \ref clientCert should be not used, as the client certificate will
	 * be readed together with the *privKey.
	 * 
	 * If the len(ca_cert) < 32, the entry will be treated as a file name and the
	 * ca_cert will be readed from this file.
	 * 
	 * Null or "" if not used.
	 */
	char privKey[32+1];
	/**
	 * password for the \ref privKey
	 */
	char privKeyPwd[32+1];

	/**
	 * Substring to be matched against the subject of the 
	 * authentication server certificate. If this
	 * string is set, the server certificate is only accepted 
	 * if it contains this string in the subject. The subject 
	 * string is in following format:
	 * 
	 * /C=US/ST=CA/L=San Francisco/CN=Test AS/emailAddress=as\@example.com
	 * 
	 * - Null or "" if not used.
	 */
	char subjMatch[50+1];
	/**
	 * Phase1 (outer authentication, i.e., TLS tunnel)
	 *  parameters (string with field-value pairs, e.g., 
	 * "peapver=0" or "peapver=1 peaplabel=1") 'peapver' 
	 * can be used to force which PEAP version (0 or 1) 
	 * is used. 'peaplabel=1' can be used to force new 
	 * label, "client PEAP encryption", to be used during key 
	 * derivation when PEAPv1 or newer. Most existing PEAPv1 
	 * implementation seem to be using the old label, "client EAP encryption",
	 *  and wpa_supplicant is now using that as the default value.
	 * 'peap_outer_success=0' can be used to terminate PEAP authentication on tunneled EAPSuccess.
	 * This is required with some RADIUS servers that implement draft-josefsson-pppexteap-
	 * tls-eap-05.txt (e.g.,Lucent NavisRadius v4.4.0 with PEAP in "IETF Draft 5" mode)
	 * include_tls_length=1 can be used to force wpa_supplicant to include TLS Message Length
	 * field in all TLS messages even if they are not fragmented. sim_min_num_chal=3 can be used
	 * to configure EAP-SIM to require three challenges (by default, it accepts 2 or 3)
	 * 
	 * - Null or "" if not used.
	 */
	char phase1[50+1];
	/**
	 * Phase2 (inner authentication with TLS tunnel) parameters (string with field-value pairs, e.g.,
	 * "auth=MSCHAPV2" for EAP-PEAP or "autheap=MSCHAPV2 autheap=MD5" for EAPTTLS)
	 * Following certificate/private key fields are used in inner Phase2 authentication when using
	 * EAP-TTLS or EAP-PEAP.
	 * 
	 * - Null or "" if not used.
	 */
	char phase2[50+1];
	/**
	 * CA certificate file. This file can have one or more trusted CA certificates. If ca_cert2 is not
	 * included, server certificate will not be verified. This is insecure and the CA file should always
	 * be configured
	 * 
	 * If the len(ca_cert2) < 32, the entry will be treated as a file name and the
	 * ca_cert2 will be readed from this file.
	 
	 * - Null or "" if not used.
	 */
	char ca_cert2[32+1];
	/**
	 * Client certificate file. To be used in phase2 authentication if required.
	 * 
	 * If the len(clientCert2) < 32, the entry will be treated as a file name and the
	 * clientCert2 will be readed from this file.
	 * 
	 * - Null or "" if not used.
	 */
	char clientCert2[32+1];
	/**
	 * Client private key. To be used in the phase2 authentication process if required
	 *
	 * If the len(privKey2) < 32, the entry will be treated as a file name and the
	 * privKey2 will be readed from this file.
	 * 
	 * - Null or "" if not used.
	 */
	char privKey2[32+1];
	/**
	 * password for the \ref privKey2
	 * 
	 * - Null or "" if not used.
	 */
	char privKey2Pwd[32+1];
	/**
	 * Substring to be matched against the subject of the authentication server certificate in phase2.
	 * see \ref subjMatch.
	 * 
	 * - Null or "" if not used.
	 */
	char subjMatch2[50+1];
} wpaCfg_t;

/**
 * Returns the lenght of the string configuration for WPA 
 *
 * @param[in] config WPA configuration data.
 * 
 * @return RET_OK if the configuration lenght was succesfully calculated.
 * @return Negative number if error.
 *  
 */
uint16 wpaCfgGetLen(wpaCfg_t *config);

/**
 * Builds and returns the string configuration for WPA using 
 * the struct configuration
 *
 * @param[out] str Configuration string built.
 * @param[in] config WPA configuration data.
 * 
 * @return RET_OK if the configuration string was succesfully built.
 * @return Negative number if error.
 *  
 */
int16 wpaCfgGetStr(char *str, wpaCfg_t *config);

/**
 * Processes the WPA configuration
 * 
 * @param[in/out] config Where to store the WPA configuration data.
 * 
 * @return RET_OK if the configuration was processed ok.
 * @return Negative number if error.
 * 
 */
int16 wpaCfgProcess(wpaCfg_t *config);

#ifdef __cplusplus
}
#endif

#endif

#ifndef IDLEMENU_H_INCLUDED
#define IDLEMENU_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

int16 Menu_Reset( uint32 hndlDevice );
int16 Menu_SetTitle( char *lpTitle );
int16 Menu_SetFooter( char *lpTitle );
void Menu_ExitOnInvalidSel( char bSet );
void Menu_BeepOnKeys(char bSet);
void Menu_SetVisaMode(char bSet);
int16 Menu_Add( char *lpItem );
int16 Menu_AddEx( char *lpItem, int bAtivo );
int16 Menu_AddEx2( char *lpItem, int bAtivo, int nRetorno );
int16 Menu_RunEx( uint32 timeout, char* lpKeySel, int start );
int16 Menu_Run( uint32 timeout, char* lpKeySel );

#ifdef __cplusplus
}
#endif

#endif


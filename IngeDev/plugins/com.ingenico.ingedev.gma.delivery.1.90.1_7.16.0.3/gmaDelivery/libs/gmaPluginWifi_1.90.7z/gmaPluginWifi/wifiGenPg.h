
#ifndef WIFI_GEN_PG_H_INCLUDED
#define WIFI_GEN_PG_H_INCLUDED

#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif

#define GEN_PLUGIN_GET_COMM_PG_NAME (1)

#define GEN_PLUGIN_STRUCT_QUERY (2000)
#define GEN_PLUGIN_STRUCT_PG_NAME (2001)

typedef struct genPluginQuery_s genPluginQuery_t;
struct genPluginQuery_s
{
   gmaStructHeader_t header;
   uint32 item;
};

typedef struct genPluginCommPgName_s genPluginCommPgName_t;
struct genPluginCommPgName_s
{
   gmaStructHeader_t header;
   uint8 status;
   char pgName[18+1];
};

int16 pgRegistryWifiGenPg(void);

#ifdef __cplusplus
}
#endif

#endif

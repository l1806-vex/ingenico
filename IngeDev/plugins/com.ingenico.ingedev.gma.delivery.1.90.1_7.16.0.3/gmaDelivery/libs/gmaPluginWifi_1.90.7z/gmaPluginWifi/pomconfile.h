#ifndef POMCONFILE_H_INCLUDED
#define POMCONFILE_H_INCLUDED

#include "messages.h"

#include "lnet.h"
#include "LNetCtrl.h"
#include "LNetSocket.h"
#include "pomConfWpa.h"

#ifdef __cplusplus
extern "C" {
#endif

// Connection Type
#define POM_CONFIG_CONNECT_DHCP  1  //HHT
#define POM_CONFIG_CONNECT_IPFIX 0  //HHT

/** Max size of a network SSID */
#define WIFI_CONFIG_MAX_SSID  (32)

/** Max length (in bytes) of a connection cryptographic key */
#define WIFI_CONFIG_MAX_KEY   (14)

/** Max length of the wpa configuration */
#define WIFI_CONFIG_MAX_WPA   (128)

/** Supported security modes */
enum pomWifiSecurityMode_e
{
   POM_WIFI_SECURITY_NONE = 0,            ///< No security enabled
   POM_WIFI_SECURITY_WEP = 1,             ///< WEP security
   POM_WIFI_SECURITY_WPA = 2              ///< WPA security
};

/** The WiFi module configuration, as stored in flash. */
typedef struct pomConfigWIFI_t pomConfigWIFI_t;
struct pomConfigWIFI_t
{  
   uint16 version;                        ///< File version
   char ssid[WIFI_CONFIG_MAX_SSID];       ///< SSID used for connection
   uint8 securityMode;                    ///< security mode, \see pomWifiSecurityMode_e
   netNiOptPrismWepKeyEntry4_t WepKey;    ///< configuration parameters for WEP security
   char key[WIFI_CONFIG_MAX_KEY * 2 + 1];

   uint8 connectionType; ///< DHCP or IPFIX
   uint32 localIpAddress; //HHT
   uint32 IpSubMask;
   uint32 dns1;
   uint32 dns2;
   uint32 dhcpServer;
   uint32 gateway;
   wpaCfg_t wpaCfg;       					///< WPA Configuration
};

/**
 * \brief Read the configuration file from flash.
 * \return RET_OK if file read correctly.
 */
int16 pomConfigFileRead(void);

/**
 * \brief Return pointer to internal cache for WiFi configuration parameters.
 *
 * This pointer can be used to directly modify the contents of the internal
 * configuration, but a call to pomSaveConFile() must be made to commit those
 * changes to flash.
 */
pomConfigWIFI_t* pomGetConfigWIFI(void);

/**
 * Write the current WiFi configuration in memory to flash.
 * \return RET_OK if file written correctly.
 * \return An error from psyFileErrnoGet() on error.
 */
int16 pomSaveConFile(void);

#ifdef __cplusplus
}
#endif

#endif


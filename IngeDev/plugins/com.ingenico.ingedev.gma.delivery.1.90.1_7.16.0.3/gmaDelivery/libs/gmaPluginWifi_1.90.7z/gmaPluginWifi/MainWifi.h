#ifndef _MAINWIFI_H_
#define _MAINWIFI_H_

#include <unicapt.h>
#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif

#define WIFI_PLUGIN_NAME "commWifi"

/** Icons */
#define ICON_ANTENA_SIZE 13
#define ICON_INFO_SIZE 8

#define ICON_ANTENA_HEIGHT 8
#define ICON_ANTENA_WIDTH 13
#define ICON_INFO_HEIGHT 8
#define ICON_INFO_WIDTH 8
#define WIFI_ICON_POS_X 38	/** Distance from right edge */
#define WIFI_ICON_POS_Y 1	/** Distance from top edge */

#define WIFI_MAX_ICONS 8

/** App Messages */
#define COMM_STATUS_ALREADY_CONNECTED        (0x01)
#define COMM_STATUS_CONNECTED                (0x02)
#define COMM_STATUS_NOT_CONFIGURED           (0x03)
#define COMM_STATUS_NOT_POSSIBLE             (0x04)
#define COMM_STATUS_CONNECTION_ERROR         (0x05)
#define COMM_STATUS_ALREADY_DISCONNECT       (0x06)
#define COMM_STATUS_DISCONNECT               (0x07)

#define COMM_STRUCT_START_CONNECTION         (2002)
#define COMM_STRUCT_CONNECTION_STATUS        (2003)

#define COMM_REQUEST_CONNECT                 (0x01)
#define COMM_REQUEST_DISCONNECT              (0x02)

/**
 * COMM_STRUCT_START_CONNECTION
 * Message received from the application asking the Wifi plugin
 * to connect to the Wifi network with the predefined configuration
 * entered directly in the Wifi plugin
 */
typedef struct commMsgStartConnect_s commMsgStartConnect_t;
struct commMsgStartConnect_s
{
   gmaStructHeader_t header;
   uint32 request;
   uint32 timeout;
};

/**
 * Message send to the application as a reply of the message 
 * COMM_STRUCT_START_CONNECTION 
 */
typedef struct commMsgStartConnectReply_s commMsgStartConnectReply_t;
struct commMsgStartConnectReply_s
{
   gmaStructHeader_t header;
   uint32 status;
};

typedef enum
{
	TYPE_ANTENA,
	TYPE_INFO
} eIconType;

typedef enum
{
	WIFI_NONE,				//0
	WIFI_1,					//1
	WIFI_2,					//2
	WIFI_3,					//3
	WIFI_ERROR,				//4
	WIFI_CONNECTED,			//5
	WIFI_NOT_CONNECTED,		//6
	WIFI_SEARCHING			//7
} eWifiIcons;

typedef struct
{
	uint8 type;
	uint16 *posX;
	uint16 *posY;
} iconType_t;

/** Integrity Check */
#define HMI_HANDLE_OK 0x01

typedef struct
{
	hmiOutputConfig_t s_outputConfig;
	uint8 integrity;
	uint8 Started;
	uint8 connected;
} wifiControl_t;

typedef struct
{
	uint16 antenaX;
	uint16 antenaY;
	uint16 infoX;
	uint16 infoY;
} iconControl_t;
	

int16 pgRegistryWifiPlugin(void);

#ifdef __cplusplus
}
#endif

#endif


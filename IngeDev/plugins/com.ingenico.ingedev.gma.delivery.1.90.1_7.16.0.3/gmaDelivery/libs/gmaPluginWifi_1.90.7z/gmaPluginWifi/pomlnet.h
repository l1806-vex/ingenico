#ifndef POMLNET_H_INCLUDED
#define POMLNET_H_INCLUDED

#include "messages.h"
//#include "Message.h"

#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////
#define POM_LNET_NOT_STARTED       0
#define POM_CONNECT_OK             1

//EMD
#define POM_LNET_START_PENDING     2
#define POM_ERR_OPEN              -1
#define POM_ERR_CHANNEL_NOT_FOUND -2
#define POM_ERR_CONFIG_ERR        -3
#define POM_ERR_START_TIMEOUT     -4
#define POM_ERR_START_ANOTHER     -5
#define POM_ERR_GET_IP_ADDRESSES  -6
#define POM_ERR_SET_GATEWAY       -7
#define POM_ERR_CONFIG_DNS        -8


/////////////////////////////////////////
void pomLNETstart(void);
void pomLNETstartTask(uint32 param);
void pomLNETstop(amgMsg_t *msg);
netNi_t pomGetNetHandle(void);
int8 pomGetLnetStatus(void);
int32 pomLNETLocalIp(void);
int16 pomLNETNetConfig(uint32 *subMask, uint32 *dns1, uint32 *dns2, uint32 *gateway);
//uint8 pomPingToGateway (void);

#ifdef __cplusplus
}
#endif

#endif

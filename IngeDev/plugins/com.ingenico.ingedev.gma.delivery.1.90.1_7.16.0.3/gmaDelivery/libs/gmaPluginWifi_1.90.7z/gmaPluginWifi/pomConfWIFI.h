#ifndef POM_CONFWIFI_H_INCLUDED
#define POM_CONFWIFI_H_INCLUDED

#include "lnet.h"
#include "LNetCtrl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
   uint32 prismMode;       // NET_NI_OPT_PRISM_MODE
   char SSID1[32];         // NET_NI_OPT_PRISM_OWNSSID
   uint32 beaconInterval;  // NET_NI_OPT_PRISM_BEACON
   uint32 wifiChannel;     // NET_NI_OPT_PRISM_OWNCHAN
   char SSID2[32];         // NET_NI_OPT_PRISM_DESIREDSSID
   uint32 rates;           // NET_NI_OPT_PRISM_RATE //bit0, bit1, bit2 & 3
   uint32 authMode;        // NET_NI_OPT_PRISM_AUTH
   uint32 encryptionMode;  // NET_NI_OPT_PRISM_WEP
   netNiOptPrismWepKeyEntry4_t WepKey;//NET_NI_OPT_PRISM_WEPKE
   uint32 selKey;          // NET_NI_OPT_PRISM_WEPAK
   char wifiWpa[512];      // NET_NI_OPT_WPA_CONF
} wifiConfig_t;

void pomWIFIConf(pomConfigWIFI_t *confWIFI);
void pomMenuConfWIFI(pomConfigWIFI_t *confWIFI);

int16 wifiConfigIngenico(netNi_t netNi);
int16 wifiChannelList(char *channelName);
int16 wifiNetNiConfig(netNi_t netNi,pomConfigWIFI_t *pomConfigWIFI); 

#ifdef __cplusplus
}
#endif

#endif

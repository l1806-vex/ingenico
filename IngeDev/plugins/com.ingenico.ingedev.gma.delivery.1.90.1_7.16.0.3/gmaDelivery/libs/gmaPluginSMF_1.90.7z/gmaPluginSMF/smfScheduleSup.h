
#ifndef SMF_SCHEDULE_SUP_H_INCLUDED
#define SMF_SCHEDULE_SUP_H_INCLUDED


#ifdef __cplusplus
extern "C" {
#endif

/**
 * Must be called at startup and after a teleload or
 * a change in the SMF configuration
 */
void smfUpdateScheduleInfo(void);

/**
 * Check if there is a schedule teleload and 
 * returns in numSecs the number of seconds
 * to it.
 * 
 * @param numSecs number of seconds to the next teleload,
 * 0xFFFFFFFF if there is no pending teleload.
 * 
 * @return RET_OK
 */
int16 smfCheckScheduleTeleload(uint32 *numSecs);

/**
 * Save the actual schedule time and date
 */
void smfScheduleConfSave(void);

/**
 * get the next date/time
 */
int16 smfScheduleGet(uint32 *date, uint32 *time);

/**
 * Set the next date/time
 */
int16 smfScheduleSet(uint32 date, uint32 time);

#ifdef __cplusplus
}
#endif
 
#endif


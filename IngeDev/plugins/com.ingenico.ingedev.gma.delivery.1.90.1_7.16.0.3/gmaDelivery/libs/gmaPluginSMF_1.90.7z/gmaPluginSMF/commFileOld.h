
#ifndef COMM_FILE_OLD_H_INCLUDED
#define COMM_FILE_OLD_H_INCLUDED

#include "communic.h"

#ifdef __cplusplus
extern "C" {
#endif

int16 commReadOldConnectionParams(char *fileName, connectionsParameters_t *connParams);

#ifdef __cplusplus
}
#endif

#endif


#if !defined(MAINTENANCE_H)
#define MAINTENANCE_H

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif

int16 mntStartTeleca(void);

int16 mntCheckUnfinishedTeleload(void);

uint8 mntGetStatusNeedTeleload(void);

void mntStartCancelTeleload(void);



/**
 * 
 */
int16 smfAsynSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * 
 */
int16 smfAsynReceive(gclConfig_t *gcl, uint8 *data,
                       uint32 *actuallyRead, uint32 maxLen);

/**
 * 
 */
int16 smfSockSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * 
 */
int16 smfSockReceive(gclConfig_t *gcl, uint8 *data,
                       uint32 *actuallyRead, uint32 maxLen);

/**
 * Get the last error
 */
void mntGetLastError(int16 *gclError, int16 *smfError);

#ifdef __cplusplus
}
#endif

#endif

#ifndef _SMFUTILS_H_
#define _SMFUTILS_H_

#include "communic.h"
#include "MainSMF.h"

#ifdef __cplusplus
extern "C" {
#endif


int16 smfMsgEndDecode (void);
int16 smfMsgDecode (uint8 *msg, uint16 msgLength);
int16 smfMsgNext (void **data);

#ifdef __cplusplus
}
#endif

#endif

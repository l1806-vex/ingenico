#ifndef COMMUNIC_H_INCLUDED
#define COMMUNIC_H_INCLUDED

#include "gcl.h"
#include "gcl_comm.h"
#include "gcl_serial.h"
#include "gcl_sock.h"
#include "smfStructures.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct 
{
   gclTelephone_t telParameters;
   gclAsynTelephone_t asyn;
   char phone[GCL_MAX_PHONE_SIZE + 1];
   char prefix[GCL_MAX_PREFIX_SIZE + 1];
} modem_t;

typedef struct 
{
   gclSerial_t serial;
   char comPortName[7];
} serial_t;

typedef struct connectionsParameters_t
{
	uint16 fileVersion; //This version is 1
	
   uint16 connectionType;
   
   struct 
   {
      gclTelephone_t telParameters;
      gclAsynTelephone_t asyn;
      char phone[GCL_MAX_PHONE_SIZE + 1];
      char prefix[GCL_MAX_PREFIX_SIZE + 1];
   } modem;
   
   struct 
   {
      gclTelephone_t telParameters;
      char phone[GCL_MAX_PHONE_SIZE + 1];
      char prefix[GCL_MAX_PREFIX_SIZE + 1];
   } modemSyn;

   struct
   {
      gclSerial_t serial;
      char comPortName[7];
   } serial;
   
   struct 
   {
      gclSock_t sockParams;
      char ipAddress[15+1];
      char tcpPort[5+1];
      char hostName[GCL_MAX_HOST_NAME];
   } sockConn;
   
} connectionsParameters_t;

typedef struct
{
   char CallInfo[4];
   uint8 Reason;
   uint8 Retries;
	uint32 date;
	uint32 time;
} SmfConfig;

int16 commSetCommType(uint32 hmiHandle, uint32 touchHandle);

int16 commConfigureConnection(uint32 hmiHandle, uint32 touchHandle);

int16 commConfigureGCL(void);

int16 commUpdateCfg (connectionsParameters_t *cfg, uint32 requests);

void smfWriteSerialCfg (smfStructCfgSerial_t *cfg);

void smfWriteModemCfg (smfStructCfgModem_t *cfg);

void smfWriteCommType (smfStructCommType_t *cfg);

void smfWriteSMFCfg (smfStructCfgSMF_t *cfg);

void smfWriteSocketCfg (smfStructCfgSocket_t *cfg);

void SaveConfiguration(void);

void smfSaveConfiguration(void);

int16 commReadConfigFileSt(void);

#ifdef __cplusplus
}
#endif

#endif


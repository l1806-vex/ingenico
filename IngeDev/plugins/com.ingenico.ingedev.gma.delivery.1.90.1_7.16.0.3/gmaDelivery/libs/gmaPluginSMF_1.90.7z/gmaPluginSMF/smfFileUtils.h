
#ifndef SMF_FILE_UTILS_H_INCLUDED
#define SMF_FILE_UTILS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

typedef void * smfFileUtilHandle;

/**
 * Open the file
 * 
 * @param type -> 0 for read 1 for write
 */
int16 smfFileUtilOpen(smfFileUtilHandle *handle, char *fileName, uint8 type);

int16 smfFileUtilClose(smfFileUtilHandle handle);

int16 smfFileUtilRead(smfFileUtilHandle handle, uint8 *data, uint16 *size);

int16 smfFileUtilWrite(smfFileUtilHandle handle, uint8 *data, uint16 size);

#ifdef __cplusplus
}
#endif

#endif


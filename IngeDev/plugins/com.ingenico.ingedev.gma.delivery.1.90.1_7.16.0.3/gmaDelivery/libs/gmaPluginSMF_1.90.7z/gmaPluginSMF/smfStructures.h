
#ifndef SMF_STRUCTURES_H_INCLUDED
#define SMF_STRUCTURES_H_INCLUDED

#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Enumerations
 */
typedef enum
{
   SMF_SERIAL,
   SMF_MODEM,
   SMF_SOCKET
} eCommType;

typedef enum
{
   DECODE_OK,
   DECODE_END,
   DECODE_ERROR
} eDecodeResult;

/**
 * Defines for message structures
 */
#define SMF_STRUCT_START        (0x2000)
#define SMF_STRUCT_COMM_TYPE    (0x2001)
#define SMF_STRUCT_CFG_SERIAL   (0x2002)
#define SMF_STRUCT_CFG_MODEM    (0x2003)
#define SMF_STRUCT_CFG_SMF      (0x2004)
#define SMF_STRUCT_RESULT       (0x2005)
#define SMF_STRUCT_SCHEDULE_MNT (0x2006)
#define SMF_STRUCT_CFG_SOCKET   (0x2007)


/**
 * Generic defines
 */
#define MAX_PHONE_SIZE 32
#define MAX_PREFIX_SIZE 3
#define MAX_PORT_NAME_SIZE 6
#define CALL_INFO_SIZE 4




/**
 * SMF start structure
 */
typedef struct
{
	gmaStructHeader_t header;
} smfStructStart_t;

/**
 * SMF communication type structure
 */
typedef struct
{
	gmaStructHeader_t header;
	uint32 type;
} smfStructCommType_t;

/**
 * SMF Modem configuration structure
 */
typedef struct
{
   gmaStructHeader_t header;
   uint8 modulationType;                    //!< modulation type (see unicapt documentation for more details)
   uint8 minSpeed;                          //!< minimum connection speedy (see unicapt documentation for more details) 
   uint8 maxSpeed;                          //!< maximum connection speedy (see unicapt documentation for more details)
   uint8 countryCode;                       //!< define the country code (see unicapt documentation for more details)
   uint8 dataCompression;                   //!< define the data compression type (see unicapt documentation for more details)
   uint8 errorCorrection;                   //!< define the error correction type (see unicapt documentation for more details)
   char phone[MAX_PHONE_SIZE + 1];
   char prefix[MAX_PREFIX_SIZE + 1];
   uint8 detectDialTone;                    //!< if the modem will try to detect the dial tone before dial
   uint8 detectLine;                        //!< if 0 there will be no detect line attempt. The line detection is made by the os reading the line voltage
                                            //! and with this information detecting if there is or not a line conect to the terminal
   uint8 useToneDialing;                    //!< 
   uint8 ringMode;							     //!<  ring mode (see unicapt documentation for more details)
   uint8 ringNumber;                        //!< ring number (see unicapt documentation for more details)
} smfStructCfgModem_t;

/**
 * SMF Serial configuration structure
 */
typedef struct
{
   gmaStructHeader_t header;
   uint8 speed;
   char comPortName[MAX_PORT_NAME_SIZE + 1];
} smfStructCfgSerial_t;

/**
 * SMF configuration structure
 */
typedef struct
{
   gmaStructHeader_t header;
   
   char CallInfo[CALL_INFO_SIZE];
   uint8 Reason;
   uint8 Retries;
   uint16 rfu;
} smfStructCfgSMF_t;

/**
 * SMF result structure
 */
typedef struct
{
   gmaStructHeader_t header;
   int16 result;
   uint16 rfu;
} smfStructResult_t;

/**
 * SMF structure to schedule an event
 * with structID \ref SMF_STRUCT_SCHEDULE_MNT
 */
typedef struct smfStructScheduleMnt_st smfStructScheduleMnt_t;

/**
 * SMF structure to schedule an event
 * with structID \ref SMF_STRUCT_SCHEDULE_MNT
 */
struct smfStructScheduleMnt_st
{
	gmaStructHeader_t header;
	/**
	 * What to do:
	 * - 2 -> ask for the actual date/time
	 * - 1 -> set the next maintenance date/time
	 * - 0 -> delete the actual schedule
	 */
	 uint16 action;
	 uint16 rfu;
	 
	 uint32 date; //!< schedule date
	 uint32 time; //!< schedule time
};

/**
 * SMF structure to configure the socket connection
 * with structID \ref SMF_STRUCT_CFG_SOCKET
 */
typedef struct smfStructCfgSocket_st smfStructCfgSocket_t;
/**
 * SMF structure to configure the socket connection
 * with structID \ref SMF_STRUCT_CFG_SOCKET
 */
struct smfStructCfgSocket_st
{
	gmaStructHeader_t header;
	/**
	 * Ip address in the form "xxx.xxx.xxx.xxx",
	 * if host name not used
	 */
	char ipAddress[15+1];
	/**
	 * tcp port
	 */
	char tcpPort[5+1];
	char rfu[2];
	/**
	 * host name if IP not used
	 */
	char hostName[32];
};

#ifdef __cplusplus
}
#endif

#endif

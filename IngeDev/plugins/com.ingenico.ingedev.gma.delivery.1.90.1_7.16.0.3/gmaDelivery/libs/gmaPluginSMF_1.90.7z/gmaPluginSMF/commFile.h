
#ifndef COMM_FILE_H_INCLUDED
#define COMM_FILE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

typedef struct fieldDescription_st fieldDescription_t;

struct fieldDescription_st
{
	uint16 fieldId;
	uint8  fieldSize;
	uint32 offSet;
};

int16 commReadConnectionParams(char *fileName, const fieldDescription_t *descr, void *params);

int16 commSaveConfigFile(char *fileName, const fieldDescription_t *descr, void *params);

#ifdef __cplusplus
}
#endif

#endif


#ifndef MANAGE_GSM_H_INCLUDED
#define MANAGE_GSM_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


int16 mgsmInitGsm(uint32 hmiHandle);

#ifdef __cplusplus
}
#endif

#endif

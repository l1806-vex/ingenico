#ifndef _MAINSMF_H_
#define _MAINSMF_H_


#include "smfStructures.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Plug-in name
 */
#define GMA_PG_NAME_MAINTENANCE "pgSMF"

/**
 * Defines for dynamic configuration
 */
#define SMF_START_MAINTENANCE (0x01)
#define SMF_DELETE_SCHEDULE_ENTRY (0x80000000)


int16 pgRegistryPluginSMF (void);

int16 preBroadcastWarning(uint32 events);

#ifdef __cplusplus
}
#endif

#endif

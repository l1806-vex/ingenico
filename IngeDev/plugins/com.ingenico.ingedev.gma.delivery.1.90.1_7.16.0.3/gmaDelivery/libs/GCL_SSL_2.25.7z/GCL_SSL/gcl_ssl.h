/**************************************************************************
                              Property of INGENICO
 *************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    GCL SSL Module
 *  FILEMANE       :    GCLSSL.h
 *  PURPOSE        :
 *  HISTORY
 *
 *  date          author   modifications
 *  2005-05-30    LSM      Creation
 *
 * ------------------------------------------------------------------------
-*/

#ifndef GCL_SSL_H
#define GCL_SSL_H

#include "gcl.h"
#include <LNetSsl.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_ssl.h
 *
 * 
 */

/**
 * \addtogroup ssl_ SSL
 *
 * Use this library when you want to make a SSL connection. The SSL is put up an
 * socket connection, like PPP, GPRS, ethernet, etc. First you need to call the
 * function \ref gclSSLInit, then configure the connection you want (ex: GPRS), then
 * you call the function \ref gclSSLAttach.
 *
 * @{
 */

/**
 * Structure used to store the information of the error, if the error is in the SSL connection part
 */
typedef struct gclSslErrorInfo_st gclSslErrorInfo_t;
/**
 * Structure used to store the information of the error, if the error is in the SSL connection part
 */
struct gclSslErrorInfo_st
{
	/**
	 * SSL function that returns an error, see the GCL_SSL_FUNC_XXX defines
	 */
	uint16 sslFunc;
	/**
	 * return code of the function.
	 * If the return code is SSL_ERR_ERROR_SSL, the 2 other fields \ref contextFunction
	 * \ref contextReason, or \ref sessionFunction, \ref sessionReason has more information about the error.
	 */
	int16  ret;
	/**
	 * information retrieve from the function sslContextErrorGet
	 * when the return code of the SSL function is SSL_ERR_ERROR_SSL
	 */
	sslFunction_t contextFunction;
   /**
	 * information retrieve from the function sslContextErrorGet
	 * when the return code of the SSL function is SSL_ERR_ERROR_SSL
	 */
	sslReason_t   contextReason;
	/**
	 * information retrieve from the function sslSessionErrorGet
	 * when the return code of the SSL function is SSL_ERR_ERROR_SSL
	 */
	sslFunction_t sessionFunction;
   /**
	 * information retrieve from the function sslSessionErrorGet
	 * when the return code of the SSL function is SSL_ERR_ERROR_SSL
	 */
	sslReason_t   sessionReason;
};

/**
 * Max size of the certificate file
 */
#define MAX_CERTIFICAT_FILE_SIZE   5000
/**
 * 
 */
#define MAX_PASSWORD_SIZE   5000

#define GCL_SSL_PRIVKEY_STR    (2) //!< private key in a string
#define GCL_SSL_PRIVKEY_SECRAM (1) //!< Private key in the SEC RAM
#define GCL_SSL_PRIVKEY_DFS    (0) //!< Private key in the DFS

/**
 * SSL configuration
 */
typedef struct
{
	/**
	 * see the LNET documentation for more details.
	 */	
   sslMethod_t       sslMethod;
   /**
    * verify or not the certificate, see the LNET documentation for more details.
    * Actually, the following values are available:
    * - SSL_NO_VERIFY -> the handshake will continue regardless of the verification result
    * - SSL_PEER_VERIFY -> the server's certificate is verified
    */ 
   sslCertVerify_t   sslVerifType;
   /**
    * The terminal certificate name in the DFS, if the server needs to
    * certify the terminal. In this case the private key must be provided
    * too. You can provide the certificate by a string, in this case you must 
    * fill with \\0 this variable and points the sslCertificateStr to the certificate
    * string.
    */
   char              sslCertificatName[PSY_SYS_PATH_MAXLEN + 1];
   /**
    *  The directory in the DFS where the certificates is. To validate the
    * server certificate received in the authentication process.
    */
   char              sslCADir[PSY_SYS_PATH_MAXLEN + 1];
   /**
    * the private key name in the dfs or in the SRAM, see the \ref sslPrivateKeySource. The private key associated with the certificate 
    * passed in the field \ref sslCertificatName.  
    */
   char              sslPrivateKeyName[PSY_SYS_PATH_MAXLEN + 1];
   /**
    * the private key password if the private key is encrypted
    */ 
   char              password[MAX_PASSWORD_SIZE + 1]; 
   /**
    * Session cache mode. One of the following values:
    *  - SSL_SESSION_CACHE_OFF           (0x0000)
    *  - SSL_SESSION_CACHE_CLIENT        (0x0001)
    *  - SSL_SESSION_CACHE_SERVER        (0x0002)
    *  - SSL_SESSION_CACHE_BOTH          (0x0003)
    *  - SSL_SESSION_CACHE_NO_AUTO_CLEAR (0x0080)
    * 
    * See the Lnet documentation for more details
    */
   int32             sessionCacheMode;
   /**
    * If the value of useActions is 0 the ssl will work as the previous
    * version, with the default settings in the actions.
    * The default values are set the following errors to stop the
    * SSL:
    * - SSL_X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT
    * - SSL_X509_V_ERR_CERT_NOT_YET_VALID
    * - SSL_X509_V_ERR_CERT_HAS_EXPIRED
    * - SSL_X509_V_ERR_CERT_SIGNATURE_FAILURE
    * - SSL_X509_V_ERR_CERT_UNTRUSTED
    * 
    * If it was not zero, the action field \ref useActions will be used instead.
    */
   uint8 useActions;
   /**
    * determine what will be checked in the certified when sslVerifType equals
    * SSL_PEER_VERIFY.
    * Each bit in this field has a meaning, see the unicapt documentation for more
    * details.
    * You can use the macros SSL_X509_V_CONTINUE_SET and
    * SSL_X509_V_STOP_SET to define which items will be checked or not.
    * See the OS function sslContextCertificateVerifySet for more
    * informations.
    * The following items can be checked:
    * - SSL_X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT
    * - SSL_X509_V_ERR_UNABLE_TO_DECRYPT_CERT_SIGNATURE
    * - SSL_X509_V_ERR_UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY
    * - SSL_X509_V_ERR_CERT_SIGNATURE_FAILURE
    * - SSL_X509_V_ERR_CERT_NOT_YET_VALID
    * - SSL_X509_V_ERR_CERT_HAS_EXPIRED
    * - SSL_X509_V_ERR_ERROR_IN_CERT_NOT_BEFORE_FIELD
    * - SSL_X509_V_ERR_ERROR_IN_CERT_NOT_AFTER_FIELD
    * - SSL_X509_V_ERR_OUT_OF_MEM
    * - SSL_X509_V_ERR_DEPTH_ZERO_SELF_SIGNED_CERT
    * - SSL_X509_V_ERR_SELF_SIGNED_CERT_IN_CHAIN
    * - SSL_X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY
    * - SSL_X509_V_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE
    * - SSL_X509_V_ERR_INVALID_PURPOSE
    * - SSL_X509_V_ERR_CERT_UNTRUSTED
    * - SSL_X509_V_ERR_CERT_REJECTED
    * - SSL_X509_V_ERR_SUBJECT_ISSUER_MISMATCH
    * - SSL_X509_V_ERR_AKID_SKID_MISMATCH
    * - SSL_X509_V_ERR_AKID_ISSUER_SERIAL_MISMATCH
    * - SSL_X509_V_ERR_KEYUSAGE_NO_CERTSIGN
    */
   uint32 actions[SSL_X509_V_MAX_ERRORS_SLOTS];
   
   /**
    * a list of algorithms that are supported by the terminal
    * and may be used during SSL negociation within
    * that context. Ored combination of SSL_KEY_*,
    * SSL_AUTH_*, SSL_ENC_*, SSL_MAC_*, SSL_VER_*.
    * used in the OS function sslContextSetCipherList.
    * If this value is 0 the function
    * sslContextSetCipherList will not be called
    * and the default LNET configuration will
    * be used.
    */
  	uint32 ciphersList;
  	/**
  	 * ORed combination of an export flag SSL_EXPORT_*
    * and a strength flag SSL_STRENGTH_*.
    * Used in the OS function sslContextSetCipherList.
    * 
    * The function sslContextSetCipherList will only
    * be called if the value of \ref ciphersList is
    * diferent from 0.
    */
  	uint32 exportStrength;
  	/**
    * Set how the private key is passed
    * - \ref GCL_SSL_PRIVKEY_STR    (2) mean that the private key is passed as a string in the 
    * field \ref privateKeyStr
    * - \ref GCL_SSL_PRIVKEY_SECRAM (1) mean that the private key is a security RAM region
    * defined in the item \ref sslPrivateKeyName
    * - \ref GCL_SSL_PRIVKEY_DFS    (0) mean that the private key is a file in the DFS with name
    * in the item \ref sslPrivateKeyName
    */
   uint8 sslPrivateKeySource;
   /**
    * Points to the private key associated with the certificate 
    * passed in the field \ref sslCertificatName. Use this field to
    * pass the private key if you have it directly hardcoded in the code and
    * not in the DFS nor the SRAM. In this case set properly the value of the
    * item \ref sslPrivateKeySource.
    */
   char *privateKeyStr;
   /**
    * Certificates with a lifespan higher than maximumLifespan days will be rejected.
    * If you want to accept any server certificate, put 0 in the value
    */
   uint16 maximumLifespan;
} gclSSL_t;

/**
 * \brief structure used to store the connection configuration
 *
 * This structure store all the configuration. This structure
 * is holded in the \ref gclConfig_t struct field gclExtension. 
 */
typedef struct gclConfigSSL_s gclConfigSSL_t;

/**
 * \brief structure used to store the connection configuration
 *
 * This structure store all the configuration. This structure
 * is holded in the \ref gclConfig_t struct field gclExtension. 
 */
struct gclConfigSSL_s
{
   uint32   sslSession;       // handle ssl session

   int16    (*predial)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        GCL_DIAL
    */
   int16    (*dial)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        GCL_CONNECT
    */
   int16    (*connect)(gclConfig_t*);
   /**
    * \brief Callback that will be called when the state machines goes to
    *        GCL_HANGUP
    */
   int16    (*hangup)(gclConfig_t*);
   

};

/*
 * SSL Function define list, used by function gclSSLGetLastErrorInfo 
 */
#define GCL_SSL_FUNC_sslContextCACertificateLoad    (1)
#define GCL_SSL_FUNC_sslContextCertificateUse       (2)
#define GCL_SSL_FUNC_sslContextPrivateKeyUse        (3)
#define GCL_SSL_FUNC_sslContextNew                  (4)
#define GCL_SSL_FUNC_sslContextCertificateVerifySet (5)
#define GCL_SSL_FUNC_sslContextSetCipherList        (6)

#define GCL_SSL_FUNC_sslSessionNew                  (100)
#define GCL_SSL_FUNC_sslAttachSocket                (101)
#define GCL_SSL_FUNC_sslConnect                     (102)
#define GCL_SSL_FUNC_sslRead                        (103)
#define GCL_SSL_FUNC_sslWrite                       (104)

/**
 * The initial SSL error
 */
#define GCL_SSL_ERROR_START                        GCL_ERR_USER
#define GCL_SSL_ERR_CANNOT_FIND_CA_DIR             (GCL_SSL_ERROR_START-1) //!< didn't find the certificate directory in the DFS
#define GCL_SSL_ERR_CANNOT_FIND_CA_FILE            (GCL_SSL_ERROR_START-2) //!< didn't find the certificate in the DFS
#define GCL_SSL_ERR_FAIL_TO_READ_CA_FILE_STATUS    (GCL_SSL_ERROR_START-3) //!< problem to read one of the certificate file status in the certificate directory
#define GCL_SSL_ERR_CA_FILE_TOO_BIG                (GCL_SSL_ERROR_START-4) //!< one of the certificate file size is bigger than the maximum allowed in the certificate directory
#define GCL_SSL_ERR_FAIL_TO_OPEN_CA_FILE           (GCL_SSL_ERROR_START-5) //!< problem to open one of the certificate file in the certificate directory
#define GCL_SSL_ERR_READ_CA_FILE                   (GCL_SSL_ERROR_START-6) //!< problem to read one of the certificate file in the certificate directory
#define GCL_SSL_ERR_LOAD_CA_FILE                   (GCL_SSL_ERROR_START-7) //!< problem to load the certificate (function sslContextCACertificateLoad)
#define GCL_SSL_ERR_CLOSE_CA_FILE                  (GCL_SSL_ERROR_START-8) //!< problem to close the certificate file
#define GCL_SSL_ERR_FIND_NEXT_CA_FILE              (GCL_SSL_ERROR_START-9) //!< error when looking for certificates
#define GCL_SSL_ERR_FIND_FILE_CLOSE                (GCL_SSL_ERROR_START-10) //!< problem in the function psyFileFindClose used to finish the certificate serach
#define GCL_SSL_ERR_CANNOT_FIND_CERTIFICAT_FILE    (GCL_SSL_ERROR_START-11) //!< the certificate was not found in the terminal
#define GCL_SSL_ERR_CERTIFICAT_FILE_TOO_BIG        (GCL_SSL_ERROR_START-12) //!< the certificate file is bigger than the maximum allowed size
#define GCL_SSL_ERR_FAIL_TO_OPEN_CERTIFICAT_FILE   (GCL_SSL_ERROR_START-13) //!< problem to open the certificate file
#define GCL_SSL_ERR_FAIL_TO_READ_CERTIFICAT_FILE   (GCL_SSL_ERROR_START-14) //!< problem to read the certificate file
#define GCL_SSL_ERR_FAIL_TO_LOAD_CERTIFICAT_FILE   (GCL_SSL_ERROR_START-15) //!< problem to load the certificate (function sslContextCACertificateLoad)
#define GCL_SSL_ERR_FAIL_TO_CLOSE_CERTIFICAT_FILE  (GCL_SSL_ERROR_START-16) //!< problem to close the certificate file
#define GCL_SSL_ERR_CANNOT_FIND_PRIVATEKEY_FILE    (GCL_SSL_ERROR_START-17) //!< the sslPrivateKeyName file was not fount in the terminal
#define GCL_SSL_ERR_PRIVATEKEY_FILE_TOO_BIG        (GCL_SSL_ERROR_START-18) //!< the private key file is bigger than the allowed maximum
#define GCL_SSL_ERR_FAIL_TO_OPEN_PRIVATEKEY_FILE   (GCL_SSL_ERROR_START-19) //!< problem to open the private key file
#define GCL_SSL_ERR_FAIL_TO_READ_PRIVATEKEY_FILE   (GCL_SSL_ERROR_START-20) //!< problem to read the private key file
#define GCL_SSL_ERR_FAIL_TO_LOAD_PRIVATEKEY_FILE   (GCL_SSL_ERROR_START-21) //!< problem to load the private key (function sslContextCACertificateLoad)
#define GCL_SSL_ERR_FAIL_TO_CLOSE_PRIVATEKEY_FILE  (GCL_SSL_ERROR_START-22) //!< problem to close the private key file
#define GCL_SSL_ERR_NO_CONTEXT                     (GCL_SSL_ERROR_START-23) //!< Probably the function sslInit was not called before start the gcl connection
#define GCL_SSL_ERR_CREATE_CONTEXT                 (GCL_SSL_ERROR_START-24) //!< error when creating the context (sslContextNew)
#define GCL_SSL_ERR_SET_VERIFY_TYPE                (GCL_SSL_ERROR_START-25) //!< error in the function (sslContextCertificateVerifySet)
#define GCL_SSL_ERR_CREATE_SESSION                 (GCL_SSL_ERROR_START-26) //!< error creating a session (sslSessionNew)
#define GCL_SSL_ERR_ATTACH_SOCKET                  (GCL_SSL_ERROR_START-27) //!< error attaching a socket (sslAttachSocket)
#define GCL_SSL_ERR_CONNECT                        (GCL_SSL_ERROR_START-28) //!< error in the ssl Connection attempt
#define GCL_SSL_ERR_MALLOC                         (GCL_SSL_ERROR_START-29) //!< error in the malloc function to allocate memory to the load the certificate in the memory
#define GCL_SSL_ERR_CONNECTION_TYPE                (GCL_SSL_ERROR_START-30) //!< if the connection type is not the one that permit the SSL
#define GCL_SSL_ERR_ATTACHMENT                     (GCL_SSL_ERROR_START-31) //!< error when attaching the SSL connection
#define GCL_SSL_ERR_CIPHER_LIST_SET                (GCL_SSL_ERROR_START-32) //!< error in the function sslContextSetCipherList
#define GCL_SSL_ERR_NO_PRIVATEKEY                  (GCL_SSL_ERROR_START-33) //!< no private key provided in the privateKeyStr entry (structure \ref gclSSL_t) when the sslPrivateKeySource is \ref GCL_SSL_PRIVKEY_STR, or bad value in the sslPrivateKeySource (structure \ref gclSSL_t).
#define GCL_SSL_NO_SSL_ERROR                       (GCL_SSL_ERROR_START-34) //!< no SSL error 
#define GCL_SSL_ERROR_READ_SERV_CERTIFICATE        (GCL_SSL_ERROR_START-35) //!< Error while reading the server certificate
#define GCL_SSL_ERR_CERTIFLIFESPAN                 (GCL_SSL_ERROR_START-36) //!< Certificate life span small than required

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclSSLId(char *zcOut);

/**
 * Function to get more information about a SSL error. Note
 * that before start a connection you must call the function
 * \ref gclSSLSresetError to reset any pending error.
 * 
 * @param errorInfo a pointer to the error information structure
 * 
 * @return RET_OK the last error was a SSL error and the information about the error
 * is inside the errorInfo structure
 * @return GCL_SSL_NO_SSL_ERROR The last error was not a SSL error. No information available in errorInfo. 
 */
int16 gclSSLGetLastErrorInfo(gclSslErrorInfo_t *errorInfo);

/**
 * Reset the internal variable that store the last
 * occured error info. Must be called after a connection
 * attempt to have a real return in the function \ref gclSSLGetLastErrorInfo
 */
void gclSSLSresetError(void);

/**
 * \brief Configure the SSL connection. Normally, you first call this function to configure the
 * SSL , than configure the communication connection and than call \ref gclSSLAttach
 *
 * @param SSLConfig (I) the SSl configuration data
 *
 * @return RET_OK no errors
 * @return \ref GCL_SSL_ERR_CREATE_CONTEXT
 * @return \ref GCL_SSL_ERR_MALLOC
 * @return \ref GCL_SSL_ERR_CANNOT_FIND_CA_DIR
 * @return \ref GCL_SSL_ERR_FAIL_TO_READ_CA_FILE_STATUS
 * @return \ref GCL_SSL_ERR_CA_FILE_TOO_BIG
 * @return \ref GCL_SSL_ERR_FAIL_TO_OPEN_CA_FILE
 * @return \ref GCL_SSL_ERR_READ_CA_FILE
 * @return \ref GCL_SSL_ERR_LOAD_CA_FILE
 * @return \ref GCL_SSL_ERR_CLOSE_CA_FILE
 * @return \ref GCL_SSL_ERR_FIND_NEXT_CA_FILE
 * @return \ref GCL_SSL_ERR_FIND_FILE_CLOSE
 * @return \ref GCL_SSL_ERR_CANNOT_FIND_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_CERTIFICAT_FILE_TOO_BIG
 * @return \ref GCL_SSL_ERR_FAIL_TO_OPEN_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_OPEN_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_READ_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_LOAD_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_CLOSE_CERTIFICAT_FILE
 * @return \ref GCL_SSL_ERR_CANNOT_FIND_PRIVATEKEY_FILE
 * @return \ref GCL_SSL_ERR_PRIVATEKEY_FILE_TOO_BIG
 * @return \ref GCL_SSL_ERR_FAIL_TO_OPEN_PRIVATEKEY_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_READ_PRIVATEKEY_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_LOAD_PRIVATEKEY_FILE
 * @return \ref GCL_SSL_ERR_FAIL_TO_CLOSE_PRIVATEKEY_FILE
 * @return \ref GCL_SSL_ERR_SET_VERIFY_TYPE
 */
int16 gclSSLInit(gclSSL_t *SSLConfig);

/**
 * Free the SSL context.
 *
 * @return always RET_OK
 */
int16 gclSSLTerminate(void);

/**
 * \brief Attach the SSL to the last communication type entered in the gcl.
 * You should configure the connection (GPRS, Ethernet, PPP, etc). Than you call the gclSSLAttach
 * to use the SSL in the connection.
 * 
 * @return RET_OK no errors
 * @return \ref GCL_ERR_CONN_LIST_FULL
 * @return \ref GCL_ERR_INTERNAL_ERR
 * @return \ref GCL_SSL_ERR_CONNECTION_TYPE
 * @return \ref GCL_SSL_ERR_ATTACHMENT
 */
int16 gclSSLAttach(void);

/**
 * \brief The same as \ref gclSSLAttach, but in this function you can change the
 * send and receive function.
 *
 * \ref gclFunctionSendReceive_t send and receive callback to be used in the connection
 * 
 * @return RET_OK no errors
 * @return \ref GCL_ERR_CONN_LIST_FULL
 * @return \ref GCL_ERR_INTERNAL_ERR
 * @return \ref GCL_SSL_ERR_CONNECTION_TYPE
 * @return \ref GCL_SSL_ERR_ATTACHMENT
 */
int16 gclSSLAttachExt(gclFunctionSendReceive_t *cbs);

/**
 * Reset the SSL, must be called before configure the connections.
 *
 * @return always RET_OK
 */
int16 gclSSLReset(void);

/**
 * This function is called in the preDial State when the ssl is attached to the
 * actual connection, this function only call
 * the specific callback (PreDial) of the communication type choose
 * 
 * @param gcl the configuration of the connection.
 *
 * @return the error code returned by the specific callback of the communication type choose.
 */
int16 gclSSLPreDial(gclConfig_t *gcl);

/**
 * This function is called in the Dial State when the ssl is attached to the
 * actual connection, this function only call
 * the specific callback (Dial) of the communication type choose
 * 
 * @param gcl the configuration of the connection.
 *
 * @return the error code returned by the specific callback of the communication type choose.
 */
int16 gclSSLDial(gclConfig_t *gcl);

/**
 * This function is called in the Connect State when the ssl is attached to the
 * actual connection, this function first call
 * the specific callback (Connect) of the communication type choose.
 * Then the functions to make the SSL connection will be called.
 * 
 * @param gcl the configuration of the connection.
 *
 * @return RET_OK if no errors
 * @return the error code returned by the specific callback of 
 *          the communication type choose
 * @return \ref GCL_SSL_ERR_CREATE_SESSION
 * @return \ref GCL_SSL_ERR_ATTACH_SOCKET
 * @return \ref GCL_SSL_ERR_CONNECT
 */
int16 gclSSLConnect(gclConfig_t *gcl);


/**
 * This function is called in the HangUp State when the ssl is attached to the
 * actual connection, this function first free the sslSession and then call
 * the specific communication callback to finish the connection.
 * 
 * @param gcl the configuration of the connection.
 *
 * @return always RET_OK
 */
int16 gclSSLHangUp(gclConfig_t *gcl);

/**
 * This function is called by the receive callback when the ssl is attached to
 * the actual connection.
 *
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param bufSize (I) the size of the buffer
 *
 * @return RET_OK no errors
 * @return GCL_ERR_RECEIVE an error occurs when receiving data.
 */
int16 gclSSLReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size,
                    uint32 bufSize);

/**
 * This function is called by the send callback when the ssl is attached to
 * the actual connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 * @return RET_OK no errors
 * @return GCL_ERR_SEND error occurs while sending data
 */
int16 gclSSLSend(gclConfig_t *gcl, uint8 *buffer, uint32 size);

/**
 * Retrieve the server certificate of the actual connection. it can be used internally in the login callback
 * if a specific test is required. Can only be called after the connect callback.
 * 
 * @param cert the address of a pointer to a sslVariableCertificate_t structure. The function will make the 
 * pointer points to the server certificate.
 * 
 * @return RET_OK no errors
 * @return GCL_SSL_ERROR_READ_SERV_CERTIFICATE error when tried to get the server certificate.
 */
int16 gclSSLGetServerCertificate(sslVariableCertificate_t **cert);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


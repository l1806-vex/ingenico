
#ifndef RAD_STRINGS_H_INCLUDED
#define RAD_STRINGS_H_INCLUDED

#include <unicapt.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "resources.h"

#define RAD_STR_BASERETURN     IDS_RAD_STR_BASERETURN
#define RAD_STR_LOADING        IDS_RAD_STR_LOADING
#define RAD_STR_CONFIG         IDS_RAD_STR_CONFIG
#define RAD_STR_IN_SER_NUM_1   IDS_RAD_STR_IN_SER_NUM_1
#define RAD_STR_IN_SER_NUM_2   IDS_RAD_STR_IN_SER_NUM_2
#define RAD_CAPT_SYNC_BASE     IDS_RAD_CAPT_SYNC_BASE
#define RAD_CAPT_RADIO         IDS_RAD_CAPT_RADIO
#define RAD_CAPT_CONTACT       IDS_RAD_CAPT_CONTACT
#define RAD_CAPT_TRANSPARENT   IDS_RAD_CAPT_TRANSPARENT
#define RAD_STR_PLEASEWAIT     IDS_RAD_STR_PLEASEWAIT
#define RAD_STR_ERROR          IDS_RAD_STR_ERROR

/**
 * Get the string
 */
char * radGetStringResource(uint16 stringId);

#ifdef __cplusplus
}
#endif

#endif

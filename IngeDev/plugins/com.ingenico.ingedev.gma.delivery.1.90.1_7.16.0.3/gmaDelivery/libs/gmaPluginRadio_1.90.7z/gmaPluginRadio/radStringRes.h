



/*
STRING_RES(RAD_STR_BASERETURN, 			 "RETORNAR BASE",   "RETURN TO BASE")
STRING_RES(RAD_STR_LOADING, 			 "CARREGANDO",      "LOADING")
STRING_RES(RAD_STR_CONFIG,               "CONFIGURACAO",    "CONFIG")
STRING_RES(RAD_STR_IN_SER_NUM_1,         "ENTRE # SERIE",   "INPUT BASE")
STRING_RES(RAD_STR_IN_SER_NUM_2,         "DA BASE",         "SERIAL NUMBER")
STRING_RES(RAD_CAPT_SYNC_BASE,           "sincr. base",     "sync base")
STRING_RES(RAD_CAPT_RADIO,               "modo radio",      "radio mode")
STRING_RES(RAD_CAPT_CONTACT,             "modo contato",    "contact mode")    
STRING_RES(RAD_CAPT_TRANSPARENT,         "modo transp.",    "transp. mode")
STRING_RES(RAD_STR_PLEASEWAIT,           "AGUARDE",         "PLEASE WAIT")
STRING_RES(RAD_STR_ERROR,                "erro",            "error")
STRING_RES(RAD_STR_LAST,                 NULL,              NULL)
*/


#ifndef _MAINRAD_H_
#define _MAINRAD_H_

#include <unicapt.h>
#include <miltypes.h>
#include <rad.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_RAD_ICONS 8

#define ICON_RAD_HEIGHT       8
#define ICON_RAD_WIDTH_BIT    16
#define ICON_RAD_WIDTH_BYTE   (ICON_RAD_WIDTH_BIT>>3)

#define RAD_BASE_ID_FILE           "rad.cfg"
#define RAD_BASE_ID_SIGNATURE      0x42415345
#define RAD_BASE_ID_VERSION        0x00000001

#define RAD_BASE_ERR_SIGNATURE     -1

#define MENU_RAD_RADIO            (0x01)
#define MENU_RAD_CONTACT          (0x02)
#define MENU_RAD_TRANSPARENT      (0x04)
#define MENU_RAD_SYNC_BASE        (0x0F)

#define ICON_RAD_POS_X  (85)
#define ICON_RAD_POS_Y  (1)

/*typedef struct
{
	uint16 status;
	uint16 length;
	uint8 data[];
} radResult_t;
*/
/* information about Radio peripheral */
typedef struct {
	uint8	state;		// state flags (docked, locked, etc)
	uint8	rssi;		// signal strength
} radioStatus_t;

/* async result from radio peripheral */
typedef struct {
	int16	status;
	uint16	length;
	uint8	data[RAD_DATA_LENGTH_MAX];
} radioResult_t;

/**
 * Return TRUE radioStatus.state shows terminal is locked
 */
#define msaIsRadLocked(radioStatus)	\
	((radioStatus.state & RAD_STATE_SERVER_LOCKED) == RAD_STATE_SERVER_LOCKED)

/**
 * Return TRUE radioStatus.state shows terminal is docked
 */
#define msaIsRadDocked(radioStatus)	\
	((radioStatus.state & RAD_STATE_SERVER_DOCKED) == RAD_STATE_SERVER_DOCKED)

#if 0

/**
 * Check if Radio signal is locked on a base, waiting at most <timeout>.
 * Radio peripheral must be *closed* before call.
 * Returns RET_OK if signal is locked, RET_NOK otherwise.
 */
int16 msaRadioCheckLocked(uint32 timeout);

/**
 *	Do a reading of status/signal strength of radio peripheral.
 *	The signal reading may not be accurate!
 */
int16 msaRadioGetStatus(radioStatus_t *radioStatus, uint32 timeout);

#define ICON_LARGE_WIDTH 32
#define ICON_LARGE_HEIGHT 16
#define ICON_SMALL_WIDTH 16
#define ICON_SMALL_HEIGHT 8
#define EAGLE_SHUTDOWN_TIMEOUT 60
#define SHUTDOWN_EVENT_ID 1

/**
 * Integrity check control
 */
#define HMI_HANDLE_OK 0x01
#define RAD_HANDLE_OK 0x02
#define TERM_TYPE_OK  0x04
#define POWER_TYPE_OK 0x08

/**
 * Icon position in screen
 * 
 * x: distance in pixels from screen's right side, -1 = CENTER position
 * y: distance in pixels from screen's top
 */
#define ICON_POS_X (32 + 16 + 16 + 48)
#define ICON_POS_X_SMALL (16 + 8 + 24)
#define ICON_POS_Y 1

typedef enum
{
	TERM_5100,
	TERM_5310,
	TERM_7780,
	TERM_EAGLE,
	TERM_UNKNOWN
} eTermType;

typedef enum
{
	THR_ERROR,
	THR_NOT_DONE,
	THR_RUNNING,
	THR_DONE
} eThreadStatus;

typedef enum
{
	CONN_RADIO,
	CONN_CONTACT,
	CONN_TRANSPARENT
} eConnectionMode;

typedef enum
{
	BAT_LEV0,
	BAT_LEV1,
	BAT_LEV2,
	BAT_LEV3,
	BAT_LEV4,
	BAT_DOCKED,
	BAT_ERROR
} eIconIndex;

typedef struct
{
	uint16 iconPos_x;
	uint16 iconPos_y;
	eConnectionMode Mode;
	eTermType termType;
} RadCtrl_t;

/**
 * Battery level to display
 */

/*
#define GetPorLevel(batteryStatus, batteryConfig) \
	((Control.termType != TERM_EAGLE) ? \
	(((batteryStatus.capacityPercent > batteryConfig.bar_3_4_Threshold) ? BAT_LEV4 : \
		((batteryStatus.capacityPercent > batteryConfig.bar_2_3_Threshold) ? BAT_LEV3 : \
			((batteryStatus.capacityPercent > batteryConfig.bar_1_2_Threshold) ? BAT_LEV2 : \
				((batteryStatus.capacityPercent > batteryConfig.bar_0_1_Threshold) ? BAT_LEV1 : BAT_LEV0))))) : BAT_LEV4)
#define IsPorDocked(batteryStatus) \
	((Control.termType != TERM_EAGLE) ? (batteryStatus.termDocked == POR_TERMINAL_DOCKED) : (Control.powerType == POR_POWER_TYPE_EXTERNAL_SUPPLY))

#define IsPorCharging(batteryStatus) \
	(batteryStatus.batteryState == POR_BATTERY_PACK_CHARGING)	

#define IsPorAlarm(batteryStatus, batteryConfig) \
	(batteryStatus.capacityPercent < batteryConfig.alarmThreshold)

#define IsPorShutdown(batteryStatus, batteryConfig) \
      ((Control.termType != TERM_EAGLE) ? ((batteryStatus.capacityPercent == 0) && !(IsPorDocked (batteryStatus))) : ((batteryStatus.lowBatAlarm == 1) && !(IsPorDocked (batteryStatus))))
	//(batteryStatus.lowBatAlarm == POR_BATTERY_LOW_ALARM)
*/

#endif

int16 pgRegistryPluginRAD(void);

#ifdef __cplusplus
}
#endif

#endif /*_MAINRAD_H_*/

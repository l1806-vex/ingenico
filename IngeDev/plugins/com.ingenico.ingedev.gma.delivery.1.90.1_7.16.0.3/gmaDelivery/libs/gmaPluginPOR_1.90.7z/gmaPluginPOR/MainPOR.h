#ifndef _MAINPOR_H_
#define _MAINPOR_H_

#include "unicapt.h"
#include "miltypes.h"
#include "gmaCustomUtil.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ICON_LARGE_WIDTH 32
#define ICON_LARGE_HEIGHT 16
#define ICON_SMALL_WIDTH 16
#define ICON_SMALL_HEIGHT 8
//#define MAX_ICONS 8
#define EAGLE_SHUTDOWN_TIMEOUT 60
#define SHUTDOWN_EVENT_ID 1

#define GMA_PG_POR_PGNAME ("pgPOR")
	
#define POR_NOTIF_POWER_OFF    (1)

#define POR_MENU_ACTIVATION    (1)
#define POR_MENU_POWEROFF_TIME (2)
#define POR_MENU_DEBUG         (3)
#define POR_MENU_DEBUG_2       (4)

/**
 * Integrity check control
 */
#define HMI_HANDLE_OK 0x01
#define POR_HANDLE_OK 0x02
#define TERM_TYPE_OK  0x04
#define POWER_TYPE_OK 0x08


/**
 * Icon position in screen
 * 
 * x: distance in pixels from screen's right side, -1 = CENTER position
 * y: distance in pixels from screen's top
 */
#define ICON_POS_X (32 + 16 + 16 + 48)
#define ICON_POS_X_SMALL (16 + 30 + 24)
#define ICON_POS_Y 1



typedef enum
{
	THR_ERROR,
	THR_NOT_DONE,
	THR_RUNNING,
	THR_DONE
} eThreadStatus;

typedef enum
{
	BAT_LEV0,
	BAT_LEV1,
	BAT_LEV2,
	BAT_LEV3,
	BAT_LEV4,
	BAT_DOCKED,
	BAT_ERROR,
	BAT_LEV4_EAGLE,
	BAT_DOCKED_EAGLE,
	BAT_LEV0_EAGLE
} eIconIndex;

typedef struct
{
	uint16 iconPos_x;
	uint16 iconPos_y;
	uint8 Enabled;
	uint8 Started;
	uint8 Updated;
	uint8 InShutDown;
	gmaUtilTermType termType;
	porPowerType_t powerType;
} PorCtrl_t;





int16 pgRegistryPluginPOR(void);

#ifdef __cplusplus
}
#endif


#endif /*_MAINPOR_H_*/


#ifndef _PGPORCFG_H_
#define _PGPORCFG_H_

int16 cfgPOffTime (void);
int16 cfgActivation (void);
int16 cfgAppStart(void);
int16 cfgAppEnd(void);
int16 cfgTermUndocked(void);
int16 cfgChkPOffTime(uint8 logicalId);
int16 cfgChkTermType(uint8 termType);
int16 gmaPgPorResetCfg(void);
int16 gmaPgPorReadCfg(void);
int16 gmaPgPorWriteCfg(void);


#endif // _PGPORCFG_H_

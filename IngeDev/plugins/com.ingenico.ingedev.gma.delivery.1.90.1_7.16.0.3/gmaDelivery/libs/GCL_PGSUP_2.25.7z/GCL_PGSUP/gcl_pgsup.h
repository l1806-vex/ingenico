#ifndef _GLC_PGSUP_H_INCLUDED
#define _GLC_PGSUP_H_INCLUDED

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_pgsup.h
 *
 * GCL GMA Communication Plugin Support
 */

/**
 * \addtogroup PGSUP_ GMA Communication plugin Support
 *
 * Support to GMA communication plugin
 *
 * These library is intended for use when you are using the GMA with a
 * communication plug-in and want to open a socket. All the LNET initialization
 * in this case is made in the plug-in. Your code must check if the plug-in is
 * connected before attempt to open and connect a socket. The gclPgSup
 * will modify the gcl callbacks to do it. See the \ref pgsup documentation for more details.
 *
 * This library uses the gmaLib, precisely the module gmaPgMsg, check if you
 * are calling the initialization function of this module. If you don't do that
 * you will receive an error when starting the connection process. Check the GMA
 * documentation to see how to properly initialize the gmaPgMsg module.
 *
 * @{
 */

 
#define GCL_PG_PLUGIN_GET_COMM_PG_NAME         (0x01)

#define GCL_PG_STATUS_ALREADY_CONNECTED        (0x01)
#define GCL_PG_STATUS_CONNECTED                (0x02)
#define GCL_PG_STATUS_NOT_CONFIGURED           (0x03)
#define GCL_PG_STATUS_NOT_POSSIBLE             (0x04)
#define GCL_PG_STATUS_CONNECTION_ERROR         (0x05)
#define GCL_PG_STATUS_ALREADY_DISCONNECT       (0x06)
#define GCL_PG_STATUS_DISCONNECT               (0x07)

#define GCL_PG_PLUGIN_STRUCT_QUERY             (2000)
#define GCL_PG_PLUGIN_STRUCT_PG_NAME           (2001)
#define GCL_PG_PLUGIN_STRUCT_START_CONNECT     (2002)
#define GCL_PG_PLUGIN_STRUCT_CONN_REPLY        (2003)


#define GCL_PG_REQUEST_CONNECT                 (0x01)
#define GCL_PG_REQUEST_DISCONNECT              (0x02)


#define GCL_PG_SUP_MAX_CONN (5)


#define GCL_PGSUP_ERR_START                    (GCL_ERR_USER - 40)
#define GCL_PGSUP_ERR_PLUGIN_NOT_CONFIGURED    (GCL_PGSUP_ERR_START - 0)
#define GCL_PGSUP_ERR_PG_CONNECT               (GCL_PGSUP_ERR_START - 1)
#define GCL_PGSUP_ERR_PLUGIN_NOT_FOUND         (GCL_PGSUP_ERR_START - 2)

#define GCL_PGSUP_FUNC_CONN_LIST_CHECK         (1)
#define GCL_PGSUP_FUNC_gclReadLastConnection   (2)
#define GCL_PGSUP_FUNC_gclWriteLastConnection  (3)
#define GCL_PGSUP_FUNC_gmaPgMsgOpenComm1       (4)
#define GCL_PGSUP_FUNC_CheckAnsPgName          (5)
#define GCL_PGSUP_FUNC_gmaPgMsgOpenComm2       (6)
#define GCL_PGSUP_FUNC_gmaPgMsgSendMsg         (7)
#define GCL_PGSUP_FUNC_gmaPgMsgReceiveMsg      (8)
#define GCL_PGSUP_FUNC_gsmPgSendConnReqSts     (9)

/**
 * store the information of the last error occurred in the gclPGSUP.
 */
typedef struct gclPGSUPErrorInfo_st gclPGSUPErrorInfo_t;

/**
 * store the information of the last error occurred in the gclPGSUP.
 */
struct gclPGSUPErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_PGSUP_FUNC_XXX defines
	 */
	uint16 pgsupFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclPGSUPErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PGSUP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclPGSUPGetLastErrorInfo(gclPGSUPErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclPGSUPGetLastErrorInfo
 */
void gclPGSUPSerrorReset(void);

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclPgSupId(char *zcOut);

 /**
 * Reset the gclPgSup library. Must be called before start to add connections
 * to the GCL.
 */
int16 gclPgSupReset(void);

/**
 * Attach the GMA plugin support to the socket connection type.
 * before open the socket a message to the available communication
 * plugin is sent asking it to start the LNET in the available communication
 * type.
 */
int16 gclPgSupAttach(uint32 connTimeout);



/**
 * @}
 */

#ifdef __cplusplus
}
#endif

 
#endif


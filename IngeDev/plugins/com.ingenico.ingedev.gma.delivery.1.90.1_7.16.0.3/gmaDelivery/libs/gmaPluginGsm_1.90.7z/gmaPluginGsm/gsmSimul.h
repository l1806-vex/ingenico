/*
 * GSM module.
 * Author: Roberto Belli
 * Creation Date: 21/10/2004
 */

#ifndef GSM_SIMUL_H_INCLUDED
#define GSM_SIMUL_H_INCLUDED

#include "gsm.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

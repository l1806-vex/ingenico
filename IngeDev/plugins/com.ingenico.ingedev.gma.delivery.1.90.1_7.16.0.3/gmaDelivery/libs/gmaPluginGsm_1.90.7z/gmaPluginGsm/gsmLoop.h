/*
 * GSM module.
 * Author: Roberto Belli
 * Creation Date: 21/10/2004
 */

#ifndef GSM_LOOP_H_INCLUDED
#define GSM_LOOP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GSM_EVENT_PRECONFIG_GSM      (0)
#define GSM_EVENT_START_GSM          (1)
#define GSM_EVENT_STOP_GSM           (2)
#define GSM_EVENT_SERIAL_AT_COMMANDS (3)
#define GSM_EVENT_VOCAL              (4)
#define GSM_EVENT_SET_GSM_SPEED      (5)
#define GSM_EVENT_GPRS_ON            (6)
#define GSM_EVENT_GPRS_OFF           (7)
#define GSM_EVENT_TURN_MODEM_OFF     (8)
#define GSM_EVENT_TURN_MODEM_ON      (9)
#define GSM_EVENT_GPRS_OFF_NOW       (10)
#define GSM_EVENT_GPRS_START_DEFAULT (11)
#define GSM_EVENT_SET_GPRS_TIMEOUT   (12)
#define GSM_EVENT_TURN_MODEM_SLEEP   (13)
#define GSM_EVENT_TOGGLE_PIN_REQUEST (14)
#define GSM_EVENT_UPDATE_PIN         (15)
#define GSM_EVENT_RESTART_GSM        (16)
	

/**
 * Define status of the modem connection.
 * This signal errors "deeper" than GSM problems, this signals errors
 * when the modem cannot be contacted.
 */
enum gsmModemStatus_t {
   GSM_MODEM_OK,           ///<Modem is OK.
   GSM_MODEM_SERIAL_ERR,   ///<Serial error, cannot communicate with serial.
   GSM_MODEM_NOT_STARTED   ///<Modem not yet started.
};

/*
 * Return the Task Processing status.
 */
uint16 gsmloopGetTaskStatus(void);

/**
 * Return the current modem status.
 */
enum gsmModemStatus_t gsmloopGetModemStatus(void);

/**
 * Set the modem status.
 * This is usually called by functions inside GSMCOMMGSM.C
 */
void gsmloopSetModemStatus(enum gsmModemStatus_t modemStatus);

/**
 * Start the GSM/GPRS control task.
 */
int16 gsmloopStart(void);

/**
 * Send a command to the GSM/GPRS task.
 * See the GSM_EVENT_... defines.
 */
int16 gsmloopOrder(uint32 order, uint32 value);

/**
 * Request to the task that the GSM/GPRS status be checked and
 * sent to IDLE.
 */
int16 gsmloopRequestStatusUpdate(void);

/*
 * Send a 'forced status update' to the task, but only update the
 * signal level;
 */
int16 gsmloopRequestStatusUpdateOnlyLevel(void);


/**
 * Wait until all pending commands on the task are done.
 * Note that this does not wait until the task is idle, only that all pending
 * commands _up to this point_ are completed.
 */
int16 gsmloopWaitResult(void);

/**
 * Inform the task that an application is starting.
 */
int16 gsmloopAppStart(void);

/**
 * Inform the task that an application has just finished.
 */
int16 gsmloopAppEnd(uint8 requestUpdate);

/*
 * Mark to retry the connection the next time that the terminal returns to
 * idle state.
 */
int16 gsmloopReconnectOnNextIdleState(void);

/**
 * Only call this function from the LOOP task
 */
void gsmLoopSetDisconnectionTimeout(void);

/*
 * gsmLoopRetryCheck
 * 
 * Checks if the current time is allowed to retry a new GPRS connection, if
 * a previous attachment was done.
 * This function automatically resets the internal time variable if the return value is TRUE.
 * return: (-1) - INVALID, No previous try was done. But this can be understood as TRUE. 
 *         ( 0) - FALSE, Not enough time has passed since last connection try. Not allowed.
 *         ( 1) - TRUE, Now is allowed to do a new retry.
 */
int gsmLoopRetryCheck(psyTime_t timeout);

/*
 * gsmLoopRetrySet
 * 
 * Sets the internal time variable with the current time.
 */
void gsmLoopRetrySet(void);

void gsmLoopRetryReset(void);


#ifdef __cplusplus
}
#endif

#endif

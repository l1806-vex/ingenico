
#ifndef GSM_MESSAGES_H_INCLUDED
#define GSM_MESSAGES_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GSM_MSG_TURN_OFF_STATUS     0x01
#define GSM_MSG_CONFIG_PIN_PUK      0x02
#define GSM_MSG_CHECK_SIGNAL_STATUS 0x03
#define GSM_MSG_CONFIG_GSM_SPEED    0x04
#define GSM_MSG_TURN_OFF_GPRS       0x05
#define GSM_MSG_TURN_ON_GPRS        0x06
#define GSM_MSG_GET_IMEI_IMSI       0x07

#define GSM_STRUCT_START_CONNECTION         (2002)
#define GSM_STRUCT_CONNECTION_STATUS        (2003)
#define GSM_STRUCT_GPRS_PARAMETERS           (2004)

#define GSM_STATUS_ALREADY_CONNECTED        (0x01)
#define GSM_STATUS_CONNECTED                (0x02)
#define GSM_STATUS_NOT_CONFIGURED           (0x03)
#define GSM_STATUS_NOT_POSSIBLE             (0x04)
#define GSM_STATUS_CONNECTION_ERROR         (0x05)
#define GSM_STATUS_ALREADY_DISCONNECT       (0x06)
#define GSM_STATUS_DISCONNECT               (0x07)


#define GSM_REQUEST_GPRS_CONNECT             (0x01)   // used by GCL
#define GSM_REQUEST_GPRS_DISCONNECT          (0x02)   // used by GCL
#define GSM_REQUEST_CLOSE_GSM_HANDLE         (0x03)   // used by GCL
#define GSM_REQUEST_GPRS_DONE                (0x04)   // GPRS is not in use anymore
#define GSM_REQUEST_RESET_GSM_HANDLE         (0x05)   // used by GCL

#include "gmaDefines.h"

/**
 * Internal structure of a connection request.
 * This is the structure that the GSMLOOP task expects to receive.
 */
typedef struct gsmMsgUser1GprsOn_st
{
   uint8 type; // fix 0x82
   uint8 subType; // 0x0
   uint32 queueId;
   char apn[64+1];
   char user[22+1];
   char password[22+1];
   uint32 timeout;
   char phone[15+1];
}gsmMsgUser1GprsOn_t;

/**
 * Format of a reply with the IMEI/IMSI values.
 */
typedef struct gsmMsgReplyImeiImsi_st
{
   char imei[17];
   char imsi[17];
}gsmMsgReplyImeiImsi_t;



/**
 * GSM_STRUCT_START_CONNECTION
 * Message received from the application asking the GSM plugin
 * to connect to the GPRS network with the predefined configuration
 * entered directly in the GSM plugin
 */
typedef struct gsmMsgStartConnect_s gsmMsgStartConnect_t;
struct gsmMsgStartConnect_s
{
   gmaStructHeader_t header;
   uint32 request;
   uint32 timeout;
};

/**
 * Format of a message with the GPRS parameters to be used for the next
 * connection.
 */
typedef struct gsmMsgGprsParameters_s gsmMsgGprsParameters_t;
struct gsmMsgGprsParameters_s
{
   gmaStructHeader_t header;
   char apn[64];
   char user[24];
   char password[24];
};

/**
 * Message send to the application as a reply of the message 
 * GSM_STRUCT_START_CONNECTION 
 */
typedef struct gmaMsgStartConnectReply_s gmaMsgStartConnectReply_t;
struct gmaMsgStartConnectReply_s
{
   gmaStructHeader_t header;
   uint32 status;
};

#ifdef __cplusplus
}
#endif

#endif

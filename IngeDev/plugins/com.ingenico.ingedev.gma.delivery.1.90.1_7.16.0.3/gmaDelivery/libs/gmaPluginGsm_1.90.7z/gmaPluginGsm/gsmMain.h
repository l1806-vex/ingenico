
#ifndef GSM_MAIN_H_INCLUDED
#define GSM_MAIN_H_INCLUDED

#define GMA_PG_GSM_PGNAME ("commGsm")

#ifdef __cplusplus
extern "C" {
#endif


uint8 gsmMainGetPluginId(void);

int16 pgRegistryGsmPlugin(void);

#ifdef __cplusplus
}
#endif

#endif

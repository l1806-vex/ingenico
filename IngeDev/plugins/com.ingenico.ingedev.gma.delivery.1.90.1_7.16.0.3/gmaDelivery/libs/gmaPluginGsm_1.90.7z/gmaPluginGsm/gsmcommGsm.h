/*
 * GSM module.
 * Author: Roberto Belli
 * Creation Date: 21/10/2004
 */

#ifndef GSM_COMM_GSM_H_INCLUDED
#define GSM_COMM_GSM_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GSM_PLACE_OPEN_GSM_HANDLE  (1)
#define GSM_PLACE_TURN_ON_OFF_GSM  (2)
#define GSM_PLACE_GET_IMEI         (3)
#define GSM_PLACE_GET_PIN_STATUS   (4)
#define GSM_PLACE_CHECK_PINPUK_REQ (5)
#define GSM_PLACE_ENTER_PIN        (6)
#define GSM_PLACE_GET_IMSI         (7)
#define GSM_PLACE_SET_OPERATOR     (8)
#define GSM_PLACE_GET_SIGSTRENGHT  (9)
#define GSM_PLACE_PRE_INIT_GSM     (10)  
#define GSM_PLACE_OPEN_COM_MODEM3  (11)
#define GSM_PLACE_SET_VOLUME_GSM   (12)
#define GSM_PLACE_GET_CCID         (13)
#define GSM_PLACE_7910_FIX         (14)
#define GSM_PLACE_TRY_OPERATOR     (15)
#define GSM_PLACE_CFG_PIN_STATUS   (16)

#define GPRS_PLACE_SET_ATTACH_STATUS   (50)
#define GPRS_PLACE_GET_ATTACH_STATUS   (51)
#define GPRS_PLACE_SET_PDP_CONTEXT     (52)
#define GPRS_PLACE_SET_QOS             (53)
#define GPRS_PLACE_PDP_ACTIVATE        (54)
#define GPRS_PLACE_GET_NET_STAT        (55)
#define GPRS_PLACE_CHECK_APN           (56)
#define GPRS_PLACE_GSM_HANGUP          (57)
#define GPRS_PLACE_OPEN_LNET           (80)
#define GPRS_PLACE_GET_CHANNEL_LIST    (81)
#define GPRS_PLACE_CONFIG_SET          (82)
#define GPRS_PLACE_START_LNET          (83)
#define GPRS_PLACE_CONFIG_GET          (84)
#define GPRS_ERROR_DEATTACH_ERROR      (85)
#define GPRS_ERROR_GET_APN             (86)
#define GPRS_ERROR_GET_GSM_HANDLE      (87)
#define GPRS_ERROR_GET_EVENTS          (88)
#define GPRS_ERROR_GET_OP_NAME         (89)

#define GSM_ERROR_TURN_ON_OFF_GSM (-1000)
#define GSM_ERROR_PUK_REQUIRED    (-1001)
#define GSM_ERROR_PIN_REQUIRED    (-1002)
#define GPRS_ERROR_ATTACH_ERROR   (-1010)
#define GPRS_ERROR_WRONG_NETSTAT  (-1011)
#define GPRS_ERROR_RECONNECT_ATTEMPT (-1012)
#define GPRS_ERROR_CHANNEL_NOT_FOUND (-1013)

#define GSM_STS_ERR_PIN_REQ (1)
#define GSM_STS_ERR_PUK_REQ (2)
#define GSM_STS_ERR_SIM_NOT_INSERTED (3) 

/* special error codes from gsmcUpdateSignalStrength() */
#define GSM_ERR_SIGNAL_NOT_STARTED     (-1)
#define GSM_ERR_SIGNAL_NOT_OPEN        (-3)
#define GSM_ERR_SIGNAL_READING         (-2)
#define GSM_ERR_SIGNAL_NOT_REGISTERED  (-4)

int16 gsmcGetConnectionStatus(uint8 *connect, uint8 *handleOpen, uint8 *rssi);
uint8 gsmcGetKnowError(void);
int16 gsmcGetGsmHandle(uint32 *handle);
int16 gsmcUpdateSignalStrength(void);
int16 gsmcStart(uint32 value);
int16 gsmcStop(uint32 value);
int16 gsmcATserialCommand(uint32 hmiHandle);
int16 gsmcVocall(uint32 hmiHandle);
int16 gsmcPreConfigGsm(uint32 value);
const char *gsmcGetModemHardware(void);
const char *gsmcGetModemFirmware(void);

/**
 * Returns the cached IMEI. Might be empty if the IMEI
 * has not been asked to the modem yet, or if the modem
 * could not answer.
 */
const char *gsmcReturnImei(void);

/**
 * Returns the cached IMSI. Might be empty if the IMSI
 * has not been asked to the modem yet, or if the modem
 * could not answer.
 */
const char* gsmcReturnImsi(void);

const char *gsmcReturnCcid(void);
int16 gsmcTurnSleepModem(uint32 value);
int16 gsmcTurnOffModem(uint32 value);
int16 gsmcTurnOnModem(uint32 value);
uint8 gsmcAlreadyTryToStart(void);
int16 gsmcSetSpeed(uint32 value);

/**
 * If the cached IMEI is empty, refresh the IMEI from the modem.
 * Otherwise do nothing. 
 */
int16 gsmcRefreshImei(void);

/**
 * Refresh the cached IMSI by asking the current value from the modem. 
 */
int16 gsmcRefreshImsi(void);

int16 gsmcStartGsmDefault(void);

/**
 * Try to connect the system to the next operator on the list.
 * This will only do the GSM registration process, but will force a complete
 * GSM unregistration and re-registration.
 * 
 * Calls gsmcNextOperator() to get the next operator to use!
 * 
 * @return RET_OK if registration was ok.
 * @return ERR_DATA_NOT_FOUND if list of operators to try has finished.
 * @return Other error codes (GSM_xxx) if registration failed.
 */
int16 gsmcTryNextOperator(void);


/**
 * Returns UserOpSelection status TRUE/FALSE
 */
int gsmcUserOpSelectionEnabled(void);

/**
 * Processes the 'User Operator Selection' if the UserOpSelection status 
 * is TRUE;
 */
int16 gsmcUserOperatorSelection(void);

/**
 * Returns the pin status of the SIM Card.
 * 
 */
int16 gsmcGetPinStatus(uint8 *pinStatus);

/**
 * For development purposes: 
 * 
 */
int16 gsmpLog(char * msg, int16 ret);

/*
 * Guarantee software GSM and GPRS data reset.
 */
int16 gsmcGsmClear(void);

/**
 * 
 */
int16 gsmcChangePassword(char *typPass, char *oldPass, char *newPass);

/**
 * Process the TogglePinRequest command
 */
int16 gsmcTogglePinRequest(uint32 value);
/**
 * Process the UpdatePin command
 */
int16 gsmcUpdatePin(uint32 value);
/**
 * Restarts the GSM Process
 */
int16 gsmcRestartGSM(uint32 value);

/**
 *
 */
int16 gsmcTurnGsmOnEx(uint32 handle, uint8 statusReq);
/**
 *
 */
int16 gsmcSetModStatus(uint8 statusReq);

/**
 * Synchrozines the modem status by waiting for it to be available.
 * That avoids to the plugin to send new commands when the modem is busy;
 *
 * \brief Synchrozines the modem status by waiting for it to be available.
 *        That avoids to the plugin to send new commands when the modem is busy;
 *
 * \param[in] ret   return value from the previous gsm/gprs function to be used as 
 *                  error treatment criteria. 
 * \param[in] fcn   Flag modem reset method: 
 *                  0 == Default, 
 *                  1 == After gsmOperatorSelection/gsmGetOperators(Ext) calling. 
 * \param[in] com   Flag communucation level. 
 *                  0 == Default(gsm), 
 *                  1 == After Gprs Attach.
 *  
 */
int16 gsmcSync(int16 ret, uint8 fnc, uint8 com);

/**
 * Reads the network status until network status is different from 2 and until 
 * get an error that is not in the CME Error list 
 * That avoids to the plugin to send new commands when the modem is busy
 *
 * \brief Synchrozines the modem status by waiting for it to be available.
 *        That avoids to the plugin to send new commands when the modem is busy;
 *
 * \param[in] fcn   Flag modem reset method: 
 *                  0 == Default, 
 *                  1 == After gsmOperatorSelection/gsmGetOperators(Ext) calling. 
 * \param[in] com   Flag communucation level. 
 *                  0 == Default(gsm), 
 *                  1 == After Gprs Attach. 
 * \param[in] cme   CME Error list 
 * \param[in] cnt   Number of items in the CME Error list. 
 *                   
 */
int16 gsmcSyncEx(uint8 fnc, uint8 com, uint16 * cme, uint8 cnt);

/*
 * Return TRUE if the GSM registration status can be considered ok. 
 */
int gsmcStatusOk(void);


#ifdef __cplusplus
}
#endif

#endif

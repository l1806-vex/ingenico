/*
 * GSM module.
 * Author: Roberto Belli
 * Creation Date: 21/10/2004
 */

#ifndef GSM_CONF_H_INCLUDED
#define GSM_CONF_H_INCLUDED

#include <miltypes.h>
#include <LNet.h>
#include <gsm.h>

#ifdef __cplusplus
extern "C" {
#endif


#define GSM_STATUS_FILE_NAME  ("gsmstat.dat")
#define GSM_MODEM_PORT        ("MODEM3")

/* sizes */
#define GSM_APN_SIZE    (64+1)
#define GSM_USER_SIZE   (20)
#define GSM_PASS_SIZE   (20)
#define GSM_OPER_SIZE   (15)
#define GSM_CCID_SIZE   (30)   

/** version of GSM module configuration file */
#define GSM_CONF_VERSION   (0x0106)

#define GSM_OLD_CONF_VERSION (0x0105)
	
typedef enum
{
	OPM_Auto = 0,		// Auto 
	OPM_Manual = 1,		// Manual
	OPM_AutoMan = 4,	// Auto/Manual
	OPM_NoSel = 5		// No Selection (User selection disabled)
} operatorMode_e;
/**
 * Configuration information for GSM POM
 */
typedef struct gsmStatus_t
{
   uint32 version;                  ///< Config file version, see \ref GSM_CONF_VERSION
   char pin[2][5];                  ///< The two possible PIN values (PIN1 and PIN2)
   int8 pinReady[2];                ///< If PIN1 or PIN2 are ready and valid to be used
   int8 pinNecessary;               ///< If PIN is necessary (overrides answer from modem)
   int8 turnOffGsm;                 ///< Should turn off GSM during power-off
   uint8 bOperSelect;               ///< Operator selection mode (see operatorMode_e)
   uint8 bOperFormat;               ///< Defines operator format wanted by modem
   char operName[GSM_OPER_SIZE];    ///< Name of operator. Depends on \ref bOperFormat 

   char apn[GSM_APN_SIZE];          ///< APN user for GPRS attachment
   char user[GSM_USER_SIZE];        ///< Username for PPP
   char pass[GSM_PASS_SIZE];        ///< Password for PPP

   // ip configuration parameters
   netIpAddr_t localIp;             ///< If DHCP is disabled, this has the machine's IP

   // serial port for external modem
   char extModemPort[4+1];          ///< On 5100's, this is the COM port for the external modem.

   // last CCID read from the modem
   char lastCCID[GSM_CCID_SIZE];    ///< CCID of the last SIM found. Used for PIN invalidation.

   // timeout before disconnecting from GPRS network
   // in 1/100 of seconds.
   uint32 gprsDisconnectTimeout;    ///< Timeout before GPRS disconnection after last use.
                                    ///A value of zero signals disconnection just after use
                                    ///A value of 0xFFFFFFFF means "never disconnect GPRS"
   uint32 gprsReconnectionTimeout;  ///< minimum time between a disconnection and a reconnection
                                    /// in the GPRS network.
   char debug;                 		///< General flag for debug purposes (Only used in debug versions)
   char old[5];                  	///< The old PIN value (PIN1 and PIN2)
   netIpAddr_t dns1;             	///
   netIpAddr_t dns2;             	///
   uint32 gprsConnectionTimeout;    ///
   uint32 gprsConnectionRetries;    ///
   uint16 gsmSignalTolerance;    	///
} gsmStatus_t;

/**
 * Status/value of PUK keys.
 */
typedef struct gsmPukStatus_st
{
   char puk[2][9];
   uint8 pukEntered[2];
} gsmPukStatus_t;

typedef struct gsmOtherConfs_st
{
	uint8 detachEnabled;
	uint8 pdpActivateBef;
	uint8 pdpDeactivate;
	uint16 rfu1;
	uint8 rfus[8];
}gsmOtherConfs_t;

//typedef enum debugTarget_e dbgTarget_t; 

enum dbgModule_e
{
    GSM_DBG_Main,
    GSM_DBG_Loop,
    GSM_DBG_CGsm,
    GSM_DBG_CGprs,

    GSM_DBG_Conf,
    GSM_DBG_Icon,
    GSM_DBG_Oper
};

// Functions prototypes

/**
 * 
 */
int16 dmIoSet(int16 io);

/**
 * 
 */
int dmIoGet(int i);

/*
 * Read the status file and retrieve the gsm configuration. If the file doesn't exist,
 * create oine with default configuration
 */
int16 gsmstsReadStatus(void);

/*
 * Return if the pin is necessary to be entered
 *
 */
int16 gsmstsIsPinRequired(void);

/*
 * Return if the debug flag is enabled
 *
 */
int16 gsmstsDebug(void);

/*
 * Set the status if the pin is necessary to be entered
 *
 */
int16 gsmstsSetPinRequired(int8 pinNecessary);

/*
 * Puk has been entered?
 * TRUE or FALSE
 */
int16 gsmstsIsPukEntered(uint8 qPuk, char *pukNumber);

/*
 * Return if the pin number is valid
 * TRUE or False
 */
int16 gsmstsIsPinValid(uint8 qPin);

/*
 * Get the pin number
 *
 */
char* gsmstsGetPinNumber(uint8 qPin);

/*
 * return the operetor configuration
 *
 */
char *gsmstsGetOperatorInfo(uint8 *mode, uint8 *format);

/*
 * get the apn stored
 * return -1 if no APN is stored
 */
int16 gsmstsGetApn(char *apn, char *user, char *pass);

/*
 * return the serial port to use for the external modem
 */
char *gsmstsGetExtModemPort(void);

/*
 * Change the external modem port.
 */
int16 gsmstsSetExtModemPort(const char *port);

/*
 * get the local IP to be used when not using DHCP
 */
int16 gsmstsGetLocalIp(netIpAddr_t *localIp);

/*
 * Get the configured DNS1 
 */
int16 gsmstsGetDns1(netIpAddr_t *dns1);

/*
 * Get the configured DNS1 
 */
int16 gsmstsGetDns2(netIpAddr_t *dns2);

/*
 *
 * Set the pin to not ready
 */
int16 gsmstsSetPinNotRead(void);

/*
 * Start the configuration menu
 *
 */
int16 gsmstsStartMenu(void);

/*
 *
 * Configure if the terminal will be turned off with the system
 */
int16 gsmstsSetTurnOffState(uint8 newState);

/*
 *
 * Set or change the pin (change PIN using the PUK)
 */
int16 gsmstsSetPinPuk(char *pin, char *puk);

uint8 gsmstsTurnOffModemRequired(void);
int16 gsmstsSetMappedKeys(void);

/*
 * Message received from idle to configure the GSM Module
 */
int16 gsmstsConfigFromIdle(void);

/**
 * \brief Set the last CCID seen.
 *
 * This is called by GSMCOMMGSM during gsmcStartGsm() to
 * set the CCID of the last SIM found.
 *
 * \param[in] ccid A string of upto GSM_CCID_SIZE characters with the CCID value.
 */
void gsmstsSetLastCCID(const char *ccid);

/**
 * \brief Get the value of the last CCID seen.
 *
 * This is called by GSMCOMMGSM to retrieve the last CCID seen, in order
 * to invalidate the stored PIN.
 *
 * \param[out] ccid Where to store the CCID. At least GSM_CCID_SIZE chars in length.
 */
void gsmstsGetLastCCID(char *ccid);

/**
 * \brief Return the current timeout for GPRS disconnection.
 */
uint32 gsmstsGetGPRSDisconnectTimeout(void);

/**
 * \brief Return the current timeout for GPRS connection.
 */
uint32 gsmstsGetGPRSConnectionTimeout(void);

/**
 * \brief Set the timeout for GPRS connection.
 *
 * \param[in] timeout   Timeout for GPRS connetion. A value of PSY_INFINITE_TIMEOUT will wait for 
 * time until a succesful connection.
 */
void gsmstsSetGPRSConnectionTimeout(uint32 timeout);

/**
 * \brief Return the current maximum number of retries for the GPRS connection.
 */
uint32 gsmstsGetGPRSConnectionRetries(void);

/**
 * \brief Set the maximum number of retries for the GPRS connection
 *
 * \param[in] retries	Maximum number of retries for GPRS connetion.
 */
void gsmstsSetGPRSConnectionRetries(uint32 retries);

/**
 * 
 */
uint16 gsmstsGetGsmSigTolerance(void);

/**
 * 
 */
void gsmstsSetGsmSigTolerance(uint16 tolerance);

/**
 * \brief Set the tiemout for GPRS disconnection.
 *
 * \param[in] timeout   Timeout for GPRS disconnection. A value of zero means "auto disconnect" and
 *                      PSY_INFINITE_TIMEOUT will never disconnect.
 */
void gsmstsSetGPRSDisconnectTimeout(uint32 timeout);

/**
 * 
 */
uint32 gsmstsGetGPRSReconnectionTimeout(void);

/**
 * 
 */
void gsmstsSetGPRSReconnectionTimeout(uint32 timeout);

/**
 * 
 */
uint8 gsmIsDetachEnabled(void);

/**
 * 
 */
uint8 gsmActivatePDPBefEnable(void);

/**
 * 
 */
uint8 gsmDeactivatePDPEnabled(void);

/**
 * 
 */
int16 gsmcManOpSelection(uint8 mode, uint8 ignoreStatus);


/**
 * 
 */
int16 gsmcSetCurrentOperatorInfo(void);


/**
 * Same as gsmOperatorSelection, but saves the operator mode if
 * the selection was successful.
 */
int16 gsmcOperatorSelection(gsmHandle_t gsmHandle,
                           uint8 mode, uint8 format, char *oper);

/**
 * 
 */
int16 gsmcResetCurrentOperatorInfo(void);

/**
 * 
 */
char * gsmcGetCurrentOperatorInfo(uint8 *mode);

/**
 * 
 */
char * gsmcGetCurrentOperatorName(void);

/**
 * 
 */
int16 gsmstsTogglePinRequest(uint8 enabled);

/**
 * 
 */
int16 gsmstsUpdatePin(void);


#ifdef __cplusplus
}
#endif
#endif

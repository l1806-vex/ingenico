
#ifndef GSM_ICON_H_INCLUDED
#define GSM_ICON_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * 
 */
void gsmIconInitializeScreenConf(void);


/*
 *
 * Send a message to the idle with the rssi
 */
int16 gsmIconSetPower(uint8 rssi);

/*
 * Set the serial connection error icon
 */
int16 gsmIconSetSerialError(void);

/*
 * Set the GSM icon to "searching"
 */
int16 gsmIconSetSearching(void);

/*
 * Show the GPRS network Icon
 * \param gprsStatus
 *  - 0 no GPRS
 *  - 1 GPRS possible
 *  - 2 GPRS connected
 *                   
 */
int16 gsmIconSetGprs(uint8 gprsStatus);

/**
 * 
 */
int16 gsmIconSet(uint8 iconNumber);

int16 gsmIconDisplayLastIconNumber(void);

void gsmIconSendGPRSIcon(void);

void gsmIconLock(uint8 lock);
void gsmIconSend(uint8 iconNumber);
int16 gsmIconOperator(char * opName);

#ifdef __cplusplus
}
#endif
#endif

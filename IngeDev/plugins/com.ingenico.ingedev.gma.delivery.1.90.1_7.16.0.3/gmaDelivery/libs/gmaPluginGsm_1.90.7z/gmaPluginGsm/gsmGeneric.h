
#ifndef GSM_GENERIC_H_INCLUDED
#define GSM_GENERIC_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Query the terminal model number from the configuration file name.
 * The code is returned as an 4-digit unsigned value (i.e. 5100, 7780, 8200)
 *
 * @param model   (out) the model number as an unsigned integer.
 *
 * @return RET_OK if model read successfully, error code otherwise.
 */
int16 hwiQueryModelNumber(uint32 *model);

int16 gsmForceAddModem3(void);

int16 gsmGenOpenSerialDebug(uint32 *serialHandle);
int16 gsmGenericATSendCommand (uint32 Handle, uint8 *zcResponse,
                              int16 MaxLenRes,uint8 *zcCommand, uint32 timeout);
int16 gsmGenericATWaitReply(uint32 Handle, uint8 *zcResponse, int16 MaxLenRes, uint32 timeout);
int16 gsmcOpenComPort(char *channelName,
                uint32 *com,
                enum comSpeed_t speed,
                enum comParity_t parity,
                enum comDataSize_t dataSize,
                enum comStopBits_t stopBits);

int16 gsmIsExternalModem(void);

#ifdef __cplusplus
}
#endif

#endif

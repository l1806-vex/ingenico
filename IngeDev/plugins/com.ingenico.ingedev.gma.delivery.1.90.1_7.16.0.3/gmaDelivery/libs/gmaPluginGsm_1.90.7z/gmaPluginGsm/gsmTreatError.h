#ifndef GSM_TREAT_ERROR_H_INCLUDED
#define GSM_TREAT_ERROR_H_INCLUDED

/**
 * \brief Error handling and treatment.
 *
 * This module keeps track of the last GSMERROR_MAX_SAVE_ERRORS errors
 * that have happened in the GSM module.
 *
 * This list is reset when the terminal is shutdown.
 */

#include "miltypes.h"

#ifdef __cplusplus
extern "C" {
#endif


/** Max number of errors stored */
#define GSMERROR_MAX_SAVE_ERRORS (10)

/**
 * Store information about a single error.
 */
typedef struct gsmteErrors_t gsmteErrors_t;
struct gsmteErrors_t
{
   uint32   date;
   uint32   time;
   int16    error;
   uint16   errorPlace;
   uint16   internalError;
   uint8	extended[20+1];
};


/**
 * \brief Reset the error table.
 *
 * Empty the list of errors and set the error count to zero.
 *
 * \return Always returns RET_OK.
 */
int16 gsmteResetErrors(void);

/**
 * \brief Add an error to the list of stored errors.
 *
 * If the number of errors in the list exceed \c GSMERROR_MAX_SAVE_ERRORS,
 * the "older" errors will be replaced.
 *
 * \param[in] error     Unicapt32/peripheral error code.
 * \param[in] position  One of GSM or GPRS PLACE constants
 * \param[in] internal  Internal error code. Usually the modem error code.
 *
 * \return Always returns RET_OK.
 */
int16 gsmteAddError(int16 error, uint16 position, uint16 internal);

/**
 * \brief Return the number of elements in the error list.
 *
 * The number of elements will never be more than \c GSMERROR_MAX_SAVE_ERRORS.
 * Note that this number never decreases! It will increase since program start
 * up to \c GSMERROR_MAX_SAVE_ERRORS.
 *
 * \return The number of elements in the error list.
 */
uint16 gsmteGetNumberOfErrors(void);

/**
 * \brief Return one error in the error list.
 *
 * \note The \c index is relative to the "most recent" error code. I.e., using
 * \c index == 0 will return the value of the latest error, \c index == 1 will
 * return the error before that and so forth.
 *
 * \param[in]  index    Index of the error. See the note for more information.
 * \param[out] error    The parameters for this error will be copied in this structure.
 *
 * \return RET_OK if the error information is returned.
 * \return ERR_INVALID_PARAMETER if \c index is out of range.
 */
int16 gsmteGetError(int index, gsmteErrors_t *error);


#ifdef __cplusplus
}
#endif
#endif


#ifndef GSM_COMM_GPRS_H_INCLUDED
#define GSM_COMM_GPRS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GSMC_LNET_NISTART_INT_ERROR (11)
#define GSMC_LNET_WRONG_STATE       (12)
#define GSMC_LNET_CONN_REFUSED      (13)
#define GSMC_LNET_CONN_TIMEOUT      (14)
#define GSMC_GPRS_LNET_INT_ERROR    (15)

#define GSMC_GPRS_ATTACH_ERROR      (20)

#define GSMC_GPRS_NOT_ALLOWED       (22)
#define GSMC_GPRS_UNSPECIFIED       (23)
#define GSMC_PDP_AUTH_FAILURE       (24)
#define GSMC_MISSING_UNK_APN        (25)
//#define GSMC_PDP_ACTIVATE_ERROR     (26)
#define GSMC_TEMP_UNAVAILABLE       (27)
#define GSMC_GPRS_CONN_TIMEOUT      (28)
#define GSMC_GPRS_INTERNAL_ERROR    (30)
#define GSMC_GPRS_APN_NOT_SET       (31)

/**
 * Check if the GPRS is currently connected
 */
int16 gsmcGprsCheckIfConnectedDefault(void);

/*
 * Interface for GSMLOOP to call gsmcGprsStartDefault()
 */
int16 gsmcGprsStartDefaultMessage(uint32 value);

/*
 * Start GPRS with default parameters (APN, user, pass, timeout)
 */
int16 gsmcGprsStartDefault(void);

/*
 * Start GPRS requested from GSMLOOP.
 */
int16 gsmcGprsStart(uint32 value);

/*
 * Start GPRS with roaming retries if the default operator 
 * is not working
 */
int16 gsmcGprsStartRetry(uint32 value); 

/*
 * Stop GPRS _now_ requested from GSMLOOP.
 * @param keepAttached if non-zero will keep the modem attached to the GPRS network.
 */
int16 gsmcGprsStopNow(uint32 keepAttached);

uint8 gsmcIsGprsConnected(void);
uint8 gsmcGprsGetLastError(void);

/**
 * Returns the GPRS Network status
 * 
 * \brief Checks the GPRS Network status and tries to attach GPRS if it 
 *        is not connected.
 *
 * @return -1 -> Error
 * @return  0 -> Not connected
 * @return  1 -> Available 
 * @return  2 -> Connected 
 */
int16 gprsCheckGprsNetwork(void);
int16 gsmcSForceGprsAttach(void);
int16 gsmcGprsAbortAttach(void);

/**
 * Returns the last stored attach status
 */
uint8 gsmcIsGprsAttached(void);

/**
 * get the GPRS connections parameters
 */
void gsmcGprsGetGprsData(uint32 *localIp, uint32 *_dns1, uint32 *dns2);

/*
 * TODO - Tracker #852 - Improve and release this function
 **/
char * gsmcGprsGetErrorDescription(char * sMsg, int16 nError);

/**
 * Restart module data as if the terminal were restarted
 */
void gsmcGprsClear(void);

/**
 * 
 */
void gsmcGetAddrf(char * sOut, uint32 nIn);

#ifdef __cplusplus
}
#endif
#endif

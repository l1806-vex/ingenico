#ifndef GSM_STRING_RESOURCE_H
#define GSM_STRING_RESOURCE_H

/**
 * Multi-language support.
 *
 * The \ref StringList.h file has only a list of strings and their translations
 * using an undefined macro. The trick is that we define the macro with varing
 * definitions here, and include the StringList file repeatedly.
 */

#include <miltypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#include "resources.h"

/**
 * \brief Return a string from the list
 *
 * \param[in] ident  ID of string, see \ref StringList.h
 *
 * \return Pointer to const string.
 */
char const *gsmGetString(uint16 ident);

#ifdef __cplusplus
}
#endif

#endif


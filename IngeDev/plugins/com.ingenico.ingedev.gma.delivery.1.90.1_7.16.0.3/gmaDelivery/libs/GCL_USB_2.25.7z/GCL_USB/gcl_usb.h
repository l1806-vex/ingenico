
#ifndef GCL_USB_H_INCLUDED
#define GCL_USB_H_INCLUDED

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_USB.h
 *
 *
 */

/**
 * \addtogroup USB_ USB
 * USB connection
 *
 * @{
 */

#define GCL_USB_FUNC_comOpen            (1)
#define GCL_USB_FUNC_comChanInit        (2)
#define GCL_USB_FUNC_comConnectReq      (3)
#define GCL_USB_FUNC_psyPeripheralResultWait (4)
#define GCL_USB_FUNC_comResultGet       (5)
#define GCL_USB_FUNC_comResultGetStatus (6)
#define GCL_USB_FUNC_gclUsbReadHidSizeEndPointLoop (7)
#define GCL_USB_FUNC_comSendMsgWait     (7)
#define GCL_USB_FUNC_comReceiveMsgWait  (8)

/**
 * store the information of the last error occurred in the gclUSB.
 */
typedef struct gclUSBErrorInfo_st gclUSBErrorInfo_t;

/**
 * store the information of the last error occurred in the gclUSB.
 */
struct gclUSBErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_USB_FUNC_XXX defines
	 */
	uint16 usbFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclUSBErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a USB error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclUSBGetLastErrorInfo(gclUSBErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclUSBGetLastErrorInfo
 */
void gclUSBSerrorReset(void);

/**
 * \brief structure with parameters for USB communication
 */
typedef struct 
{
   uint8 connectionId;
   //////////////////////////////////////////////////////////////////////////
   // TODO: ADD the USB parameters here
   uint8 subClass; //!< HID sub class
   uint16 bcdDevice; //!< bcd device
   
   ////////////////////////
   uint8    retries; //!< connection attempts = retries + 1
   ////////////////////////
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection
}gclUSB_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific USB configurations
 */
typedef struct
{
   // TODO: ADD the USB parameters here
   uint8 subClass; //!< HID sub class
   uint16 bcdDevice;//!< bcd device
   
   // values get during the connection process
   uint16 blockSendSize; //!< send block size, used internally in the USB send callback.
   uint16 blockReceiveSize; //!< receive block size, used internally in the USB receive callback.
}gclUSBConfig_t;


/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclUsbId(char *zcOut);

/**
 * This function will add an USB connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param UsbConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclUsbSet(gclUSB_t *UsbConfig, gclFunctionList_t *List,
                uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclUsbPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclUsbDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclUsbConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclUsbHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (I) a pointer to the buffer to be sent
 * @param size (I) the size of the buffer to be sent
 *
 */
int16 gclUsbSend(gclConfig_t *gcl, uint8* buffer, uint32 size);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is USB connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param buffer (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param size (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxsize (I) the size of the buffer
 *
 */
int16 gclUsbReceive(gclConfig_t *gcl, uint8 *buffer, uint32 *size,
                    uint32 maxsize);


/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


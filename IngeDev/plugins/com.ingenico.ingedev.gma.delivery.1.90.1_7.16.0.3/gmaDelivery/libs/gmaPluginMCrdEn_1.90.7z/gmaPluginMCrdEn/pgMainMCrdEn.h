
#ifndef PG_MAIN_MCRD_EN_H_INCLUDED
#define PG_MAIN_MCRD_EN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


int16 pgRegistryMCrdEnPlugin(void);

#ifdef __cplusplus
}
#endif


#endif


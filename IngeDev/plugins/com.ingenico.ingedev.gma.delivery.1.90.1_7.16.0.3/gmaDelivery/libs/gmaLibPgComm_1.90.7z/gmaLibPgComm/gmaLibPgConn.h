
#ifndef GMA_LIB_PG_CONN_H_INCLUDED
#define GMA_LIB_PG_CONN_H_INCLUDED

#include "gmaDefines.h"

#include "gmaLibPgStructDefs.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file gmaEthPgConfig.h
 *
 * Functions to configure the ethernet plug-in
 */

/**
 * Error, no plug-in available
 */
#define GMA_LIB_PG_GEN_ERROR_NO_PG_AVAILABLE  (-1)
/**
 * No generic comm plug-in 
 */
#define GMA_LIB_PG_GEN_ERROR_GEN_PG_NOT_FOUND (-2)
/**
 * Internal error
 */
#define GMA_LIB_PG_GEN_ERROR_INTERNAL_ERROR   (-3)

	
#define GMA_LIB_PG_GEN_GET_COMM_PG_NAME   (1)	

#define GMA_LIB_PG_GEN_PG_NAME ("commPg")

#define GMA_LIB_REQUEST_CONNECTION           (0x01)   // used by GCL
#define GMA_LIB_REQUEST_DISCONNECTION        (0x02)   // used by GCL
#define GMA_LIB_REQUEST_CLOSE_HANDLE         (0x03)   // used by GCL
#define GMA_LIB_REQUEST_CONNECTION_DONE      (0x04)   // GPRS is not in use anymore
#define GMA_LIB_REQUEST_RESET_HANDLE         (0x05)   // used by GCL

#define GMA_LIB_PG_STATUS_ALREADY_CONNECTED        (0x01)
#define GMA_LIB_PG_STATUS_CONNECTED                (0x02)
#define GMA_LIB_PG_STATUS_NOT_CONFIGURED           (0x03)
#define GMA_LIB_PG_STATUS_NOT_POSSIBLE             (0x04)
#define GMA_LIB_PG_STATUS_CONNECTION_ERROR         (0x05)
#define GMA_LIB_PG_STATUS_ALREADY_DISCONNECT       (0x06)
#define GMA_LIB_PG_STATUS_DISCONNECT               (0x07)

#define GMA_LIB_GEN_PG_REQUEST_NUMB_OF_APPLI (0)
#define GMA_LIB_GEN_PG_REQUEST_PGS_NAMES     (1)
#define GMA_LIB_GEN_PG_SET_PG_USED           (2)

#define GMA_LIB_GEN_MAX_NUMB_CONN_PLUGINS    (4)   



	
/**
 * GMA_LIB_PG_STRUCT_GEN_PG_QUERY
 * Send a query to the GEN PG.
 */
typedef struct gmaLibPgGenPluginQuery_st gmaLibPgGenPluginQuery_t;
/**
 * GMA_LIB_PG_STRUCT_GEN_PG_QUERY
 * Send a query to the GEN PG.
 */
struct gmaLibPgGenPluginQuery_st
{
   gmaStructHeader_t header;
   /**
    * 1 -> ask the comm PG name that is actually selected to
    * communicate
    */
   uint32 item;
};

/**
 * GMA_LIB_PG_STRUCT_GEN_PG_NAME
 * Response from the GEN PG showing the comm pg name selected to communicate
 */
typedef struct gmaLibPgGenCommPgName_st gmaLibPgGenCommPgName_t;

/**
 * GMA_LIB_PG_STRUCT_GEN_PG_NAME
 * Response from the GEN PG showing the comm pg name selected to communicate
 */
struct gmaLibPgGenCommPgName_st
{
   gmaStructHeader_t header;
   uint8 status;
   char pgName[18+1];
};



/**
 * GMA_LIB_STRUCT_START_CONNECTION
 * Message received from the application asking the connection plugin
 * to connect to the GPRS network with the predefined configuration
 */
typedef struct gmaLibStructMsgStartConnect_s gmaLibStructMsgStartConnect_t;

/**
 * GMA_LIB_STRUCT_START_CONNECTION
 * Message received from the application asking the connection plugin
 * to connect to the GPRS network with the predefined configuration
 */
struct gmaLibStructMsgStartConnect_s
{
   gmaStructHeader_t header;
   uint32 request;
   uint32 timeout;
};

/**
 * Message send to the application as a reply of the message 
 * GMA_LIB_STRUCT_START_CONNECTION. GMA_LIB_STRUCT_START_CONNECTION_REPLY 
 */
typedef struct gmaLibStructMsgStartConnectReply_s gmaLibStructMsgStartConnectReply_t;
struct gmaLibStructMsgStartConnectReply_s
{
   gmaStructHeader_t header;
   uint32 status;
};

/**
 * Structure used to make request to the genPg. Struct ID GMA_LIB_PG_STRUCT_GEN_PG_REQUESTS
 */
typedef struct gmaLibStructGenPgRequests_st gmaLibStructGenPgRequests_t; 


/**
 * Structure used to make request to the genPg. Struct ID GMA_LIB_PG_STRUCT_GEN_PG_REQUESTS
 */
struct gmaLibStructGenPgRequests_st
{
	/**
	 * header of the structure
	 */
	gmaStructHeader_t header;
	/**
	 * What request to be made, see the defines GMA_LIB_GEN_PG_REQUEST_XXXX
	 * - 0 -> require the number of comm plug-ins
	 * - 1 -> request the list of comm plug-ins available
	 * - 2 -> set the comm plug-in to be used.
	 * 		  Put the name of the plug-in in the extraData field.
	 *        Note that the size of this structure is variable depending
	 *        on the size of the extraData field 
	 * 
	 */
	uint32 reqType;	
	/**
	 * Extra data: depending on the reqType above. Variable size.
	 */
	uint8 extraData[4];
};

/**
 * Answer returned by the GENPG for the requests. IDs GMA_LIB_PG_STRUCT_GEN_PG_ANSWERS
 */
typedef struct gmaLibStructGenPgAnswers_st gmaLibStructGenPgAnswers_t;

/**
 * Answer returned by the GENPG for the requests 
 */
struct gmaLibStructGenPgAnswers_st
{
	gmaStructHeader_t header;
	int16 ret;
	uint16 nApps;
	uint8 data[4];
};


/**
 * Ask the pgName plug-in to start a connection
 * 
 * @param pgName the name of the plug-in
 * @param timeout the connection timeout
 * @param connStatus result of the connection attempt
 * @param disconnect if 1 send a message to the others plug-ins (not the one pointed by pgName)
 * forcing them to disconnect. Only one plug-in can use the LNET at one time. If 0 don't send a
 * message to the others plug-ins
 */
int16 gmaLibPgStartConn(char *pgName, uint32 timeout, uint16 *connStatus, uint8 disconnect);

/**
 * Ask the pgName plug-in to disconnect
 * 
 * @param pgName the name of the plug-in
 */
int16 gmaLibPgStopConn(char *pgName);

/**
 * Ask the pgName plug-in to disconnect
 * 
 * @param pgName the name of the plug-in
 */
int16 gmaLibPgReqCloseHandle(char *pgName);


/**
 * Ask the pgName plug-in to reset connection
 * 
 * @param pgName the name of the plug-in
 */
int16 gmaLibPgReqResetConn(char *pgName);


/**
 * Ask the GenPg the number of communicate plug-ins available
 * 
 * @param pgNumb a pointer to receive the number of available plug-ins
 */
int16 gmaLibPgGetConnPgNumber(uint16 *pgNumb);

/**
 * Ask the name of the communications plug-ins available.
 * First call the function \ref gmaLibPgGetConnPgNumber to get the number of plug-ins 
 * to allocate enougth space for the variable pgNames
 * 
 * @param pgNames a pointer to a char vector with form [][17] to receive
 * the name of the plug-ins. 
 */
int16 gmaLibPgGetConnPluginsNames(char pgNames[][17]);

/**
 * Set the communicate plug-in to be used in the following
 * connections attempts.
 * 
 * @param pgName the name of the plug-in to be used
 */
int16 gmaLibPgSetConnPluginToUse(char *pgName);

/**
 * Ask the selected communicate plug-in name.
 * 
 * @param pgName a pointer to a char buffer to receive the plug-in name
 * 
 * @return RET_OK no errors
 * @return GMA_LIB_PG_GEN_ERROR_NO_PG_AVAILABLE
 * @return GMA_LIB_PG_GEN_ERROR_GEN_PG_NOT_FOUND
  */
int16 gmaLibPgGetCommPgName(char *pgName);

#ifdef __cplusplus
}
#endif

#endif

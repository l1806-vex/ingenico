
#ifndef GMA_LIB_PG_STRUCT_DEFS_H_INCLUDED
#define GMA_LIB_PG_STRUCT_DEFS_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Definitions of the structure ID of the structure used in the library gmaLibPgComm
 */
	

#define GMA_LIB_PG_STRUCT_GEN_PG_QUERY         (2000)
#define GMA_LIB_PG_STRUCT_GEN_PG_NAME          (2001)

#define GMA_LIB_STRUCT_START_CONNECTION        (2002)
#define GMA_LIB_STRUCT_START_CONNECTION_REPLY  GMA_LIB_STRUCT_START_CONNECTION
	
#define ETH_STRUCT_CONFIG_CONNECTION           (2004)


#define GMA_PG_PPP_STRUCT_CONFIG_SERIAL        (2010)
#define GMA_PG_PPP_STRUCT_CONFIG_MODEM         (2011)
#define GMA_PG_PPP_STRUCT_CONFIG_CONNTYPE      (2012)
#define GMA_PG_PPP_STRUCT_GET_CONN_STATUS      (2013)

#define GMA_LIB_PG_STRUCT_GEN_PG_REQUESTS      (2100)
//gmaLibStructGenPgAnswers_t
#define GMA_LIB_PG_STRUCT_GEN_PG_ANSWERS       (2101)

#define SMF_COMM_STRUCT_START              (0x2000)
#define SMF_COMM_STRUCT_COMM_TYPE          (0x2001)
#define SMF_COMM_STRUCT_CFG_SERIAL         (0x2002)
#define SMF_COMM_STRUCT_CFG_MODEM          (0x2003)
#define SMF_COMM_STRUCT_CFG_SMF            (0x2004)
#define SMF_COMM_STRUCT_RESULT             (0x2005)
#define SMF_COMM_STRUCT_SCHEDULE_MNT       (0x2006)
#define SMF_COMM_STRUCT_CFG_SOCKET         (0x2007)

#define GMA_INQ_STRUCT_INQUIRE_ID          (0x2100)
#define GMA_INQ_STRUCT_GSM_SIGNAL_LEVEL_ID (0x2101)
#define GMA_INQ_STRUCT_BATT_LEVEL          (0x2102)
#define GMA_INQ_STRUCT_GSM_IMEI_IMSI       (0x2103)
#define GMA_INQ_STRUCT_GSM_LAST_ERRORS     (0x2104)
#define GMA_INQ_STRUCT_GSM_GPRS_INFO       (0x2105)
#define GMA_INQ_STRUCT_GSM_GPRS_CONN       (0x2106)

#ifdef __cplusplus
}
#endif

	
#endif

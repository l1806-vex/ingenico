
#ifndef GMA_PPP_PG_MSG_CONFIG_H_INCLUDED
#define GMA_PPP_PG_MSG_CONFIG_H_INCLUDED

#include "gmaDefines.h"
#include "gmaLibPgConn.h"
#include "gmaLibPgStructDefs.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaLibPPPPgConfig.h
 *
 * Functions to configure the PPP plug-in
 */

	
#define GMA_PG_PPP_OVER_SERIAL (1) //!< PPP over serial connection
#define GMA_PG_PPP_OVER_MODEM  (2) //!< PPP over modem (PSTN) connection
	
/**
 * PPP plug-in name
 */
#define GMA_LIB_PG_PPP_NAME ("commPPP")

	     
#define GMA_PG_PPP_ERROR_NO_CONNECT_ATTEMPT             (0)  //!< no connection attempt yet
#define GMA_PG_PPP_ERROR_OPEN_MODEM               (1)  //!< error in the comOpen to open the "MODEM" handle
#define GMA_PG_PPP_ERROR_READING_COUNTRY_CODE     (2)  //!< error in the comCfgAccess to read the country code
#define GMA_PG_PPP_ERROR_SETTING_COUNTRY_CODE     (3)  //!< error in the comCfgAccess to set the country code
#define GMA_PG_PPP_ERROR_SETTING_MODEM_PARAMETERS (4)  //!< error in the function comSetModemParameters
#define GMA_PG_PPP_ERROR_GET_CHANNEL_LIST         (5)  //!< error in the function netCfgIdentify to get the channel list
#define GMA_PG_PPP_ERROR_NO_CHANNEL_FOUND         (6)  //!< error, no channel found in the list
#define GMA_PG_PPP_ERROR_GET_NET_CONFIG           (7)  //!< error in the function netNiConfigGet
#define GMA_PG_PPP_ERROR_OPEN_NI_HANDLE           (8)  //!< error in the function netNiOpen
#define GMA_PG_PPP_ERROR_SET_LNET_CONFIG          (9)  //!< error in the function netNiConfigSet
#define GMA_PG_PPP_ERROR_START_LNET_CONNECTION    (10) //!< error in the function netNiStart
	
/**
 * Structure used to send/receive the modem configuration of the PPP plugin
 */
typedef struct gmaPPPConfigModem_st gmaPPPConfigModem_t; 

/**
 * Structure used to send/receive the modem configuration of the PPP plugin
 */
struct gmaPPPConfigModem_st
{
	enum comT35_t countryCode; //!< country code, see the UNICAPT documentation of the enum comT35_t for more details
   uint8    detectLine; //!< if the line will be checked before dial.
   uint8    detectDialTone; //!< if the dial tone will be checked before dial

   uint8    useToneDialing; //!< if use tone or pulse to dial
   uint8 rfu1; //!< not used (RFU)

   enum comModemModulation_t modulationType; //!< define the modem modulation, see the Unicapt documentation for more details
   enum comErrorCorrection_t errorCorrection; //!< define the error correction type, see the Unicapt documentation for more details
   enum comDataCompression_t dataCompression; //!< define the data compression type, see the Unicapt documentation for more details
   enum comBps_t              minBps;          /**< Minimum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/
   enum comBps_t              maxBps;          /**< Maximum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/
   uint32 lcpFlags;    //!< ored combination of the flags: NI_PPP_LCP_PAP, NI_PPP_LCP_CHAP OR NI_PPP_LCP_MSCHAP
   uint32 timeout;     //!< connection timeout
   char userName[30];  //!< user name for autentication 
   char password[30];  //!< password for autentication
   char phoneNumber[20]; //!< telephone number to be dialed
};

/**
 * Structure used to send/receive the serial configuration of the PPP plugin
 */
typedef struct gmaPPPConfigSerial_st gmaPPPConfigSerial_t;

/**
 * Structure used to send/receive the serial configuration of the PPP plugin
 */
struct gmaPPPConfigSerial_st
{
	uint32 lcpFlags; //!< ored combination of the flags: NI_PPP_LCP_PAP, NI_PPP_LCP_CHAP OR NI_PPP_LCP_MSCHAP
	uint32 timeout;  //!< connection timeout
	
	enum comSpeed_t       speed;    //!< connection speedy, see the Unicapt documentation
	enum comParity_t      parity;   //!< communication parity, see the Unicapt documentation
	enum comStopBits_t    stopBits; //!< number of stopbits , see the Unicapt documentation
	
	char userName[30];  //!< user name for autentication 
	char password[30];  //!< password for autentication
   
   char portName[8]; //!< serial port name, for example: "COM1" 
};

/**
 * Structure used to send/receive the connection type used by the PPP plug-in
 */
typedef struct gmaPPPMsgConfigConnType_st gmaPPPMsgConfigConnType_t; 

/**
 * Structure used to send/receive the connection type used by the PPP plug-in
 */
struct gmaPPPMsgConfigConnType_st
{
	gmaStructHeader_t header;
	uint8 get; //!< if 1 GET or if 0 SET the plugin configuration
	uint8 rfu;
	uint16 connType; //!< connection type, can be any GMA_PG_PPP_OVER_XXX define
};

/**
 * Structure used to send/receive the modem configuration of the PPP plugin
 */
typedef struct gmaPPPMsgConfigModem_st gmaPPPMsgConfigModem_t; 

/**
 * Structure used to send/receive the modem configuration of the PPP plugin
 */
struct gmaPPPMsgConfigModem_st
{
	gmaStructHeader_t header;
	uint8 get; //!< if 1 GET or if 0 SET the plugin configuration
	uint8 rfu1_;
	uint16 rfu2_;

	gmaPPPConfigModem_t config;
};

/**
 * Structure used to send/receive the serial configuration of the PPP plugin
 */
typedef struct gmaPPPMsgConfigSerial_st gmaPPPMsgConfigSerial_t;

/**
 * Structure used to send/receive the serial configuration of the PPP plugin
 */
struct gmaPPPMsgConfigSerial_st
{
	gmaStructHeader_t header;
	uint8 get; //!< if 1 GET or if 0 SET the plugin configuration
	uint8 rfu1_;
	uint16 rfu2_;
	
	gmaPPPConfigSerial_t config;
};


/**
 * Structure used to ask and get the connection status of the PPP plug-in
 */
typedef struct gmaPPPMsgGetStatus_st gmaPPPMsgGetStatus_t;

/**
 * Structure used to ask and get the connection status of the PPP plug-in.
 * -id:GMA_PG_PPP_STRUCT_GET_CONN_STATUS
 */
struct gmaPPPMsgGetStatus_st
{
	gmaStructHeader_t header;
	uint8 status;
	uint16 function;
   int16 errorCode;
};

/**
 * get or set the serial configuration of the PPP plug-in
 * 
 * @param get if 1 means that the cfg will receive the plug-in parameters,
 * if 0 means that the plug-in will be set with the cfg parameters
 * 
 * @param cfg a pointer to the structure that holds the serial configuration
 * can be an input parameter if get=0 or an output parameter if get=1
 */
int16 gmaLibPPPConfigSerial(uint8 get, gmaPPPConfigSerial_t *cfg);

/**
 * get or set the modem configuration of the PPP plug-in
 * 
 * @param get if 1 means that the cfg will receive the plug-in parameters,
 * if 0 means that the plug-in will be set with the cfg parameters
 * 
 * @param cfg a pointer to the structure that holds the modem configuration
 * can be an input parameter if get=0 or an output parameter if get=1
 */
int16 gmaLibPPPConfigModem(uint8 get, gmaPPPConfigModem_t *cfg);

/**
 * get or set the connection type of the PPP plug-in
 * 
 * @param get if 1 means that the cfg will receive the plug-in parameters,
 * if 0 means that the plug-in will be set with the cfg parameters
 * 
 * @param connType a pointer to the connection type.
 * can be an input parameter if get=0 or an output parameter if get=1
 */
int16 gmaLibPPPConfigConnType(uint8 get, uint16 *connType);

/**
 * Force the PPP plugin to connect.
 * 
 * @param timeout the connection timeout
 * 
 * @param status
 */
int16 gmaLibPPPForceConnect(uint32 timeout, uint16 *status);

/**
 * Force the PPP plugin to disconnect
 */
int16 gmaLibPPPForceDisconnect(void);

/**
 * Get the connection status and if apply, the error in the last connection attempt
 * 
 * @param status 0 means not connected (in this case check the errorFunction and errorCode)
 *               1 means connected
 * 
 * @param errorFunction the function in which the error happens, one of the GMA_PG_PPP_ERROR_XXX defines
 * 
 * @param errorCode the returned error by the function
 */
int16 gmaLibPPPGetConnectionStatus(uint8 *status, uint16 *errorFunction, int16 *errorCode);

#ifdef __cplusplus
}
#endif


#endif


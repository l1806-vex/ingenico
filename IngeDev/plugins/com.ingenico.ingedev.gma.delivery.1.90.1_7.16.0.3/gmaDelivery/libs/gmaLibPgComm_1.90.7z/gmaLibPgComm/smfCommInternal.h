#ifndef _SMFINTERNAL_H_
#define _SMFINTERNAL_H_

#include "smfComm.h"
#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "gmaLibPgStructDefs.h"
/**
 * Defines for dynamic configuration
 */
#define SMF_COMM_START_MAINTENANCE (0x01 << 0)
#define SMF_COMM_UPDATE_COMM_TYPE  (0x01 << 1)
#define SMF_COMM_UPDATE_SERIAL_CFG (0x01 << 2)
#define SMF_COMM_UPDATE_MODEM_CFG  (0x01 << 3)
#define SMF_COMM_UPDATE_SMF_CFG    (0x01 << 4)
#define SMF_COMM_UPDATE_SCHEDULE   (0x01 << 5)
#define SMF_COMM_UPDATE_SOCK_CFG   (0x01 << 6)



/**
 * SMF start structure
 */
typedef struct
{
	gmaStructHeader_t header;
} smfCommStart_t;

/**
 * SMF communication type structure
 */
typedef struct
{
   gmaStructHeader_t header;
   uint32 type; 
} smfCommCommType_t;

/**
 * SMF Modem configuration structure
 */
typedef struct
{
   gmaStructHeader_t header;
   smfCommConfigModem_t cfg;
} smfCommCfgModem_t;

/**
 * SMF Serial configuration structure
 */
typedef struct
{
   gmaStructHeader_t header;
   smfCommConfigSerial_t cfg;
} smfCommCfgSerial_t;

/**
 * SMF configuration structure
 */
typedef struct
{
   gmaStructHeader_t    header;
   smfCommConfigSMF_t cfg;
   uint16 rfu;
} smfCommCfgSMF_t;

/**
 * SMF socket configuration
 */
typedef struct
{
	gmaStructHeader_t header;
	smfCommConfigSocket_t cfg;
} smfCommCfgSocket_t;

/**
 * 
 */
typedef struct
{
	gmaStructHeader_t header;
	smfCommConfigScheduleMnt_t cfg;
} smfCommCfgScheduleMnt_t;

	

/**
 * SMF result structure
 */
typedef struct
{
   gmaStructHeader_t header;
   int16 result;
   uint16 rfu;
} smfCommSmfResult_t;

#ifdef __cplusplus
}
#endif


#endif


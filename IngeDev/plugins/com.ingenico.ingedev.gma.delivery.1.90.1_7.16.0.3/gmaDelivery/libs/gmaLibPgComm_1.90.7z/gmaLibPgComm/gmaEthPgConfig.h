#ifndef GMA_ETH_PG_CONFIG_H_INCLUDED
#define GMA_ETH_PG_CONFIG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "gmaDefines.h"

#include "gmaLibPgStructDefs.h"

/**
 * @file gmaEthPgConfig.h
 *
 * Functions to configure the ethernet plug-in
 */
	
/**
 * ETH_STRUCT_CONFIG_CONNECTION
 * Message to be sent to plugin containing new ethernet
 * configuration parameters
 */
struct ethMsgConfigEth_s
{
   gmaStructHeader_t header;
    uint8  connectionType; // DHCP or IPFIX
    uint8  RFU_1;
    uint16 RFU_2;
    uint32 localIpAddress;
    uint32 IpSubMask;
    uint32 dns1;
    uint32 dns2;
    uint32 dhcpServer;
    uint32 gateway;
};
typedef struct ethMsgConfigEth_s ethMsgConfigEth_t;

/**
 * Message expected from plugin as a reply of the message
 * ETH_STRUCT_CONFIG_CONNECTION
 */
struct ethMsgConfigEthReply_s
{
   gmaStructHeader_t header;
   uint32 status;
};
typedef struct ethMsgConfigEthReply_s ethMsgConfigEthReply_t;

/**
 * Sends ethernet configuration parameters to the GMA ethernet plugin.
 * 
 * @param connType Connection type (0 = fixed IP  1 = DHCP)
 * @param localIp  Local IP address
 * @param IpMask   IP Subnet Mask
 * @param dns1     Primary DNS
 * @param dns2     Secondary DNS
 * @param gateway  Gateway
 * 
 * @return RET_OK if success
 * @return GMA_PG_MSG_PLUGIN_NOT_FOUND the plugin was not found
 * @return GMA_PG_MSG_INTERNAL_ERROR o.s. error (should never happen)
 * @return GMA_PG_MSG_NO_RESOURCE system resource problem (should never happen) 
 */
int16 gmaEthPgConfig(uint8 connType, char* localIp, char* IpMask, char* dns1, char* dns2, char* gateway);

#ifdef __cplusplus
}
#endif

#endif



#ifndef GMA_INQ_STATUS_INT_H_INCLUDED
#define GMA_INQ_STATUS_INT_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#include "gmaLibPgStructDefs.h"


#define GMA_INQ_INQUIRE_TYPE_GSM_SIGNAL        (1)
#define GMA_INQ_INQUIRE_TYPE_GSM_SIGNAL_UPDATE (2)
#define GMA_INQ_INQUIRE_TYPE_GSM_IMEI_IMSI     (3)
#define GMA_INQ_INQUIRE_TYPE_GSM_LAST_ERRORS   (4)
#define GMA_INQ_INQUIRE_TYPE_GSM_GPRS_INFO     (5)
#define GMA_INQ_INQUIRE_TYPE_GSM_GPRS_CONN     (6)
#define GMA_INQ_INQUIRE_TYPE_GSM_GPRS_DISCONN  (7)
#define GMA_INQ_INQUIRE_TYPE_GSM_GPRS_DISCONN_NODETACH (8)




#define GMA_INQ_INQUIRE_TYPE_BATT_LEVEL        (3)


#define GMA_INQ_INQUIRE_TYPE_WIFI_SIGNAL       (1)

/**
 * Structure to inform the inquire type.
 */
typedef struct gmaInqStructInquire_st gmaInqStructInquire_t;

/**
 * Structure to inform the inquire type.
 */
struct gmaInqStructInquire_st
{
	gmaStructHeader_t header;
	uint16 inquireType;
};

/**
 * Structure that the GSM plug-in inform the GSM signal level
 */
typedef struct gmaInqStructGsmSignLevel_st gmaInqStructGsmSignLevel_t;

/**
 * Structure that the GSM plug-in inform the GSM signal level
 */
struct gmaInqStructGsmSignLevel_st
{
	gmaStructHeader_t header;
	uint8 signLevel;
	uint8 gprsStatus;
	uint16 errStatus;
};

/**
 * Structure that the WIFI plug-in inform the WIFI signal level
 */
typedef struct gmaInqStructWiFiSignLevel_st gmaInqStructWiFiSignLevel_t;

/**
 * Structure that the WIFI plug-in inform the WIFI signal level
 */
struct gmaInqStructWiFiSignLevel_st
{
	gmaStructHeader_t header;
	uint8 signLevel;
	uint8 wifiStatus;
	uint16 errStatus;
};

/**
 * GMA_INQ_STRUCT_BATT_LEVEL
 */
typedef struct gmaInqStructPorBattLevel_st gmaInqStructPorBattLevel_t;

/**
 * 
 */
struct gmaInqStructPorBattLevel_st
{
	gmaStructHeader_t header;
	uint8 battLevel;
	uint8 battCharging;
	uint8 termDocked;
	uint8 rfu;
};



/**
 * Structure that the GSM plug-in inform the GSM IMSI and IMEI
 */
typedef struct gmaInqStructGsmImeiImsi_st gmaInqStructGsmImeiImsi_t;

/**
 * Structure that the GSM plug-in inform the GSM signal level
 */
struct gmaInqStructGsmImeiImsi_st
{
	gmaStructHeader_t header;
	char Imsi[17];
	uint8 rfu1;
	char Imei[17];
	uint8 rfu2;
};


typedef struct gmaInqStructGsmErrors_st gmaInqStructGsmErrors_t;

struct gmaInqStructGsmErrors_st
{
	gmaStructHeader_t header;
	int16 lastGsmError;
	int16 lastGprsError;
};

/**
 * Structure that the GSM plug-in inform the GPRS connection params
 */
typedef struct gmaInqStructGsmGprsInfo_st gmaInqStructGsmGprsInfo_t;

struct gmaInqStructGsmGprsInfo_st
{
	gmaStructHeader_t header;
	uint8 connected;
	uint8 rfu1;
	uint16 rfu2;
	uint32 localIpAddress;
	uint32 dns1;
	uint32 dns2;
};

/**
 * 
 */
typedef struct gmaInqStructGsmGprsConn_st gmaInqStructGsmGprsConn_t;

struct gmaInqStructGsmGprsConn_st
{
	gmaStructHeader_t header;
	int16  retCode;
	uint16 rfu;
};


#ifdef __cplusplus
}
#endif


#endif


#ifndef GMA_GSM_PG_H_INCLUDED
#define GMA_GSM_PG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "gmaDefines.h"

#include "gmaLibPgStructDefs.h"

/**
 * @file gmaGsmPg.h
 *
 * Functions to make requests to the GMA GSM plug-in
 */

/**
 * Ask the GMA GSM plug-in to disconnect
 * 
 * @return gmaLibPgReqCloseHandle return values 
 */
int16 gmaGsmPgCloseHandle(void);

/**
 * Ask the GMA GSM plug-in to reset connection
 * 
 * @return gmaLibPgReqResetConn return values 
 */
int16 gmaGsmPgResetHandle(void);


#ifdef __cplusplus
}
#endif

#endif



#ifndef GMA_INQ_STATUS_H_INCLUDED
#define GMA_INQ_STATUS_H_INCLUDED

#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaInqStatus.h
 *
 * Functions to get the plug-in status.
 */

/**
 * Plug-in not found
 */
#define GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND (-1)
/**
 * No resource to open the communication channel
 * with the plug-in
 */
#define GMA_INQ_STS_ERR_NO_RESOURCE      (-2)
/**
 * The plug-in is not connected
 */
#define GMA_INQ_STS_ERR_NOT_CONNECTED    (-3)
/**
 * Internal error
 */
#define GMA_INQ_STS_ERR_INTERNAL         (-4)
/**
 * Plug-in don't support this inquire
 */
#define GMA_INQ_STS_ERR_NOT_SUPP_BY_PG   (-5)



/**
 * Ask the GSM plug-in about the GSM signal level and
 * if the GPRS is connected or not.
 * 
 * @param rssi a pointer to a uint8 that will receive the
 *                   GSM signal level. The RSSI is a value
 *                   from 0 (meaning no signal) to 31 (meaning 
 *                   maximum signal level).
 * @param gprsStatus a pointer to a uint8 that will receive the
 *                   GPRS status. 1 means connected, 0 means not
 *                   connected to the GPRS network.
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_NOT_CONNECTED not connected to the GSM network
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmSignLevel(uint8 *rssi, uint8 *gprsStatus);

/**
 * Ask the WiFi plug-in about the WiFi signal level and
 * if the WiFi is connected or not.
 * 
 * @param rssi a pointer to a uint8 that will receive the
 *                   WiFi signal level. The RSSI is a value
 *                   from 0 (meaning no signal) to 31 (meaning 
 *                   maximum signal level).
 * @param gprsStatus a pointer to a uint8 that will receive the
 *                   GPRS status. 1 means connected, 0 means not
 *                   connected to the GPRS network.
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_NOT_CONNECTED not connected to the WiFi network
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqWiFiSignLevel(uint8 *rssi, uint8 *wifiStatus);

/**
 * Ask the GSM plug-in to update the signal level.
 * Only update internally the signal, use the function
 * \ref gmaInqPorBattLevel to get the signal level.
 * 
 * @return RET_OK always return RET_OK
 */
int16 gmaInqGsmSignUpdate(void);


/**
 * Ask the POR plug-in about the battery level.
 * 
 * @param level a pointer to a uint8 that will receive the
 * battery level (percentage of the battery charge, 0 to 100).
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqPorBattLevel(uint8 *level);

/**
 * Ask the POR plug-in about the battery level, if the
 * terminal is docked and if the terminal is charging.
 * 
 * @param level a pointer to a uint8 that will receive the
 * battery level (percentage of the battery charge, 0 to 100).
 * 
 * @param docked a pointer to a uint8 that will receive
 * the dock information: 0 mean terminal not docked, 1 mean terminal docked.
 * 
 * @param charging a pointer to a uint8 that will receive charging info:
 * See the POR.h enum batteryState_t (POR_BATTERY_PACK_NO_CHARGE,
 * POR_BATTERY_PACK_CHARGING, POR_BATTERY_PACK_TRICKLE_CHARGE or
 * POR_BATTERY_PACK_STARTING_CHARGE).
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqPorBattLevelExt(uint8 *level, uint8 *docked, uint8 *charging);

/**
 * Ask the GSM plug-in about the IMEI and IMSI.
 * 
 * @param imei a pointer to a string to receive the IMEI
 * @param imsi a pointer to a string to receive the IMSI
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmImeiImsi(char *imei, char *imsi);

/**
 * Ask the GSM plug-in about the last GSM/GPRS errors
 * 
 * @param gprsError a pointer to a int16 that will receive
 * the gprs error or 0 if there is no error.
 * - -11: netNiStart error when the error not fit in the errors bellow
 * - -12: netNiStart error NET_ERR_NI_IN_WRONG_STATE
 * - -13: netNiStart error NET_ECONNREFUSED
 * - -14: netNiStart error NET_ETIMEDOUT
 * - -20: error in the attach process.
 * - -22: GPRS not allowed (GSM_CME_ERROR error number 107)
 * - -23: GPRS UNSPECIFIED error (GSM_CME_ERROR error 148)
 * - -24: GPRS PDP AUTH FAILURE (GSM_CME_ERROR error 149)
 * - -25: GPRS MISSING/UNK APN (GSM_CME_ERROR error 533)
 * - -27: temp unavailable   (GSM_CME_ERROR error 134)
 * - -28: connection timeout
 * - -30: GPRS internal error
 * - -31: APN not set 
 * 
 * @param gsmError a pointer to a int16 that will receive
 * the GSM error or 0 if there is no error. 
 * - -1: PIN required
 * - -2: PUK required
 * - -3: SIM not inserted 
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmLastErrors(int16 *gprsError, int16 *gsmError);

/**
 * Gets the information regarding the actual GPRS connection.
 * 
 * @param connected if 1 means the GSM plug-in is connected to the GPRS network
 * 
 * @param localIpAddr a pointer to a uint32 that will receive the local IP address
 * if the GSM plug-in is connected to the GPRS network
 * 
 * @param dns1 a pointer to a uint32 that will receive the first DNS server
 * if the GSM plug-in is connected to the GPRS network 
 * 
 * @param dns2 a pointer to a uint32 that will receive the second DNS server
 * if the GSM plug-in is connected to the GPRS network 
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmGprsInfo(uint8 *connected, uint32 *localIpAddr, uint32 *dns1, uint32 *dns2);

/**
 * Send a message to the GSM plug-in asking a connection to the GPRS network.
 * 
 * @param retCode a pointer to a int16 that will receive the status of the connection
 * request. If 0 means success in the connection attempt, if -1 there is an error in the
 * connection attempt, call the function \ref gmaInqGsmLastErrors to get more details.
 * 
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmGprsConn(int16 *retCode);

/**
 * Send a message to the GSM plug-in asking a disconnection from the 
 * GPRS network.
 * 
 * @param detach if 1 it will also make the detack from the GPRS when disconnecting.
 *
 * @return RET_OK no errors
 * @return GMA_INQ_STS_ERR_PLUGIN_NOT_FOUND
 * @return GMA_INQ_STS_ERR_NO_RESOURCE
 * @return GMA_INQ_STS_ERR_INTERNAL internal error
 * @return GMA_INQ_STS_ERR_NOT_SUPP_BY_PG
 */
int16 gmaInqGsmGprsDiscon(uint8 detach);


#ifdef __cplusplus
}
#endif


#endif




#ifndef SMF_COMM_H_INCLUDED
#define SMF_COMM_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file smfComm.h
 *
 * Functions to configure the SMF plug-in and/or start a maintenance session.
 */

/*
 * Generic defines
 */
#define SMF_COMM_MAX_PHONE_SIZE      (32)
#define SMF_COMM_MAX_PREFIX_SIZE     (3)
#define SMF_COMM_MAX_PORT_NAME_SIZE  (6)
#define SMF_COMM_CALL_INFO_SIZE      (4)

/**
 * SMF communication type
 */
typedef enum
{
   SMF_SERIAL, //!< Serial communication type
   SMF_MODEM,   //!< Modem communication type
   SMF_SOCKET  //!< Socket communication type
} smfCommCommType;

/**
 * Type of SMF start.
 */
typedef enum
{
   SMF_DIRECT,  //!< Direct start
   SMF_INDIRECT //!< indirect start
} smfCommDirectStart;

/**
 * SMF configuration. SMF connection type to be sent to the Ingestate server
 */
typedef enum {
   MTA_MANUAL,
   MTA_INTERAPP,
   MTA_RECONNECT
} smfCommConnectType;

/**
 * SMF Modem configuration structure
 */
typedef struct
{
   uint8 modulationType;                    //!< modulation type (see unicapt documentation for more details)
   /* COM_MODEM_MODULATION_DEFAULT
    * COM_MODEM_MODULATION_V22
    * COM_MODEM_MODULATION_V22B
    * COM_MODEM_MODULATION_V32
    * COM_MODEM_MODULATION_V32B
    * COM_MODEM_MODULATION_V34
    */
   uint8 minSpeed;                          //!< minimum connection speedy (see unicapt documentation for more details) 
   uint8 maxSpeed;                          //!< maximum connection speedy (see unicapt documentation for more details)
   /* COM_BPS_1200
    * COM_BPS_2400
    * COM_BPS_9600
    * COM_BPS_19200
    * COM_BPS_33600
    */
   uint8 countryCode;                       //!< define the country code (see unicapt documentation for more details)
   /* COM_T35_France
    * COM_T35_Brazil
    * COM_T35_Mexico
    * COM_T35_United_Kingdom
    * COM_T35_United_States
    * COM_T35_Canada
    * COM_T35_Germany
    * COM_T35_Spain
    */
   uint8 dataCompression;                   //!< define the data compression type (see unicapt documentation for more details)
   /* COM_COMPRESSION_NONE
    * COM_COMPRESSION_V42B
    * COM_COMPRESSION_MNP5
    * COM_COMPRESSION_V42B_MNP5
    */
   uint8 errorCorrection;                   //!< define the error correction type (see unicapt documentation for more details)
   /*COM_CORRECTION_NONE
    * COM_CORRECTION_LAPM
    * COM_CORRECTION_MNP
    * COM_CORRECTION_LAPM_MNP
    */
   char phone[SMF_COMM_MAX_PHONE_SIZE + 1]; //!< set the telephone number to dial 
   
   char prefix[SMF_COMM_MAX_PREFIX_SIZE + 1]; //!< set the preffix
   uint8 detectDialTone;                    //!< if the modem will try to detect the dial tone before dial
   /* TRUE
    * FALSE
    */
   uint8 detectLine;                        //!< if 0 there will be no detect line attempt. The line detection is made by the os reading the line voltage
   /* TRUE
    * FALSE
    */
   uint8 useToneDialing;                    //!<  True to use tone dialing, false to not use
   /* TRUE
    * FALSE
    */
   uint8 ringMode;                         //!<  ring mode (see unicapt documentation for more details)
   /* COM_RING_NO_RING},
    * COM_RING_AUTO_ANSWER
    */
   uint8 ringNumber;                       //!< ring number (see unicapt documentation for more details)
} smfCommConfigModem_t;

/**
 * SMF Serial configuration structure
 */
typedef struct
{
   uint8 speed;
   /* COM_BAUD_9600
    * COM_BAUD_38400
    * COM_BAUD_57600
    * COM_BAUD_115200
    */
   char comPortName[SMF_COMM_MAX_PORT_NAME_SIZE + 1];
   /*
    * "COM1"
    * "COM2"
    */
} smfCommConfigSerial_t;

/**
 * SMF configuration structure
 */
typedef struct
{
   char CallInfo[SMF_COMM_CALL_INFO_SIZE];
   uint8 Reason;
   /* MTA_MANUAL
    * MTA_INTERAPP
    * MTA_RECONNECT
    */
   uint8 Retries;
} smfCommConfigSMF_t;

/**
 * SMF call schedule configuration structure
 */
typedef struct 
{
	/**
	 * What to do:
	 * - 2 -> ask for the actual date/time
	 * - 1 -> set the next maintenance date/time
	 * - 0 -> delete the actual schedule
	 */
	 uint16 action;
	 uint16 rfu;
	 
	 uint32 date; //!< schedule date
	 uint32 time; //!< schedule time
	 
}smfCommConfigScheduleMnt_t;

/**
 * SMF Socket configuration structure
 */
typedef struct 
{
	/**
	 * Ip address in the form "xxx.xxx.xxx.xxx",
	 * if host name not used
	 */
	char ipAddress[15+1];
	/**
	 * tcp port
	 */
	char tcpPort[5+1];
	char rfu[2];
	/**
	 * host name if IP not used
	 */
	char hostName[32];
}smfCommConfigSocket_t;

/**
 * Set the connection type to be used by the SMF plug-in.
 * One of the values in the \ref smfCommCommType enum.
 * @param connType the connection type, one of the values
 * from the \ref smfCommCommType enum.
 */
int16 smfCommConfigConnection (uint32 connType);


/**
 * Add the serial configuration to the message to the SMF plugin.
 * 
 * @param config a pointer to the configuration to be added.
 */
int16 smfCommConfigSerial (smfCommConfigSerial_t *config);

/**
 * Add the modem configuration to the message to the SMF plugin.
 * 
 * @param config a pointer to the configuration to be added.
 */
int16 smfCommConfigModem (smfCommConfigModem_t *config);

/**
 * Add the socket configuration to the message to the SMF plugin.
 * 
 * @param config a pointer to the configuration to be added.
 */
int16 smfCommConfigSocket(smfCommConfigSocket_t *config);

/**
 * Add the schedule maintenance date/time to the message to the SMF plugin.
 * 
 * @param config a pointer to the configuration to be added.
 */
int16 smfCommConfigScheduleMnt(smfCommConfigScheduleMnt_t *config);


/**
 * Add the SMF configuration to the message to the SMF plugin.
 * 
 * @param config a pointer to the configuration to be added.
 */
int16 smfCommConfigSMF (smfCommConfigSMF_t *config);

/**
 * Send the message to the SMF plugin previous set by the functions
 * \ref smfCommConfigConnection, \ref smfCommConfigSerial,
 * \ref smfCommConfigModem and/or \ref smfCommConfigSMF.
 * 
 * @param option the action to the plugin take when receive the message.
 */
int16 smfCommStart (smfCommDirectStart option);

#ifdef __cplusplus
}
#endif


#endif



#ifndef SMF_USER_COMMAND_H_INCLUDED
#define SMF_USER_COMMAND_H_INCLUDED

#include "maintExec.h"
/**
 * SMF user command support
 */


/**
 * Reset the user command list
 */
void smfResetUserCommands(void);


/**
 * Add a user command callbacl to the user command list
 *
 * @param commandType the command type number to be treated (a number from 0x90 to 0xFF).
 * @param cb the function that will be used to treat this command.
 *
 * @return RET_OK no errors
 * @return SMF_ERR_LIST_FULL no more space to add callbacks, \ref SMF_MAX_CB_USER_COMMANDS
 */
int16 smfAddUserCommand(uint8 commandType, treatUserWrapperCommand cb);

/**
 * Get an user command callback from the user command list
 *
 * @param commandType the command type number to be treated (a number from 0x90 to 0xFF).
 * @param cb a pointer ti receive the function that will be used to treat this command.
 *
 * @return RET_OK function found
 * @return SMF_ERR_NO_FUNCTION the command is not added to the list
 */
int16 smfGetUserCommand(uint8 commandType, treatUserWrapperCommand *cb);

#endif



#ifndef MAINT_EXEC_H_INCLUDED
#define MAINT_EXEC_H_INCLUDED

/** \addtogroup SMF 
 *
 * 
 *  @{
 */
 
/** \file maintExec.h
 */

#include "mtaStd.h"
#include "wrapper.h"

#define mtaConnectionData mntConnectionData_t

/**
 * the name fo the maintenance profile file
 */
#define MAINTENANCE_FILE 	"c:\\MAINT"
//#define COMMS_FILE			"c:\\MaintPr"

/* Return Codes */
#define SMF_ERROR_BASE          (0)
#define SMF_OK				        (0)
/**
 * Error to open the communication channel
 */
#define SMF_ERR_COM_OPEN	     (SMF_ERROR_BASE - 1)
/**
 * Error in the function ssaDwlOpen.
 */
#define SMF_ERR_MNT_OPEN	     (SMF_ERROR_BASE - 2)
/**
 * Error in the function ssaIdent2
 */
#define SMF_ERR_SSA_ID		     (SMF_ERROR_BASE - 3)
/**
 * there is no retries to be made
 */
#define SMF_NO_ATTEMPTS		     (SMF_ERROR_BASE - 4)

#define SMF_ERR_LOGON		     (SMF_ERROR_BASE - 5)

#define SMF_LINE_DISCONNECTED   (SMF_ERROR_BASE - 6)
#define SMF_LINE_IN_USE         (SMF_ERROR_BASE - 7)
#define SMF_CARRIER_LOST 		  (SMF_ERROR_BASE - 8)
#define SMF_CONNECTION_FAILED	  (SMF_ERROR_BASE - 9)
#define SMF_TIMEOUT_EXPIRED     (SMF_ERROR_BASE - 10)

#define SMF_USER_ABORT			  (SMF_ERROR_BASE - 11)
#define SMF_RX_ERROR            (SMF_ERROR_BASE - 12)
#define SMF_TX_ERROR            (SMF_ERROR_BASE - 13)
#define SMF_NOT_MAINT_SESSION   (SMF_ERROR_BASE - 14)
#define SMF_BLOCKED             (SMF_ERROR_BASE - 15)

#define SMF_ERR_LIST_FULL            (SMF_ERROR_BASE - 16)
#define SMF_ERR_NO_FUNCTION          (SMF_ERROR_BASE - 17)

#define SMF_ERR_COMM_SSA             (SMF_ERROR_BASE - 18)
#define SMF_ERR_TRUST_FAILED_NEGO    (SMF_ERROR_BASE - 19)
#define SMF_ERR_TRUST_FAILED_SPONSOR (SMF_ERROR_BASE - 20)
#define SMF_ERR_TRUST_BAD_APW_FRAME  (SMF_ERROR_BASE - 21)
#define SMF_ERR_INTERNAL             (SMF_ERROR_BASE - 22)


#define SMF_MAX_CB_USER_COMMANDS (10) //!< max number of user commands that can be treated

/* End of Error Codes */

/*WRAPPER FUNCTION POINTER TYPEDEFS &STRUC */
/**
 * definition of the callback used to create the logon frame
 * \param pBuffer (O) buffer that will receive the logon frame
 * \param maximumSizeOfBuffer (I) The size of the pBuffer
 * 
 * \return
 *  The number of bytes of the logon frame, see 
 */
typedef uint32 (*ptrWrpOpen) ( uint8 *const pBuffer, const uint32 maximumSizeOfBuffer );

/**
 * definition of the callback called when the connection will be finished
 *
 * \param hmihandle (I) handle of HMI
 * \param reasonCodeForClose (I) The reason code for the closure (may
 *                                        be over-ridden by an internal reason)
 *
 * \return 
 *   the number of bytes in the close frame
 */
typedef uint32 (*ptrWrpClose) ( uint32 hmiHandle,wrapError_t  reasonCodeForClose   );

/**
 * definition of the callback that treat the received frames and prepare the response frames
 *
 * \param hmihandle (I) the handle of HMI
 * \param sizeOfFrame (I) the length of bytes actually received 
 * \param mntHandle (I) The handle of the already opened maintenance session
 * \param pSizeOfReply (O) If the input frame has been processed this will return the length of the buffer to be
 *             returned to the server
 * \param pBuffer pointer to a buffer with the received data. Will be used to store the return message to the server when the 
 * received message is processed
 *
 * \return 
 *    0 if the frame has been processed or was too large (when sizeOfFrame is
 *       NOT also 0) OR if the last frame has been processed and the session
 *       should be closed (when sizeOfFrame IS also 0).
 *    5 if the frame has not yet been collected (when sizeOfFrame is 0) and the
 *       maintenance session is not yet ready to close.
 *    Otherwise the number of bytes left to add to the end of the buffer to
 *    complete the frame's reception.
 */
typedef int32 (*ptrWrpProcess) ( const uint32 hmiHandle, const uint32 sizeOfFrame,
                    uint32 *mntHandle, uint32 *const pSizeOfReply,uint8 *const pBuffer 
                   );

/**
 * definition of the callback used to print a dump. The default implementation of this function
 * print the buffer if the F3 button is held pressed
 * 
 * @param hmiHandle (I) the hmi handle, normally used to check the keyboard in the default
 *    implementation
 * @param  header (I) the top line of the dump.
 * @param memory  (I) the buffer to be displayed in the dump
 * @param size    (I) the size of the buffer ti be displayed
 */
typedef void (*ptrWrpFrameDisplay) (const uint32 hmiHandle, const char *header,
                                 const void *memory,     uint32 size);

/**
 * definition of the callback that checks the server name. This callback is called 
 * when the terminal receives the authenticate command.
 * 
 * @param serverName (I) the name of the server received in the authenticate command
 * 
 * @return if not RET_OK the maintenance session will be stoped.
*/ 
typedef int16 (*ptrWrpCheckServer) (char *serverName);

/**
 * Struct that define the wrappers callbacks
 */
typedef struct _mtaWrapperCallback{
ptrWrpOpen  open;      /**< callback that create the logon frame */
ptrWrpClose close;     /**< callback that ...*/
ptrWrpProcess process; /**< callback that process the received orders*/
ptrWrpFrameDisplay fd; /**< callback to make a dump*/
ptrWrpCheckServer checkServer; /**< callback called with the server name, used to decide 
                                    if the maintenance will continue*/
void *wrapperParam;    /**< point to parameters that are sent to the callback functions*/
}mtaWrapperCallback;

/*COMM FUNCTION POINTER TYPEDEFS &STRUC*/
/**
 * definition of the callbacks send and recv of the mtaCommCallback struct. This callbacks are used
 * to send and receive data.
 *
 * \param commStruct (I/O)  pointer to a parameter/struct initialize by the user application, the comParam
 * of the struct mtaCommCallback. Normally this parameter has the handle of the communication channel.
 *
 * \param buferlen (I/O) when implementing the send callback receive a pointer to a uint32 with the number of bytes to be send
 *  in the buffer. When implementing the recv function receive a pointer to uint32 with the max length of the buffer and the function
 *  change the value to the number of bytes received.
 *
 * \param buffer (I/O) point to a buffer with the data to be send when implementing the send function, and a buffer to receive
 *            the data when implementing the recv function
 */
typedef int16 (*ptrCommCall) (void *commStruct, uint32 *bufferlen, uint8 *buffer);

/**
 * definition of the callbacks pOpen and pClose of the mtaCommCallback struct. This callbacks are used
 * for open and close the communication channel used in the maintenance session
 *
 * \param commStruct pointer to a parameter/struct initialize by the user application, the comParam
 * of the struct mtaCommCallback. Normally this parameter has the handle of the communication channel
 */
typedef int16 (*ptrCommOpenClose) (void *commStruct);

/**
 * Struct that define the communications callbacks
 *
 */
typedef struct _mtaCommCallback{
   ptrCommOpenClose pOpen;  /**< callback called to open the communication channel, and let the channel ready to send and receive data*/
   ptrCommOpenClose pClose; /**< callback called to close the communications channel*/
   ptrCommCall send; /**< callback called to send data through the communciation channel*/
   ptrCommCall recv; /**< callback called to receive data through the communciation channel*/
   void* comParam;   /**< pointer to a parameter or struct that is passed to the callbacks*/
}mtaCommCallback;



/*HMI FUNCTION POINTER TYPEDEFS &STRUC*/

/**
 * Definition of the callback pHmi. This callback is called to show messages in the display.
 * 
 * @param hmiStruct (I/O) pointer to a value/struct initialized by the application, the hmiStruct parameter of the
 *    mtaHmiCallback struct. Normally this parameter can store the hmi handle.
 * 
 * @param frameNumber (I) The number of the frame
 * 
 * @param state (I) Tell to the function what to display, the following values can
 * be used:
 *  - 0x00 - to inform the retries is equal 0
 *  - 0x01 - order to the glabal variable &hmiParams.string[0]
 *  - 0x02 - to inform that the SMF have an error in the function ssaDwlOpen.
 *  - 0x03 - to inform that the SMF have an error to open the communication channel.
 *  - 0x04 - to inform that the maintenance session is ending
 *  - 0x05 - to inform a problem in generate the logon frame
 *  - 0x06 - to inform that the terminal will prepare the logon frame and send it to the server
 *  - 0x07 - to inform an error while send data to the server. The send callback of the struct \ref _mtaCommCallback.
 *  - 0x08 - to inform that the terminal will receive data
 *  - 0x10 - to inform that the terminal is sending a frame to the server
 *  - 0x11 - to ask to clear the line where the above messages are displayed
 *  - 0x12 - to inform that the terminal receives a close frame
 *  - 0x13 - to inform that the terminal receives a frame that it can't treat
 *  - 0x14 - to inform that the terminal receives a illegal frame
 *  - 0x15 - to ask the terminal to clear all lines of the display
 *  - 0x16 - to inform that the terminal receives an unknown frame
 *  - 0x17 - to inform that the terminal is processing a U32 frame
 *  - 0x18 - return HMI_KEY_F3 or HMI_KEY_F6 if you want to print the trace of
 *          the frames. In the default implementation of this callback the
 *          keyboard is checked for one of this keys presseds and the key pressed is
 *          returned. 
 *  - 0x19 - put in the display the global variable uint8 *message.
 *  - 0xF0 - to ask for a beep (in the default implementation the function hmiBeep is
 *          called). This callback is called if the communication port was opened with no errors,
 *          to inform the user that the maintenance session will begin.
 *  - 0xFA - to inform that a Disable default display order arrive, and the messages 
 *           will not be put in the display.
 *  - 0xFB - to inform that a Enable default display frame arrive, and the messages 
 *          will now be put in the display.
 */   
typedef int16 (*ptrHmiCall) (void *hmiStruct, uint32 frameNumber, uint32 state);

/**
 * Definition of the callbacks pOpen and pClose in the mtaHmiCallback structure. The pOpen callback
 * is used to open the hmi handle and the pClose to close the hmi Handle.
 * 
 * @param hmiStruct (I/O) pointer to a value/struct initialized by the application, the hmiStruct parameter of the
 *    mtaHmiCallback struct. Normally this parameter can store the hmi handle.
 */
typedef uint32 (*ptrHmiOpenClose) (void *hmiStruct);

/**
 * Definition of the hostProcess callback in the mtaHostControlCommandCallback structure. This callback
 * is called when the terminal receives a Display Frame. The parameters of the duisplay frame 
 * are passed to this callback and in the default implementation the message is displayed
 * in the terminal.
 * 
 * @param commandId (I) in the actual implementation is always 0.
 * @param bufferIn (I) the buffer with the command string. The first byte has the 
 * line when the text have to be displayed. The second byte has the column. And the 
 * rest has the message to be displayed with the 0 terminator.
 * 
 * @return the return value of this callback is ignored in the actual implementation
 * 
 */
typedef int16 (*ptrHostCall) (uint8 commandID, uint8* bufferIn, uint32 bufferInLength,
                               uint8* response, uint32 responseLength, void *hostParam);


/**
 * Struct that defines the hmi callbacks
 */
typedef struct _mtaHmiCallback{
   ptrHmiCall pHmi; /**< callback called to show message in the display*/
   ptrHmiOpenClose pOpen; /**< callback called to open the hmi Handle*/
   ptrHmiOpenClose pClose; /**< call back called to close the hmi Handle */
   ptrHmiCall abort;  /**< not implemented yet*/
   ptrHmiCall frame; /**< not implemented*/
   void *hmiStruct; /**< struct/data poiter initialized by the application */
   uint32 frameResolution; /**< not used yet*/
}mtaHmiCallback;

/**
 * Structures that defines the host commands callbacks
 */
typedef struct _mtaHostControlCommandCallback{
    ptrHostCall hostProcess; /**< callback called when the terminal receives a Display frame*/
    void *hostParam; /**< pointer to a param or struct that is passed to the hostProcess callback*/
}mtaHostControlCommandCallback;

// Used for incoming call handler
typedef int16 (*incomingPtr) (uint32 handle, void *commsParam);

/**
 * Reset the user command list. will clear all the entries in the user command list
 *
 * @return RET_OK. no errors
 */
int16 mtaMaintResetUserCommands(void);

/**
 * Callback used to treat user wrapper commands (commands with type between 0x90 and 0xFF)
 * To treat a user command type it is needed to call the function \ref mtaMaintInstUserCmd
 * with the command type number and the callback function that will treat the command.
 *
 * @param recFrame The received frame from the server
 * @param frameSize The received frame size
 * @param answerFrame a pointer to a buffer where to write the answer. The answer
 *        will be the Data part of an ACK or NACK frame. An ACK frame if the
 *        return is RET_OK and a NACK frame if the return value is another value.
 *
 * @return if the function returns RET_OK the ACK frame will be set.
 * @return if any other value is returned the NACK frame will be set.
 */
typedef int16 (*treatUserWrapperCommand)(const uint8 *recFrame, uint16 frameSize, 
                                         uint8 *answerFrame, uint16 *answerFrameSize);

/**
 * Add a treatment to a user wrapper command type. (commands with type
 * between 0x90 and 0xFF). The user says what command want to treat and what function
 * will be used to treat this command. This function can be called more than
 * once and ask to treat for more than one command. The max treated commands is
 * defined by \ref SMF_MAX_CB_USER_COMMANDS
 *
 * @param commandType the command type number to be treated (a number from 0x90 to 0xFF).
 * @param cb the function that will be used to treat this command.
 *
 * @return RET_OK no errors
 * @return SMF_ERR_LIST_FULL no more space to add callbacks, \ref SMF_MAX_CB_USER_COMMANDS
 */
int16 mtaMaintInstUserCmd(uint8 commandType, treatUserWrapperCommand cb);

void varsDefault (mntMaintenanceData_t *pMaintenanceData, mntConnectionData_t *pConnectionData);

/**
 * start a maintenance session using the callbacks passed in the function. The SMF configuration have to be set before.
 *
 * \param hmiCall (I) pointer to the mtaHmiCallback struct with the callbacks that handles the display interface, 
 *            this callbacks doen't need to be implemented by the user application, defaults are available. NULL if you want
 *            to use the defaults
 * \param wrapperCall (I) pointer to the mtaWrapperCallback struct with the callbacks that implement the wrapper protocol,
 *             this callbacks doen't need to be implemented by the user application, defaults are available. NULL if you want 
 *             to use the defaults
 * \param commCall (I) pointer to the mtaCommCallback struct with the communication callbacks, 
 *                                 this callbacks have to be implemented by the user application, there is no default. Normally the GCL is used
 *                                 to implement the communication
 * \param hostCall (I) pointer to the mtaHostControlCommandCallback struct with the callback called when the server send the order 0x0c
 *                               (display frame) to the host. Null if you want to use the defaults
 *
 * \return 
 *
 */
int16 mtaMaintSessionDo (const mtaHmiCallback *hmiCall, 
                         const mtaWrapperCallback *wrapperCall, 
                         const mtaCommCallback *commCall, 
                         const mtaHostControlCommandCallback *hostCall);


int16 mtaSimpleSessionDo (void);

int16 mtaMaintConfigTLV (char *CommsTLV, char *MaintTLV);

/**
 * will schedule a new call. This information is stored in file.
 * A call to this function erases the previous scheduled call.
 * Take care if the server (Ingestate) has scheduled a call.
 * @param date (I) the date of the next call
 * @param time (I) the time of the next call
 * 
 * @return RET_OK if no errors occurs
 */
int16 smfSetSchedCall (uint32 date, uint32 time);

/**
 * Get the time and date of the next call, normally stored using the function
 * smfSetSchedCall or by a command received from the server (Ingestate).
 * 
 * @param date (O) a pointer to a uint32 that will receive the date of the next call
 * @param time (O) a pointer to a uint32 that will receive the time of the next call
 * 
 * @return RET_OK if no errors occurs
 *         -1 if no next call is configured
 */
int16 smfGetSchedCall (uint32 *date, uint32 *time);

/**
 * Will check if it is time for a smf call.
 *
 * The next call schedule can be done by a call to the function \ref smfGetSchedCall or
 * if the SMF receives a command from the server scheduling the next connection time.
 * 
 * 
 * @return number of seconds for the next call, 0 if it is time for the next call.
 * 0xFFFFFFFF if a error occur.
 */
uint32 smfCheckSchedCall (void);

int16 smfFinishSession (void);


int16 smfSetRepeatPeriod (uint32 date, uint32 time);

int16 smfGetRepeatPeriod (uint32 *date, uint32 *time);

int16 SmfIncomingSessionDo (void);

/**
 * Check if the last maintenance session was finished, if not start the maintenance session with the last parameters
 *
 * \param hmiCall (I) mtaHmiCallback struct with the callbacks that handles the display interface, 
 *            this callbacks doesn't need to be implemented by the user application, defaults are available. put NULL in the
 *            struct fields if you want to use the defaults
 * \param wrapperCall (I) pointer to the mtaWrapperCallback struct with the callbacks that implement the wrapper protocol,
 *             this callbacks doesn't need to be implemented by the user application, defaults are available. put NULL in the
 *            struct fields if you want to use the defaults
 * \param commCall (I) pointer to the mtaCommCallback struct with the communication callbacks, 
 *                                 this callbacks have to be implemented by the user application, there is no default. Normally the GCL is used
 *                                 to implement the communication
 * \param hostCall (I) pointer to the mtaHostControlCommandCallback struct with the callback called when the server send the order 0x0c
 *                               (display frame) to the host. put NULL in the
 *            struct fields if you want to use the defaults
 */
int16 smfFinishCallbacksSession (mtaHmiCallback hmiCall, mtaWrapperCallback wrapperCall, mtaCommCallback commCall, mtaHostControlCommandCallback hostCall);

/**
 * Enable the Command to set the date and time of the terminal.
 * The default is disable. You must call this function with the 
 * desired configuration before start a maintenance session.
 * 
 * @param enable 1 means that the command to set the date/time
 * of the terminal is enabled. 0 otherwise.
 */
void smfCommandEnableSetTime(uint8 enable);

/**
 * Add a firmware name/info pair to be upload to the Ingestate
 * when the Ingestate sent the wrapper command 0x13. See
 * the \ref _wrapperGetFirmwareInfo documentation.
 * See the demo application code to see how to get the firmare info for
 * some common firmwares.
 * 
 * @param firmwareName the name of the firmware. See the table
 * in " \ref _wrapperGetFirmwareInfo " to use a standard name
 * for the common firmwares.
 * 
 * @param info the information get from the firmware to be upload to
 * the ingestate 
 * 
 * @return RET_OK no errors
 * @return ERR_SYS_RESOURCE_PB problems to alloc memory to store
 * the new entry.
 */
int16 smfAddFirmwareInfo(char *firmwareName, char *info);

/**
 * Reset the firmware list inside the SMF that were
 * previous entered by calls to the function \ref smfAddFirmwareInfo
 */
void smfFirmwareListReset(void);


/** @} */
#endif

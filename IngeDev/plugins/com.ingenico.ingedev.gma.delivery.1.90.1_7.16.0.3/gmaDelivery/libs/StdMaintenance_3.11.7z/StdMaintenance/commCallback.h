
#ifndef COMM_CALL_BACK_H_INCLUDED
#define COMM_CALL_BACK_H_INCLUDED

/************************************************************************/
/* Server Initiated Call                                                */
/************************************************************************/
int16 sicOpenCall(void *data)
{
   return RET_OK;
}

/************************************************************************/
/* Normal Call                                                          */
/************************************************************************/
int16 comOpenCall (void *data)
{
   return RET_OK;
}

/************************************************************************/
/* Close the communication channel previously open                      */
/************************************************************************/
int16 comCloseCall (void *data)
{
   return RET_OK;
}

/************************************************************************/
/* Received data using the connection previously open                   */
/************************************************************************/
int16 comRxCall( void *CommStruct, uint32 *bufferlen, uint8 *buffer)
{
   return RET_OK;
}

/************************************************************************/
/* Send data thru the connection previously open                        */
/************************************************************************/
int16 comTxCall( void *CommStruct, uint32 *bufferlen, uint8 *buffer)
{
   return RET_OK;
}



#endif

#ifndef _APPWRAPPER_EXPORTS_H
#define _APPWRAPPER_EXPORTS_H

#include "AppWrapperUserExports.h"
#include "wrapper.h"


uint32 createLogonFrame (uint8 *const pBuffer, const uint32 maximumSizeOfBuffer);
uint32 sendCloseFrame (uint32 hmiHandle, wrapError_t reasonCodeForClose);
void   wrapSFrameDump (const uint32 hmiHandle, const char* header, const void *memory, uint32 size);
int16  wrapperHmi(void *hmiStruct, uint32 frameNumber, uint32 state);
int32  wrapOrder (const uint32 hmiHandle, const uint32 sizeOfFrame, uint32 *mntHandle,uint32 *const pSizeOfReply, uint8 *const pBuffer);
int16 hostCommand (uint8 commandID, uint8 *bufferIn, uint32 bufferInLength, uint8 *response,uint32 responseLength, void *hostParam);
int16 checkServerName(char *serverName);
#endif

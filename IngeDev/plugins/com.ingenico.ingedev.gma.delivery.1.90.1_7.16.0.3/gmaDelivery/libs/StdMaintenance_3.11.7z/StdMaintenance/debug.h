
#ifndef DEBUG_H_INCLUDED_
#define DEBUG_H_INCLUDED_

void debugPrint (char *text);
void comDebugInit (comInit_t *comInit);
void comDebugInitUart(comUartInit_t *comInit);
void comDebugInitModem (comATModemInit_t *comInit);
void comDebugConnect (comConnect_t *comConnect);
void ssaDebugIdent (ssaStaticConf2_t staticConf);
uint16 saveSetup(char *filePath,void *data, uint16 length);

#endif


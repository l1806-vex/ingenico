/*******************************************************************************
                              Property of INGENICO
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Generic Communications Module
 *  FILENAME       :    maintTags.h
 *  PURPOSE        :    Maintenance Tag List
 *
 *  HISTORY
 *
 *  date        author     	modifications
 *  10/05/04    CDL        	Initial Version
 *  17/05/04    CDL        	Addition of RETRIES_TAG
 *  09/06/04    CDL        	Addition of CALL_REASON_TAG
 *  16/06/04    CHH        	Changed CALL_REASON_TAG from \x4D to \x40
 *  14/09/04	CDL 		Added NEXT_DATE_TAG + NEXT_TIME_TAG for cyclic calls
 *  21/09/04	CDL 		Added CURRENT_RETRIES_TAG
 * 	26/10/04	CDL			Added REPEAT_DATE_TAG + REPEAT_TIME_TAG
 *  16/11/04	CDL			Added ERROR_TAG
 * -----------------------------------------------------------------------------
 *  DESCRIPTION    :    
-*/

#ifndef MAINT_TAGS_H_INCLUDED
#define MAINT_TAGS_H_INCLUDED

/** \addtogroup profTags  profile tags
 *
 * The 
 * 
 *  @{
 */


/** 
 * \file maintTags.h
 */


/**
 * Root of all maitenance tags. All the maintenance tags will be
 * inside this tag
 */
#define MAINTENANCE_TAG  	   "\xFF\x01\xFF\x45" 
/**
 * This tag will hold the Maintenance Application Identification data.
 * Normally if no value is set in this tag the maintenance application
 * will add this tag with the "U32MS" value. The length of this value is 
 * 5 bytes. The type is a uint8 vector.
 */
#define APPSIG_TAG       	   "\xFF\x01\xFF\x45\xDF\x46"
/**
 * the version of the wrapper protocol to use. It stores 2 bytes.
 */
#define MAINT_V_TAG      	   "\xFF\x01\xFF\x45\xDF\x47"
/**
 * This field will hold the call info that is sent to the server in the 
 * logon frame. It stores up to 17 bytes.
 */
#define CALLINFO_TAG     	   "\xFF\x01\xFF\x45\xDF\x48"
/**
 * The sap code of the terminal that is sent in the logon frame.
 * If this field is not present in the maintenance configuration, the actual
 * sap code of the terminal (in the config file) will be sent. It stores a
 * vector (string) up to 17 bytes.
 */
#define SAPCODE_TAG      	   "\xFF\x01\xFF\x45\xDF\x49"
/**
 * This tag holds the serial number. It is used if you want to
 * set up a diferent serial number. It stores a vector (string) up to 17 bytes.
 */
#define SERIALNUM_TAG    	   "\xFF\x01\xFF\x45\xDF\x4A"

#define MAINT_STATE_TAG  	   "\xFF\x01\xFF\x45\xDF\x4B"
/**
 * This tag store the number of connection attempts to the server. It stores an uint8 value. The
 * most significant bit is not used, then 0x83 and 0x03 means 3 attempts.
 */
#define RETRIES_TAG      	   "\xFF\x01\xFF\x45\xDF\x4C"
/**
 * This tag stores the reason for calling information. It is an uint8 value.
 */
#define CALL_REASON_TAG  	   "\xFF\x01\xFF\x45\xDF\x40"
/**
 * Internal tag used by the cyclic module
 */
#define NEXT_DATE_TAG 	 	   "\xFF\x01\xFF\x45\xDF\x4D"
/**
 * Internal tag used by the cyclic module
 */
#define NEXT_TIME_TAG    	   "\xFF\x01\xFF\x45\xDF\x4E"
/**
 * This tag stores the current number of connection attempts left.
 * This value is used internally.
 */
#define CURRENT_RETRIES_TAG	"\xFF\x01\xFF\x45\xDF\x4F"
/**
 * Not used
 */
#define MODE_TAG			      "\xFF\x01\xFF\x45\xDF\x50"
/**
 * Not used
 */
#define DELAY_TAG			      "\xFF\x01\xFF\x45\xDF\x51"
/**
 * Internal tag used by the cyclic module
 */
#define REPEAT_DATE_TAG 	   "\xFF\x01\xFF\x45\xDF\x52"
/**
 * Internal tag used by the cyclic module
 */
#define REPEAT_TIME_TAG    	"\xFF\x01\xFF\x45\xDF\x53"
/**
 * 
 */
#define ERROR_TAG			      "\xFF\x01\xFF\x45\xDF\x54"

/**
 * @}
 */

#endif

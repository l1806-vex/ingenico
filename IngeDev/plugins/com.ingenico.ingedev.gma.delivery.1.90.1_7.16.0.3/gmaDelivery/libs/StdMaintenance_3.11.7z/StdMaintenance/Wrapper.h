/*******************************************************************************
                                 Property of INGENICO
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Maintenance Application
 *  FILENAME       :    Wrapper.h
 *  PURPOSE        :    Protocol Wrapper API
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  05/03/2004   CDL        Intitial Version
 *  15/11/2004   CDL        COUNTER_ID_RANGE changed to 19 due to addition of
 *							repeat date/time counter
 * -----------------------------------------------------------------------------
 * DESCRIPTION     :    Protocol wrapper API functions
-*/

#ifndef __Wrap_H
#define __Wrap_H

#ifdef __cplusplus
extern "C" {
#endif

/*+++******* INCLUDES *****************************************************---*/

#include "miltypes.h"

/*+++******* EXTERNAL GLOBAL #DEFINE CONSTANTS ****************************---*/
#define COUNTER_ID_RANGE 19


/*+++******* EXTERNAL GLOBAL TYPES ****************************************---*/
typedef enum
{
    wrapErrorNone=              0x00,
    wrapErrorFrameLength=       0x01,
    wrapErrorUnknownFrame=      0x02,
    wrapErrorTimeout=           0x03,
    wrapErrorWrongFrameNumber=  0x04,
    wrapErrorBufferOverflow=    0x05,
    wrapErrorUnknownHSCid=      0x06,
    wrapErrorProtocolError=     0x07,
    wrapErrorSystemCallFailure= 0x08,
    wrapErrorCounterType=       0x09,
    wrapErrorCounterId=         0x0A,
    wrapErrorServerName=        0x0B,
    wrapErrorUnsupportedFrame=  0xFF
} wrapError_t;

typedef struct _hmiStructure{
    uint32 handle;
    char string[17];
    uint8 keyBuffer[2];
}hmiStructure;

/*+++******* EXTERNAL GLOBAL MACROS ***************************************---*/
// None.


/*+++******* EXTERNAL GLOBAL DATA DECLARATIONS ****************************---*/
// None.


/*+++******* EXTERNAL GLOBAL FUNCTION PROTOTYPES **************************---*/

#ifdef __cplusplus
}
#endif

#endif // __Wrap_H

/*
 * End of file Wrapper.h
 */

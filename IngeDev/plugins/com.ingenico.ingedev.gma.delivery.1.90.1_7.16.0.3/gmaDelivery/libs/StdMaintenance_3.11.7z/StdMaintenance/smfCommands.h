
#ifndef SMF_COMMANDS_H_INCLUDED
#define SMF_COMMANDS_H_INCLUDED

int16 smfCommandTreatCM12(const uint8 *recFrame, uint16 frameSize, 
                            uint8 *answerFrame, uint16 *answerFrameSize);



#endif


/*******************************************************************************
                              Property of INGENICO
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Maintenance Application
 *  FILEMANE       :    mtaStd.h
 *  PURPOSE        :    Standard interface definitions for the
 *                      invocation of the maintenance app.
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  2003-MAY-19  DRA        Creation.
 *  2003-JUL-22  DRA        Use second phone number for interapp calls
 *                          MTA_DRA00XXa
 *  2003-OCT-06  CDL        MTA_CDL0003
 *                          mntConnectionData_t extended with extra fields.
 *                          MNTC_VERSION updated to 202
 *  2003-OCT-15  CDL        MTA_CDL0007
 *                          mtAppSig added to mtnConnectionData_t
 *  2003-NOV-05  CDL        mntConnectType_t enum changed. File IDs are defined.
 *
 *  $Log: mtaStd.h,v $
 *  Revision 1.2  2007/06/13 18:29:40  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.1  2007/03/07 17:52:06  rbelli
 *  SMF
 *
 *  Revision 1.4  2006/05/05 18:04:18  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.3  2006/03/30 17:50:02  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.2  2005/10/05 14:19:15  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.1  2005/07/04 16:55:40  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.1  2005/04/28 15:44:56  rbelli
 *  *** empty log message ***
 *
 *  Revision 1.2  2004/03/23 11:20:11  cl
 *  CDL: Misc. updates for Release0.1
 *
 *  Revision 1.1  2004/03/15 11:45:23  cl
 *  CDL: Changes to allow Maintenance Functionality in a library
 *
 *  Revision 1.1  2004/03/15 08:56:50  cl
 *  CDL: Creation of common module for Maintenance
 *
 *  Revision 1.5  2004/03/09 16:24:39  cl
 *  Bug fixes based on results of testing with Ingeload X and feedback from Spanish.
 *
 *  Revision 1.4  2004/02/26 15:26:02  cl
 *  Development phase 0 : stage 4
 *
 *  Revision 1.11  2003/12/18 10:46:03  da
 *  Removal and addition of comments as necessary plus the removal of an unnecessary prototype.
 *
 *  Revision 2.02  2005/10/03 
 *    Remove some not used items from the struct mntConnectionData_t
 * ----------------------------------------------------------------------------- 
-*/

#ifndef MTA_STD_H_INCLUDED_
#define MTA_STD_H_INCLUDED_

// //-- Denotes implementation not complete 
// //** Denotes compulsory option
// These because the underlying maintenance code does not support the
// option. i.e. it is not an interapp communication issue.

typedef struct {
	char bufferName[16];
	char buffer[128];
	uint16 bufferLength;
} mntMaintenanceData_t;


typedef struct
{
   uint32 date;
   uint32 time;
   uint8  repeat; // In Minutes
   uint8  null;
   uint8  retries;

  //Long term retries
   uint32 baseDate;
   uint32 baseTime;
   uint8  baseRepeat; // In Minutes
} varsAutoConnect_t;

// This has been chosen to match with version M2 of the Maintenance App Spec
// Do not change unless spec is changed
typedef enum {
    MTA_MANUAL    = 0,
	MTA_INTERAPP  = 1,
	MTA_RECONNECT = 2
} mntConnectType_t;

#define MANUAL_CFG_FILE   0
#define INTERAPP_CFG_FILE 1
#define MNTC_VERSION	0x201L

typedef struct {
  uint16 version;		//version of the structure. Set to 202 for version 2.0.2
  char appName[13];  	//The name of the calling app so we can reply


  //Temporal config
  mntConnectType_t cnxtype;

  //Number of retries (minimum number 1 - i.e. try once)
  uint8 retries;

  char callInfo[17]; //AKA callerID

  //MTA_CDL0003 Extended for 2.0.2 API
  char  TerminalID[26];
  char  SAPCode   [17];
  char  mtAppSig [5]; //This is the Maintenance App Sig used during logon
                      //Note it is referred to as logon info field in docs
  varsAutoConnect_t autoConnect;
} mntConnectionData_t;


#endif



#ifndef SMF_FIRMWARE_INFO_H_INCLUDED
#define SMF_FIRMWARE_INFO_H_INCLUDED



/**
 * 
 */
int16 smfFirmTreatCmd13(const uint8 *recFrame, uint16 frameSize, 
                        uint8 *answerFrame, uint16 *answerFrameSize);


#endif


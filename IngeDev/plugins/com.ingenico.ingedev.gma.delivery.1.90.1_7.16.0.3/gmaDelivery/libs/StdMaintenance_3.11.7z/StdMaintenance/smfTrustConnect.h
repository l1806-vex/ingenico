
#ifndef SMF_TRUST_CONNECT_H_INCLUDED
#define SMF_TRUST_CONNECT_H_INCLUDED

/**
 * 
 */
int16 smfProcessTrustConnect(uint32 dwlHandle[5], uint32 hmiHandle, uint8 *frameBuffer,
                             uint16 sizeFrameBuffer);



#endif


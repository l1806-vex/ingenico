#ifndef GCL_PPPGSM_H_INCLUDED
#define GCL_PPPGSM_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>
#include <gsm.h>


#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_PPPGSM.h
 *
 *
 */


/**
 * \addtogroup GSM_ GSM
 * 
 * Connections that uses the GSM modem.
 * 
 * Refer to the \ref gsminitializationnote.
 *
 * @{
 */


/**
 * \addtogroup GSMPPP_ GSM PPP over dial GSM communication
 *
 * Will make an PPP connection over an assynchronous dial connection using the GSM network.
 *
 * Refer to the \ref gsminitializationnote
 * 
 * @{
 */

#define GCL_PPP_GSM_FUNC_gsmOpen           (1)
#define GCL_PPP_GSM_FUNC_gsmDataMode       (2)
#define GCL_PPP_GSM_FUNC_netNiOpen         (3)
#define GCL_PPP_GSM_FUNC_netCfgIdentify    (4)
#define GCL_PPP_GSM_FUNC_CHANNEL_NOT_FOUND (5)
#define GCL_PPP_GSM_FUNC_netNiConfigSet    (6)
#define GCL_PPP_GSM_FUNC_netNiStart        (7)
#define GCL_PPP_GSM_FUNC_netNiConfigGet    (8)
#define GCL_PPP_GSM_FUNC_dnsGetHostByName  (9)
#define GCL_PPP_GSM_FUNC_SOCKET_CONNECT    (40)
#define GCL_PPP_GSM_FUNC_SOCKET_SEND       (41)
#define GCL_PPP_GSM_FUNC_SOCKET_RECEIVE    (42)

/**
 * store the information of the last error occurred in the gclPPPGSM.
 * Note that if the gsmFunc is GCL_PPP_GSM_FUNC_SOCKET_CONNECT, GCL_PPP_GSM_FUNC_SOCKET_SEND
 * or GCL_PPP_GSM_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclPPPGSMErrorInfo_st gclPPPGSMErrorInfo_t;

/**
 * store the information of the last error occurred in the gclPPPGSM.
 * Note that if the pppFunc is GCL_PPP_GSM_FUNC_SOCKET_CONNECT, GCL_PPP_GSM_FUNC_SOCKET_SEND
 * or GCL_PPP_GSM_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclPPPGSMErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_PPP_GSM_FUNC_XXX defines
	 */
	uint16 pppFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclPPPGSMErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP over GSM error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclPPPGSMGetLastErrorInfo(gclPPPGSMErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclPPPGSMGetLastErrorInfo
 */
void gclPPPGSMSerrorReset(void);

/**
 * \brief Structure with the PPP over GSM dial configuration
 */
typedef struct
{
   uint8    connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ///////////////////
   ///////////
   char     *phoneNumber; //!< telephone number to dial
   ///
   uint8    dataMode; //!< data mode of the connection, see the gsm documentation of the function gsmDataMode
   //
   uint32   lcpFlags; //!< defines the LCP configuration, see the LNET documentation for more details.
   char     *loginName; //!< login name
   char     *password; //!< password
   ///////////
   char     *ipAddress; //!< ip address in dotted decimal string
   char     *tcpPort;   //!< TCP port
   char     *hostName;  //!< host name if the IP address is not define, the IP will be get by the DNS.
   ///////////////////
   uint8    retries;    //!< connection attempts = retries + 1
   ///////////
   // timeouts
   uint32   connectTimeout;      //!< connect timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection
   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
   ///////////
} gclPPPGSM_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific GPRS configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!<  socket configuration, IP, port, etc...
   /////////////////////////////////////////////////////////////////////////////
   gclPPPNi_t        PPPNi; //!< LNET configuration data
   /////////////////////////////////////////////////////////////////////////////
   uint32            gsmHandle; //!< gsm Handle

   char              phoneNumber[GCL_MAX_PHONE_SIZE + 1]; //!< telephone number to dial
   //
   uint8             dataMode; //!< data mode of the connection, see the gsm documentation of the function gsmDataMode

   char              rfu[50]; //!< RFU

} gclPPPGSMConfig_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclPPPGSMId(char *zcOut);

/**
 * This function will add an PPP over GSM connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param PPPGSMConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclPPPGSMSet(gclPPPGSM_t* PPPGSMConfig, gclFunctionList_t *List,
                   uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPGSMPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclPPPGSMDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPGSMConnect(gclConfig_t* gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclPPPGSMHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclPPPGSMSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is PPP over GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclPPPGSMReceive(gclConfig_t *gcl, uint8 *data, uint32 *actuallyRead,
                       uint32 maxLen);
/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


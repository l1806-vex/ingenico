#ifndef GCL_GSM_H_INCLUDED
#define GCL_GSM_H_INCLUDED

#include "gcl.h"
#include <gsm.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_GSM.h
 *
 *
 */

/**
 * \addtogroup GSM_ GSM
 *
 * @{
 */


/**
 * \addtogroup GSMC_ GSM asynchronous communication
 *
 * Will make an assynchronous dial connection using the GSM network.
 *
 * Refer to the \ref gsminitializationnote
 * 
 * @{
 */

#define GCL_GSM_FUNC_gsmOpen            (1)
#define GCL_GSM_FUNC_gsmClose           (2)
#define GCL_GSM_FUNC_comOpen            (3)
#define GCL_GSM_FUNC_comSetProtocol     (4)
#define GCL_GSM_FUNC_comConnectReq      (5)
#define GCL_GSM_FUNC_psyPeripheralResultWait (6)
#define GCL_GSM_FUNC_comResultGet       (7)
#define GCL_GSM_FUNC_comResultGetStatus (8)
#define GCL_GSM_FUNC_comSendMsgWait     (9)
#define GCL_GSM_FUNC_comReceiveMsgWait  (10)
/**
 * store the information of the last error occurred in the gclGSM.
 * 
 */
typedef struct gclGSMErrorInfo_st gclGSMErrorInfo_t;

/**
 * store the information of the last error occurred in the gclGSM.
 * 
 */
struct gclGSMErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_GSM_FUNC_XXX defines
	 */
	uint16 gsmFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclGSMErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a PPP error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclGSMGetLastErrorInfo(gclGSMErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclGSMGetLastErrorInfo
 */
void gclGSMSerrorReset(void);

/**
 * \brief Structure with the GSM configuration.
 *
 * Note that the cnxMode field was added.
 */
typedef struct
{
   uint8    connectionId;        //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ///////////
   char     *phoneNumber;        //!< phone Number that will be dial
   ///
   uint8    dataMode;            //!< data mode of the connection, see the documentation of the function gsmDataMode
   uint32   interCharTimeout;    //!> inter character timeout
   ////////////////////////
   uint8    retries;             //!< connection attempts = retries + 1
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection

   uint8    cnxMode;  //!< cnxMode, see the documentation of the function gsmDataMode
} gclGSM_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific GPRS configuration
 */
typedef struct
{
   ////////////////////////
   char     phoneNumber[GCL_MAX_PHONE_SIZE + 1]; //!< phone number
   //
   uint8    dataMode;         //!< data mode of the connection, see the documentation of the function gsmDataMode

   uint8    cnxMode;          //!< cnxMode, see the documentation of the function gsmDataMode

   uint32   interCharTimeout; //!> inter character timeout

   char     rfu[44];          //!< RFU

} gclGSMConfig_t;


/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclGSMId(char *zcOut);


/**
 * This function will add an Ethernet connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param GSMConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclGSMSet(gclGSM_t* GSMConfig, gclFunctionList_t *List,
                uint32 userDataSize, void *userData);


/**
 * this function has to be called by the preDial callback when the
 * connection type is GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGSMPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclGSMDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGSMConnect(gclConfig_t* gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGSMHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclGSMSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is GSM connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclGSMReceive(gclConfig_t *gcl, uint8 *data, uint32 *actuallyRead,
                    uint32 maxLen);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


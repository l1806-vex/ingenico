#ifndef GCL_GPRS_H_INCLUDED
#define GCL_GPRS_H_INCLUDED

#include "gcl.h"
#include <LNet.h>
#include <LNetSocket.h>
#include <gsm.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_GPRS.h
 *
 * GCL assynchronous modem communication type
 */

/**
 * \addtogroup GSM_ GSM
 *
 * @{
 */


/**
 * \addtogroup GPRS_ GPRS communication
 *
 * Will open a socket connection using the GPRS network.
 * 
 * Refer to the \ref gsminitializationnote
 *
 * @{
 */

#define GCL_GPRS_FUNC_gsmOpen            (1)
#define GCL_GPRS_FUNC_netNiOpen          (2)
#define GCL_GPRS_FUNC_netCfgIdentify     (3)
#define GCL_GPRS_FUNC_CHANNEL_NOT_FOUND  (4)
#define GCL_GPRS_FUNC_netNiConfigSet     (5)
#define GCL_GPRS_FUNC_netNiStart         (6)
#define GCL_GPRS_FUNC_netNiConfigGet     (7)
#define GCL_GPRS_FUNC_dnsGetHostByName   (8)
#define GCL_GPRS_FUNC_SOCKET_CONNECT     (40)
#define GCL_GPRS_FUNC_SOCKET_SEND        (41)
#define GCL_GPRS_FUNC_SOCKET_RECEIVE     (42)

/**
 * store the information of the last error occurred in the gclGPRS.
 * Note that if the pppFunc is GCL_GPRS_FUNC_SOCKET_CONNECT, GCL_GPRS_FUNC_SOCKET_SEND
 * or GCL_GPRS_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
typedef struct gclGPRSErrorInfo_st gclGPRSErrorInfo_t;

/**
 * store the information of the last error occurred in the gclGPRS.
 * Note that if the pppFunc is GCL_GPRS_FUNC_SOCKET_CONNECT, GCL_GPRS_FUNC_SOCKET_SEND
 * or GCL_GPRS_FUNC_SOCKET_RECEIVE, you
 * can get more information about error from the \ref gcl_sockutil.h, using the function
 * \ref gclSockUtilGetLastErrorInfo
 */
struct gclGPRSErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_GPRS_FUNC_XXX defines
	 */
	uint16 grpsFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclGPRSErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a GPRS error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclGPRSGetLastErrorInfo(gclGPRSErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclGPRSGetLastErrorInfo
 */
void gclGPRSSerrorReset(void);

#define GCL_MAX_APN 64 //!< max APN size


/**
 * \brief Structure with the GPRS configuration
 */
typedef struct
{
   uint8    connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   ///////////////////
   char     contextId;    //!< context ID to use in the GSM modem to configure the APN, see the GSM/GPRS documentation
   ///////////
   char     *APN;         //!< apn string
   //
   uint32   lcpFlags;     //!< defines the LCP configuration, see the LNET documentation for more details.
   char     *loginName;   //!< login name
   char     *password;    //!< password
   ///////////
   char     *ipAddress;   //!< ip address in dotted decimal string
   char     *tcpPort;     //!< TCP port
   char     *hostName;    //!< host name if the IP address is not define, the IP will be get by the DNS.
   ///////////////////
   uint8    retries;      //!< connection attempts = retries + 1
   ///////////
   // timeouts
   uint32   connectTimeout;      //!< connect timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login timeout
   uint32   retryDelay;          //!< the delay before retying connection
   // no delay for sending tcp data
   char     tcpNoDelay;   //!< 1 to set the TCP_NODELAY option
   /**
    * 1 to enable the SO_LINGER with timeout to 0. 0 will not enable the SO_LINGER.
    */
   char     soLinger;
   ///////////
} gclGPRS_t;


/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific GPRS configuration
 */
typedef struct
{
   /////////////////////////////////////////////////////////////////////////////
   gclConnectSock_t  cSock; //!<  socket configuration, IP, port, etc...
   /////////////////////////////////////////////////////////////////////////////
   gclPPPNi_t        PPPNi; //!< LNET configuration data
   /////////////////////////////////////////////////////////////////////////////
   /**
    * phone to dial, if the SIM card has the APN configuration already configured and a fix
    * number is necessary to be dialed to connect to the GPRS network.
    */
   char              sDialNumber[GCL_MAX_PHONE_SIZE + 1];

   uint32            gsmHandle; //!< gsm handle

   gsmGprsProfile_t  QoS; //!< Quality of service configuration -> see the LNET documentation to more details

   gsmGprsContext_t  context; //!< Gprs configuration, see the gsm documentation for more details

   char              rfu[50]; //!< rfu

} gclGPRSConfig_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclGPRSId(char *zcOut);


/**
 * This function will add an Ethernet connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param GPRSConfig (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclGPRSSet(gclGPRS_t* GPRSConfig, gclFunctionList_t *List,
                 uint32 userDataSize, void *userData);


/**
 * this function has to be called by the preDial callback when the
 * connection type is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGPRSPreDial(gclConfig_t *gcl);


/**
 * this function has to be called by the Dial callback when the
 * connection type is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclGPRSDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGPRSConnect(gclConfig_t* gcl);


/**
 * this function has to be called by the hangUp callback when the
 * connection type is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclGPRSHangUp(gclConfig_t *gcl);


/**
 * This function has to be called by the SEND callback if the connection type
 * is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclGPRSSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is GPRS connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclGPRSReceive(gclConfig_t *gcl, uint8 *data, uint32 *actuallyRead,
                     uint32 maxLen);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


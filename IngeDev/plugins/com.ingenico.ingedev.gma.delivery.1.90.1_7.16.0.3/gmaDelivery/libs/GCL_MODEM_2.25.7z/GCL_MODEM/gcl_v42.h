#ifndef _GLC_V42_H
#define _GLC_V42_H

#include "gcl_comm.h"

#ifdef __cplusplus
extern "C" {
#endif


// PROTOCOLE V42
#define V42_NEGOTIATED		  1

/**
 * @file gcl_v42.h
 *
 * GCL V42 modem communication type
 */

/**
 * \addtogroup comm
 *
 * @{
 */

/**
 * \addtogroup V42Comm V42 modem
 *
 * V42 modem connection.
 *
 * @{
 */

/**
 * \brief Structure with the general v42 configuration
 */
typedef struct
{
   uint8    phoneId; //!< the id of the configuration, retrieved with the function \ref gclCurrentConfigState
   uint8    connectionType; //!< the type of the connection, in this case can be \ref GCL_HDLC or \ref GCL_ASYN
   char     *prefix; //!< the prefix of the telephone to call
   char     *phoneNumber; //!< the telephone to call

   /* dialing setup */
   uint8    detectLine; //!< if 0 there will be no detect line attempt. The line detection is made by the os reading the line voltage
                        //! and with this information detecting if there is or not a line conect to the terminal

   uint8    detectDialTone; //!< if the modem will try to detect the dial tone before dial
   uint8    useToneDialing; //!<
   //
   enum comModemModulation_t  modulationType;   //!< modulation type (see unicapt documentation for more details)
   enum comBps_t              minSpeed;   //!< minimum connection speedy (see unicapt documentation for more details)
   enum comBps_t              maxSpeed;   //!< maximum connection speedy (see unicapt documentation for more details)
   enum comFieldStatus_t      fastConnectMode;  //!< the fast connection status (see unicapt documentation for more details)

   enum comErrorCorrection_t  errorCorrection;  //!< define the error correction type (see unicapt documentation for more details)
   enum comDataCompression_t  dataCompression;  //!< define the data compression type (see unicapt documentation for more details)

   enum comT35_t              countryCode;      //!< define the country code (see unicapt documentation for more details)

   uint8    v42Negociated;       //1=normal negociation of V42, 0=negociation phase is skipped (used with GCL_V42)
   /* general config */
   uint8    retries;             //!< the number of retries attempts for this connections.

   uint32   connectTimeout;      //!< the connection timeout in 1/100 sec units
   uint32   communicationTimeout;//!< the communication timeout in 1/100 sec units.
   uint32   loginTimeout;        //!< the login timeout in 1/100 sec units.
   uint32   retryDelay;          //!< the delay before retrying connection.

} gclV42_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclV42Id(char *zcOut);

/**
 * This function will add the connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param tel (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return GCL_ERR_PARAMETER if modulation is not allowed for V42
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclV42Set(gclV42_t *tel, gclFunctionList_t *List,
                uint32 userDataSize, void *userData);

/**
 * This function will call the \ref gclModemPreDial, and can be used instead of it.
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclV42 prefix.
 * This function if used instead of the \ref gclModemPreDial has to be called by
 * the preDial callback if the connection type is asynchronous. In the new projects
 * prefer to use this function.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclV42PreDial(gclConfig_t *gcl);

/**
 * This function has to be called by the dial callback if the connection type
 * is asynchronous modem.. This function starts the connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclV42Dial(gclConfig_t* gcl);

/**
 * This function will call the \ref gclModemConnect function in this version, and
 * can be used instead.
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclV42 prefix. This function has to be called by the
 * connect callback if the connection type is asynchronous modem connection.
 * In the new projects prefer to use this function instead of the gclModemConnect.
 *
 * This function will wait the connection completion.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclV42Connect(gclConfig_t *gcl);

/**
 * This function will call the \ref gclModemHangUp in this version, and can
 * be used instead.
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclV42 prefix. This function has to be called by the
 * hangup callback if the connection type is asynchronous modem connection.
 * In the new projects prefer to use this function instead of the gclHangUpConnect.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclV42HangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is asynchronous modem.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclV42Send(gclConfig_t *gcl, uint8 *data, uint32 dataSize);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is asynchronous modem.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclV42Receive(gclConfig_t *gcl, uint8 *data, uint32 *actuallyRead,
                     uint32 maxLen);


/**
 * @}
 */

/**
 * @}
 */


#ifdef __cplusplus
}
#endif

#endif


#ifndef _GLC_ASYN_H
#define _GLC_ASYN_H

#include "gcl_comm.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_asyn.h
 *
 * GCL assynchronous modem communication type
 */

/**
 * \addtogroup comm
 *
 * @{
 */

/**
 * \addtogroup AsynComm Asynchronous modem
 *  
 * Asynchronous modem connection.
 *
 * @{
 */


/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclAsynId(char *zcOut);

/**
 * This function will call the \ref gclModemPreDial, and can be used instead of it.
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclAsyn prefix.
 * This function if used instead of the \ref gclModemPreDial has to be called by
 * the preDial callback if the connection type is asynchronous. In the new projects
 * prefer to use this function.
 * 
 * @param gcl (I) the configuration of the connection.
 */
int16 gclAsynPreDial(gclConfig_t *gcl);

/**
 * This function has to be called by the dial callback if the connection type
 * is asynchronous modem.. This function starts the connection.
 *
 * @param gcl (I) the configuration of the connection.
 * 
 */
int16 gclAsynDial(gclConfig_t* gcl);

/**
 * This function will call the \ref gclModemConnect function in this version, and
 * can be used instead. 
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclAsyn prefix. This function has to be called by the
 * connect callback if the connection type is asynchronous modem connection.
 * In the new projects prefer to use this function instead of the gclModemConnect.
 *
 * This function will wait the connection completion.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclAsynConnect(gclConfig_t *gcl);

/**
 * This function will call the \ref gclModemHangUp in this version, and can
 * be used instead.
 * It was defined for practical use. You can set all the callbacks for asynchronous
 * configuration with the gclAsyn prefix. This function has to be called by the
 * hangup callback if the connection type is asynchronous modem connection.
 * In the new projects prefer to use this function instead of the gclHangUpConnect.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclAsynHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is asynchronous modem.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclAsynSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);


/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is asynchronous modem.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclAsynReceive(gclConfig_t *gcl, uint8 *data, uint32 *actuallyRead,
                     uint32 maxLen);

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif


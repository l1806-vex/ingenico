/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT      :   GENERIC COMMUNICATION MODULE
 *  COMPONENT    :   GCM
 *  FILENAME     :   V42Protocol.h
 *  PURPOSE      :   Implementation of the V42 protocol in the terminal
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  2003-08-01   cbn        v 1.2
 *  2003-09-01   HG         creation
 *  2003-09-19   PS         documentation
 * --------------------------------------------------------------------------
 *  DESCRIPTION    :
 *     This file roles :
 *       - Define internal structure if the V42 protocol context type.
 *       - Define V42 protocol constants/types.
 *       - Define some internal operations of V42 protocol.
-*/


#ifndef __V42PROTOCOL_H
#define __V42PROTOCOL_H

/*+++******* INCLUDES ****************************************************---*/
#include "unicapt.h"
//#include "arch.h"
//#include "com.h"


/*+++******* INTERNAL GLOBAL #DEFINE CONSTANTS ***************************---*/

#ifdef __cplusplus
extern "C" {
#endif


#ifndef TDEFINE
#define TDEFINE extern
#undef  INIT_VALUE
#else
#define INIT_VALUE
#endif

#define ERR_V42_PROTOCOL     -1001
#define ERR_BUFFER_LENGTH    -1002
#define ERR_COM_PORT         -1003
#define ERR_CONNECT_V42      -1004
#define ERR_ALREADY_INIT     -1005
#define ERR_TIME_OUT         -1006
#define ERR_DISCONNECTED     -1007
#define ERR_BAD_FRAME        -1008
#define ERR_UNKNOWN_FRAME    -1009
#define ERR_BAD_SEQUENCE     -1010
#define ERR_BAD_CRC          -1013


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


/*+++******* INTERNAL GLOBAL TYPES ***************************************---*/

/*+++******* INTERNAL GLOBAL FUNCTION PROTOTYPES *************************---*/

// Interface functions

/**
 * special functions for V42 protocol
 */

TDEFINE int16 initV42(uint32 comHandle, uint8 negotiate, comModemModulationPar_t *modulation);
TDEFINE int16 sendV42(uint32 comHandle, uint8 *pBuffer, uint16 bufferLength,
                      uint32 timeOut_ms);
TDEFINE int16 sendBreakV42(uint32 comHandle, uint16 code);
TDEFINE int16 receiveV42(uint32 comHandle, uint8 *pBuffer, uint16 *pBufferLength,
                         uint32 timeOut);
TDEFINE int16 stopV42(uint32 comHandle);

#undef TDEFINE

#ifdef __cplusplus
}
#endif


#endif /* __V42PROTOCOL_H */


/**
 * End of File V42Protocol.h
 */



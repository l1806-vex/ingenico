#ifndef _GCL_COMM_H_INCLUDED
#define _GCL_COMM_H_INCLUDED

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_comm.h
 *
 * GCL assynchronous and synchronous modem communication type
 */

/**
 * \addtogroup comm Assynchronous and synchronous modem communication
 *
 * @{
 */

#define GCL_MODEM_COMM_FUNC_comOpen         (1)
#define GCL_MODEM_COMM_FUNC_comChanInit     (2)
#define GCL_MODEM_COMM_FUNC_comCfgAccess1   (3)
#define GCL_MODEM_COMM_FUNC_comCfgAccess2   (4)
#define GCL_MODEM_COMM_FUNC_comCfgAccess3   (5)
#define GCL_MODEM_COMM_FUNC_comCfgAccess4   (6)
#define GCL_MODEM_COMM_FUNC_comSetModemParameters (7)
#define GCL_MODEM_COMM_FUNC_psyPeripheralResultWait (8)
#define GCL_MODEM_COMM_FUNC_comResultGet    (9)
#define GCL_MODEM_COMM_FUNC_comResultGetStatus (10)

#define GCL_MODEM_ASYN_FUNC_comConnectReq  (100)
#define GCL_MODEM_ASYN_FUNC_comSendMsgWait (101)
#define GCL_MODEM_ASYN_FUNC_comReceiveMsgWait (102)

#define GCL_MODEM_HDLC_FUNC_comConnectReq  (200)
#define GCL_MODEM_HDLC_FUNC_comSendMsgWait (201)
#define GCL_MODEM_HDLC_FUNC_comReceiveMsgWait (202)

#define GCL_MODEM_V42_FUNC_comConnectReq   (300)

#define GCL_MODEM_V42_FUNC_sendV42         (301)
#define GCL_MODEM_V42_FUNC_receiveV42      (302)
#define GCL_MODEM_V42_FUNC_sendBreakV42    (303)
#define GCL_MODEM_V42_FUNC_send_V42A       (304)
#define GCL_MODEM_V42_FUNC_comSendMsgWait  (305)
#define GCL_MODEM_V42_FUNC_comReceiveMsgWait (306)
#define GCL_MODEM_V42_FUNC_comReceiveByteWait (307)


/**
 * store the information of the last error occurred in any of the \ref comm type.
 */
typedef struct gclModemErrorInfo_st gclModemErrorInfo_t;

/**
 * store the information of the last error occurred in the gclPPPCOM.
 */
struct gclModemErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_MODEM_XXX_FUNC_XXX defines
	 */
	uint16 modemFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclModemErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a error in any of the \ref comm type and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclModemGetLastErrorInfo(gclModemErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclModemGetLastErrorInfo
 */
void gclModemSerrorReset(void);

/**
 * \brief structure with parameters speceific for asynchronous communication
 */
typedef struct
{
   enum comParity_t     Asyncparity;      //!< parity type (see unicapt documentation for more details)
   enum comDataSize_t   AsyncdataSize;    //!< data size (see unicapt documentation for more details)
   enum comStopBits_t   AsyncstopBits;    //!< number of stop bits (see unicapt documentation for more details)
   uint32               interCharTimeout; //!< inter character timeout

} gclAsynTelephone_t;

/**
 * \brief Structure with the general modem configuration (synchronous and asynchronous)
 */
typedef struct
{
   uint8    phoneId; //!< the id of the configuration, retrieved with the function \ref gclCurrentConfigState
   uint8    connectionType; //!< the type of the connection, in this case can be \ref GCL_HDLC or \ref GCL_ASYN
   char     *prefix; //!< the prefix of the telephone to call
   char     *phoneNumber; //!< the telephone to call

   /* dialing setup */
   uint8    detectLine; //!< if 0 there will be no detect line attempt. The line detection is made by the os reading the line voltage
                        //! and with this information detecting if there is or not a line conect to the terminal

   uint8    detectDialTone; //!< if the modem will try to detect the dial tone before dial
   uint8    useToneDialing; //!<
   //
   enum comModemModulation_t  modulationType; //!< modulation type (see unicapt documentation for more details)
   enum comBps_t              minSpeed; //!< minimum connection speedy (see unicapt documentation for more details)
   enum comBps_t              maxSpeed; //!< maximum connection speedy (see unicapt documentation for more details)

   enum comFieldStatus_t      fastConnectMode; //!< the fast connection status (see unicapt documentation for more details)

   enum comErrorCorrection_t  errorCorrection; //!< define the error correction type (see unicapt documentation for more details)
   enum comDataCompression_t  dataCompression; //!< define the data compression type (see unicapt documentation for more details)

   enum comT35_t              countryCode; //!< define the country code (see unicapt documentation for more details)

   enum comRingMode_t         ringMode;   //!<  ring mode (see unicapt documentation for more details)
   uint8                      ringNumber; //!< ring number (see unicapt documentation for more details)

   /* only for async connection, NULL if not used */
   gclAsynTelephone_t         *Asyn_Config; //!< a pointer to the \ref gclAsynTelephone_t if the communication type is
                                            // asynchronous or NULL otherwise

   /* general config */
   uint8    retries; //!< connection attempts = retries + 1.

   uint32   connectTimeout;      //!< the connection timeout in 1/100 sec units
   uint32   communicationTimeout;//!< the communication timeout in 1/100 sec units.
   uint32   loginTimeout;        //!< the login timeout in 1/100 sec units.
   uint32   retryDelay;          //!< the delay before retying connection

} gclTelephone_t;

/**
 * \brief internal structure put in the extradata field of the \ref gclConfig_s structure used
 * to hold the specific modem configurations
 */
typedef struct
{
   char                 prefix[GCL_MAX_PREFIX_SIZE + 1];  //!< the prefix of the telephone to be dial
   char                 phoneNumber[GCL_MAX_PHONE_SIZE + 1]; //!< the phone to be dial
   /* useful serial link config */
   enum comParity_t     parity;           //!< Connection Parity
   enum comStopBits_t   stopBits;         //!< Number of Stop bits
   enum comDataSize_t   dataSize;         //!< data Size
   //
   comModemParameter_t  modemParameters; //!< modem parameters (see unicapt documentation for more details)
   //* country code
   enum comT35_t        countryCode; //!< country code (see unicapt documentation for more details)

   uint32               interCharTimeout; //!> inter character timeout

   uint8                v42Negociated; //!< for specific v42 usage see GCL_V42

   char                 rfu[45]; //!< reserved for future use

} gclModemConfig_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclModemId(char *zcOut);

/*----------------------------------------------------------------------------*/

/**
 * This function will add the connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param tel (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclModemTelephoneSet(gclTelephone_t *tel, gclFunctionList_t *List,
                           uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDiaal callback when the
 * connection type is asynchronous or synchronous (HDLC) modem.
 * In new projects prefer to use the \ref gclAsynPreDial for
 * asynchronous connection or \ref gclHDLCPreDial for synchronous (HDLC)
 * connections.
 * This function opens  and configure the "MODEM".
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclModemPreDial(gclConfig_t *gcl);

/**
 * This function has to be called by the Connect callback when the connection is
 * asynchronous or synchronous (HDLC) modem. In new projects prefer
 * to use the \ref gclAsynConnect for
 * asynchronous connection or \ref gclHDLCConnect for synchronous (HDLC)
 * connections.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclModemConnect(gclConfig_t *gcl);


/**
 * This function has to be called by the HangUp callback when the connection type
 * is asynchronous or synchronous (HDLC) modem. In new projects prefer
 * to use the \ref gclAsynHangUp for
 * asynchronous connection or \ref gclHDLCHangUp for synchronous (HDLC)
 * connections.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclModemHangUp(gclConfig_t *gcl);


/**
 * Function to calibrate the line in use
 * used to calibrate the line in use if standard value doesn't work properly
 * User have to ensure that the line is off hook and properly plugged
 * and the "MODEM" peripheral (handle) have to be closed.
 *
 * @param newThreshold (O) receives the threshold detect by the OS
 */
int16 gclModemLineInUseCalibration(uint8 *newThreshold);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif



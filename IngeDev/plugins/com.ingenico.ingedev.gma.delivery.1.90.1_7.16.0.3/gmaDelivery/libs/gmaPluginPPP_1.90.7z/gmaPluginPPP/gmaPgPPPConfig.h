
#ifndef GMA_PG_PPP_CONFIG_H_INCLUDED
#define GMA_PG_PPP_CONFIG_H_INCLUDED

#include "gmaLibPPPPgConfig.h"

#ifdef __cplusplus
extern "C" {
#endif



struct gmaPgPPPModem_st
{
	enum comT35_t countryCode;
   uint8    detectLine; //!< if the line will be checked before dial
   uint8    detectDialTone; //!< if the dial tone will be checked before dial

   uint8    useToneDialing; //!< if use tone to dial

   enum comModemModulation_t modulationType; //!< define the modem modulation, see the Unicapt documentation for more details
   enum comErrorCorrection_t errorCorrection; //!< define the error correction type, see the Unicapt documentation for more details
   enum comDataCompression_t dataCompression; //!< define the data compression type, see the Unicapt documentation for more details
   enum comBps_t              minBps;          /**< Minimum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/
   enum comBps_t              maxBps;          /**< Maximum modem connection velocity. See the documentation
                                                of the comBps_t for the available values*/
   
   uint32 lcpFlags;
   uint32 timeout;
   
   char userName[30];
   char password[30];
   
   char phoneNumber[20];
   
   
};

struct gmaPgPPPSerial_st
{
	uint32 lcpFlags;
	uint32 timeout;
	
	enum comSpeed_t       speed;    //!< connection speedy, see the Unicapt documentation
	enum comParity_t      parity;   //!< communication parity, see the Unicapt documentation
	enum comStopBits_t    stopBits; //!< number of stopbits , see the Unicapt documentation
	
   char userName[30];
   char password[30];
   
   char portName[8]; 
   
   
};
	
typedef struct gmaPgPPPConf_st gmaPgPPPConf_t;

struct gmaPgPPPConf_st
{
	/**
	 * type of connection. Or GMA_PG_PPP_OVER_SERIAL or GMA_PG_PPP_OVER_MODEM
	 */
	uint8 connectionType; 
	struct gmaPgPPPModem_st   pppModem;
	struct gmaPgPPPSerial_st  pppSerial;
};




/**
 * will read the information in the file, if the file exists
 */
int16 gmaPgPPPConfInit(void);

int16 gmaPgPPPConfshowMenu(uint32 hmiHandle, uint32 touchHandle);

/**
 * 
 */
void gmaPgPPPConfSerial(uint8 get, gmaPPPConfigSerial_t *serial);

/**
 * 
 */
void gmaPgPPPConfModem(uint8 get, gmaPPPConfigModem_t *modem);

/**
 * 
 */
void gmaPgPPPConfConnType(uint8 get, uint16 *connType);

/**
 * 
 */
int16 gmaPgPPPConnectNow(void);

/**
 * 
 */
int16 gmaPgPPPDisconnectNow(void);



#ifdef __cplusplus
}
#endif
	
#endif


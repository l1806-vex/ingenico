
#ifndef GMA_PG_PPP_LNET_H_INCLUDED
#define GMA_PG_PPP_LNET_H_INCLUDED

#include "gmaPgPPPConfig.h"

#ifdef __cplusplus
extern "C" {
#endif


	
	
/**
 * 
 */
int16 gmaPgPPPConnect(gmaPgPPPConf_t *params);


/**
 * 
 */
int16 gmaPgPPPDisconnect(void);

/**
 * 
 */
void gmaPgPPPGetErrorCode(uint16 *pos, int16 *errCode);

/**
 * 0 means not connected
 * 1 means connected
 */
uint8 gmaPgPPPGetConnStatus(void);

#ifdef __cplusplus
}
#endif


#endif


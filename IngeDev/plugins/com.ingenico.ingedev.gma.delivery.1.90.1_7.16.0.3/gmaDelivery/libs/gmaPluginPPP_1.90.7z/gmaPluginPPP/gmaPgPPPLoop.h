
#ifndef GMA_PG_PPP_H_INCLUDED
#define GMA_PG_PPP_H_INCLUDED

#define GMA_PG_PPP_LOOP_ORDER_PING         (0)
#define GMA_PG_PPP_LOOP_ORDER_CONNECT      (1)
#define GMA_PG_PPP_LOOP_ORDER_DISCONNECT   (2)


#ifdef __cplusplus
extern "C" {
#endif

/**
 * Start the module and created the LOOP task
 */
int16 gmaPgPPPLoopStart(void);

/**
 * 
 */
int16 gmaPgPPPLoopEnterIdle(void);

/**
 * 
 */
int16 gmaPgPPPLoopLeaveIdle(void);

/**
 * Send an order to the loop task
 */
int16 gmaPgPPPLoopSendOrder(uint16 orderId, uint32 param1, uint32 param2);

/**
 * Wait for the loop to execute the order
 */
int16 gmaPgPPPWaitPing(void);

/**
 * 
 */

#ifdef __cplusplus
}
#endif

#endif


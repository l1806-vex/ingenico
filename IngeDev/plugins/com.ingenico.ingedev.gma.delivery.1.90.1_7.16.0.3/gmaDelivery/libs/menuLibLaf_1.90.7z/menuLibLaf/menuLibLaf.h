
#ifndef MENU_LIB_LAF_H_INCLUDED
#define MENU_LIB_LAF_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define MNU_OK            (RET_OK) //!< No errors

#define MNU_ERR_BASE      (-1) //!< base errors for menu library

#define MNU_ERR_CANCEL    (MNU_ERR_BASE) //!< cancel by user
#define MNU_ERR_TIMEOUT   (MNU_ERR_BASE-1) //!< timeout error
#define MNU_ERR_INVALID   (MNU_ERR_BASE-2) 
#define MNU_ERR_DISABLED  (MNU_ERR_BASE-3)
#define MNU_ERR_EMPTY     (MNU_ERR_BASE-4) //!< there is no enable item in the menu
#define MNU_ERR_HMI       (MNU_ERR_BASE-5) 
#define MNU_ERR_FULL      (MNU_ERR_BASE-6) //!< the internal menu item list is full

/**
 * Set if the terminal has touch screen capabilities. Must be called only
 * one before the first call to any other function of this lib.
 */
int16 mnuLafInitialize(uint8 touchScreen);

/**
 * Reset the menu (must be called if you will use the function
 * \ref mnuRun.).
 * 
 */
int16 mnuLafReset(void);

/**
 * Open the sec Handle
 */
int16 mnuLafSecHandleOpen(void);

/**
 * Close the Sec Handle
 */
int16 mnuLafSecHandleClose(void);

/**
 * Add a menu item to the menu. (must be called if you will use the function
 * \ref mnuRun.).
 * 
 * @param caption the menu item caption
 * @param value the value to be returned by the \ref mnuRun function if
 * this item was selected.
 * 
 * @return RET_OK no errors
 * @return MNU_ERR_FULL if the menu list is full
 */
int16 mnuLafAddItem(const char *caption, int16 value);

/**
 * Set the menu title (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param title the menu title to be set.
 */
int16 mnuLafSetTitle(const char *title);

/**
 * Set the menu timeout (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param timeout the menu timeout.
 */
int16 mnuLafSetTimeout(uint32 timeout);

/**
 * Start the menu with the previously enter configuration. Calls the 
 * ssaSecLafListSelectTo to shows the menu.
 * 
 * @param startingSelection the item to be shown as selected when the menu starts
 */
int16 mnuLafRun(int16 startingSelection);

#ifdef __cplusplus
}
#endif

#endif


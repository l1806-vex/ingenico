/**
 * MenuLib.h
 *
 * Display of Menu Items
 * Version 1.0
 * TiagoTM, June, 21, 2004
 */

#ifndef MNU_LIB_H
#define MNU_LIB_H

#ifdef __cplusplus
extern "C" {
#endif

/** @file menuLib.h
 * 
 * library for showing selection menus.
 */

/**
 * Maximum caption length
 */
#define MNU_CAPTION_LEN   (25)
/**
 * Maximum menu itens
 */
#define MNU_MAX_ITEMS     (30)

/*
 * Return values.	
 */
#define MNU_OK            (RET_OK) //!< No errors

#define MNU_ERR_BASE      (-1) //!< base errors for menu library

#define MNU_ERR_CANCEL    (MNU_ERR_BASE) //!< cancel by user
#define MNU_ERR_TIMEOUT   (MNU_ERR_BASE-1) //!< timeout error
#define MNU_ERR_INVALID   (MNU_ERR_BASE-2) 
#define MNU_ERR_DISABLED  (MNU_ERR_BASE-3)
#define MNU_ERR_EMPTY     (MNU_ERR_BASE-4) //!< there is no enable item in the menu
#define MNU_ERR_HMI       (MNU_ERR_BASE-5) 
#define MNU_ERR_FULL      (MNU_ERR_BASE-6) //!< the internal menu item list is full

/**
 * Key mapping structure.
 */
typedef struct mnuKeyMap_s mnuKeyMap_t;
/**
 * Key mapping structure.
 */
struct mnuKeyMap_s
{
   uint8 srcKey; //!< Original code of the key to remap, as returned by the terminal
   uint8 dstKey; //!< Emulated code of the key
};

/**
 * One item in the menu
 */
typedef struct mnuItem_s mnuItem_t;
/**
 * One item in the menu
 */
struct mnuItem_s
{
   char  caption[MNU_CAPTION_LEN + 1]; //!< menu item caption
   uint8 enabled;    //!< if the menu item is enable: 1 = enabled, 0 = disabled
   int16 value;      // If this item is selected if value >= 0 return value, else return index
};

/**
 * Menu configuration parameters, used for each menu.
 */
typedef struct mnuConfig_s mnuConfig_t;
/**
 * Menu configuration parameters, used for each menu.
 */
struct mnuConfig_s
{
   uint8    exitOnInvalid;
   char     title[MNU_CAPTION_LEN + 1]; //!< menu title
   char     footer[MNU_CAPTION_LEN + 1]; //!< menu footer
   void     *font; //!< font to be used
   void     *titleFont; //!< font of the menu title
   uint32   timeout;
};

/**
 * Get the key mapping.
 * 
 * @param map a pointer to a poiter to a mnuKeyMap_t vector to receive
 * a pointer to the key map.
 */
int16 mnuKeyMapGet(const mnuKeyMap_t **map);

/**
 * Set the key mapping.
 * 
 * @param map a vector of mnuKeyMap_t entries. To last item of the vector must
 * have the src field equals zero.
 */
int16 mnuKeyMapSet(const mnuKeyMap_t *map);

/**
 * Display and run a menu.
 * 
 * @param hmiHandle a valid hmi handle
 * @param touchHandle a handle for the touchscreen. If 0 no touch screen.
 * @param config points to the menu configuration
 * @param items a vector of the menu itens entries
 * @param itemCount the number of menu itens
 * @param startingSelection the selection item when display the menu
 */
int16 mnuRunItems(uint32 hmiHandle, uint32 touchHandle, const mnuConfig_t *config,
                  const mnuItem_t *items, int16 itemCount,
                  int16 startingSelection);


/*
 * These functions allow to create iteractively the menu.
 * They use a static instance of the structures and then
 * call mnuRunItems().
 */

/**
 * Reset the menu (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param hmiHandle a valid hmi handle
 */
int16 mnuReset(uint32 hmiHandle, uint32 touchHandle);

/**
 * Add a menu item to the menu. (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param caption the menu item caption
 * @param enabled if the menu item is enabled
 * @param value the value to be returned by the \ref mnuRun function if
 * this item was selected.
 * 
 * @return RET_OK no errors
 * @return MNU_ERR_FULL if the menu list is full
 */
int16 mnuAddItem(const char *caption, uint8 enabled, int16 value);

/**
 * Set the menu footer (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param footer the footer to be set.
 */
int16 mnuSetFooter(const char *footer);

/**
 * Set the menu title (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param title the menu title to be set.
 */
int16 mnuSetTitle(const char *title);
int16 mnuSetExitOnInvalid(uint8 exitOnInvalid);

/**
 * Set the title font
 */
int16 mnuSetTitleFont(void *font);


/**
 * Set the font of the menu itens (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param font the font to be used.
 */
int16 mnuSetFont(void *font);

/**
 * Set the menu timeout (must be called if you will use the function
 * \ref mnuRun. Not to be used with \ref mnuRunItems).
 * 
 * @param timeout the menu timeout.
 */
int16 mnuSetTimeout(uint32 timeout);

/**
 * Start the menu with the previously enter configuration
 * 
 * @param startingSelection the item to be shown as selected when the menu starts
 * 
 * @return the value item of the menu selection
 * @return MNU_ERR_EMPTY no enabled itens in the menu item list
 * @return MNU_ERR_TIMEOUT timeout occured
 * @return MNU_ERR_CANCEL HMI_KEY_CLEAR was pressed
 */
int16 mnuRun(int16 startingSelection);


/**
 * Select the foreground and background of the menu
 * 
 * @param foreGround the foreGround color
 * @param backGround the backGround color
 */
int16 mnuSetColors(uint8 foreGround, uint8 backGround);

#ifdef __cplusplus
}
#endif

#endif

/**
 *  DebugLib
 *
 *  This file defines debug support routines, macros and constants.
 *  The behavior of the functions here depend on the definition or not
 *  of #define DEBUG_ON.
 *
 *  It is recommended to use the Ingedev 'Define' field,
 *  (see Options + Configuration on Ingedev).
 *
 *  Tiago Martinez
 *  Ingenico Latin America
 *  May, 25, 2004
 */

#ifndef __DEBUG_LIB_H
#define __DEBUG_LIB_H

#include <miltypes.h>

#ifdef __cplusplus
extern "C" {
#endif


/**
 *  Helper for short pieces of code that depend on debug compile.
 *  Use: IFDEBUG( do_something(param); )
 *  This will result in 'do_something(param);' if DEBUG_ON is defined
 *  and nothing if DEBUG_ON is not defined.
 */

#ifdef DEBUG_ON
#define IFDEBUG(x) x
#else
#define IFDEBUG(x)
#endif

#ifdef DEBUG_LG
#define LGDEBUG(x) x
#else
#define LGDEBUG(x)
#endif

/**
 *  DebugLib error codes
 */

#define DEBUG_OK (RET_OK)

#define DEBUG_ERR_BASE  (-1)
#define DEBUG_ERR_OPEN  (DEBUG_ERR_BASE)
#define DEBUG_ERR_OUT   (DEBUG_ERR_BASE-1)

/**
 *  Supported ports for debugging.
 * 
 * DEBUG_PRN -> printer, Unicapt32 PRN peripheral. Obviously, it should not be 
 * open. It will default to font HWIDTH.
 * 
 * DEBUG_COM1 -> serial communication port 1, The connection is 115200,8,N,1
 * 
 * DEBUG_COM2 -> serial communication port 2, The connection is 115200,8,N,1
 * 
 * DEBUG_FILE -> file in the DFS, default file is debug.txt
 * 
 * DEBUG_HMI -> HMI
 */
enum debugTarget_e
{
    DEBUG_PRN,
    DEBUG_COM1,
    DEBUG_COM2,
    DEBUG_FILE,
    DEBUG_LOG,
    DEBUG_HMI,
    DEBUG_APP,
    DEBUG_LDBG,
    
    // Must be kept last
    DEBUG_NONE
};

/**
 * Prepend number of 10ms since terminal startup to trace.
 */
#define DEBUG_FLAG_TIMESTAMP 0x00000001

/**
 * Prepend task name to trace.
 */
#define DEBUG_FLAG_TASK_NAME 0x00000002

/**
 * Prepend date/time to trace, in the following format:
 *  MM/DD hh:mm:ss
 */
#define DEBUG_FLAG_DATE_TIME 0x00000004

/**
 * debugPrintf: prints debug information
 * 
 * debugPrintf sends a formatted debug string (like printf) to a target.
 * IMPORTANT: the message must not exceed 255 bytes
 * 
 * @param target: destination of the debug information. \
 * DEBUG_PRN -> printer, 
 * DEBUG_COM1 -> serial communication port 1, 
 * DEBUG_COM2 -> serial communication port 2,
 * DEBUG_FILE -> file in the DFS
 * DEBUG_HMI -> HMI
 * 
 * @param fmt: format
 * 
 * @return RET_OK debug information succesfully printed
 * @return DEBUG_ERR_OPEN the specified debug output could not be opened
 * @return DEBUG_ERR_OUT the debug message coud not be sent to the specified
 * output
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
int16 debugPrintf(enum debugTarget_e target, const char *fmt, ...);
#else
#define debugPrintf debugNullPrintf
//
// Dummy function with multiple parameters.
// This is needed because the C preprocessor does not accept (...) 
// parameter lists.
//
int16 debugNullPrintf(enum debugTarget_e target, const char *fmt, ...);
#endif

/**
 * Sets flags specifying how to display the traces
 * 
 * @param newFlags Flags to set, one of DEBUG_FLAG_xxx:
 *   - DEBUG_FLAG_TIMESTAMP: prepend traces with the number of 
 *      10 ms since terminal startup (this is the default)
 *   - DEBUG_FLAG_TASK_NAME: prepend traces with current task name
 *   - DEBUG_FLAG_DATE_TIME: prepend traces with current date/time
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
void debugSetFlags(uint32 newFlags);
#else
#define debugSetFlags(x)
#endif


/**
 * debugHexDump: prints an hexa dump
 * 
 * debugHexDump send the hexa dump from a region in the memory to a target
 * 
 * @param target: destination of the debug information. \
 * DEBUG_PRN -> printer, \
 * DEBUG_COM1 -> serial communication port 1, \
 * DEBUG_COM2 -> serial communication port 2, \
 * DEBUG_FILE -> file in the DFS \
 * DEBUG_HMI -> HMI 
 * 
 * @param data: the data to be dumped
 * @param length: the length of the data to be dumped
 * 
 * @return RET_OK debug information succesfully printed
 * @return DEBUG_ERR_OPEN the specified debug output could not be opened
 * @return DEBUG_ERR_OUT the debug message coud not be sent to the specified
 * output
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
int16 debugHexDump(enum debugTarget_e target, const void *data, uint32 length);
#else
#define debugHexDump(target, data, length) (0)
#endif


/**
 * debugAssignHandle: assigns a handle to the library
 * 
 * debugAssignHandle assigns an already opened handle to the library
 * 
 * @param target: kind of handle opened \
 * DEBUG_PRN -> printer, \
 * DEBUG_COM1 -> serial communication port 1, \
 * DEBUG_COM2 -> serial communication port 2, \
 * DEBUG_FILE -> file in the DFS \
 * DEBUG_HMI -> HMI
 * 
 * @param handle: the opened handle
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
void debugAssignHandle(enum debugTarget_e target, uint32 handle);
#else
#define debugAssignHandle(target, handle)
#endif

/**
 * debugReleaseHandle: gets a previously assigned handle to the library
 * 
 * debugReleaseHandle gets a previously assigned handle to the library
 * 
 * @param target: kind of handle expected \
 * DEBUG_PRN -> printer, \
 * DEBUG_COM1 -> serial communication port 1, \
 * DEBUG_COM2 -> serial communication port 2, \
 * DEBUG_FILE -> file in the DFS \
 * DEBUG_HMI -> HMI
 * 
 * @return the previously assigned handle
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
uint32 debugReleaseHandle(enum debugTarget_e target);
#else
#define debugReleaseHandle(target) (0)
#endif


/**
 * debugSetFileName: sets the name of the debug output file name
 * 
 * debugSetFileName sets the name of the debug output file name
 * 
 * @param fileName: the new name of the debug output file name. \
 * If fileName == NULL the debug output file name is reset to "debug.txt"
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
void debugSetFileName(char *fileName);
#else
#define debugSetFileName(fileName)
#endif


/**
 * debugResetFile: resets the debug output file name
 * 
 * debugResetFile resets the debug output file contents
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
void debugResetFile(void);
#else
#define debugResetFile()
#endif


/**
 * debugSErr: prints a detailed system error
 * 
 * debugSErr send the formated detailed system error to a target
 * 
 * @param target: destination of the debug information. \
 * DEBUG_PRN -> printer, \
 * DEBUG_COM1 -> serial communication port 1, \
 * DEBUG_COM2 -> serial communication port 2, \
 * DEBUG_FILE -> file in the DFS \
 * DEBUG_HMI -> HMI 
 * 
 * @param txt: Title to identify the error to be dumped
 * @param err: Error code to be dumped
 * 
 * @return <<system error offset>>
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
int16 debugSErr(enum debugTarget_e target, char * txt, int16 err);
#else
#define debugSErr(target, txt, err)
#endif

/**
 * debugSErrBase: Returns the system base of a specific error 
 * 
 * @param err: Error code to be processed
 * 
 * @return <<system base error>>
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG)) 
int16 debugSErrBase(int16 err);
#else
#define debugSErrBase(err)
#endif

/**
 * debugSErrOffs: Returns the base offset of a specific error 
 * 
 * @param err: Error code to be processed
 * 
 * @return <<system error offset>>
 * 
 */
#if (defined(DEBUG_ON) || defined(DEBUG_LG))
int16 debugSErrOffs(int16 err);
#else
#define debugSErrOffs(err)
#endif




#ifdef __cplusplus
}
#endif

#endif


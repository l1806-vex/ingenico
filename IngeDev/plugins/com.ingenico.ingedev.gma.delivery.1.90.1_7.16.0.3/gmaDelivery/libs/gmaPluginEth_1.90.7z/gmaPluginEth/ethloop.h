
#ifndef ETH_LOOP_H_DEFINED
#define ETH_LOOP_H_DEFINED

#ifdef __cplusplus
extern "C" {
#endif

#define ETH_LOOP_ORDER_START (0x01)
#define ETH_LOOP_ORDER_END   (0x02)

/**
 * 
 */
int16 ethLoopStart(void);

/**
 * 
 */
int16 ethLoopSendOrder(uint16 orderType, uint32 value);

/**
 * 
 */
int16 ethLoopWaitLastOrder(void);


#ifdef __cplusplus
}
#endif

#endif


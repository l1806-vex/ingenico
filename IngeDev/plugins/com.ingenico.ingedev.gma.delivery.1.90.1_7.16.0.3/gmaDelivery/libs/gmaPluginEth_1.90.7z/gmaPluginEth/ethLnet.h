#ifndef POMLNET_H_INCLUDED
#define POMLNET_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

////////////////////////////////////////
#define ETH_LNET_NOT_STARTED       0
#define ETH_CONNECT_OK             1

#define ETH_ERR_OPEN              -1
#define ETH_ERR_CHANNEL_NOT_FOUND -2
#define ETH_ERR_CONFIG_ERR        -3
#define ETH_ERR_START_TIMEOUT     -4
#define ETH_ERR_START_ANOTHER     -5
#define ETH_ERR_GET_IP_ADDRESSES  -6
#define ETH_ERR_SET_GATEWAY       -7
#define ETH_ERR_CONFIG_DNS        -8


/////////////////////////////////////////
void ethLNETstart(void);
void ethLNETstop(void);

int8 ethGetLnetStatus(void);

#ifdef __cplusplus
}
#endif

#endif

#ifndef POMCONFILE_H_INCLUDED
#define POMCONFILE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#ifndef COM_IDLE
#define COM_IDLE // with idle
#endif

// Connection Type
#define ETH_CONFIG_CONNECT_DHCP  1
#define ETH_CONFIG_CONNECT_IPFIX 0


typedef struct _ethConfigEth_t
{
    uint8  connectionType; // DHCP or IPFIX
    uint32 localIpAddress;
    uint32 IpSubMask;
    uint32 dns1;
    uint32 dns2;
    uint32 dhcpServer;
    uint32 gateway;
}ethConfigEth_t;


void ethConfigurationFileRead(void);

ethConfigEth_t* ethGetConfigEth(void);
uint32 ethGetConfigStatus(void);
void ethSaveConFile(void);

#ifdef __cplusplus
}
#endif

#endif



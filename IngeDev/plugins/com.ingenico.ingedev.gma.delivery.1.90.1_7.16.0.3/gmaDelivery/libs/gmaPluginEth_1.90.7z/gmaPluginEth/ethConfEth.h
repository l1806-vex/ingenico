#ifndef POM_CONFETH_H_INCLUDED
#define POM_CONFETH_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

void ethEthConf(ethConfigEth_t *confEth);
void ethMenuConfEth(ethConfigEth_t *confEth);

#ifdef __cplusplus
}
#endif

#endif


#ifndef ETH_STRINGS_H_INCLUDED
#define ETH_STRINGS_H_INCLUDED

#include "unicapt.h"

#ifdef __cplusplus
extern "C" {
#endif


#define ETH_STR_TEXT_CONNECTION_TYPE     IDS_ETH_STR_TEXT_CONNECTION_TYPE
#define ETH_STR_YES                      IDS_MAIN_YES
#define ETH_STR_NO                       IDS_MAIN_NO
#define ETH_STR_LOCAL_IP                 IDS_ETH_STR_LOCAL_IP
#define ETH_STR_IP_SUBMASK               IDS_ETH_STR_IP_SUBMASK
#define ETH_STR_IP_DNS1                  IDS_ETH_STR_IP_DNS1
#define ETH_STR_IP_DNS2                  IDS_ETH_STR_IP_DNS2
#define ETH_STR_IP_GATEWAY               IDS_ETH_STR_IP_GATEWAY
#define ETH_STR_ETH_CONFIGURE            IDS_ETH_STR_ETH_CONFIGURE
#define ETH_STR_ETH_PRINT_CONF           IDS_ETH_STR_ETH_PRINT_CONF
#define ETH_STR_ETH_TESTS                IDS_ETH_STR_ETH_TESTS
#define ETH_STR_ETH_TEST_PING            IDS_ETH_STR_ETH_TEST_PING
#define ETH_STR_ETH_TEST_SOCKET          IDS_ETH_STR_ETH_TEST_SOCKET
#define ETH_STR_ETH_MENU_CONF            IDS_ETH_STR_ETH_MENU_CONF
#define ETH_STR_ETH_RETURN               IDS_ETH_STR_ETH_RETURN
#define ETH_STR_PRINT_CONFIG             IDS_ETH_STR_PRINT_CONFIG
#define ETH_STR_PRINT_WAIT               IDS_ETH_STR_PRINT_WAIT
#define ETH_STR_IP_TO_PING               IDS_ETH_STR_IP_TO_PING
#define ETH_STR_SOCKET_IP                IDS_ETH_STR_SOCKET_IP
#define ETH_STR_SOCKET_TCP               IDS_ETH_STR_SOCKET_TCP
#define ETH_STR_PRESS_A_KEY              IDS_ETH_STR_PRESS_A_KEY



/**
 * Get the string
 */
char * ethGetStringResource(uint16 stringId);

#ifdef __cplusplus
}
#endif

#endif


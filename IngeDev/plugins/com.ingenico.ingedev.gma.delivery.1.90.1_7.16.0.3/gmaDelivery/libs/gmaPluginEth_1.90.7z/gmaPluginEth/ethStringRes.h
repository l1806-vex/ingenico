


STRING_RES(ETH_STR_TEXT_CONNECTION_TYPE, "Utilizar DHCP",   "Utilizar DHCP",   "USE DHCP")
STRING_RES(ETH_STR_YES                 , "SIM",             "SI",              "YES")
STRING_RES(ETH_STR_NO,                   "NAO",             "NO",              "NO")
STRING_RES(ETH_STR_LOCAL_IP,             "IP LOCAL",        "IP LOCAL",        "LOCAL IP")
STRING_RES(ETH_STR_IP_SUBMASK,           "IP SUB MASK",     "IP SUB MASK",     "SUB MASK IP")
STRING_RES(ETH_STR_IP_DNS1,              "IP DNS 1",        "IP DNS 1",        "DNS 1 IP")
STRING_RES(ETH_STR_IP_DNS2,              "IP DNS 2",        "IP DNS 2",        "DNS 2 IP")
STRING_RES(ETH_STR_IP_GATEWAY,           "IP GATEWAY",      "IP GATEWAY",      "GATEWAY IP")
STRING_RES(ETH_STR_ETH_CONFIGURE,        "conf. Ethernet",  "conf. Ethernet",  "Settings")
STRING_RES(ETH_STR_ETH_PRINT_CONF,       "imprimir config", "Imp. Config.",    "Print Config.")
STRING_RES(ETH_STR_ETH_TESTS,            "testes ethernet", "Pruebas",         "Tests")
STRING_RES(ETH_STR_ETH_TEST_PING,        "PING",            "PING",            "PING")
STRING_RES(ETH_STR_ETH_TEST_SOCKET,      "SOCKET",          "SOCKET",          "SOCKET")
STRING_RES(ETH_STR_ETH_MENU_CONF,        "ETHERNET",        "ETHERNET",        "ETHERNET")
STRING_RES(ETH_STR_ETH_RETURN,           "voltar",          "Regressar",       "Back")
STRING_RES(ETH_STR_PRINT_CONFIG,         "Configuracao Ethernet", "configuracion Ethernet", "Ethernet configuration")
STRING_RES(ETH_STR_PRINT_WAIT,           " AGUARDE",        " AGUARDE",        " WAIT")
STRING_RES(ETH_STR_IP_TO_PING,           "IP PING",         "IP PING",         " IP PING")
STRING_RES(ETH_STR_SOCKET_IP,            "SOCKET IP",       "SOCKET IP",       "SOCKET IP")
STRING_RES(ETH_STR_SOCKET_TCP,           "TCP PORT",        "TCP PORT",        "TCP PORT")
STRING_RES(ETH_STR_PRESS_A_KEY,          "press a key",     "press a key",     "press a key")
STRING_RES(ETH_STR_LAST,                 NULL,              NULL,               NULL)


/*
#define POM_TEXT_YES             "SIM"
#define POM_TEXT_NO              "NAO"
#define POM_TEXT_LOCAL_IP        "IP LOCAL"
#define POM_TEXT_IP_SUBMASK      "IP SUB MASK"
#define POM_TEXT_IP_DNS1         "IP DNS 1"
#define POM_TEXT_IP_DNS2         "IP DNS 2"
#define POM_TEXT_IP_GATEWAY      "IP GATEWAY"
#define POM_TEXT_ETH_CONFIGURE   "conf. Ethernet"
#define POM_TEXT_ETH_PRINT_CONF  "imprimir config."
#define POM_TEXT_ETH_TESTS       "testes Ethernet"
#define POM_TEXT_ETH_TEST_PING   "PING"
#define POM_TEXT_ETH_TEST_SOCKET "SOCKET"
#define POM_TEXT_ETH_MENU_CONF   "Menu de Conf."
#define POM_TEXT_ETH_RETURN      "voltar"

#define POM_TEXT_PRINT_CONFIG    "Configuracao Ethernet"
#define POM_TEXT_PRINT_WAIT      " AGUARDE"
#define POM_TEXT_IP_TO_PING      "IP PING"
#define POM_TEXT_SOCKET_IP       "SOCKET IP"
#define POM_TEXT_SOCKET_TCP      "TCP PORT"
#define POM_TEXT_PRESS_A_KEY     "press a key"
#endif

#ifdef POM_TEXT_MEXICO
#define POM_TEXT_CONNECTION_TYPE "Utilizar DHCP"
#define POM_TEXT_YES             "SI"
#define POM_TEXT_NO              "NO"
#define POM_TEXT_LOCAL_IP        "IP LOCAL"
#define POM_TEXT_IP_SUBMASK      "IP SUB MASK"
#define POM_TEXT_IP_DNS1         "IP DNS 1"
#define POM_TEXT_IP_DNS2         "IP DNS 2"
#define POM_TEXT_IP_GATEWAY      "IP GATEWAY"
#define POM_TEXT_ETH_CONFIGURE   "conf. Ethernet"
#define POM_TEXT_ETH_PRINT_CONF  "Imp. Config."
#define POM_TEXT_ETH_TESTS       "Pruebas"
#define POM_TEXT_ETH_TEST_PING   "PING"
#define POM_TEXT_ETH_TEST_SOCKET "SOCKET"
#define POM_TEXT_ETH_MENU_CONF   "Menu Config."
#define POM_TEXT_ETH_RETURN      "Regresar"

#define POM_TEXT_PRINT_CONFIG    "configuracion Ethernet" 
#define POM_TEXT_PRINT_WAIT      " AGUARDE" //falta
#define POM_TEXT_IP_TO_PING      "IP PING" //falta
#define POM_TEXT_SOCKET_IP       "SOCKET IP" //falta
#define POM_TEXT_SOCKET_TCP      "TCP PORT" //falta
#define POM_TEXT_PRESS_A_KEY     "press a key" //falta
#endif
*/



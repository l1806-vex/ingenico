
#ifndef ETH_MAIN_H_INCLUDED
#define ETH_MAIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define ETH_STATUS_ALREADY_CONNECTED        (0x01)
#define ETH_STATUS_CONNECTED                (0x02)
#define ETH_STATUS_NOT_CONFIGURED           (0x03)
#define ETH_STATUS_NOT_POSSIBLE             (0x04)
#define ETH_STATUS_CONNECTION_ERROR         (0x05)
#define ETH_STATUS_ALREADY_DISCONNECT       (0x06)
#define ETH_STATUS_DISCONNECT               (0x07)

#define ETH_STRUCT_START_CONNECTION         (2002)
#define ETH_STRUCT_CONNECTION_STATUS        (2003)
#define ETH_STRUCT_CONFIG_CONNECTION        (2004)


#define ETH_REQUEST_ETH_CONNECT                 (0x01)
#define ETH_REQUEST_ETH_DISCONNECT              (0x02)
#define ETH_REQUEST_CLOSE_GSM_HANDLE             (0x03)

#include "gmaDefines.h"

/**
 * ETH_STRUCT_START_CONNECTION
 * Message received from the application asking the GSM plugin
 * to connect to the GPRS network with the predefined configuration
 * entered directly in the GSM plugin
 */
typedef struct ethMsgStartConnect_s ethMsgStartConnect_t;
struct ethMsgStartConnect_s
{
   gmaStructHeader_t header;
   uint32 request;
   uint32 timeout;
};

/**
 * 
 */
typedef struct ethMSgConfigConnection_st ethMSgConfigConnection_t;

struct ethMSgConfigConnection_st
{
	gmaStructHeader_t header;
	
};

/**
 * Message send to the application as a reply of the message 
 * ETH_STRUCT_START_CONNECTION 
 */
typedef struct ethMsgStartConnectReply_s ethMsgStartConnectReply_t;
struct ethMsgStartConnectReply_s
{
   gmaStructHeader_t header;
   uint32 status;
};



uint8 ethMainGetPluginId(void);

int16 pgRegistryEthPlugin(void);

#ifdef __cplusplus
}
#endif

#endif


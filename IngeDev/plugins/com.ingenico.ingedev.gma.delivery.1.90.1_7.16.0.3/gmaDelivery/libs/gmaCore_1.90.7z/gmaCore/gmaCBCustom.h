
#ifndef GMA_CB_CUSTOM_H_INCLUDED
#define GMA_CB_CUSTOM_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Will start to send the power on messages to the applications
 */
#define GMA_CB_STATE_BEF_POWER_ON          (1)
/**
 * the power on was sent, will start to send the Integrity check messages
 */
#define GMA_CB_STATE_BEF_INTEGRITY_CHECK   (2)
/**
 * the integrity check messages was sent, will start to sent the Startup message
 */
#define GMA_CB_STATE_BEF_STARTUP           (3)
/**
 * the Startup message was sent. The GMA will enter the Main loop
 */
#define GMA_CB_STATE_BEF_LOOP              (4)
/**
 * the GMA will wake up an application
 */
#define GMA_CB_STATE_WAKE_APPL             (5)
/**
 * the terminal will return to the IDLE state
 */
#define GMA_CB_STATE_IDLE_STATE            (6)
/**
 * the GMA will wait for the end of Maintenance event
 */
#define GMA_CB_STATE_MAINTENANCE           (7)

#include "gmaDefines.h"

/**
 * @file gmaCBCustom.h
 *
 * 
 */

/**
 * See \ref gmaCustomCallBacks_s
 * 
 * 
 * @param state (I) the state of the GMA, one of the following:
 * - GMA_CB_STATE_BEF_POWER_ON: will start to send the power On messages to the applications
 * - GMA_CB_STATE_BEF_INTEGRITY_CHECK: the power on was sent, will start to send the Integrity check messages
 * - GMA_CB_STATE_BEF_STARTUP: the integrity check messages was sent, will start to sent the Startup message
 * - GMA_CB_STATE_BEF_LOOP: the Startup message was sent. The GMA will enter the Main loop
 * - GMA_CB_STATE_WAKE_APPL: the GMA will wake up an application
 * - GMA_CB_STATE_IDLE_STATE: the terminal will return to the IDLE state
 */
typedef int16 (*gmaCustomCBStateChange)(uint16 state);

/**
 * @param msg message to be sent by the core to an application
 */
typedef int16 (*gmaCustomCBMsg)(amgMsg_t *msg);

/**
 * See \ref gmaCustomCallBacks_s
 *
 * @param perIds the peripheral ids that a request was made
 * @param timeout the timeout to wait in the psyPeripheralResultWait function
 */
typedef int16 (*gmaCustomCBRequests)(uint32 *perIds, uint32 *timeout);

/**
 * See \ref gmaCustomCallBacks_s
 *
 * @param ret the return from the psyPeripheralResultWait function
 */
typedef int16 (*gmaCustomCBResults)(int32 ret);

/**
 * See \ref gmaCustomCallBacks_s
 * 
 */
typedef int16 (*gmaCustomCBRedraw)(void);

/**
 * See \ref gmaCustomCallBacks_s
 * 
 * @param appId physical application ID of the application that send the message
 * @param header a pointer to struct received
 */
typedef int16 (*gmaCustomCBMsgFrom)(uint16 appId, gmaStructHeader_t *msg);

/**
 * See \ref gmaCustomCallBacks_s
 * 
 * @param appId physical application Id
 * @param logicalId logical application Id
 * @param event Id
 */
typedef int16 (*gmaCustomCBTreatevent)(uint16 appId, uint8 logicalId, uint16 eventId);


/**
 * callback called before the GMA wake up an application.
 * 
 * @param appId application Id of the application that will be wakeup
 * @param logicalId logical Id of the application that will be wakeup
 * @param sendMsg the message that will be sent
 */
typedef int16 (*gmaCustomCBBeforeWakeUpApp)(uint16 appId, uint8 logicalId, amgMsg_t *sendMsg);

/**
 * Structure with the callbacks to be set by the custom.
 */
typedef struct gmaCustomCallBacks_s gmaCustomCallBacks_t;
/**
 * Structure with the callbacks to be set by the custom.
 */
struct gmaCustomCallBacks_s
{
   /**
    * Function to be called when the core state change
    */
   gmaCustomCBStateChange stateChange;
   /** 
    * Function to be called before the core send the message to
    * the application and after the default message is prepare by
    * the core
    */
   gmaCustomCBMsg beforeSendMsg;
   /**
    * Function to be called before the core send the message to
    * the application and after the default message is prepare by
    * the core.
    */
   gmaCustomCBMsg afterSendMsg;
   /**
    * Function to be called in the GMA loop. The custom
    * will use the function to make asynchronous requests
    * or some quickly synchronous requests.After this function
    * returns the core will call the OS function
    * psyPeripheralResultWait with the parameters returned by this
    * function
    */
   gmaCustomCBRequests requests;
   /**
    * Function to be called when the psyPeripheralResultWait in 
    * the core part return and after the normal core treatment for that is
    * finished.
    */
   gmaCustomCBResults results;
   /**
    * Function called to the custom redraw the screen
    */
   gmaCustomCBRedraw redrawDisplay;
   /**
    * treat a message received from the plugin by the
    * plugin queue task. This call will occur not in
    * the main task, but in the plugin queue task
    */
   gmaCustomCBMsgFrom msgFromPlugin;
   /**
    * Treat the reply structs received from the applications;
    * Normally this function will be used to treat the optional
    * replies not treated by the core part.
    */
   gmaCustomCBMsgFrom msgFromApp;
   /**
    * Treat an event that occurs
    */
   gmaCustomCBTreatevent treatEvent;
};

/**
 * Structure with adicional callbacks to be set by the custom.
 */
typedef struct gmaCustomNewCallBacks_s gmaCustomNewCallBacks_t;
/**
 * Structure with the callbacks to be set by the custom.
 */
struct gmaCustomNewCallBacks_s
{
	/**
	 * This function is called before the GMA wake up an application
	 */
	gmaCustomCBBeforeWakeUpApp beforeWakeUpApp;
	/**
	 * MUST BE ZERO FOR FUTURE COMPATIBILITY
	 */
	void *rfu[5];
};

/**
 * Set the custom call backs
 *
 * param cbs the custom callbacks
 */
int16 gmaCBCustomSetCallBacks(gmaCustomCallBacks_t *cbs);

/**
 * Set the new custom call backs
 *
 * param cbs the new custom callbacks
 */
int16 gmaCBCustomSetNewCallBacks(gmaCustomNewCallBacks_t *cbs);


/*
 * This function is called when the core state change
 *
 * The following states are reported. The first number indicate
 * the state number.
 *
 * GMA_CB_STATE_BEF_POWER_ON:
 *   will start to send the power On messages to the applications
 * GMA_CB_STATE_BEF_INTEGRITY_CHECK:
 *   the power on was sent, will start to send the Integrity check messages
 * GMA_CB_STATE_BEF_STARTUP:
 *   the integrity check messages was sent, will start to sent the Startup message
 * GMA_CB_STATE_BEF_LOOP:
 *   the Startup message was sent. The GMA will enter the Main loop
 * GMA_CB_STATE_WAKE_APPL:
 *   the GMA will wake up an application
 * GMA_CB_STATE_IDLE_STATE:
 *   the terminal will return to the IDLE state
 *
 * @param state (I) the state of the GMA (see the states above)
 */
int16 gmaCBCustomStateChange(uint16 state);

/**
 * This funcion returns the last state of the GMA setted by gmaCBCustomStateChange
 * function
 */
uint16 gmaCBCustomGetLastState(void);

/*
 * This function is called before the core send the message to
 * the application and after the default message is prepare by
 * the core.
 *
 * @param sendMsg a pointer to the message to be send.
 */
int16 gmaCBCustomBeforeSendMessage(amgMsg_t *sendMsg);

/**
 * 
 * This function is called after the answer message is received 
 * by the core part. And after the core do its default treatment.
 *
 * @param recMsg a pointer to the received message.
 *
 */
int16 gmaCBCustomAfterReceiveMessage(amgMsg_t *recMsg);

/*
 * This function is called in the GMA loop. The custom
 * will use the function to make asynchronous requests
 * or some quickly synchronous requests.After this function
 * returns the core will call the OS function
 * psyPeripheralResultWait with the parameters returned by this
 * function
 *
 * @param perIds the peripheral ids that a request was made
 * @param timeout the timeout to wait in the psyPeripheralResultWait function
 */
int16 gmaCBCustomRequests(uint32 *perIds, uint32 *timeout);

/*
 * This callback will be called when the psyPeripheralResultWait in 
 * the core part return and after the normal core treatment for that is
 * finished.
 *
 * @param ret the return from the psyPeripheralResultWait function
 */
int16 gmaCBCustomResult(int32 ret);

/**
 * Function called to the custom redraw the screen
 */
int16 gmaCBCustomRedrawDisplay(void);

/*
 * treat a message received from the plugin by the
 * plugin queue task. This call will occur not in
 * the main task, but in the plugin queue task
 */
int16 gmaCBCustomTreatMsgFromPlugin(uint16 appId, gmaStructHeader_t *msg);

/*
 * Treat the reply structs received from the applications;
 * Normally this function will be used to treat the optional
 * replies not treated by the core part.
 *
 * @param appId physical application ID of the application that send the message
 * @param header a pointer to struct received
 */
int16 gmaCBCustomTreatStructFromApp(uint16 appId, gmaStructHeader_t *header);

/*
 * Treat an event that occurs
 *
 * @param appId physical application Id
 * @param logicalId logical application Id
 * @param eventId the id of the event to treat
 */
int16 gmaCBCustomTreatEvent(uint16 appId, uint8 logicalId, uint16 eventId);


/**
 * callback called before the GMA wake up an application.
 * 
 * @param appId application Id of the application that will be wakeup
 * @param logicalId logical Id of the application that will be wakeup
 * @param sendMsg the message that will be sent
 */
int16 gmaCBCustomBeforeWakeUpApp(uint16 appId, uint8 logicalId, amgMsg_t *sendMsg);

#ifdef __cplusplus
}
#endif


#endif

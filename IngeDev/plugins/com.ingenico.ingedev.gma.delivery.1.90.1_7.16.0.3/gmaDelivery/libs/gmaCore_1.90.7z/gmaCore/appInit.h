/**
 * 
 * Send the first messages to the applications
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */
#ifndef APP_INIT_H_INCLUDED
#define APP_INIT_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define GMA_INIT_ERR_NO_PHYSICAL_APP_INFO_FIELD (-1) //!< struct missing in the answer
#define GMA_INIT_ERR_WRONG_INFO_TYPE            (-2) //!< wrong info field type


/**
 * Get the master version
 * 
 * @param implVersion the GMA version number
 * @param specVersion the GMA release number
 */
void gmaInitGetMasterVersion(uint16 *implVersion, uint16 *specVersion);

/**
 * Set the master version
 * 
 * @param implVersion the GMA version number
 * @param specVersion the GMA release number
 */
void gmaInitSetMasterVersion(uint16 implVersion, uint16 specVersion);

/**
 * Send a power on message to all the applications in the terminal
 * and will update the internal list of applications
 */
int16 gmaInitPowerOn(void);

/**
 * Send the integrity check message to all applications
 */
int16 gmaInitIntegrityCheck(void);

/**
 * Send the Startup message to all applications
 */
int16 gmaInitStartup(void);


/**
 * Process the applcations responses 
 */
void gmaInitProcessResponse(uint16 appId, amgMsg_t * pResponseMsg);

/**
 * Process the specific applcations responses for Logical Application Info 
 */
int16 gmaInitProcessLogicalAppInfo(uint16 appId, void * pHeader);

/**
 * Process the specific applcations responses for Logical Application Status 
 */
int16 gmaInitFillLogicalAppStatus(uint16 appId, void * header);

#ifdef __cplusplus
}
#endif


#endif

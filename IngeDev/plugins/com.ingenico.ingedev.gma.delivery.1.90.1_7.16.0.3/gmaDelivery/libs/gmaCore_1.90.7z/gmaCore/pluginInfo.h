
/**
 * Reset the plugin info list
 */

/**
 * add a plugin info struct in the internal list of plugin info
 */

/**
 * get a specific entry in the list
 */

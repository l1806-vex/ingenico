/**
 * @file gmaMedia.h
 * Store the media information
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */


#ifndef GMA_MEDIA_H_INCLUDED
#define GMA_MEDIA_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_MEDIA_ERR_NO_SPACE     (-1)
#define GMA_MEDIA_ERR_NOT_FOUND    (-2)
#define GMA_MEDIA_FILE_NOT_FOUND   (-3)




typedef struct gmaMediaListData_st gmaMediaListData_t;
struct gmaMediaListData_st
{
   uint8  logicalId;
   uint8  mediaId;
   uint16 physicalId;
   uint16 mediaType;
   uint16 status;
   uint16 posX;
   uint16 posY;
   uint16 dataSize;
   uint16 customField;
   uint8  *data;
   void   *customData;
};

/**
 * reset the media list
 */
int16 gmaMediaListReset(void);

/**
 * add or modify an entry in the media list
 *
 * @param logId the logical Id of the application
 * @param phyId the physical application id
 * @param mediaId the id of the media data to be added
 * @param mediaType the type of the media
 * @param dados a pointer to the data to be added
 * @param size the size of the data
 *
 * @return RET_OK the data was added with no problem
 * @return GMA_MEDIA_ERR_NO_SPACE no space to add the data
 */
int16 gmaMediaListAdd(uint8 logId, uint16 phyId, uint8 mediaId,
                      uint16 mediaType, uint8 *dados, uint16 size);


/**
 * add or modify an entry in the media list
 *
 * @param logId the logical Id of the application
 * @param phyId the physical application id
 * @param mediaId the id of the media data to be added
 * @param mediaType the type of the media
 * @param fileName the name of the global file with the data
 *
 * @return RET_OK the data was added with no problem
 * @return GMA_MEDIA_ERR_NO_SPACE no space to add the data
 * @return GMA_MEDIA_FILE_NOT_FOUND no file found
 */
int16 gmaMediaListFileAdd(uint8 logId, uint16 phyId, uint8 mediaId,
									uint16 mediaType, char *fileName);

/**
 * Set the position of the specified Media Data
 *
 * @param logId the logical Id of the application
 * @param phyId the physical application id
 * @param mediaId the id of the media data to be added
 * @param posX x pos in pixel of the media data
 * @param posY y pos in pixel of the media data
 * @param status If the image is visible or not
 * 
 */
int16 gmaMediaListSetPos(uint8 logId, uint16 phyId, uint8 mediaId,
                         uint16 posX, uint16 posY, uint16 status);

/**
 * delete an entry in the media list
 *
 * @param logId the logical Id of the application
 * @param phyId the physical application id
 * @param mediaId the id of the media data to be added
 * @return RET_OK the data was deleted with no problem
 * @return GMA_MEDIA_ERR_NOT_FOUND the entry was not found
 */
int16 gmaMediaListDel(uint8 logId, uint16 phyId, uint8 mediaId);

/**
 * This function is called before start to call the
 * function \ref gmaMediaGetNextEntry. This function will make the next
 * entry be the first entry in the list
 */
int16 gmaMediaGetEntryStart(void);

/**
 * Get the next entry in the list of media data. Before start to use this
 * function call the \ref gmaMediaGetEntryStart
 * @param data a pointer to a pointer when the data will be returned
 *
 * @return RET_OK entry return OK
 * @return GMA_MEDIA_ERR_NOT_FOUND no more available entries in the list
 */
int16 gmaMediaGetNextEntry(gmaMediaListData_t **data);


/**
 * Get the media Index in the table.
 * 
 * @param logId logical Id of the plugin or application that own this media ID
 * @param phyId physical Id of the plugin or application that own this media ID
 * @param mediaId ID of the media
 * 
 * @return greater or equal zero indicate the index in the table.
 * a negative value indicate that the entry is not found in the table.
 */
int16 gmaMediaGetIndex(uint8 logId, uint16 phyId, uint8 mediaId);

/**
 * Get an entry from the table
 * @param index index to read for
 * @param data a pointer to a pointer when the data will be returned
 *
 * @return RET_OK entry return OK
 * @return -1 index to big
 */
int16 gmaMediaGetEntryFromIndex(uint16 index, gmaMediaListData_t **data);

#ifdef __cplusplus
}
#endif


#endif






/**
 * 
 * @file gmaAppMsg.h
 * manage the messages to and from the application
 *
 * @author Roberto Belli
 */

#ifndef GMA_APP_MSG_H_INCLUDED
#define GMA_APP_MSG_H_INCLUDED

#include "applist.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Callback define to check the answer message receive from the applications when
 * the function gmaAppMsgBroadcastExt is called.
 *
 * @param appEntry the application that send the message
 *
 * @param msg the message sent by the application
 *
 * @return RET_OK to continue the process of send a message to all applications
 * @return any other value will stop the process of send messages to all applications
 */
typedef int16 (*gmaAppMsgCheckAnswer)(gmaAppListPhysicalData_t *appEntry, amgMsg_t *msg);


/**
 * this function will send a query message to all application
 * and return a table with the answer of the application.
 * The custom prepare the message before call this function
 *
 * @param msg the query message to be sent
 *
 * @param queryAns a vector with the answer to the query message.
 */
int16 gmaAppMsgQueryDriven(amgMsg_t *msg, uint8 **queryAns);

/**
 * Send a wake up message to the specified application.
 * Before the message was sent to this specific application a message
 * is sent to all the plugins warning that an application will be started.
 * After the application answer back the message a message to all the plugins
 * were sent warning that the terminal returns to the idle state.
 *
 * @param appId Send the message to the application with this appId
 *
 * @param logicalId Send the message to the application with this logicalId
 *
 * @param msg the message to be sent
 *
 * @param answer the message send back by the aplication
 */
int16 gmaAppMsgWakeApp(uint16 appId, uint8 logicalId, amgMsg_t *msg, amgMsg_t *answer);

/**
 * send a message to all the applications in the terminal
 *
 * @param msg the message to be sent to all applications
 */
int16 gmaAppMsgBroadcast(amgMsg_t *msg);

/**
 * Send a message to all applications and check for the answer
 *
 * @param msg the message to be send to all applications
 *
 * @param checkMsgCb the callback to check each answer. If the callback return
 *                   is OK the process of send the message continues, if it
 *                   is any other value the process stop and the function returns
 *                   the value returned by the callback
 *
 * 
 */
int16 gmaAppMsgBroadcastExt(amgMsg_t *msg, gmaAppMsgCheckAnswer checkMsgCb);


/**
 * Send a message to all plugins warning the activity GMA status
 *
 * @param activityStatus the activity status of the GMA.
 * One of the following values:
 * - \ref GMA_PG_ACTIVITY_START
 * - \ref GMA_PG_ACTIVITY_END
 * - \ref GMA_PG_APP_START
 * - \ref GMA_PG_APP_END
 */
int16 gmaAppMsgSendActivityMsg(uint8 activityStatus);

/**
 * 
 */
int16 gmaAppMsgSendNotifyMsg(uint16 appId, uint8 pgId, uint16 notifyType, uint8 notifParam);

/**
 * send a message to an application and wait the answer
 * treat special answer if necessary.
 * 
 * @param appEntry the application to send the message
 * 
 * @param msg the message to be sent
 * 
 * @param answer the return message
 */
int16 gmaAppMsgSendRecMsg(gmaAppListPhysicalData_t *appEntry, amgMsg_t *msg, amgMsg_t *answer);

#ifdef __cplusplus
}
#endif


#endif


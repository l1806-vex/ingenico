#ifndef GMA_MSG_SUP_H_DEFINED
#define GMA_MSG_SUP_H_DEFINED

#ifdef __cplusplus
extern "C" {
#endif


/*
   General message support for Idle

   Unicapt32 - Idle Application
   Ingenico Latin America
*/

/**
 * @file gmaMsgSup.h
 *
 * Gma message support
 */

#define GMA_MSG_ERR_LIST_FULL (-1) //<! the list is full

/**
 * callback for treatment of optional reply by the core or custom part
 */
typedef int16 (* gmaMsgOptionalReplyFunc)(uint16, gmaStructHeader_t *);

/**
 * Force the creation of the global message file
 */
int16 gmaMsgCreateGlobalFile(void);

/**
 * Clean-up the global message file.
 */
int16 gmaMsgResetGlobalFile(void);

/**
 * Set the logical Id to use in the headers of next calls to add structures
 * to the message
 *
 * @param logicalId logical identifier to be used in the next structures added
 * in the message
 */
void gmaMsgSetLogicalId(uint8 logicalId);

/**
 * Generate the Power On Message
 */
int16 gmaMsgsAddMasterVersion(uint16 implVersion, uint16 specVersion);

/**
 * Add application information in the power on message
 */
int16 gmaMsgsAddApplicationInfo(uint16 appId, uint16 pid);


/**
 * Generate the integrity check message
 */
int16 gmaMsgsAddEmpty(void);

/**
 * Add the struct with the ID GMA_STRUCT_ to the GMA_STRUCT_TRANS_TYPE
 * current message
 */
int16 gmaMsgAddTransType(uint8 logicalId, uint8 transType);

/**
 * GMA_STRUCT_PG_QUEUE_ID
 */
int16 gmaMsgAddPGQueueId(uint32 queueId);

/**
 * GMA_STRUCT_PG_ACTIVITY_INFO
 */
int16 gmaMsgAddPGActivityInfo(uint16 activityType);

/**
 * GMA_STRUCT_PLUGIN_INFO
 */
int16 gmaMsgAddPluginInfo(char *pluginName, uint16 pluginVersion, uint16 appId, uint8 logicalId);

/**
 * Add the struct with the ID GMA_STRUCT_TRN_PAYMENT_INFO
 */
int16 gmaMsgsAddPaymentInfo(uint32 trnAmount, uint16 trnCurrency, uint8 trnType);

/************ Smart card ***************/
/**
 * Add the struct with the ID GMA_STRUCT_TRN_SMART_CARD_EVENT_INFO to the 
 * current message
 */
int16 gmaMsgsAddTransSmartCard(uint8 cardType, uint8 infoType);

/**
 * Add the struct with the ID GMA_STRUCT_TRN_SMART_CARD_INFO
 */
int16 gmaMsgsAddTransSmcAtr(uint8 *atrValue, uint16 atrLength);

/**
 * Add the struct with the ID GMA_STRUCT_TRN_EMV_SMART_CARD_INFO
 */
int16 gmaMsgsAddTransSmcEmv(uint8 *cardResponse, uint16 cardResponseLength);

/**
 * Add the struct with the ID GMA_STRUCT_SMC_SELECTION_MODE
 */
int16 gmaMsgAddSmcSelectionMode(uint16 selectionType);

/********* MAGNETIC CARD ***********/

/**
 * Add the struct with the ID GMA_STRUCT_TRN_MAG_CARD_EVENT_INFO
 */
int16 gmaMsgsAddTransMagCard(uint8 magType, uint8 selectionType);
/**
 * Add the struct with the ID GMA_STRUCT_TRN_MAG_CARD_INFO
 */
int16 gmaMsgsAddTransMagTrack(uint8 trackNumber, uint8 trackLength, 
                            uint8 *trackData);

/**
 * Add the structure gmaStructEmvFallback_t in the message. (ID GMA_STRUCT_EMV_FALLBACK).
 */
int16 gmaMsgsAddSmcFallback(uint8 fallbackStatus, uint32 timeSinceSmcInsertion, uint8 step, int16 status);


/******** keyboard *************/

/**
 *  Add the struct with the ID GMA_STRUCT_TRN_KEYBOARD_EVENT_INFO
 */
int16 gmaMsgsAddTransKeyPressed(uint8 keyPressed);
/******** Menu **************/

/**
 * Add the struct with the ID GMA_STRUCT_TRN_MENU_EVENT_INFO
 */
int16 gmaMsgsAddTransMenu(uint16 menuItem);

/******** Scheduled Event **************/

/**
 * Add the struct with the ID GMA_STRUCT_EVENT_OCCUR
 */
int16 gmaMsgsAddEventOccur(uint8 logicalId, uint16 eventId);



/////////////////////////
/**
 * GMA_STRUCT_TRANS_ADM_FUNC
 */
int16 gmaMsgAddTransAdmFunc(uint8 funcType, uint8 funcId);

/**
 * GMA_STRUCT_PG_NOTIFICATION_TYPE
 */
int16 gmaMsgAddNotificationType(uint8 pluginId, uint16 notificationType,
                                uint8 notificationParam);

/**
 * GMA_STRUCT_PG_SET_CONFIG
 */
int16 gmaMsgAddPGSetConfig(uint8 pluginId, uint8 parameterId,
                           uint16 dataLength, uint8 *data);


/******** Optional Structures **************/

/**
 * This will skip over all messages, processing only on those that it can
 * actually process.
 * After all messages are seen, the message parser will rewind so the next
 * gmaMsgRead() gets the first message.
 */
int16 gmaMsgsProcessOptionalReply(uint16 appId, amgMsg_t *reply);

/**
 * Media data inline in message
 */
int16 gmaMsgsProcessMediaData(uint16 appId, gmaStructHeader_t *data);

/**
 * Media data in global file
 */
int16 gmaMsgsProcessMediaFile(uint16 appId, gmaStructHeader_t *data);

/**
 * Media data in resource file
 */
int16 gmaMsgsProcessMediaResource(uint16 appId, gmaStructHeader_t *data);

/**
 * Position of a media file
 */
int16 gmaMsgsProcessMediaPosition(uint16 appId, gmaStructHeader_t *data);


/**
 * Event scheduling
 */
int16 gmaMsgsProcessSchedEventInfo(uint16 appId, gmaStructHeader_t *data);


/*****************************************************************************/
/***** Message from the plugins *************/

/**
 * Treat the messages received from the plugin that need to be treated in the main Task
 */
int16 gmaMsgsProcessMsgFromPlugin(uint16 appId, gmaStructHeader_t *header);


/**
 * Treat the broadcast request from a plug-in
 */
int16 gmaMsgsProcessPGBroadcast(uint16 appId, gmaStructHeader_t *header);

/**
 * Get the broadcast answer from applications
 */
void gmaMsgsGetBroadcastResult(int16 *results, uint16 *length);

#ifdef __cplusplus
}
#endif


#endif

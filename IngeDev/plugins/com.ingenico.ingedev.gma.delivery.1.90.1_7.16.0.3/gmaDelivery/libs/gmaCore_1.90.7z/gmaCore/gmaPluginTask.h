/**
 * 
 * plugin Task manager
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */

#ifndef GMA_PLUGIN_TASK_H_INCLUDED
#define GMA_PLUGIN_TASK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_PLUGIN_TASK_ERR_CREATE_TASK (-1)

/**
 * Create the plugin task
 * and call the gmaPGinitialize function
 */
int16 gmaPGTCreatePGTask(void);

/**
 * Send a message to the plugin and wait for the answer
 *
 * @param sendMsg   the message to be sent to the plugin
 * @param answerMsg the message to be returned
 */
int16 gmaPGTsendMessagePg(amgMsg_t *sendMsg);


/**
 * Send a message to the plugin received from the application.
 */
int16 gmaPGTsendAppMsgPg(uint8 *msg, uint16 length);

#ifdef __cplusplus
}
#endif


#endif




#ifndef GMA_APP_LIST_FILE_H_INCLUDED
#define GMA_APP_LIST_FILE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#define GMA_APP_LIST_APP_ID_BASE (2000)

/**
 * Start this library. Read the file from the terminal with the
 * actual applications names - appIds pair entries. If the
 * file don't exist, create an empty one
 * 
 * @return RET_OK No error occurs
 */
int16 gmaALFStart(void);

/**
 * Get the appId of the application with the appName.
 * First, check if the application exists in the
 * file, if yes, return the associated appId, if not
 * get a non uses appId and return it, and save it
 * in the file.
 * Set the entry of the file (mark the entry as used) as used too, to enable
 * the deletion of the file of the deleted applications.
 * Applications entries in the file that are not marked will be deleted
 * when the functions \ref gmaALFDeleteNotUsed function are called.
 */
uint16 gmaALFGetAppId(char *appName);

/**
 * Called after finish the calls to function \ref gmaALFGetAppId
 * to save in the file the final list. Only the entries with the
 * marked field on one will be saved
 */
int16 gmaALFSaveList(void);

#ifdef __cplusplus
}
#endif


#endif


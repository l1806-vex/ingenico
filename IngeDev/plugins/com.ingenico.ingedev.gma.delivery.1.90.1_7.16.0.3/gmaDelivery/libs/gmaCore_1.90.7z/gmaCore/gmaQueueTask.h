
#ifndef GMA_QUEUE_TASK_H_INCLUDED
#define GMA_QUEUE_TASK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_QTASK_MAX_MSG_SIZE (512)

int16 gmaQTaskPluginTableAdd(uint16 oldAppId, uint16 newAppId);

/**
 * Create the task that receive messages from the plugins
 */
int16 gmaQTaskCreate(void);

/**
 * Get the plugin queue Id
 */
uint32 gmaQTaskGetQueueId(void);

/**
 * Send the received message to the main task. Then, the main task will treat the
 * received message
 */
int16 gmaQTaskSendEventMTask(uint16 appId, gmaStructHeader_t *msg);

/**
 * called by the main task to tell the queue task that 
 * the main task finish the treatment of the message
 */
int16 gmaQTaskEndEventTreatment(void);

/**
 * Retrieve the data send by the event
 */
int16 gmaQTaskGetEventParams(uint16 *appId, gmaStructHeader_t **msg);

#ifdef __cplusplus
}
#endif


#endif

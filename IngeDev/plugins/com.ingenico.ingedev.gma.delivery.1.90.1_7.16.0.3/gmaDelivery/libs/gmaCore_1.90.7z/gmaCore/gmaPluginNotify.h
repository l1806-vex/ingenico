
#ifndef GMA_PLUGIN_NOTIFY_H_INCLUDED
#define GMA_PLUGIN_NOTIFY_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_PLUGIN_NOTIFY_MAX_TABLE_SIZE (10)


/**
 * Add an notify request in the FIFO
 * 
 * @param appId the application ID that request the notification
 * @param pgId the plugin id that request the notification
 */
int16 gmaPgNotAddNotif(uint16 appId, uint8 pgId, uint16 notifType, uint8 notifParam);

/**
 * Check if there is a notification waiting in the queue
 * 
 * @param appId a pointer to where the appId will be stored
 * @param pgId a pointer ro where the plugin id will be stored
 */
int16 gmaPgNotCheckNotif(uint16 *appId, uint8 *pgId, uint16 *notifType, uint8 *notifParam);

#ifdef __cplusplus
}
#endif


#endif


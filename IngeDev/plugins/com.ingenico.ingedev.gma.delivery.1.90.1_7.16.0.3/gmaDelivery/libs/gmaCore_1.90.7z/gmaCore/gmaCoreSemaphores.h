
/**
 * Semaphore functions
 */

#ifndef GMA_CORE_SEMAPHORE_H_INCLUDED
#define GMA_CORE_SEMAPHORE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_CORE_SEMAPHORE_EV_LIST (0)
#define GMA_CORE_SEMAPHORE_MEDIA_DATA (1)
#define GMA_CORE_SEMAPHORE_NOTIFY_TABLE (2)

#define GMA_CORE_SEMAPHORE_MAX_NUMB (3)

/**
 * Initialize the library variables and
 * create the semaphores
 */
int16 gmaCoreSemaphoreInit(void);

/**
 * Acquire a semaphore.
 */
int16 gmaCoreSemaphoreAcquire(uint8 semaphoreId);

/**
 * Release the semaphore
 */
int16 gmaCoreSemaphoreRelease(uint8 semaphoreId);

#ifdef __cplusplus
}
#endif


#endif


/**
 * 
 * Manage the application list for the GMA application
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */

/**
 * @file applist.h
 *
 * application list table support
 */

#ifndef GMA_APP_LIST_H_INCLUDE
#define GMA_APP_LIST_H_INCLUDE

#include "gmaStructures.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ************************************************************************* */



#define GMA_APP_LIST_PHYSICAL_APP_NUMBER        (15) //!< max number of physical apps
#define GMA_APP_LIST_LOGICAL_APP_NUMBER         (35) //!< max number of logical applications

#define GMA_APP_LIST_INSIDE_PLUGIN_APP          (0xFFFF) //!< number of physical app for internal plugin

#define GMA_APP_LIST_LOGICAL_ID_DEFAULT         (0xFF)
#define GMA_APP_LIST_LOGICAL_NAME_DEFAULT       ("def")

#define GMA_APP_LIST_ERR_NO_APPID      (-1) //!< error, the app id is not in the list
#define GMA_APP_LIST_ERR_WRONG_INDEX   (-2) //!< error, the index is too high
#define GMA_APP_LIST_ERR_NO_SPACE      (-3) //!< error, there is no space to return the result
#define GMA_APP_LIST_ERR_LIST_FULL     (-4) //!< error, the list is full
#define GMA_APP_LIST_ERR_WRONG_PARAM   (-5) //!< error, normally pointer to NULL in the parameter list of the function
#define GMA_APP_LIST_ERR_NO_TASKID     (-6) //!< error, the taskId is not found in the list of applications
#define GMA_APP_LIST_NO_APP            (-7) //!< error, there is no application with the search parameter


/* ************************************************************************* */



/* ************************************************************************* */
// READ DATA FUNCTIONS

/**
 * used to get the entry related to the application Id
 *
 * @param appId application id which the information will be returned
 *
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 *
 * @return RET_OK no errors and the return value is valid
 * @return GMA_APP_LIST_ERR_NO_APPID the application id is not on the list
 *
 */
int16 gmaAppListGetAppEntryFromId(uint16 appId, gmaAppListPhysicalData_t **entry);

/**
 * get the entry related to the index in the list
 *
 * @param index index in the list of application which the information will be returned
 *
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_WRONG_INDEX the index is too high (no item with this index)
 */
int16 gmaAppListGetAppEntryFromInd(uint16 index, gmaAppListPhysicalData_t **entry);

/**
 * get the entry related to the application name
 * 
 * @param appName the name of the physical application
 * 
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 * 
 * @return RET_OK NO ERRORS
 * @return GMA_APP_LIST_NO_APP there is no physical application with this name
 */
int16 gmaAppListGetAppEntryFromName(const char *appName, gmaAppListPhysicalData_t **entry);

/**
 * get the number of logical applications of a physical application ID
 *
 * @param appId physical application Id
 *
 * @param nLogical a poiter to receive the number of logical applications
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_NO_APPID the application id is not on the list
 */
int16 gmaAppListGetLogicalAppNumFromAppId(uint16 appId, uint16 *nLogical);

/**
 * get the list of logical applications index of a specified physical application id
 *
 * @param appId physical application Id
 *
 * @param index a vector of uint8 that will receive the logical app index
 *
 * @param length (in) the size of the logicalIds vector (out) the number of logical apps returned
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_NO_APPID the application id is not on the list
 * @return GMA_APP_LIST_ERR_NO_SPACE there is no space in logicalIds vector to return the entiry logical apps id
 */
int16 gmaAppListGetLogicalAppListFromAppId(uint16 appId, uint8 *index, uint16 *length);

/**
 * Get the entry in the application list from the taskId number
 *
 * @param taskId task id
 *
 * @param  entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 *
 * @return RET_OK
 *
 * @return GMA_APP_LIST_ERR_NO_TASKID
 */
int16 gmaAppListGetAppEntryFromTID(uint32 taskId, gmaAppListPhysicalData_t **entry);

/**
 * get the entry in the logical application list from the logicalId and applicationId
 *
 * @param logicalId id of the logical application
 *
 * @param appId id of the physical application
 *
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 *
 * @return RET_OK no error
 * @return GMA_APP_LIST_ERR_NO_APPID there is no entry in the list with the logicalId and appId
 */
int16 gmaAppListGetLogicalEntryFromId(uint16 logicalId, uint16 appId, gmaAppListLogicalData_t **entry);

/**
 * get an entry in the logical application list from the app Name
 *
 * @param name the name to be search
 *
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 * @return RET_OK no error
 * @return GMA_APP_LIST_ERR_NO_APPID there is no entry found in the list
 */
int16 gmaAppListGetLogicalEntryFromName(const char *name, gmaAppListLogicalData_t **entry);

/**
 * get the entry in the logical application list with the "index" index
 *
 * @param index index of the entry in the logical application list
 *
 * @param entry a pointer to a pointer to thegmaAppListPhysicalData_t structure. The pointer will
 *        point to the correct entry
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_WRONG_INDEX the index is too high (no item with this index)
 */
int16 gmaAppListGetLogicalEntryFromInd(uint16 index, gmaAppListLogicalData_t **entry);

/* ************************************************************************* */
// WRITE DATA FUNCTIONS

/**
 * reset the physical application list
 *
 * @return Always RET_OK
 */
int16 gmaAppListResetLists(void);

/**
 * Add a entry in the physical application list
 *
 * @param entry the entry to be added
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_LIST_FULL the physical application list is full
 */
int16 gmaAppListAddPhysicalAppEntry(gmaAppListPhysicalData_t *entry);

/**
 * Add a entry in the logical application list
 *
 * @param entry the entry to be added in the logical application list
 *
 * @return RET_OK no errors
 *
 * @return GMA_APP_LIST_ERR_LIST_FULL the logical application list is full
 */
int16 gmaAppListAddLogicalAppEntry(gmaAppListLogicalData_t *entry);

/**
 * Remove an entry in the logical app List
 *
 * @param entry the entry to be deleted in the logical application list
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_WRONG_INDEX wrong index
 *
 */
int16 gmaAppListDelLogicalAppEntry(gmaAppListLogicalData_t *entry);

/**
 * Remove an entry in the physical app list
 * remove also all the logical app entries related to this
 * physical app.
 *
 * @param index index in the list
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_WRONG_INDEX wrong index
 *
 */
int16 gmaAppListRemoveAppPhysicalEntry(uint16 index);

/**
 * remove an entry in the logical app List
 *
 * @param index index in the list
 *
 * @return RET_OK no errors
 * @return GMA_APP_LIST_ERR_WRONG_INDEX wrong index
 *
 */
int16 gmaAppListRemoveLogicalAppEntry(uint16 index);

/**
 * get the index of the entry in the physical application list with the current appId
 *
 * @param appId application Id
 *
 * @return a positive number is the index
 * @return a negative number is error
 * @return GMA_APP_LIST_ERR_NO_APPID appId not found
 */
int16 gmaAppListGetIndexFromAppId(uint16 appId);

/**
 * Return the index of an application from its process ID,
 * or (-1) if appId not found in list.
 */
int16 gmaAppListGetIndexFromPid(uint16 pid);

/*
 * Order the physical application list, putting the plug-ins in the beggining of the list 
 */
int16 gmaAppListSortByAppType(void);

#ifdef __cplusplus
}
#endif


#endif

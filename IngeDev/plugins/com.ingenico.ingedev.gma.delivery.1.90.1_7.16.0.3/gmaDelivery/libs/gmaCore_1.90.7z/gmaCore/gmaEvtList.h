#ifndef GMA_EVT_LIST_H
#define GMA_EVT_LIST_H

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gmaEvtList.h
 *
 * Handle list of scheduled events.
 *
 * @author Roberto Belli
 */

#define GMA_EVT_LIST_ERR_NO_ENTRY      (-1) //!< entry not found in the list
#define GMA_EVT_LIST_ERR_NO_EVENT      (-2) //!< no event occur
#define GMA_EVT_LIST_ERR_OPEN_FILE     (-3) //!< error opennig the event list file
#define GMA_EVT_LIST_ERR_READ_FILE     (-4) //!< error reading event list file
#define GMA_EVT_LIST_ERR_WRITE_FILE    (-5) //!< error writting the event list file
#define GMA_EVT_LIST_ERR_CREATE_FILE   (-6) //!< error creating the event list file
#define GMA_EVT_LIST_ERR_NO_MEM        (-7) //!< error no memory available
#define GMA_EVT_LIST_ERR_PARAM         (-8) //!< wrong parameter
#define GMA_EVT_LIST_ERR_INV_FILE      (-9) //!< invalid or corrupted event list file


#define GMA_EVT_LIST_EVT_STANDART      (1) //!< normal event type
#define GMA_EVT_LIST_EVT_REPEATED      (2) //!< repeated event

/**
 * Structure that holds an event
 */
typedef struct gmaEvtListData_t gmaEvtListData_t;
/**
 * Structure that holds an event
 */
struct gmaEvtListData_t
{
   /**
    * Event type, can be:
    *
    * - \ref GMA_EVT_LIST_EVT_STANDART
    *
    * - \ref GMA_EVT_LIST_EVT_REPEATED
    */
   uint8 type;

   uint8 logicalId; //!< logical Id
   uint16 physicalId; //!< physical Id
   uint16 evtId; //!< the event Id

   uint32 date; //!< date in Unicapt format
   uint32 time; //!< time in Unicapt format
   uint32 repeatPeriod; //!< period to the next connection in seconds
};

/**
 * Clear all elements on the event list.
 *
 * @return RET_OK
 */
int16 gmaEvtListReset(void);

/**
 * Load the list from the event list file
 *
 * @return RET_OK
 *
 * @return GMA_EVT_LIST_ERR_OPEN_FILE error opennig the event list file
 *
 * @return GMA_EVT_LIST_ERR_READ_FILE error reading event list file
 */
int16 gmaEvtListReadFromFile(void);

/**
 * Save the list in the event list file. If the file didn't exist it will be created
 *
 *
 * @return RET_OK no error
 *
 * @return GMA_EVT_LIST_ERR_CREATE_FILE
 *
 * @return GMA_EVT_LIST_ERR_WRITE_FILE
 */
int16 gmaEvtListSaveInFile(void);

/**
 * Add an event to the event list sorting in date format
 *
 * @param[in] event event to be added in the list
 *
 * @return RET_OK
 */
int16 gmaEvtListAdd(gmaEvtListData_t *event);

/**
 * Delete an event in the event list
 *
 * @param[in] physicalId physical application Id
 *
 * @param[in] logicalId logical Id
 *
 * @param[in] eventId Id of the event
 *
 * @return RET_OK entry found and deleted
 *
 * @return GMA_EVT_LIST_ERR_NO_ENTRY entry not found in the list
 */
int16 gmaEvtListDel(uint16 physicalId, uint8 logicalId, uint16 eventId);

/**
 * Delete all entries from a specific physical and logical application
 * if the logicalId is equal GMA_APP_LIST_LOGICAL_ID_DEFAULT then
 * all the events from the physical application will be deleted
 *
 * @param[in] physicalId physical application Id
 *
 * @param[in] logicalId logical Id
 *
 * @return RET_OK entry found and deleted
 *
 * @return GMA_EVT_LIST_ERR_NO_ENTRY entry not found in the list
 */
int16 gmaEvtListDelAll(uint16 physicalId, uint8 logicalId);

/**
 * check to see if a event occurs, if a event occur, return it and delete it from the list
 * if it is not a repeated event
 *
 * @param actualDate actual date in Unicapt format
 *
 * @param actualTime actual time in Unicapt format
 *
 * @param event return the occured event if exists
 *
 * @return RET_OK if a event occur
 *
 * @return GMA_EVT_LIST_ERR_NO_EVENT no event occur
 *
 */
int16 gmaEvtListCheckEvtOccur(uint32 actualDate, uint32 actualTime, gmaEvtListData_t *event);

/**
 * get the number of seconds for the next schedule event
 *
 * @param secs a pointer to receive the number of bytes to the next schedule event
 *
 * @return RET_OK no problem
 * @return GMA_EVT_LIST_ERR_NO_EVENT no event in the schedule event list
 */
int16 gmaEvtListNextEvtNumSecs(uint32 *secs);

/**
 * Reset internally the parse of the event list.
 * Must be called before the calls to \ref gmaEvtListReadNext
 */
int16 gmaEvtListReadStart(void);

/**
 * Read the next schedule event in the schedule event list
 * 
 * @param event a pointer to a pointer to the event.
 * 
 * @return RET_OK the event was read
 * @return GMA_EVT_LIST_ERR_NO_EVENT there is no more events to bee readed
 */
int16 gmaEvtListReadNext(gmaEvtListData_t **event);

#ifdef __cplusplus
}
#endif


#endif

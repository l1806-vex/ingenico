/*******************************************************************************
                              Property of INGENICO
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Generic Communications Module
 *  FILENAME       :    configMgr.h
 *  PURPOSE        :    GCM Configuration Manager
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  10/05/04     CHU        Initial Version
 *  17/05/04     CDL        Updated gcmConfigGetParameter prototype
 * 
 *  RELEASE 1.01
 *  11/08/04     CHH        Modified gcmConfigGetParamater prototype.
 *                          Added new return Code.
 * -----------------------------------------------------------------------------
 *  DESCRIPTION    :    
-*/

#ifndef CONFIGMGR_H
#define CONFIGMGR_H

#include "tlv.h"

/** \addtogroup Config_ Config Manager
 *
 * 
 * 
 *  @{
 */

/**
 * \file configmgr.h
 */


/////////////


#define GCM_ERROR_BASE                 (-0x100)
#define GCM_NO_PROFILE_HANDLES         (GCM_ERROR_BASE - 1)  /*!< No profile handles available*/
#define GCM_INVALID_PROFILE_HANDLE     (GCM_ERROR_BASE - 2)  /*!< The profile handle is Invalid*/
#define GCM_FILE_OPEN_FAILED           (GCM_ERROR_BASE - 3)  /*!< The attempt to open the file failed*/
#define GCM_FILE_DELETE_FAILED         (GCM_ERROR_BASE - 4)  /*!< The attempt to delete the file failed*/
#define GCM_FILE_READ_FAILED           (GCM_ERROR_BASE - 5)  /*!< The attempt to read the file failed*/
#define GCM_SET_PROFILE_FAILED         (GCM_ERROR_BASE - 6)  /*!< The attempt to update data in a profile failed*/
#define GCM_INVALID_FILE               (GCM_ERROR_BASE - 7)  /*!< The file doens't appear to be a validy profile*/
#define GCM_NOT_CONFIG_FILE            (GCM_ERROR_BASE - 8)  
#define GCM_PARAMETER_NOT_IN_PROFILE   (GCM_ERROR_BASE - 9)  /*!< the tag is not found in the profile*/
#define GCM_TLV_SET_FAILED             (GCM_ERROR_BASE - 10) /*!< problem to set the value in the profile*/
#define GCM_BASE_FILE_OPEN_FAILED      (GCM_ERROR_BASE - 11) /*!< problem with the basename profile*/
#define GCM_CREATE_BASE_FAILED         (GCM_ERROR_BASE - 12) 
#define GCM_TAG_DOES_NOT_EXIST         (GCM_ERROR_BASE - 13) /*!< the tag does not exist in the profile*/
#define GCM_DATA_TOO_LONG              (GCM_ERROR_BASE - 14) /*!< the data to be return does not fit in the buffer*/


typedef uint8 profileHandle_t;

/**
 * Initialize the internal variables, must be called before any other functions 
 * of this llibrary
 */
extern void gcmConfigInitialise(void);

/**
 * Creates a new file that will store the configuration of the SMF in a TLV
 * format.
 *
 * @param profileHandle (O) will receive a profile handle for next access to this
 * created profile
 *
 * @param profileName (I) the name of the file with will store the configuration
 *                        the maintenance library expect that the configuration be
 *                        stored in a file named MAINTENANCE_FILE (a define)
 *
 * @param baseProfile (I) a already exist profile, it will have your value copy
 *                        to the created one
 *
 * @return 
 *   RET_OK                     no errors
 *   GCM_NO_PROFILE_HANDLES    no free space in the internal table to open one more profile
 *   GCM_BASE_FILE_OPEN_FAILED Failed to open the base file
 *   GCM_INVALID_FILE          Invalid base file format
 *   GCM_FILE_READ_FAILED      Failed to read the base file
 *   GCM_FILE_OPEN_FAILED      file to open/create the new file
 *   GCM_SET_PROFILE_FAILED    failed to save defaults values in the new file
 */
extern int16 gcmConfigCreateProfile(profileHandle_t *profileHandle, char *profileName, char *baseProfile);

/**
 * Open a file with configuration of the SMF in a TLV format.
 * 
 * @param profileHandle (O) a poiter to profileHandle_t type to receive the handle
 * of the profile open
 * @param profileName (I) the name of the file to be open that has the SMF configuration
 * 
 * @return 
 *    RET_OK                  no errors
 *    GCM_NO_PROFILE_HANDLES  no free space in the internal table to open one more profile
 *    GCM_FILE_OPEN_FAILED    error to open the file
 *    GCM_INVALID_FILE        invalid file
 *    GCM_FILE_READ_FAILED    error when reading the file (incorrect file size normally)
 *    
 */
extern int16 gcmConfigOpenProfile(profileHandle_t *profileHandle, char *profileName);

/**
 * close the profile previous openned by the gcmConfigOpenProfile or gclConfigCreateProfile
 * 
 * @param profileHandle a poiter to the profile handle previous opened
 * 
 * @return 
 *    RET_OK                       no errors
 *    GCM_INVALID_PROFILE_HANDLE   
 */
extern int16 gcmConfigCloseProfile(profileHandle_t *profileHandle);

/**
 * Delete the given configuration profile
 * 
 * @param profileName (I) the name of the profile file to be deleted
 * 
 * @return 
 *    RET_OK if no errors occurs
 *    GCM_FILE_DELETE_FAILED if a error occurs in the attempt to delete the file
 */
extern int16 gcmConfigDeleteProfile(char *profileName);

/**
 * set a parameter in the profile
 * 
 * @param profileHandle (I) the handle of the profile to be modified. The profile need
 *    to be open by the function \ref gcmConfigOpenProfile ir \ref gcmConfigCreateProfile.
 * 
 * @param newTag (I) the tag name to be added or modified. The available tags to configure the SMF are in the 
 *    \ref profTags
 * 
 * @param newLength (I) the length of the data to be put in the tag
 * 
 * @param tlvValue (I) a poiter to the data to be put in the tag.
 * 
 * @return 
 *    RET_OK if no errors occurs
 *    GCM_INVALID_PROFILE_HANDLE if the profile handle is invalid or not open yet.
 * 
 */
extern int16 gcmConfigSetParameter(profileHandle_t profileHandle, TlvTypeEle *newTag, TlvLength newLength, uint8 *tlvValue);

/**
 * Add the configuration in a tlv struct to the profile configuration referent to the profileHandle.
 * 
 * @param profileHandle (I) handle of the profile to be modified
 * 
 * @param newTlv (I) tlv struct to be added (merge) to the profile to be modified
 * 
 * @return 
 *    RET_OK if no errors occurs
 *    GCM_INVALID_PROFILE_HANDLE if the profile handle is invalid or not open yet.
 *    GCM_TLV_SET_FAILED if the merge of the tlv with the profile failed
 */
extern int16 gcmConfigTLVSetParameter(profileHandle_t profileHandle, pTlv newTlv);

/**
 * Get a specified tag from the configuration profile.
 * 
 *  @param profileHandle (I) handle of the profile
 *  @param tag (I) the tag name where we want to get the value
 *  @param newLength (IO) a pointer to the size of the buffer that will receive the
 *       result. The value will be change to the size of the data readed.
 *  @param tlvValue (O) A pointer to a buffer where the data will be returned. The size
 *       of the buffer is passed to the function using the newLength pointer and
 *       the number of bytes will be returned in the same newLength pointer.
 * 
 *  @return 
 *    RET_OK if no errors occurs
 *    GCM_INVALID_PROFILE_HANDLE if the profile handle is invalid or not open yet.
 *    GCM_PARAMETER_NOT_IN_PROFILE if the tag was not found in the profile
 *    GCM_DATA_TOO_LONG if the buffer can't hold the entire data in the tag.
 */
extern int16 gcmConfigGetParameter(profileHandle_t profileHandle, uint8 *tag, TlvLength *newLength, uint8 *tlvValue);

/**
 * Delete a tag from the configuration profile specified by the profileHandle
 * 
 *  @param profileHandle (I) handle of the profile
 *  @param tag (I) the tag name that will be deleted
 * 
 *  @return 
 *    RET_OK if no errors occurs
 *    GCM_INVALID_PROFILE_HANDLE if the profile handle is invalid or not open yet.
 *    GCM_TAG_DOES_NOT_EXIST if the tag doens't exist
 */
extern int16 gcmConfigDeleteParameter(profileHandle_t profileHandle, TlvTypeEle *tag);

extern void gcmConfigStatus(void);

extern int16 gcmConfigCreateBaseProfile(profileHandle_t *profileHandle, char *baseName);

/**
 * @}
 */

#endif

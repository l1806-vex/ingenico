/*******************************************************************************
                              Property of INGENICO
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Generic Communications Module
 *  FILENAME       :    gcmTags.h
 *  PURPOSE        :    GCM Tag List
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  07/04/04     CDL        Initial Version
 *  13/04/04     CDL        Updated due to V1.2 of GCM Specification &API
 *  18/05/04     CHH        Added RX_BUFFER_SIZE_TAG and TX_BUFFER_SIZE_TAG.
 *                          Corected X25HOST_IP_TAG.
 *  27/05/04     CDL        Added tags concerning modulation setup
 *  02/06/04     CDL        Change tags that were incorrectly allocated constructed
 *                          values.
 *  03/06/04     CHH        X25HOST_IP_TAG incorrectly allocated constructed value.
 * 
 *  RELEASE 1.01
 *  08/07/04     CHH        Added on and off character tags. Removed unused tags.
 *  11/08/04     CHH        Added channel enumeration
 * 
 *  RELEASE 1.10
 *  12/08/04     CHH        Added Modem Line Test and in use and disconnected 
 *                          threshold tags.
 *  26/08/04     CHH        Error in PABX and ALPHA_PHONE_TAG.
 *
 *  RELEASE 1.40
 *  01/10/04     CHH        Added tags to support Ethernet.
 *                          Removed unused tags.
 * 
 *  RELEASE 1.21
 *  03/11/04     CHH        Add ring number tag.
 *  
 *  NEXT RELEASE
 *  25/11/04     CHH        Add socket listen tag.
 * -----------------------------------------------------------------------------
 *  DESCRIPTION    :    
-*/

#ifndef GCMTAGS_H
#define GCMTAGS_H

/** \addtogroup profTags  profile tags
 *
 * 
 * 
 *  @{
 */

// TAG DEFINITIONS

#define PROFILE_TAG  "\xFF\x01"
#define CHANNEL_TAG  "\xFF\x01\xDF\x42"
#define VERSION_TAG  "\xFF\x01\xDF\x43"

#define UART_TAG         "\xFF\x01\xFF\x02"
#define BAUD_TAG         "\xFF\x01\xFF\x02\xDF\x44"
#define PARITY_TAG       "\xFF\x01\xFF\x02\xDF\x03"
#define DATASIZE_TAG     "\xFF\x01\xFF\x02\xDF\x04"
#define STOPBITS_TAG     "\xFF\x01\xFF\x02\xDF\x05"
#define FLOW_CONTROL_TAG "\xFF\x01\xFF\x02\xDF\x06"
#define CHAR_TIMEOUT_TAG "\xFF\x01\xFF\x02\xDF\x07"
#define RX_BUFFER_SIZE_TAG "\xFF\x01\xFF\x02\xDF\x45"
#define TX_BUFFER_SIZE_TAG "\xFF\x01\xFF\x02\xDF\x46"
#define XON_CHAR_TAG     "\xFF\x01\xFF\x02\xDF\x50"
#define XOFF_CHAR_TAG    "\xFF\x01\xFF\x02\xDF\x51"

#define ETHERNET_TAG				"\xFF\x01\xFF\x0C"
#define LOCAL_IP_ADDR_TAG			"\xFF\x01\xFF\x0C\xDF\x01"
#define SUB_NET_MASK_TAG			"\xFF\x01\xFF\x0C\xDF\x02"
#define BROADCAST_IP_ADDR_TAG		"\xFF\x01\xFF\x0C\xDF\x03"
#define ETHER_MTU_TAG				"\xFF\x01\xFF\x0C\xDF\x04"

#define IP_TTL_TAG					"\xFF\x01\xFF\x0C\xDF\x05"
#define IP_TOS_TAG					"\xFF\x01\xFF\x0C\xDF\x06"
#define IP_FORWARD_TAG				"\xFF\x01\xFF\x0C\xDF\x07"
#define IP_SEND_REDIRECT_TAG		"\xFF\x01\xFF\x0C\xDF\x08"
#define IP_FRAG_TIMEOUT_TAG			"\xFF\x01\xFF\x0C\xDF\x09"
#define IP_DEFAULT_ROUTE_TAG		"\xFF\x01\xFF\x0C\xDF\x10"
#define IP_ROUTE_ADD_TAG			"\xFF\x01\xFF\x0C\xDF\x11"
#define IP_ROUTE_DELETE_TAG			"\xFF\x01\xFF\x0C\xDF\x12"

#define SOCKET_FAMILY_TAG			"\xFF\x01\xFF\x0C\xDF\x13"
#define SOCKET_PORT_TAG				"\xFF\x01\xFF\x0C\xDF\x14"
#define SOCKET_ADDRESS_TAG 			"\xFF\x01\xFF\x0C\xDF\x15"
#define SOCKET_NAME_TAG				"\xFF\x01\xFF\x0C\xDF\x16"
#define SOCKET_TYPE_TAG				"\xFF\x01\xFF\x0C\xDF\x17"
#define SOCKET_PROTOCOL_TAG			"\xFF\x01\xFF\x0C\xDF\x18"
#define SOCKET_LISTEN_TAG			"\xFF\x01\xFF\x0C\xDF\x49"

#define DHCP_TIMER_SELECT_TAG		"\xFF\x01\xFF\x0C\xDF\x19"
#define DHCP_MODE_TAG				"\xFF\x01\xFF\x0C\xDF\x1A"
#define DHCP_SERVER_IP_ADDR_TAG		"\xFF\x01\xFF\x0C\xDF\x1B"
#define DHCP_CLIENT_IP_ADDR_TAG		"\xFF\x01\xFF\x0C\xDF\x1C"
#define DHCP_T1_TAG					"\xFF\x01\xFF\x0C\xDF\x1D"
#define DHCP_T2_TAG					"\xFF\x01\xFF\x0C\xDF\x1E"
#define DHCP_LEASE_TAG				"\xFF\x01\xFF\x0C\xDF\x1F"
#define DHCP_RANDOM_SEED_TAG		"\xFF\x01\xFF\x0C\xDF\x40"

#define DNS1_IP_ADDR_TAG			"\xFF\x01\xFF\x0C\xDF\x41"
#define DNS1_PORT_NUMBER_TAG		"\xFF\x01\xFF\x0C\xDF\x42"
#define DNS2_IP_ADDR_TAG			"\xFF\x01\xFF\x0C\xDF\x43"
#define DNS2_PORT_NUMBER_TAG		"\xFF\x01\xFF\x0C\xDF\x44"
#define DNS_DOMAIN_NAME_TAG			"\xFF\x01\xFF\x0C\xDF\x45"
#define DNS_TIMEOUT_TAG				"\xFF\x01\xFF\x0C\xDF\x46"
#define DNS_MAX_RETRIES_TAG			"\xFF\x01\xFF\x0C\xDF\x47"
#define DNS_MAX_SWITCHES_TAG		"\xFF\x01\xFF\x0C\xDF\x48"

#define MODEM_TAG        "\xFF\x01\xFF\x0E"
#define MODULATION_TAG   "\xFF\x01\xFF\x0E\xDF\x0F"
#define ERROR_CORR_TAG   "\xFF\x01\xFF\x0E\xDF\x10"
#define DATA_COMP_TAG    "\xFF\x01\xFF\x0E\xDF\x11"
#define CMD_MODE_TAG     "\xFF\x01\xFF\x0E\xDF\x12"
#define HANGMAN_MODE_TAG "\xFF\x01\xFF\x0E\xDF\x13"
#define FLOW_MODE_TAG    "\xFF\x01\xFF\x0E\xDF\x14"
#define DCD_MODE_TAG     "\xFF\x01\xFF\x0E\xDF\x15"
#define LINE_USE_TAG     "\xFF\x01\xFF\x0E\xDF\x16"
#define BLIND_DIAL_TAG   "\xFF\x01\xFF\x0E\xDF\x17"
#define V80_MODE_TAG     "\xFF\x01\xFF\x0E\xDF\x18"
#define FAST_CONNECT_TAG "\xFF\x01\xFF\x0E\xDF\x19"
#define RING_MODE_TAG    "\xFF\x01\xFF\x0E\xDF\x1A"
#define DIAL_MODE_TAG    "\xFF\x01\xFF\x0E\xDF\x1B"
#define CALL_MODE_TAG    "\xFF\x01\xFF\x0E\xDF\x1C"
#define MODEM_RFU_TAG    "\xFF\x01\xFF\x0E\xDF\x1D"
#define MIN_BPS_TAG      "\xFF\x01\xFF\x0E\xDF\x47"
#define MAX_BPS_TAG      "\xFF\x01\xFF\x0E\xDF\x48"
#define MIN_BPSTX_TAG    "\xFF\x01\xFF\x0E\xDF\x49"
#define MAX_BPSTX_TAG    "\xFF\x01\xFF\x0E\xDF\x4A"
#define LINE_TEST_TAG               "\xFF\x01\xFF\x0E\xDF\x4B"
#define IN_USE_THRESHOLD_TAG        "\xFF\x01\xFF\x0E\xDF\x4C"
#define DISCONNECTED_THRESHOLD_TAG  "\xFF\x01\xFF\x0E\xDF\x4D"
#define RING_NUMBER_TAG  "\xFF\x01\xFF\x0E\xDF\x4E"

#define POTS_TAG         "\xFF\x01\xFF\x1E"
#define PABX_TAG         "\xFF\x01\xFF\x1E\xDF\x1F"
#define ALPHA_PHONE      "\xFF\x01\xFF\x1E\xDF\x51"

/**
 * @}
 */

#endif


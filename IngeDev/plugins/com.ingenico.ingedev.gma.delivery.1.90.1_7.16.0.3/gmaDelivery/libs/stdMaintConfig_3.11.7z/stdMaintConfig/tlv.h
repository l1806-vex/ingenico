/*******************************************************************************
                              Property of INGENICO 
							  Copyright 2004
 ******************************************************************************/
/*+
 *  PROJECT        :    MILLENNIUM SOFTWARE
 *  MODULE         :    Standard TLV library
 *  FILENAME       :    tlv.h
 *  PURPOSE        :    Manipulation of TLVs
 *
 *  HISTORY
 *
$Log: tlv.h,v $
Revision 1.1  2007/03/07 17:52:09  rbelli
SMF

Revision 1.1  2005/07/04 16:55:42  rbelli
*** empty log message ***

Revision 1.1  2005/04/28 15:42:21  rbelli
*** empty log message ***

Revision 1.3  2004/05/26 10:50:15  clobodzinski
#undef FREE

Revision 1.2  2004/05/25 15:31:24  chunter
Change WIN32 conditional compilation to _GCM_WIN32

Revision 1.1  2004/05/25 13:33:16  chunter
Integrate with channel manager

Revision 1.4  2004/05/20 13:55:55  dalexander
Tidy up.

Revision 1.3  2004/05/20 08:14:59  dalexander
Slight rearrangement to improve legibility.

Revision 1.1  2004/04/06 13:44:55  da
Initial creation

Revision 1.2  2004/05/18 08:34:21  chunter
Latest version of TLV code

Revision 1.2  2004/05/07 10:47:34  dalexander
Memory usage reduction.
Introduction of Merge Tree.
Fix compilation problems.

 *
 * -----------------------------------------------------------------------------
 *  DESCRIPTION    :    Parse, manipulate and serialise TLV style messages. 
-*/
#ifndef _TLV_H
#define _TLV_H
#ifdef _GCM_WIN32
typedef unsigned short uint16;
typedef unsigned char uint8;
typedef signed char sint8;
typedef unsigned char Boolean;
#define NULL 0
#define TRUE 1
#define FALSE 0

#define MALLOC(X) malloc(X)
#define FREE(X) free(X)

#else
typedef unsigned char Boolean;
#undef FREE
#define MALLOC(X) malloc(X)
#define FREE(X) free(X)
#endif

#define MAX_TLV_PATH_LENGTH 20
#define MAX_TLV_TAG_LENGTH 2

struct Tlv_s;

//Private pointers for supporting the tree structure
typedef struct TlvPrivate_s
{
  struct Tlv_s *head;
  struct Tlv_s *parent;
  struct Tlv_s *firstOff;
  struct Tlv_s *nextSib;
  struct Tlv_s *prevSib;
} TlvPrivate;
typedef TlvPrivate *pTlvPrivate;


typedef uint8 TlvTypeEle;
typedef TlvTypeEle TlvType[MAX_TLV_TAG_LENGTH];
typedef TlvTypeEle TlvTagPath[MAX_TLV_PATH_LENGTH];
typedef uint16 TlvLength;

typedef struct Tlv_s
{
  //The tag value at this level
  TlvType type;

  //The length of the value as in integer
  TlvLength length;

  // Used to store interim constructed tags as well as full tags.
  uint8 *value;

  // Used to store the inter-tlv links
  pTlvPrivate privateV;
} Tlv;

typedef Tlv *pTlv;

typedef struct TlvBuffer_s
{
  TlvLength maxLength;
  TlvLength currentLength;
  uint8 *buffer;
} TlvBuffer;

//******************************************************************************************
//** Conversion to and from string data
//******************************************************************************************
//Takes a string in buffer and parses it - generating a tree
extern pTlv tlvParseBuffer(pTlv buffer, TlvLength length, uint8 *value);
// Note: buffer may be NULL in which case a tree is generated and its head returned

//Takes a string with a TLV element and parses it
extern pTlv tlvParse(pTlv tree);

//Recursively interrogate a TLV tree and generate the string into a buffer and returns
//a pointer to that buffer.
extern pTlv tlvGenerate(pTlv tree);

//******************************************************************************************
//** Manipulation functions
//******************************************************************************************
//Adds a new element with the given data at the location of the full path
//It creates interim constructed tags if necessary.
extern pTlv tlvUpdate(pTlv current, TlvTypeEle *newTag, TlvLength newLength, uint8 *tlvValue);

//Creates a new empty TLV element (use tlvChange to fill)
extern pTlv tlvBufferNew(void);

//Recusively delete the element and all sub-elements (frees memory)
extern Boolean tlvDelete(pTlv element);

//Change the contents of a TLV element (re-mallocs for longer data)
extern Boolean tlvChange(pTlv old, TlvLength newLength, uint8 *newValue);

//Merge two TLV trees together (using pointers)
extern Boolean tlvMergePtr(pTlv base, pTlv addition);

//Merge two TLV trees together (using paths)
extern Boolean tlvMergePath(pTlv base, uint8 *basePath, pTlv addition, uint8 *additionPath);

//Locates a TLV with the path indicated by tlvFind
extern pTlv tlvFind(pTlv tree, uint8 *tagPath);

//Adds a new element with the given data at the level below the 'current' element
extern pTlv tlvAddOffspring(pTlv current, TlvTypeEle *newTag, TlvLength newLength, uint8 *tlvValue);

//Adds a new element with the given data at the same level as the 'current' element
extern pTlv tlvAddSibling(pTlv current, TlvTypeEle *newTag, TlvLength newLength, uint8 *tlvValue);


//******************************************************************************************
//** Manual traversal functions
//******************************************************************************************
//Returns a pointer to the head of the tree containing a given element
extern pTlv tlvHead(pTlv tree);

//Returns the element of the TLV tree one level of nesting up from the given element
extern pTlv tlvParent(pTlv tlv);

//Returns the first element of the TLV tree one level of nesting down from the given element
extern pTlv tlvFirstOffspring(pTlv tlv);

//Returns the next element on the same level of the TLV tree as the given element 
extern pTlv tlvNextSib(pTlv tlv);

//Returns the next element on the same level of the TLV tree as the given element 
extern pTlv tlvPrevSib(pTlv tlv);

#endif

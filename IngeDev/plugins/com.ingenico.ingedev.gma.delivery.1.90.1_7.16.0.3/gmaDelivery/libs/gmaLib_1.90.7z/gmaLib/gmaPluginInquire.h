
#ifndef GMA_PLUGIN_INQUIRE_H_INCLUDED
#define GMA_PLUGIN_INQUIRE_H_INCLUDED

#include "gmaStructures.h"

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_PLUGIN_INQUIRE_MAX_MESSAGE_SIZE (100)

#define GMA_PG_INQ_PHY_TYPE_APP_ID (0)
#define GMA_PG_INQ_PHY_TYPE_INDEX  (1)
#define GMA_PG_INQ_PHY_TYPE_TASKID (2)
#define GMA_PG_INQ_PHY_TYPE_PID    (3)
#define GMA_PG_INQ_PHY_TYPE_NAME   (4)

typedef struct gmaPgInqPhyAppInq_st gmaPgInqPhyAppInq_t;

struct gmaPgInqPhyAppInq_st{
   uint16 dataType; // 0-> for appId, 1-> for index, 2-> taskId, 3-> for PID and 4-> for name
   uint16 rfu;
   union{
      uint16 appId;
      uint8  index;
      uint32 taskId;
      uint16 PID;
      char name[16]; // app name
   }param;
};

#define GMA_PG_INQ_LOG_TYPE_APPLOGID     (0)
#define GMA_PG_INQ_LOG_TYPE_LOGICAL_NAME (1)
#define GMA_PG_INQ_LOG_TYPE_INDEX        (2)

typedef struct gmaPgInqLogAppInq_st gmaPgInqLogAppInq_t;

struct gmaPgInqLogAppInq_st{
   uint16 inqTypr; // 0-> appId and logicalId, 1-> logicalName or 2-> index
   union{
      struct{
         uint16 appId;
         uint16 logicalId;
      }appId;
      char logicalName[16];
      uint8 index;
   }param;
};

/**
 * Open a session to inquire the GMA
 *
 * @param handle a pointer to receive the handle for this session
 */
int16 gmaPgInqOpen(uint32 *handle, uint8 pluginId);

/**
 * Open the inquire session
 *
 * @param handle the previous open handle
 */
int16 gmaPgInqClose(uint32 handle);

/**
 * Will return the number of seconds to the next event
 *
 * @param handle the inquire session handle (\ref gmaPgInqOpen)
 *
 * @param seconds a pointer to a uint32 that will receive the number
 *        of seconds to the next event
 */
int16 gmaPgInqGetNextEvtTime(uint32 handle, uint32 *seconds);

/**
 * Return an entry in the physical application list
 * 
 * @param handle the inquire session handle (\ref gmaPgInqOpen)
 * 
 * @param inq the inquire data
 * 
 * @param answer the physical application entry if found
 * 
 * @return RET_OK the physical entry was found
 * 
 */
int16 gmaPgInqPhyAppInquire(uint32 handle, gmaPgInqPhyAppInq_t *inq, 
                            gmaAppListPhysicalData_t *answer);

/**
 * Return an entry in the logical application list
 * 
 * @param handle the inquire session handle (\ref gmaPgInqOpen)
 * 
 * @param inq the inquire data
 * 
 * @param answer the logical application entry if found
 * 
 * @return RET_OK the logical entry was found
 * 
 */
int16 gmaPgInqLogAppInquire(uint32 handle, gmaPgInqLogAppInq_t *inq, 
                            gmaAppListLogicalData_t *answer);


/**
 * Get the answers to a broadcast request. The answers valid are gmaStructReturnCode_t;
 * 
 * @param handle the inquire session handle (\ref gmaPgInqOpen)
 * 
 * @param answers a pointer to a vector of int16 that will receive the answers
 * from the broadcast message. There will be an entry in this vector for each physical 
 * application in the terminal.
 * 
 * @param length a pointer to receive the number of items in the answers vector.
 *  
 */
int16 gmaPgInqGetBroadcastReturns(uint32 handle, int16 *answers, uint16 *length);


#ifdef __cplusplus
}
#endif


#endif


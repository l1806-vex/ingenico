
#ifndef GMA_PLUGIN_EXTERN_SUPPORT_H_INCLUDED
#define GMA_PLUGIN_EXTERN_SUPPORT_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**  
 * @file gmaPluginExtSup.h
 * GMA Plugin external support
 * This module provide the support for external plugins.
 *
 */

/**
 * Entry point of the external plugin mannager
 * Should be called  after install the plugins using the
 * function \ref gmaPGAddPlugin. This function will never
 * return.
 */
void gmaPGExtMain(void);

#ifdef __cplusplus
}
#endif


#endif

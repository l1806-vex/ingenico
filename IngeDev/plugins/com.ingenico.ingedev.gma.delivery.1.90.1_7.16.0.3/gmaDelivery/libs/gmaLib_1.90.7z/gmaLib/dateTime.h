
#ifndef DATE_TIME_H_INCLUDED
#define DATE_TIME_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define TerminalDATEC(yy,mm,dd) ((((uint32)yy) << 16) + (((uint32)mm) << 8) +((uint32)dd))
#define TerminalTIMEC(hh,mm,ss) TerminalDATEC(hh,mm,ss) 

/** @file dateTime.h
 * Date functions
 *
 * Functions to help the calculation with time and date.
 */

/**
 * Check for a valid unicapt32 date
 * 
 * @param date the date to be checked
 * 
 * @return RET_OK valid date
 * @return -1 invalid date
 */
int16 dateTimeCheckDate(uint32 date);

/**
 * Check for a valid unicapt32 time
 * 
 * @param time the time to be checked
 * 
 * @return RET_OK valid time
 * @return -1 invalid time
 */
int16 dateTimeCheckTime(uint32 time);

/**
 * Calculate the Julian day of a date in Unicapt format
 *
 * @param date date in Unicapt format
 *
 * @param julianDay a pointer to the Julian Day
 *
 * @return RET_OK no error
 * @return -1 invalid date format
 */
int dateTimeCalcJulian(uint32 date, uint32 *julianDay);

/**
 * Calculate the data in Unicapt format from a Julian day.
 * This function only works for julianday greater than
 * 1757583, 1/1/100. Julianday lower than this limit will
 * cause the function to return -1.
 *
 * @param date a pointer to a date in Unicapt format
 *
 * @param julianDay Julian Day
 *
 * @return RET_OK
 * @return -1 if the julianDay is invalid or out of
 * the work range. 
 */
int dateTimeCalcDate(uint32 julianDay, uint32 *date);

/**
 * Calculate the number of seconds since midnight
 *
 * @param terminalTime the time in Unicapt format
 *
 * @param nSec a pointer to receive the number of seconds since midnight
 * 
 * @return RET_OK no errors
 * @return -1 invalid terminalTime format
 */
int16 datetimeCalcSec(uint32 terminalTime, uint32 *nSec);

/**
 * add the number of seconds to the date and time parameters (for calculation
 * only). The number of seconds can be a positive value (calculate a new
 * date/time seconds after) or can be negative (calculate the new date/time 
 * seconds before).
 *
 * @param date a pointer to the date (Unicapt format), will be replaced with the
 * date added "seconds" seconds.
 * @param time a pointer to the time (Unicapt format), will be replaced with the
 * time added "seconds" seconds.
 *
 * @param seconds the number of seconds to be added to the date and time parameters.
 *
 * @return RET_OK 
 * @return -1 invalid format of the date or the time
 */
int16 datetimeAddSeconds(uint32 *date, uint32 *time, int32 seconds);

/**
 * Calculate the number of seconds between two dates
 *
 * @param startDate the start date in unicapt format
 * @param startTime the start time in unicapt format
 * @param endDate the end date in unicapt format
 * @param endTime the end time in unicapt format
 *
 * @return the number of seconds between the two dates
 * @return 0 if the format of the date or the time is wrong.
 */
int64 datetimeCalcDiffSec(uint32 startDate, uint32 startTime, uint32 endDate, uint32 endTime);

#ifdef __cplusplus
}
#endif


#endif

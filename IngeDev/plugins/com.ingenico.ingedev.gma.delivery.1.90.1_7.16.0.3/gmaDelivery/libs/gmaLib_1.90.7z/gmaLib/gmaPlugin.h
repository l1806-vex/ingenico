/**
 * 
 * plugin (functions the GMA call)
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */
#ifndef GMA_PLUGIN_H_INCLUDED
#define GMA_PLUGIN_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


/**
 * Called to set the application ID
 */
int16 gmaPGSetAppId(uint16 appId);

/**
 * called before the GMA start to send the power on
 */
int16 gmaPGinitialize(void);

/**
 * Entry point to treat the message and prepare the answer
 */
int16 gmaPGtreatMessage(amgMsg_t *msgReceive, amgMsg_t *msgSend);

/**
 * call the plugins to make requests to the peripherals
 *
 * @param perIds a pointer to a uint32 with the ids of the peripherals
 *        where the requests were made.
 */
int16 gmaPGRequests(uint32 *perIds);

/**
 * call the plugins to treat the answer to the psyPeripheralResultWait
 * function
 *
 * @param the return of the function psyPeripheralResultWait
 */
int16 gmaPGResults(int32 ret);

/**
 * Entry point to treat messages from the application
 */
int16 gmaPGtreatApplicationsMsg(uint8 *msg, uint16 length, uint32 appQueueId, uint32 pgQueueId);

/**
 * 
 */
int16 gmaPGSendMsgApp(uint32 appQueueId, uint32 pgQueueId, uint8 msgType, uint16 appId,
                      uint8 logicalId, uint8 *msg, uint16 length);

#ifdef __cplusplus
}
#endif


#endif

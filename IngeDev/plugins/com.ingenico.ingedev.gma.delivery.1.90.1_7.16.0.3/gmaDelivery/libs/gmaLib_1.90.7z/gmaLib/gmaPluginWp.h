/**
 * 
 * plugin wrapper (functions the plugin can call)
 *
 * GMA PROJECT
 *
 * Author: Roberto Belli
 *
 * Data: 01/11/2005
 */

#ifndef GMA_PLUGIN_WRAPPER_H_INCLUDED
#define GMA_PLUGIN_WRAPPER_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_PLUGIN_MAX_NUMBER_PG (10)

#define GMA_PLUGIN_ERR_NO_SPACE (-1)
#define GMA_PLUGIN_ERR_MSG_TO_BIG (-2)


/**  
 * @file GmaPluginWp.h
 * GMA Plugin Wrapper
 *
 */

typedef int16 (*gmaPgCallBackWarn)(uint8 logicalId);
typedef int16 (*gmaPgCallBackMsg)(amgMsg_t *msg);
typedef int16 (*gmaPgCallBackMsgFrAp)(uint16 appId, uint8 *msgRec, uint16 msgRecLength, 
                                      uint8 *msgBack, uint16 *msgBackLength);
typedef int16 (*gmaPGCallBackRequests)(uint32 *perIds);
typedef int16 (*gmaPGCallBackResults)(int32 ret);


/**
 * plugin Callbacks 
 */
typedef struct gmaPgCallBacks_st gmaPgCallBacks_t;

/**
 * plugin Callbacks 
 */
struct gmaPgCallBacks_st
{
   /**
    * callback called when the wrapper begins
    */
   gmaPgCallBackWarn     initCB; 
   /**
    * callback called when the plugin receives a power On
    */
   gmaPgCallBackMsg      powerOn; 
   /**
    * //!< callback called when the plugin receives a integrity check message
    */
   gmaPgCallBackMsg      integrityCheck; 
   /**
    * callback called when the plugin receives a startup message
    */
   gmaPgCallBackMsg      startup;
   /**
    * callback called when the plugin receives an AMG message from the GMA that
    * is not one of the above messages
    */
   gmaPgCallBackMsg      gmaMsgs;
   /**
    * callback called when the plugin receives a message from an application.
    */
   gmaPgCallBackMsgFrAp  appMsg;
   /**
    * callback for the plugins make assynchronous requests.
    */
   gmaPGCallBackRequests requests;
   /**
    * callback called after the the function psyPeripheralResultWait returns. 
    * The return value is passed to the callback.
    */
   gmaPGCallBackResults  results;   
};


/**
 * add a new plugin. This function will register the callback function
 * in the wrapper. See the description of the callback function in 
 * \ref gmaPgCallBacks_st
 *
 * @param cbs callbacks that will be called by the wrapper
 */
int16 gmaPGAddPlugin(const gmaPgCallBacks_t *cbs);


/**
 * Function that send a message to the GMA.
 * This is a one way message. The plugin send
 * the message and the GMA will not answer it.
 * will only execute the contents order.
 */
int16 gmaPGSendMsgToGma(uint8 pluginId, const uint8 *msg, uint16 msgLength);

/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * schedule an event or delete a previous scheduled event.
 * 
 * @param pluginId the Id of the plugin that is calling this function
 * @param date the date where to schedule the event
 * @param time the time where to schedule the event
 * @param eventId the Id of the event to be scheduled
 * @param eventAction what to do:
 *      - GMA_EVENT_ACTION_ADD: add this event
 *      - GMA_EVENT_ACTION_DEL: delete this event
 *      - GMA_EVENT_ACTION_DEL_ALL: delete all events scheduled by this plugin

 */
int16 gmaPGSendScheduleEvent(uint8 pluginId, uint32 date, uint32 time, uint16 eventId,
                             uint8 eventAction);

/**
 * Send a display alert message to the GMA.
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param alertLevel ...
 * @param text the text to be displayed in the alert message
 */
int16 gmaPGSendDisplayAlertMsg(uint8 pluginId, uint8 alertLevel, const char *text);

/**
 * Send a MediaData message to GMA using the \ref gmaPGSendMsgToGma
 * @param pluginId the Id of the plugin that is calling this function
 * @param mediaId the id of this media data
 * @param mediaType the type of this media data, one of the 
 *      GMA_MEDIA_MONO_BITMAP, GMA_MEDIA_TEXT, GMA_MEDIA_DELETE.....
 * @param data a pointer to the media data
 * @param size the length of the media data
 */
int16 gmaPGSendMediaDataMsg(uint8 pluginId, uint8 mediaId, uint16 mediaType, const uint8 *data, uint16 size);

/**
 * Send the media position message to GMA using the \ref gmaPGSendMsgToGma
 * 
 * @param pluginId the Id of the plugin that is calling this function
 * @param mediaId the ID of the media data to set the position
 * @param active if the media data will be show or not (GMA_MEDIA_HIDDEN or GMA_MEDIA_VISIBLE)
 * @param xPos the x position of the image
 * @param yPos the y position of the image
 */
int16 gmaPGSendMediaPosMsg(uint8 pluginId, uint8 mediaId, uint16 active,
                           uint16 xPos, uint16 yPos);

/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * change the configuration of the keys
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param key the code of the key to have its behaviour change
 * @param action what the key will do:
 *          GMA_KEY_ACTION_DEFAULT  - the default behaviour (send a query message and then an event message).
 *          GMA_KEY_ACTION_FUNCTION - the action will depend on the parameter:
 *                     - GMA_KEY_FUNC_MENU: will show the applications menu
 *                     - GMA_KEY_FUNC_PAPER_FEED: will do the printer paper feed
 *                     - GMA_KEY_FUNC_TECHNICAL: will show the technical menu (plugins menu)
 *          GMA_KEY_ACTION_NOTIFY   - will send a notification message to this plugin
 * @param parameter the parameter for the action choose, see above.
 */
int16 gmaPGSendKeyboardConfigMsg(uint8 pluginId, uint8 key, uint8 action, uint8 parameter);


/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * ask the GMA to send a Notify me message to this plugin.
 * One use of this function is when the plugin wants to gain the control of
 * the terminal.
 * 
 * @param pluginId the Id of the plugin that is calling this function
 */
int16 gmaPGSendNotifyMeMsg(uint8 pluginId);

/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * ask the GMA to send a Notify me message to this plugin.
 * One use of this function is when the plugin wants to gain the control of
 * the terminal.
 * 
 * @param pluginId the Id of the plugin that is calling this function
 * @param notifType if 0-> the notification will work as in the function 
 * \ref gmaPGSendNotifyMeMsg. if 1 -> the GMA will send the notification to
 * the plugin without close the handles.
 * @param notifParam parameter that will be sent in the GMA_STRUCT_PG_NOTIFICATION_TYPE message in the 
 * field notificationParam.
 * 
 */
int16 gmaPGSendNotifyMeMsgExt(uint8 pluginId, uint16 notifType, uint8 notifParam);

/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * ask the GMA to send a broadcast message 
 * (a message to all the application in the terminal).
 * A good plugin behaviour is only call this function when the plugin
 * has the control of the terminal. Call this function as the last thing before
 * return the control to the GMA.
 * The plugin can call the function \ref gmaPGSendNotifyMeMsg
 * to get the control of the terminal.
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param msgLength the size of the message to be sent
 * @param msg a pointer to the message to be sent
 * @param msgType the msg type to be sent
 */
int16 gmaPGSendBroadcastMsg(uint8 pluginId, uint16 msgLength, const uint8 *msg, uint16 msgType);

/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * ask the GMA to send a broadcast message 
 * (a message to all the application in the terminal).
 * A good plugin behaviour is only call this function when the plugin
 * has the control of the terminal. Call this function as the last thing before
 * return the control to the GMA.
 * The plugin can call the function \ref gmaPGSendNotifyMeMsg
 * to get the control of the terminal.
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param type one of the following values:
 * - \ref GMA_PG_BROADCAST_TYPE_NOCHECK Don't check the answer of the applications
 * for the broadcast messages.
 * - \ref GMA_PG_BROADCAST_TYPE_CHECKANSWER Check the message answer of the applications
 * replies for the broadcast message. Check the \ref gmaStructReturnCode_t present
 * in the reply message. The plug-in than will use the \ref GMA_PG_INQUIRE_BROADCAST_ANSWER
 * inquire to get information from the application answers.
 * 
 * @param msgLength the size of the message to be sent
 * @param msg a pointer to the message to be sent
 * @param msgType the msg type to be sent
 */
int16 gmaPGSendBroadcastMsgExt(uint8 pluginId, uint8 type, uint16 msgLength, const uint8 *msg, uint16 msgType);


/**
 * Send a message to GMA using the \ref gmaPGSendMsgToGma to
 * ask the GMA to a menu item in the the technical function menu
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param action the action to be performed when this menu item is selected
 *        - GMA_PG_MENU_ACTION_NOTIFY : send a notify message to the plugin
 *        - GMA_PG_MENU_ACTION_EDIT   : show a edit menu, see the \ref gmaPGSendEditResource
 * @param parameter if the action is GMA_PG_MENU_ACTION_EDIT the lower 8 bits represents
 *        the id of the editResource.
 * @param itemId the id of the menu item
 * @param caption the caption of the menu item
 */
int16 gmaPGSendMenuItem(uint8 pluginId, uint8 action, uint32 parameter,
                        uint8 itemId, const char *caption);

/**
 * Send a edit resource message to the GMA using the \ref gmaPGSendMsgToGma.
 * Define the edit resource to be executed when a menu with
 * action GMA_PG_MENU_ACTION_EDIT is selected.
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param itemId the id of this edit resource
 * @param caption the caption of this edit menu
 * @param mask the edit mask (see the editlib library)
 * @param minLength the minimum length of the edited text 
 */
int16 gmaPGSendEditResource(uint8 pluginId, uint8 itemId, const char *caption,
                             const char *mask, uint8 minLength);

/**
 * Send an transaction message to the applications.
 * A good plugin behaviour is only call the function when it has the control 
 * of the terminal and only call this function as the last thing before 
 * give back the control to the GMA.
 * The plugin can call the function \ref gmaPGSendNotifyMeMsg.
 *
 * @param pluginId the Id of the plugin that is calling this function
 * @param transType transaction type, one of the: GMA_TRANS_XXXX constants
 * @param selectionType Selection type. Can be \ref GMA_SELECTION_MENU, \ref GMA_SELECTION_QUERY or 
 *        \ref GMA_SELECTION_NONE.
 * @param appId application Id if GMA_SELECTION_NONE
 * @param logicalId application Id if GMA_SELECTION_NONE
 * @param data a pointer to a buffer that contain a 
 *        structure to be added after the structure GMA_STRUCT_TRANS_TYPE.
 * @param dataSize the size of the data buffer size
 */
int16 gmaPGSendTransactionReq(uint8 pluginId, uint8 transType, uint8 selectionType,
                              uint16 appId, uint8 logicalId, const uint8 *data, uint16 dataSize);

/**
 * Set in the GMA if the plug-in support HMI handle transfer or not.
 * 
 * @param pluginId the Id of the plugin that is calling this function
 * 
 * @param status if 0 the plug-in don't support HMI handle transfer. If 1 the plug-in support.
 */
int16 gmaPGSendHmiTransferSup(uint8 pluginId, uint8 status);

/**
 * Structure used to set the display configuration to the gma custom.
 */
typedef struct gmaPgStructDispConfigData_st gmaPgStructDispConfigData_t;

/**
 * Structure used to set the display configuration to the gma custom.
 */
struct gmaPgStructDispConfigData_st
{
   /**
    * type of configuration.
    * \ref GMA_PG_DISP_CONFIG_BACKLIGHT or \ref GMA_PG_DISP_CONFIG_BEEP.
    */
   uint16 configItem;
   uint16 rfu;
   union{

      /**
       * used when configType == GMA_PG_DISP_CONFIG_BACKLIGHT
       */
      struct{
         uint8 status; //!< 0 - backlight on || 1 - backlight off
         uint8 rfu;
         uint16 timeOut; //!< timeout in seconds. The time the backlight remain turned on.
      }backLight;
      
      /**
       * used when configType == GMA_PG_DISP_CONFIG_BEEP
       */
      struct{
         uint8 status; //!< 1 - beep on || 0 - beep off
         uint8 rfu;
         uint16 rfu2;
      }beep;
   }config;
};

/**
 * Send display configuration to the GMA custom.
 * \param pluginId the Id of the plugin that is calling this function.
 * \param data a pointer to the configuration data.
 */
int16 gmaPgSendDispConfiguration(uint8 pluginId, gmaPgStructDispConfigData_t *data);

#ifdef __cplusplus
}
#endif

 
#endif



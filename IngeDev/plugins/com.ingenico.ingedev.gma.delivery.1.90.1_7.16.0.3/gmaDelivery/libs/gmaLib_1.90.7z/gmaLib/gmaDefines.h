/*
 * General Definitions and Types for Idle
 *
 * Unicapt32 - Idle Application
 * Ingenico Latin America
 */

#ifndef IDLE_DEFINES_H
#define IDLE_DEFINES_H

#ifdef __cplusplus
extern "C" {
#endif

/** @file gmaDefines.h
 * gma defines
 *
 */

/**
 * Message types and structure for messages from Idle to applications and
 * their expected replies.
 */


/* base for Idle messages */
#define GMA_MSG_BASE                  (0x100) /*!< base value for GMA application messages*/
#define GMA_MSG_PLUGIN_BASE           (0x200) /*!< base value for GMA plugin messages*/

/* boot messages */   
/**
 * Instead of this message type for the power on value, it is used the
 * MSG_POWER_ON value because of the amgSynchroProcess function.
 *
 * In this message the GMA sends the struct \ref GMA_STRUCT_MASTER_VERSION.
 *
 * The GMA waits in the answer the struct \ref GMA_STRUCT_PHYSICAL_APP_INFO and a 
 * \ref GMA_STRUCT_LOGICAL_APP_INFO for each logical application.
 */
#define GMA_MSG_POWER_ON              (GMA_MSG_BASE + 1)

/**
Integrity check message type.

In this message the GMA sends no structs (the data field is empty)

The GMA waits in the answer the struct \ref GMA_STRUCT_LOGICAL_APP_STATUS.
*/
#define GMA_MSG_INIT_INTEGRITY_CHECK  (GMA_MSG_BASE + 2) 

/**
startup message type

In this message the GMA sends a struct \ref GMA_STRUCT_PLUGIN_INFO for each plugin in the terminal

The GMA doesn't wait for any struct in the reply. 
*/
#define GMA_MSG_STARTUP               (GMA_MSG_BASE + 3)

/* transaction messages */
/**
 * Transaction message type. This message is received by an application.
 * The application that receives this message needs to treat this transaction
 * event. The data field of this message is composed by the struct 
 * \ref GMA_STRUCT_TRANS_TYPE and one more struct depending of the event type.
 */
#define GMA_MSG_TRANSACTION           (GMA_MSG_BASE + 4) 
/**
 * Transaction query message type. This message is sent to all the applications when a query
 * is needed. Each application will answer this message sending the acceptance level for this 
 * application. The data field of this message is the same as in the \ref GMA_MSG_TRANSACTION.
 */
#define GMA_MSG_TRANSACTION_QUERY     (GMA_MSG_BASE + 5)

/* other application messages */
#define  GMA_MSG_EVENT_SCHEDULING     (GMA_MSG_BASE + 6)

#define  GMA_MSG_EVENT_OCCUR          (GMA_MSG_BASE + 7) /*!< Message send to the application when an event occurs */
#define  GMA_MSG_APP_STATUS_UPDATE    (GMA_MSG_BASE + 8) 
#define  GMA_MSG_MNT                  (GMA_MSG_BASE + 9) /*!< message send to all application to warn about a maintenance session*/
#define  GMA_MSG_DATE_TIME            (GMA_MSG_BASE + 10)
#define  GMA_MSG_CURRENCY_RETRIEVAL   (GMA_MSG_BASE + 11)
#define  GMA_MSG_PRINT_INFORMATION    (GMA_MSG_BASE + 12)
#define  GMA_MSG_POWER_LEVEL          (GMA_MSG_BASE + 13) /*!< Message sent to all application indicating if the terminal will shut down or enter in sleep mode*/
#define  GMA_MSG_COMM_PLUGIN_REQ      (GMA_MSG_BASE + 14) //!< request a communication with a plugin

/* plug-ins specific messages */
#define  GMA_MSG_PG_ACTIVITY          (GMA_MSG_PLUGIN_BASE + 0) //!< warn a plugin to a change in the activity of the terminal
#define  GMA_MSG_PG_MENU_SELECTION    (GMA_MSG_PLUGIN_BASE + 1) //!< Message sent to the plugin when a menu item is selected
#define  GMA_MSG_PG_SET_CONFIG        (GMA_MSG_PLUGIN_BASE + 2) //!< Message sent to the plugin when a edition in a edit resource is made
#define  GMA_MSG_PG_NOTIFY            (GMA_MSG_PLUGIN_BASE + 3) //!< Notification message sent to the plugin

/* master/applications structures */
#define GMA_STRUCT_BASE                      (0)
#define GMA_STRUCT_EMPTY                     (GMA_STRUCT_BASE + 0) //!< id of the empty struct
#define GMA_STRUCT_MASTER_VERSION            (GMA_STRUCT_BASE + 1) //!< id of the structure that holds the master version \ref gmaStructMasterVersion_t
#define GMA_STRUCT_PHYSICAL_APP_INFO         (GMA_STRUCT_BASE + 2) //!< id of the structure with the physical app info \ref gmaStructPhysicalAppInfo_t
#define GMA_STRUCT_LOGICAL_APP_INFO          (GMA_STRUCT_BASE + 3) //!< id of the structure with the logical app info \ref gmaStructLogicalAppInfo_t
#define GMA_STRUCT_LOGICAL_APP_STATUS        (GMA_STRUCT_BASE + 4) //!< id of the structure with the logical app status \ref gmaStructLogicAppStatus_t
#define GMA_STRUCT_TRANS_TYPE                (GMA_STRUCT_BASE + 5) //!< id of the structure with the transaction type \ref gmaStructTransType_t
#define GMA_STRUCT_TRANS_SMART_CARD          (GMA_STRUCT_BASE + 6) //!< id of the structure with the smart card transaction data \ref gmaStructTransSmartCard_t
#define GMA_STRUCT_TRANS_SMC_ATR             (GMA_STRUCT_BASE + 7) //!< id of the structure with specific smart card transaction data \ref gmaStructTransSmcAtr_t
#define GMA_STRUCT_TRANS_SMC_EMV             (GMA_STRUCT_BASE + 8) //!< id of the structure with specific smart card transaction data \ref gmaStructTransSmcEmv_t
#define GMA_STRUCT_TRANS_PAYMENT_INFO        (GMA_STRUCT_BASE + 9) //!< id of the structure with the payment info \ref gmaStructTransPaymentInfo_t
#define GMA_STRUCT_TRANS_MAG_CARD            (GMA_STRUCT_BASE + 10) //!< id of the structure with the magnetic card transaction info \ref gmaStructTransMagCard_t
#define GMA_STRUCT_TRANS_MAG_TRACK           (GMA_STRUCT_BASE + 11) //!< id of the structure with the magnetic track data \ref gmaStructTransMagTrack_t
#define GMA_STRUCT_TRANS_KEY_PRESSED         (GMA_STRUCT_BASE + 12) //!< id of the structure with the key transaction data \ref gmaStructTransKeyPressed_t
#define GMA_STRUCT_TRANS_MENU                (GMA_STRUCT_BASE + 13) //!< id of the structure with the menu transaction data \ref gmaStructTransMenu_t
#define GMA_STRUCT_RETURN_CODE               (GMA_STRUCT_BASE + 14) //!< id of the structure with the return code \ref gmaStructReturnCode_t
#define GMA_STRUCT_QUERY_RESULT              (GMA_STRUCT_BASE + 15) //!< id of the structure with the query result \ref gmaStructQueryResult_t
#define GMA_STRUCT_EVENT_OCCUR               (GMA_STRUCT_BASE + 16) //!< id of the structure with the event occur data \ref gmaStructEventOccur_t
#define GMA_STRUCT_MNT_INFO                  (GMA_STRUCT_BASE + 17) //!< id of the structure with the maintenance info data \ref gmaStructMntInfo_t
#define GMA_STRUCT_DATE_TIME                 (GMA_STRUCT_BASE + 18) ////!< id of the structure with the date/time data
#define GMA_STRUCT_DISPLAY_INFO              (GMA_STRUCT_BASE + 19) ////!< id of the structure with display info data
#define GMA_STRUCT_POWER_LEVEL               (GMA_STRUCT_BASE + 20) //!< id of the structure with power level data \ref gmaStructPowerLevel_t
#define GMA_STRUCT_SCHEDULED_EVENT_INFO      (GMA_STRUCT_BASE + 21) //!< id of the structure with schedule event info \ref gmaStructScheduledEventInfo_t
#define GMA_STRUCT_TEXT_DISPLAY              (GMA_STRUCT_BASE + 22) ///!< id of the structure with text display info
#define GMA_STRUCT_MEDIA_DATA                (GMA_STRUCT_BASE + 23) //!< id of the structure with the media data \ref gmaStructMediaData_t
#define GMA_STRUCT_MEDIA_FILE                (GMA_STRUCT_BASE + 24) // id of the structure with media file info \ref gmaStructMediaFile_t
#define GMA_STRUCT_MEDIA_RESOURCE            (GMA_STRUCT_BASE + 25) // id of the structure with media resource \ref gmaStructMediaResource_t
#define GMA_STRUCT_MEDIA_POSITION            (GMA_STRUCT_BASE + 26) //!< id of the structure with media position \ref gmaStructMediaPosition_t
#define GMA_STRUCT_EMV_AID                   (GMA_STRUCT_BASE + 27) //!< id of the structure with EMV AID info \ref gmaStructEmvAid_t
#define GMA_STRUCT_CURRENCY                  (GMA_STRUCT_BASE + 28) //!< id of the structure with currency info \ref gmaStructCurrency_t
#define GMA_STRUCT_TRANS_ADM_FUNC            (GMA_STRUCT_BASE + 29) //!< id of the structure with adm. func. transaction info \ref gmaStructTransAdmFunc_t
#define GMA_STRUCT_PLUGIN_INFO               (GMA_STRUCT_BASE + 30) //!< id of the structure with plugin info \ref gmaStructPluginInfo_t
#define GMA_STRUCT_COMM_PLUGIN               (GMA_STRUCT_BASE + 31) //!< id of the structure with request for comm. with plugin info. \ref gmaStructCommPlugin_t
#define GMA_STRUCT_TRANSFER_HMI              (GMA_STRUCT_BASE + 32) //!< if of the structure used to send the hmi handle. \ref gmaStructTransferHmi_t
#define GMA_STRUCT_TRANSFER_HMI_SUP          (GMA_STRUCT_BASE + 33) //!< if of the structure used to inform the GMA if the application support hmi transfer. \ref gmaStructTransferHmiSup_t
#define GMA_STRUCT_APP_INFO                  (GMA_STRUCT_BASE + 34) //!< used in the power on to send application information to the applications
#define GMA_STRUCT_EMV_AID_DEL               (GMA_STRUCT_BASE + 35) //!< id of the structure \ref gmaStructEmvAidDel_t.
#define GMA_STRUCT_CONFIG_INFO               (GMA_STRUCT_BASE + 36) //!< id of the structure \ref gmaStructConfigInfo_t.
#define GMA_STRUCT_EMV_FALLBACK              (GMA_STRUCT_BASE + 37) //!< id of the structure \ref gmaStructEmvFallback_t
#define GMA_STRUCT_SMC_SELECTION_MODE        (GMA_STRUCT_BASE + 38) //!< id of the structure \ref gmaStructSmcSelectionMode_t.


/* plug-ins specific structures */
#define GMA_STRUCT_PG_BASE                   (0x1000)
#define GMA_STRUCT_PG_INFO                   (GMA_STRUCT_PG_BASE + 0) //!< id of the structure with plugin info \ref gmaStructPGInfo_t
#define GMA_STRUCT_PG_QUEUE_ID               (GMA_STRUCT_PG_BASE + 1) //!< id of the structure with queue info \ref gmaStructPGQueueId_t
#define GMA_STRUCT_PG_ACTIVITY_INFO          (GMA_STRUCT_PG_BASE + 2) //!< id of the structure with activity info \ref gmaStructPGActivityInfo_t
#define GMA_STRUCT_PG_SET_CONFIG             (GMA_STRUCT_PG_BASE + 3) //!< id of the structure with edit config info \ref gmaStructPGSetConfig_t
#define GMA_STRUCT_PG_ERROR_MESSAGE          (GMA_STRUCT_PG_BASE + 4) ////!< id of the structure with error message
#define GMA_STRUCT_PG_ALERT_MESSAGE          (GMA_STRUCT_PG_BASE + 5) ////!< id of the structure with alert message \ref gmaStructPGAlertMessage_t
#define GMA_STRUCT_PG_KEYBOARD_CFG           (GMA_STRUCT_PG_BASE + 6) //!< id of the structure with keyboard config info \ref gmaStructPGKeyboardCfg_t
#define GMA_STRUCT_PG_NOTIFICATION_TYPE      (GMA_STRUCT_PG_BASE + 7) //!< id of the structure with notification info \ref gmaStructPGNotificationType_t
#define GMA_STRUCT_PG_BROADCAST              (GMA_STRUCT_PG_BASE + 8) //!< id of the structure with broadcast request info \ref gmaStructPGBroadcast_t
#define GMA_STRUCT_PG_IDENTIFY               (GMA_STRUCT_PG_BASE + 9) //!< id of the structure used in the message sent to GMA \ref gmaStructPGIdentify_t
#define GMA_STRUCT_PG_NOTIFY_ME              (GMA_STRUCT_PG_BASE + 10) //!< id of the structure with the notify me request info \ref gmaStructPGNotifyMe_t
#define GMA_STRUCT_PG_MENU_ITEM              (GMA_STRUCT_PG_BASE + 11) //!< id of the structure with the menu item data \ref gmaStructPGMenuItem_t
#define GMA_STRUCT_PG_EDIT_RESOURCE          (GMA_STRUCT_PG_BASE + 12) //!< id of the structure with the edit resource data \ref gmaStructPGSetConfig_t
#define GMA_STRUCT_PG_EXT_INFO               (GMA_STRUCT_PG_BASE + 13) //!< id of the structure with the plugin extended info \ref gmaStructPgExtInfo_t
#define GMA_STRUCT_PG_TRANSACTION_REQ        (GMA_STRUCT_PG_BASE + 14) //!< id of the structure with the Transaction request \ref gmaStructPGTransactionReq_t
#define GMA_STRUCT_PG_INQUIRE_GMA            (GMA_STRUCT_PG_BASE + 15) //!< id of the structure with the Inquire requested \ref gmaStructPGInquireGma_t
#define GMA_STRUCT_PG_INQUIRE_ANSWER         (GMA_STRUCT_PG_BASE + 16) //!< id of the structure with the Inquire answer \ref gmaStructPGInquireAnswer_t
#define GMA_STRUCT_PG_NOTIFY_ME_EXT          (GMA_STRUCT_PG_BASE + 17) //!< id of the structure with the Inquire answer \ref gmaStructPGNotifyMeExt_t
#define GMA_STRUCT_PG_DISP_CONFIG            (GMA_STRUCT_PG_BASE + 18) //!< id of the structure with the display configuration \ref gmaStructPGDispConfig_t
#define GMA_STRUCT_PG_CUSTOM_STATE           (GMA_STRUCT_PG_BASE + 19) //!< id of the structure that permits for a plug-in disable the GMA custom c
/**
 * id of the structure that tell the GMA to return directly to the
 * GMA without continues to show the menus. Used for example
 * when a plugin receives a notification menu message,
 * and want when return from the treatment to go directly to the
 * GMA screen instead of shown the menu again.
 * This structure doesn't has a definition as only the presence of
 * the structure is the information.
 */
#define GMA_STRUCT_PG_BACK_GMA               (GMA_STRUCT_PG_BASE + 19) 

/* transactions events type */
/*#define GMA_EVENT_BASE                       (0x00)
#define GMA_EVENT_SMART_CARD                 (GMA_EVENT_BASE + 0x01)
#define GMA_EVENT_MAG_CARD                   (GMA_EVENT_BASE + 0x02)
#define GMA_EVENT_KEYBOARD                   (GMA_EVENT_BASE + 0x03)
#define GMA_EVENT_MENU                       (GMA_EVENT_BASE + 0x04)
#define GMA_EVENT_ECR                        (GMA_EVENT_BASE + 0x05)
#define GMA_EVENT_CHECK                      (GMA_EVENT_BASE + 0x06)
#define GMA_EVENT_USER                       (GMA_EVENT_BASE + 0x07)*/

/* actions for event scheduling */
#define GMA_EVENT_ACTION_ADD                 (0) //!< add a schedule event
#define GMA_EVENT_ACTION_DEL                 (1) //!< delete a schedule event
#define GMA_EVENT_ACTION_DEL_ALL             (2) //!< delete all schedule events from an application or plugin
#define GMA_EVENT_ACTION_REPEAT              (3)

/* application types */
#define GMA_USER_APPLICATION                 (1) //!< an user application
#define GMA_PLUGIN_APPLICATION               (2) //!< a plugin application

#define GMA_APPLICATION_TYPE_ERROR           (0xFF)

/* accept levels */
#define GMA_ACCEPTLEVEL_NO_ACCEPT            (0x00) //!< application don't treat this transaction
#define GMA_ACCEPTLEVEL_LOW                  (0x40) //!< application treat this transaction with a low accept level
#define GMA_ACCEPTLEVEL_MEDIUM               (0x80) //!< application treat this transaction with a medium accept level
#define GMA_ACCEPTLEVEL_HIGH                 (0xFF) //!< application treat this transaction with a high accept level

/* transactions defines */
#define GMA_TRANS_KEY_PRESSED          (0) //!< a key pressed transaction
#define GMA_TRANS_MAG_CARD             (1) //!< a magnetic card transaction
#define GMA_TRANS_SMART_CARD           (2) //!< a smart card transaction
#define GMA_TRANS_MENU                 (3) //!< a menu select transaction
#define GMA_TRANS_ADM_FUNC             (4) //!< a admin select transaction

/* general defines */
#define GMA_MAX_ATR_LENGTH             (32)
#define GMA_MAX_CARD_RESPONSE_LENGTH   (258)
#define GMA_MAX_TRACK_SIZE             (128)
#define GMA_MAX_PRESSED_KEYS           (60)

/* magCards defines */
#define GMA_MAX_SIZE_CARD_TRACKS       (255)
#define GMA_MAG_TRACK_ISO              (1)
#define GMA_MAG_TRACK_ISOJIS           (2)
#define GMA_MAG_TRACK_AAMVA            (3)
#define GMA_MAG_TRACK_CDL              (4)
#define GMA_MAG_TRACK_MANUAL           (5)

/* ACTIVITY STATUS*/
#define GMA_PG_ACTIVITY_MARK           (0)
#define GMA_PG_ACTIVITY_START          (1) //!< activity START, the terminal leaves the idle state
#define GMA_PG_ACTIVITY_END            (2) //!< activity END, the terminal returns to the idle state
#define GMA_PG_APP_START               (3) //!< application START, the terminal leaves the idle state
#define GMA_PG_APP_END                 (4) //!< application END, the terminal returns the idle state

/* Notification types */
#define GMA_NOTIFICATION_KEY_PRESS     (0) //!< a key configured by a plugin is pressed
#define GMA_NOTIFICATION_MENU          (1) //!< a menu item assigned by a plugin is selected
#define GMA_NOTIFICATION_SIGNAL        (2) //!< send when a plugin ask for a notification message
#define GMA_NOTIFICATION_WARN          (3) //!< send when a plugin ask for a notification message, but in this case the GMA doesn't close the handles

/* SMC defines */
#define GMA_SMART_CARD_SYNCHRONOUS     (0) //!< synchronous smart card
#define GMA_SMART_CARD_ASYNCHRONOUS    (1) //!< assynchronous smart card
#define GMA_SMART_CARD_UNKNOWN         (2) //!< unknown smart card

#define GMA_SMC_DEVICE_DISABLE         (0)  //!< disable SMC reader
#define GMA_SMC_DEVICE_ENABLE          (1)  //!< enable SMC reader with normal behavior

#define GMA_SELECTION_CARD_INSERTED    (0) //!< a smart card is inserted, the field card type is ignored when the info type has this value.
#define GMA_SELECTION_NOT_DONE         (1)
#define GMA_SELECTION_DONE             (2) //!< a smart card is inserted and the application selection was done by the GMA

/* other defines */

#define GMA_MAG_SELECTION_NONE         (0) /*!< No selection */
#define GMA_MAG_SELECTION_MENU         (1) /*!< Selection done by menu */
#define GMA_MAG_SELECTION_QUERY        (2) /*!< Selection done by Query message */

#define GMA_SMC_SELECTION_NONE         (GMA_MAG_SELECTION_NONE) /*!< see the \ref GMA_MAG_SELECTION_NONE*/
#define GMA_SMC_SELECTION_MENU         (GMA_MAG_SELECTION_MENU) /*!< see the \ref GMA_MAG_SELECTION_MENU*/
#define GMA_SMC_SELECTION_QUERY        (GMA_MAG_SELECTION_QUERY)/*!< see the \ref GMA_MAG_SELECTION_QUERY*/

#define GMA_KEY_ACTION_DEFAULT         (0) //!< Key Action default
/**
 * the key action is a Function, one of the \ref GMA_KEY_FUNC_PAPER_FEED,
 * \ref GMA_KEY_FUNC_MENU or \ref GMA_KEY_FUNC_TECHNICAL.
 */
#define GMA_KEY_ACTION_FUNCTION        (1) 
/**
 * The key action is send a notify message to the plugin
 */
#define GMA_KEY_ACTION_NOTIFY          (2)
/**
 * Execute no action
 */
#define GMA_KEY_ACTION_NONE            (3)


#define GMA_KEY_FUNC_PAPER_FEED        (0) //!< paper feed in the printer
#define GMA_KEY_FUNC_MENU              (1) //!< call the application menu
#define GMA_KEY_FUNC_TECHNICAL         (2) //!< call the technical menu (plugin menu)

/* Maintenance defines */
#define GMA_MNT_ACTION_AUTH            (0) //!< Maintenance Authorization request
#define GMA_MNT_ACTION_START           (1) //!< Maintenance Start
#define GMA_MNT_ACTION_DONE            (2) //!< Maintenance's finished successfuly
#define GMA_MNT_ACTION_NOT_DONE        (3) //!< Maintenance's finished with errors

/* Power Level defines */
#define GMA_POWER_OFF                  (0) //!< POR will shut down the terminal
/**
 * The terminal will enter in sleep mode (not because of LOW battery,
 * this name is because of historic reasons). All terminals with the
 * settings plug-in can enter in sleep mode.
 */
#define GMA_POWER_LOW_BATTERY          (1) 
#define GMA_POWER_RESTORE              (2) //!< Notify when got out from sleep mode

/* MEDIA DEFINES */
#define GMA_MEDIA_HIDDEN               (0) //!< media data hidden
#define GMA_MEDIA_VISIBLE              (1) //!< media data visible

#define GMA_MEDIA_MONO_BITMAP          (0) //!< mono bitmap media type
#define GMA_MEDIA_TEXT                 (1) //!< normal text media type
#define GMA_MEDIA_COLOR_BITMAP         (2) //!< color bitmap media type
#define GMA_MEDIA_DELETE               (0xFFFF) //!< delete the media data

#define GMA_MEDIA_COMP_NONE            (0) //!< no compression used in the media data
#define GMA_MEDIA_COMP_RLE             (1) //!< RLE compression used in the media data

#define GMA_PG_MENU_ACTION_NOTIFY      (0) //!< plugin menu item assigned to send a notify message
#define GMA_PG_MENU_ACTION_EDIT        (1) //!< plugin menu item assigned to call an edit resource

/*
 * Selection types for gmaStructPGTransactionReq_t struct 
 */
#define GMA_SELECTION_MENU             (0) //!< Selection by menu
#define GMA_SELECTION_QUERY            (1) //!< Selection by Query message
#define GMA_SELECTION_NONE             (2) //!< No Selection, specific applications to be wake up.

/**
 * used in the type field of the structure \ref gmaStructPGBroadcast_t
 * to indicate that the answer to the broadcast message is not important
 */
#define GMA_PG_BROADCAST_TYPE_NOCHECK     (0)

/**
 * used in the type field of the structure \ref gmaStructPGBroadcast_t
 * to indicate that the answer to the broadcast message IS important.
 * In this case the applications should answer to the broadcast using the 
 * structure \ref gmaStructReturnCode_t. And then the plug-in should 
 * make a inquire to see the result (\ref GMA_PG_INQUIRE_BROADCAST_ANSWER).
 */
#define GMA_PG_BROADCAST_TYPE_CHECKANSWER (1)

/*
 *
 */
#define GMA_PG_INQUIRE_NEXT_EVENT_SEC  (1) /*!< Inquire the number of seconds to the next 
                                                scheduled event. No parameters in the inquire message. */

/**
 * Inquire an entry in the physical application list.
 * The plugin can ask an application by its appID, index,
 * taskId, PID or name.
 * The inquire message has 2 fields:
 * struct{
 *    uint16 dataType // 0-> for appId, 1-> for index, 2-> taskId, 3-> for PID and 4-> for name
 *    uint16 rfu;
 *    union{
 *       uint16 appId;
 *       uint8  index;
 *       uint32 taskId;
 *       uint16 PID;
 *       char name[16]; // app name
 *    };
 * }
 * 
 * The answer will have the struct gmaAppListPhysicalData_t defined in
 * the file appList.h (gmaCore).
 */
#define GMA_PG_INQUIRE_PHYSICAL_APP    (2) 

/**
 * Inquire an entry in the logical application list.
 * The inquire message has 3 fields
 * struct{
 *    uint16 inqTypr; // 0-> appId and logicalId, 1-> logicalName or 2-> index
 *    union{
 *       struct{
 *          uint16 appId;
 *          uint16 logicalId;
 *       }
 *       char logicalName[16];
 *       uint8 index;
 *    }
 * }
 * 
 * The answer will have the structure gmaAppListLogicalData_t defined in
 * the file appList.h (gmaCore).
 */
#define GMA_PG_INQUIRE_LOGICAL_APP     (3)

/**
 * TODO:
 */
#define GMA_PG_INQUIRE_BROADCAST_ANSWER (4)

/**
 * Send the configuration for backlight in the structure \ref gmaStructPGDispConfig_t.
 * The configData in this case will have the following structure:\n
 * uint8 backlightStatus; -> 0 turn off or 1 turn on\n
 * uint8 rfu;
 * uint16 backlightTimeout;
 * 
 */
#define GMA_PG_DISP_CONFIG_BACKLIGHT (1)

/**
 * Send the configuration for Beep in the structure \ref gmaStructPGDispConfig_t.
 * The configData in this case will have the following structure:\n
 * uint8 beepOnOff; 0 for beep off and 1 for beep on. \n
 * uint8 rfu1;\n
 * uint16 rfu2;\n
 */
#define GMA_PG_DISP_CONFIG_BEEP      (2)


/**
 * header for any GMA structure 
 */ 
typedef struct gmaStructHeader_s gmaStructHeader_t;
/**
 * header for any GMA structure 
 */ 
struct gmaStructHeader_s
{
   uint32  id;     /*!< id of the structure */
   uint16  length; /*!< length of the structure */
   uint8   logicalApp; /*!< logical id of destination, not used when the message is to the GMA*/
   uint8   rfu;
};

/**
 * structure with type \ref GMA_STRUCT_MASTER_VERSION
 * sent from GMA to applications during power-on
 */
typedef struct gmaStructMasterVersion_s gmaStructMasterVersion_t;

/**
 * structure with type \ref GMA_STRUCT_MASTER_VERSION
 * sent from GMA to applications during power-on
 */
struct gmaStructMasterVersion_s
{
   gmaStructHeader_t header;         /*!< header */
   uint16            implVersion;    /*!< GMA implementation version */
   uint16            specVersion;    /*!< GMA spec version */
};

/**
 * structure with type \ref GMA_STRUCT_PHYSICAL_APP_INFO with the
 * information about a physical U32 application
 */ 
typedef struct gmaStructPhysicalAppInfo_s gmaStructPhysicalAppInfo_t;
/**
 * structure with type \ref GMA_STRUCT_PHYSICAL_APP_INFO with the
 * information about a physical U32 application
 */ 
struct gmaStructPhysicalAppInfo_s
{
   gmaStructHeader_t header;           /*!< header*/
   int16             retCode;          /*!< RET_OK or error code */
   uint16            phyVersion;       /*!< application version */
   char              phyName[16 + 1];  /*!< application name */
   uint8             applicationType;  /*!< type of application, \ref GMA_USER_APPLICATION or \ref GMA_PLUGIN_APPLICATION*/
   uint16            rfu;
};

/**
 * structure with type \ref GMA_STRUCT_RETURN_CODE.
 * generic reply about a transaction or other operation
 */
typedef struct gmaStructReturnCode_s gmaStructReturnCode_t;
/**
 * structure with type \ref GMA_STRUCT_RETURN_CODE.
 * generic reply about a transaction or other operation
 */
struct gmaStructReturnCode_s 
{
   gmaStructHeader_t header;           /*!< header*/
   int16             retCode;          /*!< return code, OK-> RET_OK */
   uint16            rfu;
};


/**
 * structure with type \ref GMA_STRUCT_LOGICAL_APP_INFO
 * logical application info
 */ 
typedef struct gmaStructLogicalAppInfo_s gmaStructLogicalAppInfo_t;
/**
 * structure with type \ref GMA_STRUCT_LOGICAL_APP_INFO
 * logical application info
 */ 
struct gmaStructLogicalAppInfo_s
{
   gmaStructHeader_t header;           /*!< header*/
   uint8             logicalId;            /*!< logical application ID. Can be a value in the range [0,254]. 255 means "all logical applications of the physical application. */
   char              logicalName[16 + 1];  /*!< name of the logical application*/
   uint16            rfu;
};


/**
 * structure with type \ref GMA_STRUCT_LOGICAL_APP_STATUS 
 * status of a logical application
 */
typedef struct gmaStructLogicAppStatus_s gmaStructLogicAppStatus_t;
/**
 * structure with type \ref GMA_STRUCT_LOGICAL_APP_STATUS 
 * status of a logical application
 */
struct gmaStructLogicAppStatus_s
{
   gmaStructHeader_t header;           /*!< header */
   uint8             logId;            /*!< logical app id */
   uint8             logState;         /*!< logical app state. 0 for OK. 1 for error.*/
   uint16            rfu;
};


/**
 * structure with type \ref GMA_STRUCT_CURRENCY
 * currency information for an application 
 */ 
typedef struct gmaStructCurrency_s gmaStructCurrency_t;
/**
 * structure with type \ref GMA_STRUCT_CURRENCY
 * currency information for an application 
 */ 
struct gmaStructCurrency_s
{
   gmaStructHeader_t header;           /*!< header */
   uint8             logId;            /*!< logical application id */
   uint8             curExponent;      /*!< exponent */
   uint16            curNumCode;       /*!< numeric code in BCD format */
   uint8             curAlphaNumCode[3 + 1]; /*!< alphanumeric code (ISO4217) */
};


/**
 * structure with type \ref GMA_STRUCT_TRANS_SMART_CARD
 * smart card event information
 */ 
typedef struct gmaStructTransSmartCard_s gmaStructTransSmartCard_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_SMART_CARD
 * smart card event information
 */ 
struct gmaStructTransSmartCard_s
{
   gmaStructHeader_t header;           /*!< header */
   uint8             cardType;         /*!< The currently supported types of smart card are: \n
											GMA_SMART_CARD_SYNCHRONOUS \n
											GMA_SMART_CARD_ASYNCHRONOUS */				   
   uint8             infoType;        /*!< The currently supported values for infoType: \n
											GMA_SELECTION_CARD_INSERTED \n
											GMA_SELECTION_NOT_DONE \n
											GMA_SELECTION_DONE */
   uint16            rfu;
   
};


/**
 * structure with type \ref GMA_STRUCT_TRANS_SMC_ATR
 * information about a non-EMV smart card
 */ 
typedef struct gmaStructTransSmcAtr_s gmaStructTransSmcAtr_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_SMC_ATR
 * information about a non-EMV smart card
 */ 
struct gmaStructTransSmcAtr_s
{
   gmaStructHeader_t header;           /*!< header */
   uint16            atrLength;        /*!< length of ATR received on poweron */
   uint8             atrValue[GMA_MAX_ATR_LENGTH]; /*!< ATR contents */
   uint16            rfu;
};


/**
 * structure with type \ref GMA_STRUCT_TRANS_SMC_EMV
 * information about an EMV smart card
 */ 
typedef struct gmaStructTransSmcEmv_s gmaStructTransSmcEmv_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_SMC_EMV
 * information about an EMV smart card
 */ 
struct gmaStructTransSmcEmv_s 
{
   gmaStructHeader_t header;          /*!< header */
   uint16            responseLength;  /*!< length of smart card response */
   uint8             response[GMA_MAX_CARD_RESPONSE_LENGTH]; /*!< SMC response */
};

/**
 * structure with type \ref GMA_STRUCT_TRANS_PAYMENT_INFO
 * Optional transaction information
 */ 
typedef struct gmaStructTransPaymentInfo_s gmaStructTransPaymentInfo_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_PAYMENT_INFO
 * Optional transaction information
 */ 
struct gmaStructTransPaymentInfo_s
{
   gmaStructHeader_t header;           /*!< header */
   uint32            tmAmount;         /*!< transaction amount */
   uint16            tmCurrency;       /*!< current code -- ISO4217 */
   uint8             tmType;           /*!< type of transaction */
   uint8             rfu;
};


/**
 * structure with type \ref GMA_STRUCT_TRANS_MAG_CARD
 * magnetic card swipe event
 */ 
typedef struct gmaStructTransMagCard_s gmaStructTransMagCard_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_MAG_CARD
 * magnetic card swipe event
 */ 
struct gmaStructTransMagCard_s
{
   gmaStructHeader_t header; /*!< header */
   uint8             magType;  /*!< The following magnetic card types are currently defined: \n
										GMA_MAG_TRACK_ISO \n
										GMA_MAG_TRACK_ISOJIS \n
										GMA_MAG_TRACK_AAMVA \n
										GMA_MAG_TRACK_CDL  */
   uint8             selectionType; /*!< The following selection processes are possible: \n
											GMA_MAG_SELECTION_NONE: no selection was done (possibly this is the only application in the terminal); \n
											GMA_MAG_SELECTION_MENU: the user selected this application from a menu; \n
											GMA_MAG_SELECTION_QUERY: a query message was sent to all applications, this application was selected among them. \n\n
											In the case when a menu needs to be used after a round of query messages, the selection type should be GMA_SELECTION_QUERY. */
   uint16            rfu;
};

/**
 * structure with type \ref GMA_STRUCT_TRANS_MAG_TRACK
 * Magnetic card track data. One structure per track.
 */ 
typedef struct gmaStructTransMagTrack_s gmaStructTransMagTrack_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_MAG_TRACK
 * Magnetic card track data. One structure per track.
 */ 
struct gmaStructTransMagTrack_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 trackNumber; /*!< number of the track */
   uint8 trackLength; /*!< track data length */
   uint8 magTrack[GMA_MAX_TRACK_SIZE]; /*!< track data */
   uint16 rfu;
};

/* keyboard event */
/**
 * structure with type \ref GMA_STRUCT_TRANS_KEY_PRESSED
 * key pressed event
 */ 
typedef struct gmaStructTransKeyPressed_s gmaStructTransKeyPressed_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_KEY_PRESSED
 * key pressed event
 */ 
struct gmaStructTransKeyPressed_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 keyCode; /*!< key pressed */
   uint8 rfu[3];
};

/* menu event */
/**
 * structure with type \ref GMA_STRUCT_TRANS_MENU
 * menu event
 */ 
typedef struct gmaStructTransMenu_s gmaStructTransMenu_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_MENU
 * menu event
 */ 
struct gmaStructTransMenu_s
{
   gmaStructHeader_t header;/*!< header */
   uint16 itemId; /*!< the Id of the menu item selected */
   uint16 rfu;
};

/* query return */
/**
 * structure with type \ref GMA_STRUCT_QUERY_RESULT
 * structure received by the GMA as a answer to the query message.
 */ 
typedef struct gmaStructQueryResult_s gmaStructQueryResult_t;
/**
 * structure with type \ref GMA_STRUCT_QUERY_RESULT
 * structure received by the GMA as a answer to the query message.
 */ 
struct gmaStructQueryResult_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;        /*!< logical application Id that answer */
   uint8 acceptationLevel; /*!< the acceptance level of this application to the actual transaction */
   uint16 rfu;
};


/**
 * structure with type \ref GMA_STRUCT_EVENT_OCCUR. 
 * Structure sent in the \ref GMA_MSG_EVENT_OCCUR message.
 * sent when an scheduled event occur
 */ 
typedef struct gmaStructEventOccur_s gmaStructEventOccur_t;
/**
 * structure with type \ref GMA_STRUCT_EVENT_OCCUR. 
 * Structure sent in the \ref GMA_MSG_EVENT_OCCUR message.
 * sent when an scheduled event occur
 */ 
struct gmaStructEventOccur_s
{
   gmaStructHeader_t header;   /*!< header */
   uint8 logicalId;            /*!< logical Id of the application that needs to treat the event */
   uint8 rfu; 
   uint16 eventId;             /*!< Identifier of the event */
};

/**
 * structure with type \ref GMA_STRUCT_MNT_INFO
 * Sent by the maintenance plugin to inform the maintenance progress
 */
typedef struct gmaStructMntInfo_s gmaStructMntInfo_t;
/**
 * structure with type \ref GMA_STRUCT_MNT_INFO
 * Sent by the maintenance plugin to inform the maintenance progress
 */
struct gmaStructMntInfo_s
{
   gmaStructHeader_t header;/*!< header */
   uint16 mntAction;        /*!< The possible maintenance actions are: \n
									GMA_MNT_ACTION_AUTH \n
									GMA_MNT_ACTION_START \n
									GMA_MNT_ACTION_DONE \n
									GMA_MNT_ACTION_NOT_DONE */
   /**
    * error code if the mntAction is GMA_MNT_ACTION_NOT_DONE. 0 means
    * that the maintenance is cancelled because one application didn't aprove it.
    */
   int16 errorCode;         
};

/**
 * structure with type \ref GMA_STRUCT_POWER_LEVEL 
 * indicating if the terminal will shut down or 
 * enter in low power mode (Sleep Mode).
 */ 
typedef struct gmaStructPowerLevel_s gmaStructPowerLevel_t;
/**
 * structure with type \ref GMA_STRUCT_POWER_LEVEL 
 * indicating if the terminal will shut down or enter
 * in low power mode (Sleep Mode).
 */ 
struct gmaStructPowerLevel_s
{
   gmaStructHeader_t header;/*!< header */
   /**indicating if the terminal will shut down or enter
    * in low power mode (Sleep Mode)
    * The possible maintenance actions are: \n
	* The indication field can be one of the following values: \n
	* GMA_POWER_OFF: The terminal will be shut down \n
	* GMA_POWER_LOW_BATTERY: The terminal will enter in sleep mode (not because of LOW battery, this name is because of historic reasons). All terminals with the settings plug-in can enter in sleep mode. \n
	* GMA_POWER_RESTORE: The terminal has wake up from the sleep mode. */
   uint16 indication;
   uint16 rfu;
};

/* scheduled event programming */
/**
 * structure with type \ref GMA_STRUCT_SCHEDULED_EVENT_INFO
 * this structure is used by the applications or by the plugins
 * to schedule an event
 */ 
typedef struct gmaStructScheduledEventInfo_s gmaStructScheduledEventInfo_t;
/**
 * structure with type \ref GMA_STRUCT_SCHEDULED_EVENT_INFO
 * this structure is used by the applications or by the plugins
 * to schedule an event.This event will never happen earlier than 
 * the scheduled date and time, but may happen later
 * (due to the system being shut off or kept busy by another application).
 */ 
struct gmaStructScheduledEventInfo_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;      /*!< logical id of the application that wants to schedule the event */
   uint8 eventAction;    /**< GMA_EVENT_ACTION_ADD:     add add a new scheduled event with the given date and time, if the date is 0xFFFFFFFF than the event will be scheduled to the next day if the actual time is grater than the schedule time or to the same day if not. \n
   						      GMA_EVENT_ACTION_DEL:     delete an existing event, for this logical ID, with same event ID. \n
   						      GMA_EVENT_ACTION_DEL_ALL: delete all events of this logical application. \n
   						      GMA_EVENT_ACTION_REPEAT:  add a new recurring event. In this case, the date and time fields define the delta between the occurrences. GMA should do proper date and time calculation. */
   uint16 eventId;       /*!< the event identifier */
   uint32 date;          /*!< the date to schedule the event, Unicapt format*/
   uint32 time;          /*!< the time to schedule the event, Unicapt format*/
};

/* send media data */
/**
 * structure with type \ref GMA_STRUCT_MEDIA_DATA
 * this structure is used to send a media data information.
 * bitmap or text to the GMA.
 */ 
typedef struct gmaStructMediaData_s gmaStructMediaData_t;
/**
 * structure with type \ref GMA_STRUCT_MEDIA_DATA
 * this structure is used to send a media data information.
 * bitmap or text to the GMA. A GMA implementation is allowed 
 * to handle this information according to its own rules, but 
 * usually any bitmap sent with this structure is displayed during idle-screen.
 * The mediaID is per-logical-application, so two logical applications can safely
 * use the same mediaID (and this is actually required for application logos).
 * For a logical application, the media information with mediaID of zero is reserved
 * to be the logo displayed during idle-screen. A logical application is allowed to 
 * change this logo at any moment that it could send a MEDIA_DATA structure. The handling
 * of any other mediaID is implementation dependant, and a GMA implementation is allowed to ignore them.
 * If the media is a bitmap, an application may also send a MEDIA_POSITION structure with the display
 * coordinates of the bitmap. By default all media is displayed at zero coordinates on the display, 
 * and set as not-shown (except for the application logo, see above).
 * It is important to remember that the mediaData field should be padded so its length is a multiple of 32-bits.
 */ 
struct gmaStructMediaData_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 mediaId;      /*!< the Identifier of the media data*/
   uint8 logicalId;    /*!< the logical application that is sending the media data*/
   uint16 mediaType;   /*!< GMA_MEDIA_MONO_BITMAP: an uncompressed black & white bitmap with 1 bit-per-pixel, see below for the exact formatting. \n
					        GMA_MEDIA_TEXT: ASCII text with some formatting information. This allows an application to use a text instead of a bitmap as logo, for example. \n
							GMA_MEDIA_DELETE: the media with this mediaID will not be used anymore and its memory can be freed. In this case the mediaData field should be zero length.	*/
   uint8  mediaData[4]; /*!< For GMA_MEDIA_MONO_BITMAP, the mediaData field is formatted as a very small header with image dimensions, one byte each, followed by the actual image data, with 8-pixels-per-byte, without any special separation between scan lines. In the image data a bit set (1) signals a black pixel, and a bit not set (0) signals a white pixel. \n\n
                            TYPE: uint8 \n
							NAME: imageWidth \n
							DESCRIPTION: Width of image in pixels \n
                            TYPE: uint8 \n
							NAME: imageHeight \n
							DESCRIPTION: Height of image in pixels \n
                            TYPE: uint8 \n
							NAME: imageData[N] \n
							DESCRIPTION: Actual data of image \n\n
                            Since the packing does not respect scan line boundaries, it is possible that two lines share the same byte. For example, if we have an image 4 pixels wide, with two pixels of height, it will use exactly 1 byte (padded by one more byte so the structure length is a multiple of 32-bits). \n \n
                            Example 1: a bitmap 4 pixels wide by 2 pixels high, all black pixels. \n
							In this case, mediaData is formatted as follows: \n
								1 byte image width (0x04) \n
								1 byte image height (0x02) \n
								1 byte image data (0xFF) \n \n
							Example 2: a bitmap 7 pixels wide by 3 pixels high, only the bottom rightmost pixel is black, all others are white. \n
                            In this case, mediaData is formatted as follows: \n
								1 byte image width (0x07) \n
								1 byte image height (0x03) \n
    							8 bytes image data (0x0000080000000000). The image has 21-bits of data (3x7), add the two bytes of header and we get 37-bits total, so we need to pad to 64-bits (8 bytes). This padding is ignored by GMA when reading the image. \n\n
                            For GMA_MEDIA_COLOR_BITMAP, the mediaData field is formatted as a small header with image dimensions, bits per pixel and if the image data uses a compression. \n\n
                            TYPE: uint8 \n
							NAME: imageWidth \n
							DESCRIPTION: Width of image in pixels \n
                            TYPE: uint8 \n
							NAME: imageHeight \n
							DESCRIPTION: Height of image in pixels \n
                            TYPE: uint8 \n
							NAME: imageDeep \n
							DESCRIPTION: Bits per pixel \n
                            TYPE: uint8 \n
							NAME: compression \n
							DESCRIPTION: If compression will be used \n
                            TYPE: uint8 \n
							NAME: imageData[N] \n
							DESCRIPTION: Actual data of image \n\n
							The compression field defines if the imageData is compressed or not. Actually only RLE compression is supported. If the value is 0 (GMA_MEDIA_COMP_NONE) no compression is used, if 1 (GMA_MEDIA_COMP_RLE) the RLE compression is used. \n
                            The imageDeep field value can be 4 or 8 bits per pixels. \n\n
                            For GMA_MEDIA_TEXT, the media data is formatted as a zero-terminated (C-like) string with embedded formatting tags. \n
                            The string must be padded to 32-bits. For example: a 2-char string "ab", plus its zero terminator will occupy 3 bytes total "ab\0"; this need to be padded to 32-bits (4 bytes). \n
                            The formatting tags follow the format "%<parameters><option>", much like the format used by the C sprintf function. In addition, some control characters, such as ASCII 0x0A (line feed, "\n") are supported. Below is a list of the supported commands and control characters and their effects: \n\n
                            OPTION/CNTRL CHAR: %. Insert the "%" character. Example: "100%% completed" \n
							OPTION/CNTRL CHAR: f. Set the font for the text. This should be the first tag in the text and only one should be present, tags not at the beginning of the text are ignored. The parameter for this tag is an integer value in decimal base with the number of the font use. \n\n
							The supported parameters are: \n
								1 for HMI_INTERNAL_FONT_1 \n
								2 for HMI_INTERNAL_FONT_2 \n
								And so forth, up to 5 \n\n
								Example: "%5fSmall Text!" \n
							OPTION/CNTRL CHAR: 0x0A. Line feed */
};

/*
 * structure with type \ref GMA_STRUCT_MEDIA_FILE 
 * send media date by file
 */ 
typedef struct gmaStructMediaFile_s gmaStructMediaFile_t;
/*
 * structure with type \ref GMA_STRUCT_MEDIA_FILE
 * send media date by file
 */ 
struct gmaStructMediaFile_s
{
   gmaStructHeader_t header; /*!< header */
   uint8 mediaId;
   uint8 logicalId;
   uint16 mediaType;
   char  mediaFileName[40];
};

/* media position */
/**
 * structure with type \ref GMA_STRUCT_MEDIA_POSITION
 * This structure is used to send the position of a media data item 
 */ 
typedef struct gmaStructMediaPosition_s gmaStructMediaPosition_t;
/**
 * structure with type \ref GMA_STRUCT_MEDIA_POSITION
 * This structure is used to send the position of a media data item, indexed by its ID.
 */ 
struct gmaStructMediaPosition_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 mediaId;    /*!<the identifier of the media data */
   uint8 logicalId;  /*!< the logical Id of the application*/
   uint16 xPosition; /*!< the x position where the media data will be drawed*/
   uint16 yPosition; /*!< the y position where the media data will be drawed*/
   uint16 active;    /*!< if the image is active: GMA_MEDIA_HIDDEN or GMA_MEDIA_VISIBLE */
};


/*
 * structure with type \ref GMA_STRUCT_MEDIA_RESOURCE
 * 
 */ 
typedef struct gmaStructMediaResource_s gmaStructMediaResource_t;
struct gmaStructMediaResource_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 mediaId;
   uint8 logicalId;
   uint16 mediaType;
   uint32 mediaResource;
};

/* EMV AID retrieval */
/**
 * structure with type \ref GMA_STRUCT_EMV_AID
 * Structure send by the application to the GMA.
 * This structure allows an application to associate an logical application with an EMV AID.
 */ 
typedef struct gmaStructEmvAid_s gmaStructEmvAid_t;
/**
 * structure with type \ref GMA_STRUCT_EMV_AID
 * Structure send by the application to the GMA.
 * This structure allows an application to associate an logical application with an EMV AID.
 */ 
struct gmaStructEmvAid_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalID;     /*!< Logical Application Identifier*/
   uint8 aidLength;     /*!< Length of AID */
   uint8 aidPriorityIndex; /*!< AID Priority Index */
   uint8 aidAppSelIndicator; /*!< AID Application Selection Indicator */
   uint8 aidName[16];  /*!< AID value */
};

/**
 * structure with type \ref GMA_STRUCT_TRANS_TYPE
 * This is the first structure send in the GMA_MSG_TRANSACTION or GMA_MSG_TRANSACTION_QUERY.
 * It has the information of which transaction happens
 */
typedef struct gmaStructTransType_s gmaStructTransType_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_TYPE
 * This is the first structure send in the GMA_MSG_TRANSACTION or GMA_MSG_TRANSACTION_QUERY.
 * It has the information of which transaction happens
 */
struct gmaStructTransType_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId; /*!< logical application identifier */
   uint8 transType; /*!< The following transaction types are defined: \n
							GMA_TRANS_KEY_PRESS \n
							GMA_TRANS_MAG_CARD \n
							GMA_TRANS_SMART_CARD \n
							GMA_TRANS_MENU \n
							GMA_TRANS_ADM_FUNC 	*/
   uint16 rfu;
};

/**
 * structure with type \ref GMA_STRUCT_TRANS_ADM_FUNC
 * Structure that follows the GMA_STRUCT_TRANS_TYPE when the transaction type is
 */
typedef struct gmaStructTransAdmFunc_s gmaStructTransAdmFunc_t;
/**
 * structure with type \ref GMA_STRUCT_TRANS_ADM_FUNC
 * Structure that follows the GMA_STRUCT_TRANS_TYPE when the transaction type is
 */
struct gmaStructTransAdmFunc_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 funcType; /*!< The function type field can be one of the following: \n
							GMA_ADM_FUNC_MERCHANT: a merchant function was selected, this is usually some function code that the merchant himself can select; \n
							GMA_ADM_FUNC_TECHNICAL: a technical function was selected, those usually require a special password and are only used by technical support staff. */
   uint8 funcId;   /*!< ID of administrative function */
   uint16 rfu;
};

/**
 * structure with type \ref GMA_STRUCT_PLUGIN_INFO
 * In the startup message it is sent one structure for each plugin to every applications
 * in the terminal. This structure contain the plugin information.
 */
typedef struct gmaStructPluginInfo_s gmaStructPluginInfo_t;
/**
 * structure with type \ref GMA_STRUCT_PLUGIN_INFO
 * In the startup message it is sent one structure for each plugin to every applications
 * in the terminal. This structure contain the plugin information.
 */
struct gmaStructPluginInfo_s 
{
   gmaStructHeader_t header;/*!< header */
   char   pluginName[16+1]; /*!< name of the plugin */
   uint8  rfu;             
   uint16 pluginVersion;    /*!< version of the plugin */
   uint32 pluginId;         /*!< id of the plugin */
};

/**
 * structure with type \ref GMA_STRUCT_COMM_PLUGIN
 * This structure is used to send the request from the application
 * to the GMA to start a communication channel with one plugin.
 */
typedef struct gmaStructCommPlugin_s gmaStructCommPlugin_t;
/**
 * structure with type \ref GMA_STRUCT_COMM_PLUGIN
 * This structure is used to send the request from the application
 * to the GMA to start a communication channel with one plugin.
 */
struct gmaStructCommPlugin_s 
{
   gmaStructHeader_t header;/*!< header */
   char pluginName[16+1]; /*!< the name of the plugin which we want to communicate */
   uint8 logicalId;       /*!< logical Id of the application that wants to communicate */
   uint16 physicalId;     /*!< physicalId of the application that wants to communicate */
   uint32 queueId;        /*!< queue Id created */
};

/**
 * Structure with type \ref GMA_STRUCT_TRANSFER_HMI.
 * This structure is used by the GMA to transfer the hmi handle to an application
 * when the application support this feature
 */
typedef struct gmaStructTransferHmi_st gmaStructTransferHmi_t;

/**
 * Structure with type \ref GMA_STRUCT_TRANSFER_HMI.
 * This structure is received by an application with any message if the application
 * sends a structure to the GMA saying it wants to use the HMI transfer functionality,
 * see structure \ ref GMA_STRUCT_TRANSFER_HMI_SUP. In this case the GMA instead of close 
 * the HMI handle will transfer the handle to the application task and send it using this structure.
 * The application should not close the HMI handle, and before return the control to 
 * the GMA it must transfer the handle back to the GMA task (the GMA tasked can be get
 * from the amgMsg_t message received from the GMA) using the OS function hmiChangeOwner.
 */
struct gmaStructTransferHmi_st
{
	gmaStructHeader_t header; /*!< header */
	uint32 hmiHandle;         /*!< hmi handle transfered */
};

/**
 * Structure with type \ref GMA_STRUCT_TRANSFER_HMI_SUP.
 * This structure is sent by an application or a plugin to the GMA
 * to inform the transfer hmi handle support. If an application
 * send this message to the GMA with status equal 1 the GMA
 * will transfer the HMI handle to this application instead
 * of close it when transfer to the application the control of
 * the terminal.
 */
typedef struct gmaStructTransferHmiSup_st gmaStructTransferHmiSup_t;

/**
 * Structure with type \ref GMA_STRUCT_TRANSFER_HMI_SUP.
 * This structure is sent by an application or a plugin to the GMA
 * to inform the transfer hmi handle support. If an application
 * send this message to the GMA with status equal 1 the GMA
 * will transfer the HMI handle to this application instead
 * of close it when transfer to the application the control of
 * the terminal.
 */
struct gmaStructTransferHmiSup_st
{
	gmaStructHeader_t header; /*!< header */
	uint8 status; //!< status equals 1 to the GMA send the HMI handle without close it, 0 otherwise
	uint8 logicalId; //!< logical Id of the application
	uint16 rfu2;
};

/**
 * Structure with type \ref GMA_STRUCT_EMV_AID_DEL.
 * This structure is sent by the application to the GMA asking
 * the GMA to delete all EMV AID entries.
 */
typedef struct gmaStructEmvAidDel_st gmaStructEmvAidDel_t;

/**
 * Structure with type \ref GMA_STRUCT_EMV_AID_DEL.
 * This structure is sent by the application to the GMA asking
 * the GMA to delete all EMV AID entries.
 */
struct gmaStructEmvAidDel_st
{
	gmaStructHeader_t header; /*!< header */
	uint32 rfu;
};

/**
 * Structure with type \ref GMA_STRUCT_APP_INFO. 
 * This structure is sent in the power on to the applications 
 * to inform to the application its physical application ID
 * and PID
 */
typedef struct gmaStructAppInfo_st gmaStructAppInfo_t;

/**
 * Structure with type \ref GMA_STRUCT_APP_INFO. 
 * This structure is sent in the power on to the applications 
 * to inform to the application its physical application ID
 * and PID
 */
struct gmaStructAppInfo_st
{
	gmaStructHeader_t header; /*!< header */
	uint16 appId; /*!< physical application ID*/
	uint16 pid;   /*!< Process ID*/
	uint32 rfu;   /*!< for future use */
};

/**
 * Structure with type \ref GMA_STRUCT_CONFIG_INFO.
 *  Used to inform the plug-ins and the application
 * about the configuration set in the GMA. In the
 * actual implementation only the option beepStatus
 * is sent. 
 */
typedef struct gmaStructConfigInfo_st gmaStructConfigInfo_t;

struct gmaStructConfigInfo_st
{
	gmaStructHeader_t header; /*!< header */
	/**
	 * If 1 indicates that the GMA is set to beep when
	 * a key is pressed. If 0 it is set to not beep.
	 */
	uint8  beepStatus;
	uint8  rfu1;
	uint16 rfu2;
};



/**
 * Structure with type \ref GMA_STRUCT_EMV_FALLBACK.
 * Structure attached in the magnetic card transaction to tell if
 * a SMC fallback is activate or not. 
 */
typedef struct gmaStructEmvFallback_st gmaStructEmvFallback_t;

/**
 * Structure with type \ref GMA_STRUCT_EMV_FALLBACK.
 * Structure attached in the magnetic card transaction to tell if
 * a SMC fallback is activate or not. 
 */
struct gmaStructEmvFallback_st
{
	gmaStructHeader_t header; /*!< header */
	/**
	 * 1 means a fallback active (last SMC insertion has a fallback error)
	 * 0 means no fallback active
	 */
	uint8 fallbackStatus;
	/**
	 * if fallbackStatus = 1 this field will tell in which step the
	 * EMV has an error, the following values are valid:
	 * - 1 -> error in the card power on, the status indicate the return error
	 * 
	 * - 2 -> Error in the function amgInitPayment that starts the EMV selection process.
	 * The status field indicate the return error
	 * 
	 * - 3 -> No applications in the terminal to treat the EMV inserted card.
	 * 
	 * - 4 -> Error in the function amgAskSelection. The status field will indicate the return error
	 * 
	 * - 5 -> Error in the function amgEmvFinalSelect. The status field indicates the return value.
	 */
	uint8 step;
	/**
	 * The return value of the function that returns an error, see the step field documentation for more details.
	 */
	int16 status;
	/**
	 * it means the number of 1/100 seconds since
	 * the last insertion of a smart card if the fallbackStatus
	 * is active.
	 */
	uint32 timeSinceSmcInsertion;
	uint32 rfu;
};

/**
 * Structure with type \ref GMA_STRUCT_SMC_SELECTION_MODE.
 * Struct to inform the application the type of selection process used
 * to define the application that will treat the smart card
 * when the EMV selection process is not used.
 */
typedef struct gmaStructSmcSelectionMode_st gmaStructSmcSelectionMode_t;

/**
 * Structure with type \ref GMA_STRUCT_SMC_SELECTION_MODE.
 * Struct to inform the application the type of selection process used
 * to define the application that will treat the smart card
 * when the EMV selection process is not used.
 */struct gmaStructSmcSelectionMode_st
{
	gmaStructHeader_t header; /*!< header */
	uint16 selectionType; /*! one of the GMA_SMC_SELECTION_XXXX */
	uint16 rfu;
};

/**
 * *****************************************************************
 * PLUGIN STRUCTS
 * *****************************************************************
 */


/**
 * structure with type \ref GMA_STRUCT_PG_INFO
 * Structure returned by the plugins as a answer to power on message.
 */
typedef struct gmaStructPGInfo_s gmaStructPGInfo_t;
/**
 * structure with type \ref GMA_STRUCT_PG_INFO
 * Structure returned by the plugins as a answer to power on message.
 */
struct gmaStructPGInfo_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;      /*!< plugin logical Id */
   char pluginName[16+1]; /*!< plugin Name */
   uint16 pluginVersion;  /*!< plugin version */
};

/**
 * structure with type \ref GMA_STRUCT_PG_EXT_INFO
 * It is used to send the menu plugin name. This is the string
 * that will appear in the first level of the technical menu 
 */
typedef struct gmaStructPgExtInfo_s gmaStructPgExtInfo_t;

/**
 * structure with type \ref GMA_STRUCT_PG_EXT_INFO
 * It is used to send the menu plugin name. This is the string
 * that will appear in the first level of the technical menu 
 */
struct gmaStructPgExtInfo_s 
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;      /*!< plugin logical Id */
   char pluginMenuName[16+1]; /*!< plugin Technical menu Name */
   uint16 rfu;
};

/**
 * structure with type \ref GMA_STRUCT_PG_QUEUE_ID
 * Structure used to send the queueId to the plugins.
 * This queue is used to receive commands from the plugin.
 */
typedef struct gmaStructPGQueueId_s gmaStructPGQueueId_t;
/**
 * structure with type \ref GMA_STRUCT_PG_QUEUE_ID
 * Structure used to send the queueId to the plugins.
 * This queue is used to receive commands from the plugin.
 */
struct gmaStructPGQueueId_s
{
   gmaStructHeader_t header;/*!< header */
   uint32 queueId;           /*!< the queue identifier */
};

/**
 * structure with type \ref GMA_STRUCT_PG_ACTIVITY_INFO
 * Message sent to the plugins telling the state of the GMA.
 */
typedef struct gmaStructPGActivityInfo_s gmaStructPGActivityInfo_t;
/**
 * structure with type \ref GMA_STRUCT_PG_ACTIVITY_INFO
 * Message sent to the plugins telling the state of the GMA.
 */
struct gmaStructPGActivityInfo_s 
{
   gmaStructHeader_t header;/*!< header */
   /**
    * The actual state of the GMA, the following values are possible:
    * - GMA_PG_ACTIVITY_MARK: an activity mark, it is signaled when the user does some quick, punctual, action.
    *   Can be used as a "ping" from GMA to the plug-ins;
    * - GMA_PG_ACTIVITY_START (1): some possibly long user-interaction has started;
    * - GMA_PG_ACTIVITY_END (2): this is send after each ACTIVITY_START to signal that the activity has ended;
    * - GMA_PG_APP_START (3): this is sent to signal that an user-application will start (i.e. a transaction will start);
    * - GMA_PG_APP_END (4): this is sent after each APP_START to signal that the transaction has ended;
    */
   uint16 activityType;
   uint16 rfu;
};

/**
 * structure with type \ref GMA_STRUCT_PG_SET_CONFIG
 * This message is sent to a plug-in when some configuration data has been changed.
 * This message is the result of the user interacting with the configuration options
 * that this plug-in made public. \ref GMA_STRUCT_PG_EDIT_RESOURCE
 */
typedef struct gmaStructPGSetConfig_s gmaStructPGSetConfig_t;
/**
 * structure with type \ref GMA_STRUCT_PG_SET_CONFIG
 * This message is sent to a plug-in when some configuration data has been changed.
 * This message is the result of the user interacting with the configuration options
 * that this plug-in made public. \ref GMA_STRUCT_PG_EDIT_RESOURCE
 */
struct gmaStructPGSetConfig_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 parameterId; /*!< the parameter Identifier */
   uint8 pluginId;    /*!< plugin identifier */
   uint16 dataLength; /*!< length of the dataBuffer field */
   uint8 dataBuffer[4]; /*!< the data edited. 32 bits multiple */
};

/*
 * GMA_STRUCT_PG_ERROR_MESSAGE
 *
 */
typedef struct gmaStructPGErrorMsg_s gmaStructPGErrorMsg_t;
struct gmaStructPGErrorMsg_s
{
   gmaStructHeader_t header;/*!< header */
   int16 retCode;
   uint8 pluginId;
   uint8 rfu;
   uint8 message[4]; // 32 bits multiple
};

/**
 * GMA_STRUCT_PG_ALERT_MESSAGE
 */
typedef struct gmaStructPGAlertMessage_s gmaStructPGAlertMessage_t;

/**
 * GMA_STRUCT_PG_ALERT_MESSAGE
 */
struct gmaStructPGAlertMessage_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginId;
   uint8 alertLevel;/*!< possible values: \n
						GMA_ALERT_MSG_INFORMATION \n
						GMA_ALERT_MSG_WARNING \n
						GMA_ALERT_MSG_ERROR	*/
   uint16 rfu;
   char text[4]; /*!< 32 bits multiple. It is a zero-terminated C-like string where the only allowed control char is "\n", that forces a new line. */ 
};

/**
 * structure with type \ref GMA_STRUCT_PG_KEYBOARD_CFG
 * A plug-in may require a specific functioning for some keys during the idle screen
 * (e.g. starting a menu, notifying a plug-in, etc.). This structure allows configuring these keys.
 */
typedef struct gmaStructPGKeyboardCfg_s gmaStructPGKeyboardCfg_t;
/**
 * structure with type \ref GMA_STRUCT_PG_KEYBOARD_CFG
 * A plug-in may require a specific functioning for some keys during the idle screen
 * (e.g. starting a menu, notifying a plug-in, etc.). This structure allows configuring these keys.
 */
struct gmaStructPGKeyboardCfg_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginId;    /*!< plugin identifier */
   uint8 key;         /*!< key to be reconfigured */
   uint8 action;      /*!< action to execute when the key is pressed: \n
							GMA_KEY_ACTION_DEFAULT: disables any customization of the key. When the key is pressed the default behavior (as if no customization had been done) should be followed; \n
							GMA_KEY_ACTION_FUNCTION: invoke one of the possible internal behaviors for this key; see below for the list of functions. \n
							GMA_KEY_ACTION_NOTIFY: send a key-press notification to a plug-in. This message cannot directly start an application, but a combination of this with one of the commands to send messages (defined below) could be used to start a transaction to a specific application simply by pressing a key. The notification message will be sent to the plug-in that made the command request (see the $notify message above). \n\n

							If the action selects a function action, it may provide which action should be taken in the 'setting' field. Currently only two functions are supported: \n
							GMA_KEY_FUNC_PAPER_FEED: this key should behave as the paper-feed button; \n
							GMA_KEY_FUNC_MENU: this key should behave as the menu button.  */
   uint8 parameter;   /*!< parameter of the select action */
};

/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFICATION_TYPE
 * The notify message always begins with this structure,
 * followed by other structures with any necessary parameters of the notification.
 */
typedef struct gmaStructPGNotificationType_s gmaStructPGNotificationType_t;
/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFICATION_TYPE
 * The notify message always begins with this structure,
 * followed by other structures with any necessary parameters of the notification.
 */
struct gmaStructPGNotificationType_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginId;      /*!< plugin identifier */
   uint8 notificationParam; /*!< notification parameter, depend on the notification type */ 
   uint16 notificationType; /*!< type of the notification: \n
								GMA_NOTIFICATION_KEY_PRESS: a key was pressed. A GMA_STRUCT_TRANS_KEY_PRESS with the actual key code of the pressed key must be the next structure in the message; \n
								GMA_NOTIFICATION_MENU: a menu item was selected, see "Menu creation  and Parameter Configuration" for more information about creating menus. In this case the notificationParam field includes the ID of the menu item selected. \n
								GMA_NOTIFICATION_SIGNAL: this message is a result of a "notify me" request from the plug-in. */
};

/**
 * structure with type \ref GMA_STRUCT_PG_BROADCAST
 * This command allows a plug-in to send a pre-formatted message to all applications and plug-ins.
 */
typedef struct gmaStructPGBroadcast_s gmaStructPGBroadcast_t;
/**
 * structure with type \ref GMA_STRUCT_PG_BROADCAST
 * This command allows a plug-in to send a pre-formatted message to all applications and plug-ins.
 */
struct gmaStructPGBroadcast_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginId;             /*!< plugin identifier */
   uint8 type;                 /*!< one of the GMA_PG_BROADCAST_TYPE_XXX */ 
   uint16 msgType;             /*!< message type to send */
   uint8 data[4];              /*!< message data field (multiple of 32 bits) */
};

/**
 * structure with type \ref GMA_STRUCT_PG_TRANSACTION_REQ
 * This command allows a plugin to send a transaction/query message to the applications
 */
typedef struct gmaStructPGTransactionReq_s gmaStructPGTransactionReq_t;

/**
 * structure with type \ref GMA_STRUCT_PG_TRANSACTION_REQ
 * This command allows a plugin to send a transaction/query message to the applications
 */
struct gmaStructPGTransactionReq_s
{
   gmaStructHeader_t header;
   uint8 transType; /*!< transaction type, one of the: GMA_TRANS_XXXX constants*/
   /**
    * Selection type. Can be \ref GMA_SELECTION_MENU, \ref GMA_SELECTION_QUERY or 
    * \ref GMA_SELECTION_NONE.
    */
   uint8 selectionType;
   uint8 logicalId;     /*!< logical application Id if GMA_SELECTION_NONE*/
   uint8 rfu;
   uint16 appId;        /*!< application Id if GMA_SELECTION_NONE*/
   uint16 rfu2;
   uint8 data[4];    /*!< structure add after structure GMA_STRUCT_TRANS_TYPE*/
};

/**
 * structure with type \ref GMA_STRUCT_PG_IDENTIFY
 * Structure used as header to the messages sent to the command queue
 */
typedef struct gmaStructPGIdentify_s gmaStructPGIdentify_t;
/**
 * structure with type \ref GMA_STRUCT_PG_IDENTIFY
 * Structure used as header to the messages sent to the command queue
 */
struct gmaStructPGIdentify_s
{
   gmaStructHeader_t header;/*!< header */
   uint16 appId;             /*!< application physical Id */
   uint16 rfu;
};

/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFY_ME
 * Structure send to the GMA command queue asking the GMA to send a notify message
 */
typedef struct gmaStructPGNotifyMe_s gmaStructPGNotifyMe_t;
/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFY_ME
 * Structure send to the GMA command queue asking the GMA to send a notify message
 */
struct gmaStructPGNotifyMe_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;         /*!< plugin identifier */
   uint8 rfu1;
   uint16 rfu2;
};

/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFY_ME_EXT
 * Structure send to the GMA command queue asking the GMA to send a notify message
 */
typedef struct gmaStructPGNotifyMeExt_s gmaStructPGNotifyMeExt_t;
/**
 * structure with type \ref GMA_STRUCT_PG_NOTIFY_ME_EXT
 * Structure send to the GMA command queue asking the GMA to send a notify message
 */
struct gmaStructPGNotifyMeExt_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 logicalId;         /*!< plugin identifier */
   uint8 notifyParam;       /*!< added in the notify message to be send to the plugin */
   /** 
    * - 0-> normal notification, the GMA will close the handles
    * before send the notification to the plugin.
    * - 1-> notification to the plugin without close the GMA handles
    **/
   uint16 notificationType;
};


/**
 * structure with type \ref GMA_STRUCT_PG_MENU_ITEM
 * Add a menu item in the GMA related to this plugin
 */
typedef struct gmaStructPGMenuItem_s gmaStructPGMenuItem_t;
/**
 * structure with type \ref GMA_STRUCT_PG_MENU_ITEM
 * Add a menu item in the GMA related to this plugin
 */
struct gmaStructPGMenuItem_s
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginID;         /*!< plugin Identifier */
   uint8 caption[16+1];    /*!< Text of the menu item */
   uint8 itemID;           /*!< ID of this item */
   uint8 action;           /*!< Which action to take: �GMA_PG_MENU_ACTION_NOTIFY or GMA_PG_MENU_ACTION_EDIT  */
   uint32 parameter;       /*!< Action parameter  */
};

/**
 * structure with type \ref GMA_STRUCT_PG_EDIT_RESOURCE
 * when the menu action is GMA_PG_MENU_ACTION_EDIT than a edit screen will be shown.
 * this structure will set it.
 */
typedef struct gmaStructPGEditResource_s gmaStructPGEditResource_t;
/**
 * structure with type \ref GMA_STRUCT_PG_EDIT_RESOURCE
 * when the menu action is GMA_PG_MENU_ACTION_EDIT than a edit screen will be shown.
 * this structure will set it.
 */
struct gmaStructPGEditResource_s 
{
   gmaStructHeader_t header;/*!< header */
   uint8 pluginId;      /*!< plugin identifier */
   char caption[16+1];  /*!< Caption of editing */
   uint8 itemId;        /*!< ID of this item */
   uint8 minLength;     /*!< Minimum length allowed for string value */
   char mask[4];        /*!< The mask field is a zero-terminated string with a mask that will be followed by GMA during editing. \n
						     This mask defines fixed chars to appear on the display, chars that allow only numeric digits, or alphanumeric characters.\n
							 The meaning of each character in the mask is: \n
								#: Digit (drawn if necessary) \n
								0: Digit (always drawn) \n
								A/a: Alphanumeric character (always drawn) \n
								?: Invert the �always draw� status of the following character. \n
								*: Password character. Will be replaced on the screen by an asterisk. \n
								\\: The next character will be considered a literal, and not a macro. \n
								To allow for arbitrary large inputs, this field does not have a fixed length, instead it has a variable length and, as with all other GMA messages, its length must be a multiple of 32-bits (4 bytes). \n\n
								Mask examples:\n\n

								$ ##.###.##0,00\n
								The above mask will show the following on the screen: \n
								$   .   .  0,00 \n
								If you want to show the separators only if necessary, use the ? mask as following: \n
								$ ##?.###?.##0,00 \n
								This mask will show: \n
								$         0,00 	*/
};


/**
 * structure with type \ref GMA_STRUCT_PG_INQUIRE_GMA
 * Inquire a GMA about some information. For example,
 * the time for the next event
 */
typedef struct gmaStructPGInquireGma_s gmaStructPGInquireGma_t;

/**
 * structure with type \ref GMA_STRUCT_PG_INQUIRE_GMA
 * Inquire a GMA about some information. For example,
 * the time for the next event
 */
struct gmaStructPGInquireGma_s
{
   gmaStructHeader_t header; /*!< header */
   uint8  pluginId;          /*!< plugin identifier */
   uint8  rfu;
   uint16 inquireType;       /*!< Type of inquire: \ref GMA_PG_INQUIRE_NEXT_EVENT_SEC*/
   uint32 returnQueueId;     /*!< the return queue ID to send the answer to the inquire */
   uint8  InquireData[4];    /*!< Inquire data in necessary */
};

/**
 * structure with type \ref GMA_STRUCT_PG_INQUIRE_ANSWER
 * This structure is used to answer an \ref GMA_STRUCT_PG_INQUIRE_GMA
 * message.
 */
typedef struct gmaStructPGInquireAnswer_s gmaStructPGInquireAnswer_t;

/**
 * structure with type \ref GMA_STRUCT_PG_INQUIRE_ANSWER
 * This structure is used to answer an \ref GMA_STRUCT_PG_INQUIRE_GMA
 * message.
 */
struct gmaStructPGInquireAnswer_s
{
   gmaStructHeader_t header; /*!< header */
   uint8  pluginId;          /*!< plugin identifier */
   uint8  rfu;
   int16  retCode;           /*!< return code for the inquire. Could be RET_OK or 
                                  one of the GMA_PG_INQUIRE_ERR_XXX defines */
   uint8  inquireAnswer[4];  /*!< Inquire answer data if necessary */
};

/**
 * structure with type \ref GMA_STRUCT_PG_DISP_CONFIG.
 * This structure is used by a plug-in to send display configuration to the 
 * gmaCustom
 */
typedef struct gmaStructPGDispConfig_st gmaStructPGDispConfig_t;

/**
 * structure with type \ref GMA_STRUCT_PG_DISP_CONFIG.
 * This structure is used by a plug-in to send display configuration to the 
 * gmaCustom
 */
struct gmaStructPGDispConfig_st
{
   gmaStructHeader_t header; /*!< header */
   uint8 pluginId;           /*!< plugin identifier */
   uint8 rfu;
   /**
    * Which item willl be configured.\n
    * See \ref GMA_PG_DISP_CONFIG_BACKLIGHT and \ref GMA_PG_DISP_CONFIG_BEEP.
    */
   uint16 configItem;
   /**
    * the configuration data.
    * See \ref GMA_PG_DISP_CONFIG_BACKLIGHT and \ref GMA_PG_DISP_CONFIG_BEEP.
    */
   uint8 configData[4];
};

/**
 * GMA_STRUCT_PG_CUSTOM_STATE
 */
typedef struct gmaStructPGCustomState_st gmaStructPGCustomState_t; 

/**
 * GMA_STRUCT_PG_CUSTOM_STATE
 */
struct gmaStructPGCustomState_st
{
	gmaStructHeader_t header;
	uint8 state;
	uint8 rfu1;
	uint16 rfu2;
};

#ifdef __cplusplus
}
#endif

#endif



#ifndef GMA_STRUCTURES_H_INCLUDED
#define GMA_STRUCTURES_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_APP_LIST_PHYSICAL_APP_NAME_LENGTH   (16) //!< max length of the physical app name
#define GMA_APP_LIST_LOGICAL_APP_NAME_LENGTH    (16) //!< max length of the logical app name
#define GMA_APP_LIST_DFS_APP_NAME_SIZE          (12) //!< max length of the system app name


/**
 * Structure that hold the physical application data
 */
typedef struct gmaAppListPhysicalData_t gmaAppListPhysicalData_t;
/**
 * Structure that hold the physical application data
 */
struct gmaAppListPhysicalData_t
{
   char name[GMA_APP_LIST_PHYSICAL_APP_NAME_LENGTH + 1]; //!< name of the physical application 
   char dfsName[GMA_APP_LIST_DFS_APP_NAME_SIZE + 1]; //!< system name of the application
   uint16 appId; //!< number of the physical application
   uint16 pid;   //!< process Id of the application
   uint8 type;   //!< type of the application (plugin or normal application)
   uint8 nLogical; //!< number of logical application
   uint32 taskId;  //!< the task Id of the application
   uint16 version; //!< the physical application version
};

/**
 * Structure that hold the logical application data
 */
typedef struct gmaAppListLogicalData_t gmaAppListLogicalData_t;
/**
 * Structure that hold the logical application data
 */
struct gmaAppListLogicalData_t
{
   uint8 logicalId; //!< logical Id
   uint16 appId; //!< physical application number that this logical application belongs
   char name[GMA_APP_LIST_LOGICAL_APP_NAME_LENGTH+1]; //!< logical application name
   char tmName[GMA_APP_LIST_LOGICAL_APP_NAME_LENGTH+1]; //!< logical application name to appear in the technical menu
   uint8 state; //!< state of the logical application, can be Active (1) or inactive (0)
   uint16 version; //!< 
};


#ifdef __cplusplus
}
#endif


#endif

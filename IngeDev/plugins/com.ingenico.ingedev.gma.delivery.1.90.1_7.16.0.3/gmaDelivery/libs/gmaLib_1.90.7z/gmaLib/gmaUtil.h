/*
   General utility functions.

   Unicapt32 - Idle Application
   Ingenico Latin America
*/

#ifndef IDLE_UTIL_H
#define IDLE_UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

/**  
 * @file gmaUtil.h
 * GMA Utilities functions
 * 
 *
 */


/**
 * Return the application number from the DFS name.
 * Works on both 'old' and 'new' naming conventions.
 *
 * @param dfsName the DFS name of the application to get the 
 * application number 
 */
uint16 gmaUtilIdFromDfsName(const char *dfsName);

/**
 * Get the DFS name from application number 
 *
 * @param appNumber application number
 *
 * @param dfsName a pointer to a buffer to receive the DFS name.
 */
int16 gmaUtilGetDfsFromAppNum(uint16 appNumber, char *dfsName);

/**
 * get the DFS name from the PID
 *
 * @param pid the process Id
 *
 * @param dfsName a pointer to a buffer to receive the DFS name.
 */
int16 gmaUtilGetDfsFromPid(uint16 pid, char *dfsName);

/**
 * Return the application number from the taskId
 * (won't work with older OS's like 2.1.x)
 *
 * @param taskId the task Identification
 */
uint16 gmaUtilGetAppNumber(uint32 taskId);

/**
 * Return the application number from the application Pid
 *
 * @param pid the process ID.
 */
uint16 gmaUtilGetAppNumberFromPid(psyPid_t pid);


#ifdef __cplusplus
}
#endif

#endif


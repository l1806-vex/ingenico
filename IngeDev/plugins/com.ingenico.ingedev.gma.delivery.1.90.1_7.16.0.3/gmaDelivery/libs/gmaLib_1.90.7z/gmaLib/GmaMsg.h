#ifndef GMA_MSG_LIB_H
#define GMA_MSG_LIB_H

/*
   Support code for packing/unpacking GMA messages.
   This library provides seamless support for messages
   larger than AMG message limit when formatting
   GMA structures.
*/

#include <miltypes.h>

#ifdef __cplusplus
extern "C" {
#endif


/** @file GmaMsg.h
 * GMA Message Functions
 *
 */

/*
 * Constants.
 */
#define GMA_MSG_FILE             ("GmaMsgFi.dat")
#define GMA_MSG_PASSWORD         ("GMAMSGFILE")
#define GMA_MSG_REDIRECT_STRUCT  (0xFFFFFFFF)
#define GMA_MSG_REDIRECT_RFU     (0xFF)
#define GMA_MSG_FILE_BUF_LEN     (2048)

/*
 * Error codes
 */
#define GMA_MSG_ERR_BASE            (-0x4000) /*!< Error Base*/
#define GMA_MSG_ERR_NOT_BEGAN       (GMA_MSG_ERR_BASE) /*!< not initialized */
#define GMA_MSG_ERR_NO_MORE_STRUCTS (GMA_MSG_ERR_BASE - 1) /*!< there is no more structures in the message*/
#define GMA_MSG_ERR_MSG_TOO_BIG     (GMA_MSG_ERR_BASE - 2) /*!< data to big to add to the message */

/**
 * Begin message composition.
 * Will start the internal (static!) buffers that are used to
 * compose the message.
 * All fields of {msg} that does not need to change will be left untouched.
 *
 * @param msg  where to construct the AMG message to be sent. \
 *             note that in some cases the packing process will use external \
 *             storage (and send this to Idle outside the AMG message), so \
 *             the gmaMsgSend() functions _must be used_!
 *
 * @param msgType the type of the message
 *
 * @return RET_OK
 */
int16 gmaMsgEncode(amgMsg_t *msg, uint32 msgType);

/**
 * Send a message to an application by name.
 * This is an equivalent to amgSend().
 * Note that this function will call internally the functio
 * \ref gmaMsgEndEncode. Then you must not call
 * \ref gmaMsgEndEncode when you use this function
 * to send the message.
 * 
 * @param app  application system name.
 *
 * @return same as amgSend().
 */
int16 gmaMsgSend(const char *app);

/**
 * Send the formatted message to a determined task.
 * This is equivalent to amgSendId()
 * Note that this function will call internally the function
 * \ref gmaMsgEndEncode. Then you must not call
 * \ref gmaMsgEndEncode when you use this function
 * to send the message.
 *
 * @param taskId  ID of receiving task.
 *
 * @return same as amgSendId()
 */
int16 gmaMsgSendId(uint32 taskId);

/**
 * Add a block of data to currently editing message
 *
 * @param data a pointer to the data to be added.
 * @param length the number of bytes to be added
 */
int16 gmaMsgAdd(const void *data, uint16 length);

/**
 * Begin decoding of AMG message.
 * Will start the internal static buffer that are used to decode the message.
 *
 * @param msg a pointer to the amg message to be decoded
 */
int16 gmaMsgDecode(amgMsg_t const *msg);

/**
 * Rewind the parse to the beginning of the message struct list
 */
int16 gmaMsgRewind(void);

/**
 * Extract next structure from the message being decoded.
 *
 * @param data a pointer to a pointer that will point to the next struct in the message.
 * @param length a pointer to uint16 that will receive the length of the structure readed.
 *
 * @return RET_OK no error
 * @return GMA_MSG_ERR_NO_MORE_STRUCTS no more structures to be decoded.
 */
int16 gmaMsgRead(void **data, uint16 *length);

/**
 * Finish a encoding session. The \ref gmaMsgSend and \ref gmaMsgSendId
 * functions call this function
 * automatically, so when use one of these function to send the message
 * you must not use this function.
 */
int16 gmaMsgEndEncode(void);

/**
 * Finish a decoding session. Must be called when the decode is done.
 */
int16 gmaMsgEndDecode(void);

#ifdef __cplusplus
}
#endif


#endif


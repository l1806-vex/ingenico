
#ifndef GMA_PG_MSG_H_INCLUDED
#define GMA_PG_MSG_H_INCLUDED


#ifdef __cplusplus
extern "C" {
#endif


#define GMA_PG_MSG_PLUGIN_NOT_FOUND (-1)
#define GMA_PG_MSG_HANDLE_NOT_OPEN  (-2)
#define GMA_PG_MSG_INTERNAL_ERROR   (-3)
#define GMA_PG_MSG_TIMEOUT          (-4)
#define GMA_PG_MSG_NO_RESOURCE      (-5)
#define GMA_PG_MSG_LIB_NOT_INITIALIZED (-6)


#define GMA_PG_MSG_TYPE_START (1)
#define GMA_PG_MSG_TYPE_END   (2)
#define GMA_PG_MSG_TYPE_MSG   (3)
#define GMA_PG_MSG_TYPE_ERROR (4)
#define GMA_PG_MSG_TYPE_LOCAL_PLUGIN (5)

typedef struct gmaPgMsgStructMsg_s gmaPgMsgStructMsg_t;
struct gmaPgMsgStructMsg_s
{
   uint32 fix;
   uint8  msgType;
   uint8  logicalId;
   uint16 phyId;
   uint32 queueId;
   uint32 size;
   uint8  msg[4];
};

typedef void (*gmaPgMsgCallerFunction)(uint8 *msg, uint16 *msgLength);


                               
/** @file GmaPgMsg.h
 * GMA Plugin Message Functions
 *
 */



/**
 * 
 *
 */
void gmaPgMsgSetCaller(gmaPgMsgCallerFunction func);

/**
 * Initialize the library. Called when the application receive the Power On.
 *
 * @param msg a pointer to the message received in the power on.
 */
int16 gmaPgMsgInitialize(const amgMsg_t *msg);

/**
 * Open a communication "channel" with a plugin.
 *
 * @param pluginName the name of the plugin
 *
 * @param handle the handle of the communication this handle
 *         will be used in \ref gmaPgMsgCloseComm and in the
 *         \ref gmaPgMsgSendMsg. In the \ref gmaPgMsgReceiveMsg
 *         the handle will be returned and will refer to the
 *         plugin that send the data.
 *
 * @return RET_OK
 * @return GMA_PG_MSG_PLUGIN_NOT_FOUND the plugin was not found
 * @return GMA_PG_MSG_NO_RESOURCE there is no resource to open a new channel
 */
int16 gmaPgMsgOpenComm(const char *pluginName, uint32 *handle);

/**
 * close the communication channel
 *
 * @param handle the handle of the channel to be closed
 */
int16 gmaPgMsgCloseComm(uint32 handle);

/**
 * Send the data to the plugin using the previous open channel
 * 
 * @param handle the handle of the channel
 * @param data a pointer to the data to be sent
 * @param length the size of the data to be sent
 *
 * @return RET_OK
 * @return GMA_PG_MSG_HANDLE_NOT_OPEN
 * @return GMA_PG_MSG_INTERNAL_ERROR
 */
int16 gmaPgMsgSendMsg(uint32 handle, const uint8 *data, uint16 length);

/**
 * receive data from any open channel
 *
 * @param handle return the handle of the channel that receive the data
 * @param buff a pointer to a pointer to receive a pointer to the buffer
 * @param length a pointer to a uint16 that will receive the
 *  number of bytes received
 * @param timeout the timeout to wait while receiving data
 *
 * @return RET_OK
 * @return GMA_PG_MSG_TIMEOUT
 */
int16 gmaPgMsgReceiveMsg(uint32 *handle, uint8 **buff, uint16 *length, uint32 timeout);

#ifdef __cplusplus
}
#endif


#endif

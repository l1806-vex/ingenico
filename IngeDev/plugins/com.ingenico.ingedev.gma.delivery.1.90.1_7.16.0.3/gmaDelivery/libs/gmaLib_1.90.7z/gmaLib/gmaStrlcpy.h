#ifndef GMA_STRLCPY_H_INCLUDED
#define GMA_STRLCPY_H_INCLUDED

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

size_t gmaStrlcpy(char *dst, const char *src, size_t siz);

#ifdef __cplusplus
}
#endif

#endif


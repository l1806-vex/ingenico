#ifndef GMA_MSG_CON_LIB_H
#define GMA_MSG_CON_LIB_H

/*
   Support code for generate the return message to the idle
   Application (GMA)
*/

/** @file GmaMsgCon.h
 * GMA Message Functions
 *
 */

#include <unicapt.h>
#include "gmaDefines.h"

#ifdef __cplusplus
extern "C" {
#endif


#define GMA_MSG_CON_ERR_WRONG_PARAMS (-1)
#define GMA_MSG_CON_ERR_FUNC_NOT_SUPPORTED (-2)

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_PHYSICAL_APP_INFO.
 * This structure is sent in the answer to the power on message.
 *
 * @param retCode the return code of the Power On. A value of zero is considered OK. The actual version
 * of the GMA didn't check this value.
 * @param phyVersion version of the physical application.
 * @param phyName name of the physical application
 * @param appType type of the application (\ref GMA_USER_APPLICATION for application or 
 *   \ref GMA_PLUGIN_APPLICATION for plugin).
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddPhysicalAppInfo(int16 retCode, uint16 phyVersion, const char *phyName, uint8 appType);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_LOGICAL_APP_INFO.
 * This structure is sent in the answer to the power on message. One structure for each
 * logical application. 
 * If this structure is not added as an answer to the power on, the GMA will
 * automatically add one with logicalId equals 0xFF and with the name copied from
 * the physical app name (phyName from function \ref gmaMsgAddPhysicalAppInfo). 
 * 
 * @param logicalId the Id of the logical application
 * @param logicalName the name of the logical application
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddLogicalAppInfo(uint8 logicalId, const char *logicalName);
int16 gmaMsgDelLogicalAppInfo(uint8 logicalId);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_LOGICAL_APP_STATUS_INFO.
 * This structure is sent in the answer to the integrity check message and is used
 * to tell the GMA is the logical app is ok for running or not.
 *
 * @param logicalId the id of the logical application. An Id of value 0xFF means
 * all logical applications from this physical application. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId = 0xff too.
 * @param logicalState the state of the logical application. 
 *     0-> application OK -- 1-> error, other values are reserved for future use.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddLogicalAppStatus(uint8 logicalId, uint8 logicalState);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_CURRENCY
 * This structure can be sent as a answer to any message. This structure allows an 
 * application to inform GMA of the currencies it can handle. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId = 0xff too.
 *
 * @param logicalId the logical application id.
 * @param curExpoent Currency Exponent
 * @param curNumCode Currency numeric code (BCD format)
 * @param curAlphaNumCode Currency alphanumeric code (ISO4217)
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddCurrency(uint8 logicalId, uint8 curExpoent, uint16 curNumCode,
                        const char *curAlphaNumCode);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_RETURN_QUERY.
 * This structure is sent as a answer to the GMA_MSG_TRANSACTION_QUERY message.
 * It is used to inform the acceptance level of this application to the Transaction to be treated.
 * 
 * 
 * @param logicalId the logical application Id, if the value is 0xFF means all logical applications
 * from this physical application. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff too.
 * @param acceptLevel the acceptance level to treat the transaction. Could be one of
 * the following values: GMA_ACCEPTLEVEL_NO_ACCEPT, GMA_ACCEPTLEVEL_LOW, GMA_ACCEPTLEVEL_MEDIUM
 * or GMA_ACCEPTLEVEL_HIGH
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddQueryResult(uint8 logicalId, uint8 acceptLevel);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_RETURN_CODE.
 * This structure is used as a return to all the message that require it. See the 
 * gma documentation for more details.
 *
 * @param retCode the return code
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddReturnCode(uint16 retCode);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_SCHEDULED_EVENT_INFO
 * This structure is sent as a answer to any message and is used to schedule an event in the GMA.
 *
 * @param logicalID the logical application Id. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff.
 *
 * @param eventAction Can be one of the following values:
 *        - GMA_EVENT_ACTION_ADD: to add this event
 *        - GMA_EVENT_ACTION_DEL: to delete this event
 *        - GMA_EVENT_ACTION_DEL_ALL: to delete all schedule events for this logical application
 *        - GMA_EVENT_ACTION_REPEAT: to schedule an repeated event.
 *
 * @param eventID the event identifier.
 * @param date the date to schedule event
 * @param time the time to schedule event
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgScheduleEvent(uint8 logicalID, uint8 eventAction, uint16 eventID, 
                          uint32 date, uint32 time);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_MEDIA_DATA.
 * This structure is sent as a answer to any message and is used to send a media data to the GMA.
 * The possible media data types now are �	GMA_MEDIA_MONO_BITMAP, GMA_MEDIA_TEXT or GMA_MEDIA_DELETE.
 *
 * @param mediaID the Id of the media data to be sent
 * @param logicalId the logical application Id. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff.
 * @param mediaType the type of the media data: GMA_MEDIA_MONO_BITMAP, GMA_MEDIA_TEXT or GMA_MEDIA_DELETE
 * @param mediaSize the number of the bytes in the media data
 * @param data a pointer to the media data to be sent.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 * @return GMA_MSG_ERR_MSG_TOO_BIG if the mediaSize is too big. The internal buffer to hold one 
 * structure is 2KB. If the mediaData is too big the idea is to use a file to pass the information
 * to the GMA. Save the mediaData to a file and use the function \ref gmaMsgMediaFile
 */
int16 gmaMsgMediaData(uint8 mediaID, uint8 logicalId, uint16 mediaType, uint16 mediaSize,
                      const uint8 *data);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_MEDIA_POSITION.
 * This structure is sent as a answer to any message and is used to set the position
 * and if the media data is active or not.
 *
 * @param mediaID the Id of the media data to be sent
 * @param logicalId the logical application Id. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff.
 * @param xPos the horizontal position where to draw the media in pixels
 * @param yPos the vertical position where to draw the media in pixels
 * @param active if the mediaData is active (TRUE) or not (FALSE)
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgMediaPosition(uint8 mediaID, uint8 logicalId, uint16 xPos, uint16 yPos,
                          uint16 active);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_MEDIA_FILE
 * Not implemented yet
 */
int16 gmaMsgMediaFile(uint8 mediaID, uint8 logicalId, uint16 mediaType, const char *fileName);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_EMV_AID.
 * This structure is sent as a answer to any message and is used to the application
 * send information to the application selection process when a smart card EMV is
 * inserted.
 *
 * @param logicalId the logical application Id. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff.
 * @param aid the information to be used in the selection. See the Unicapt documentation
 *        for more details.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgEmvAid(uint8 logicalId, const amgAid_t *aid);

/**
 * Will add to the reply message the structure \ref gmaStructEmvAidDel_t that
 * ask the GMA to delete all EMV AID previously received
 */
int16 gmaMsgAddEmvAidDel(void);

/**
 * Will inform the GMA if the application supports or not the HMI handle
 * transfer. 
 * 
 * This function will not work in simulation in the Ingedev5 or 4.
 * 
 * Note: You will receive the handle in a attached structure in the 
 * messages received from the GMA, the structure used is the \ref gmaStructTransferHmi_t.
 * You get the hmi Handle from this structure. If you receive the handle
 * from the GMA with the structure above before return the control of the
 * terminal to the GMA you must call the OS function hmiChangeOwner to
 * pass the handle back to the GMA. You can use the callerTaskId field of
 * the received message from the GMA as the parameter to the hmiChangeOwner 
 * function. If you close the received handle from the GMA before return the control
 * of the terminal to the GMA you must reopen the handle, call the hmiChangeOwner
 * as explained above and then call the function \ref gmaMsgAddHmiTransferBack
 * to inform the GMA the new hmi Handle.
 * 
 * @param logicalId the logical Id of the application that send the structure.
 * the logicalId equals 0xFF means all logical applications from this physical
 * application. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff too.
 * 
 * @param status 0 means the application don't support hmi handle transfer, 1
 *   means the application support.
 * 
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddHmiTransferSup(uint8 logicalId, uint8 status);

/**
 * If an application support hmi transfer, when the control is passed to
 * the application the hmi handle will be passed with the transaction
 * message. If the application needed to close the handle and open
 * the handle again, the handle should be sent back to the GMA.
 * In this case call this function to send the handle back to the GMA.
 * 
 * This function will not work in simulation in the Ingedev5 or 4.
 * 
 * @param hmiHandle the new handle to be sent to the GMA in the 
 * answer message
 * 
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddHmiTransferBack(uint32 hmiHandle);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_COMM_PLUGIN.
 * This structure is used when returning the message type GMA_MSG_COMM_PLUGIN_REQ.
 * This is used to request a communication with the plugin. This function is not intended
 * to be used directly. Instead use the functions gmaPgMsgXXXX to deal with plugin communication.
 *
 * @param pluginName the name of the plugin the application wants to talk.
 * @param logicalId the logicalId of this application. If you don't have added
 * a logical application (using the function \ref gmaMsgAddLogicalAppInfo)
 * use the logicalId 0xff.
 * @param physicalId the physicalId of this application
 * @param queueId the Id of a Vqueue created by the application to receive the messages
 *        from the plugin.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgCommPlugin(const char *pluginName, uint8 logicalId, uint16 physicalId, uint32 queueId);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_PG_INFO.
 * This structure is sent as a answer to the Power On message. Each plugin need to add
 * this structure to the answer to the power on message.
 *
 * @param logicalId the logical application Id (plugin Identificator)
 * @param pluginName the name of the plugin. This name will appear in the
 * technical menu if a call to the \ref gmaMsgAddPgExtInfo was
 * not done.
 * @param pluginVersion the version of the plugin
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddPGInfo(uint8 logicalId, const char *pluginName, uint16 pluginVersion);

/**
 * Will add to the current encoding message the struct type GMA_STRUCT_PG_INFO.
 * This structure is sent as a answer to the Power On message. Each plugin need to add
 * this structure to the answer to the power on message.
 *
 * @param logicalId The logical application Id (plugin Identificator)
 * @param pluginMenuName the plugin name that will appear in the 
 * technical menu.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddPgExtInfo(uint8 logicalId, const char *pluginMenuName);


/**
 * Will add the structure with id \ref GMA_STRUCT_PG_BACK_GMA.
 * tell the GMA to return directly to the
 * GMA without continues to show the menus. Used for example
 * when a plugin receives a notification menu message,
 * and want when return from the treatment to go directly to the
 * GMA screen instead of return to the menu again.
 * This structure doesn't has a definition as only the presence of
 * the structure is the information. 
 */
int16 gmaMsgAddPgBackGma(void);

/**
 * Will add the structure with id \ref GMA_STRUCT_PG_CUSTOM_STATE, tell
 * the GMA to disable the GMA idle display or not.
 * 
 * @param state: 1 -> disable the custom display, doesn't show the GMA display. 
 * 0-> normal behaviour.
 *
 * @return the value returns of the function \ref gmaMsgAdd
 */
int16 gmaMsgAddCustomState(uint8 state);

/**
 * Fill the struct header of the structure
 *
 */
int16 gmaMsgGenerateHeader(gmaStructHeader_t *header, uint32 strType,
                           uint16 strLength);

/**
 * Fill the header struct extended
 */
int16 gmaMsgGenerateHeaderExt(gmaStructHeader_t *header, uint32 type,
                           uint16 length, uint8 logicalApp);

#ifdef __cplusplus
}
#endif


#endif


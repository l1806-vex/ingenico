/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT        :    SSA application
 *  FILEMANE       :    lafFunctions.h
 *  PURPOSE        :    Exported functions of the LAF library
 *
 *  HISTORY
 *  date         author     modifications
 *  2003-09-03   MAB        creation
 *  2004-06-22   AMO        change lafTermConfigRead API
 *  2006-01-03   FCL        Re-oragnisation of the LAF library
 *  2006-01-30   ROM        lafSaveInitialSettings & lafRestoreInitialSettings added
 *  2006-11-24   FCL        Modifications to manage Font by OS
 *
 * --------------------------------------------------------------------------
 *  PLEASE USE 3 CHAR. TABULATIONS
-*/

#ifndef __lafFunctions_H
#define __lafFunctions_H

#ifdef __cplusplus
extern "C" {
#endif


/*+++******* EXPORTED FUNCTIONS DEFINITIONS ***********************---*/
int16 	lafTermOpenSecuredWindow(uint32* outputHandle,uint32* inputHandle,uint32 mode);
int16 	lafOpenSecuredWindow(uint32* winHandle);
int16 	lafGenOpenSecuredWindow(uint32* winHandle, uint32* inputHandle);
int16 	tlsOpenSecuredWindow(uint32* winHandle,uint32 mode);
int16 	lafTermCloseSecuredWindow(uint32 outputHandle,uint32 inputHandle);
int16 	lafCloseSecuredWindow(uint32 winHandle);
int16 	lafGenCloseSecuredWindow(uint32 winHandle, uint32 inputHandle);
int16 	tlsCloseSecuredWindow(uint32 winHandle);
int16 	lafOpenWarningWindow(uint32* pwinHandle);
int16 	lafGenOpenWarningWindow(uint32* pwinHandle,uint32* inputHandle);
void 		lafGetApiVersion(char *pt_input);
int16 	lafTermMenuSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *menu, int16 idStartUp, uint32 timeOut, int16 *idSelected);
int16 	lafMenuSelect(uint32 outputHandle, uint32 inputFlags, char *menu, int16 idStartUp, int16 *idSelected);
int16 	lafGenMenuSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *menu, int16 idStartUp, int16 *idSelected);
int16 	lafTermListSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, int16 iStartUp, uint32 timeOut, int16 *iSelected);
int16 	lafListSelect(uint32 outputHandle, uint32 inputFlags, char *title, char *lines, int16 iStartUp, int16 *iSelected);
int16 	lafGenListSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, int16 iStartUp, int16 *iSelected);
int16 	lafTermListDisplay( uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, uint32 timeOut, int16 *response);
int16 	lafListDisplay( uint32 outputHandle, uint32 inputFlags, char *title, char *lines, int16 *response);
int16 	lafGenListDisplay( uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, int16 *response);
int16 	lafTermMessageBox(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *message, uint32 timeOut, int16 *response);
int16 	lafMessageBox(uint32 outputHandle, uint32 inputFlags, char *title, char *message, int16 *response);
int16 	lafGenMessageBox(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *message, int16 *response);
int16 	lafTermSecuredInput(uint32 outputHandle, uint32 inputHandle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafSecuredInput(uint32 outputHandle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafGenSecuredInput(uint32 outputHandle, uint32 inputHandle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafTermSecuredInput_adv(uint32 outputHandle, uint32 inputHandle, ssaSecInput_adv_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafTermMessageShow(uint32 outputHandle, uint32 inputFlags, char *title, char *message, uint32 timeOut);
int16 	lafMessageShow(uint32 outputHandle, uint32 inputFlags, char *title, char *message, uint32 timeOut);
int16 	lafTermBackLightOnWindow(uint32 outputHandle);
int16 	lafBackLightOnWindow(uint32 outputHandle);
int16 	lafTermBackLightOffWindow(uint32 outputHandle);
int16 	lafBackLightOffWindow(uint32 outputHandle);
int16 	lafADDisplayText (uint32 handle, uint32 line, uint32 column, char *text);
int16 	lafADClearLine(uint32 outputHandle, uint16 line);
int16 	lafWindowDim(uint32 outputHandle, int16 *windowWidth, int16 *windowHeight);
int16 	lafADFont (uint32 handle, void const *font);
int16 	lafCfgBackLight(uint32 handle,uint8 mode, lafBackLight_t *pLafBackLight);
int16 	lafCfgContrast(uint32 handle,uint8 mode, lafContrast_t *pLafContrast);
int16 	lafTermConfigRead(uint32 handle, lafConfig_t type, uint16 *plength, void *pBuffer);
int16 	lafTermSetModeReverseVideo(uint32 handle);
int16 	lafSetModeReverseVideo(uint32 handle);
int16 	lafTermSetModeNormalVideo(uint32 handle);
int16 	lafSetModeNormalVideo(uint32 handle);
int16 	lafBacklightWindow (uint8 percent);
void 		lafAutoCentreSet (uint32 handle, uint8 state);
uint8 	lafAutoCentreGet (void);
void  	lafCfgInit(void);
void     lafSaveInitialSettings(void);
void     lafRestoreInitialSettings(void);
void  	lafPinConfig(uint32 outputHandle, uint8 type, void *ptData);
void  	lafTermPinConfig(uint32 outputHandle, uint8 type, void *ptData);
int16		lafWriteFont(uint32 outputHandle, uint8 fontIsoNb, uint8 *normFontSlot, uint8 *boldFontSlot);
int16		lafTermWriteFont(uint8 fontIsoNb, uint8 *normFontSlot, uint8 *boldFontSlot);
int16 	lafSelectDispDefaultFont(uint32 outputHandle, void *fontId);
int16 	lafTermSelectDispDefaultFont(void *fontId);
int16 	lafSelectPrnDefaultFont(uint32 outputHandle, void *normalFontId, void *boldFontId);
int16 	lafTermSelectPrnDefaultFont(void *normalFontId, void *boldFontId);





/*+++******* ADDITIONNAL FUNCTIONS INFORMATIONS ***********************---*/


/**++*************************************************************************/
// void lafGetApiVersion(char *pt_buffer);
/*****************************************************************************
 * Description:
 *	return the current version of this LAF library
 *
 * Parameters:
 *   - pt_Input		pointer to a buffer
 *	 - ui8InputSize	size of the buffer
 * 
 * Returns:
 *   - RET_OK
 *   - Value superior to zero, size that should be passed to the function
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermMenuSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *menu, int16 idStartUp, uint32 timeOut, int16 *idSelected);
/*****************************************************************************
 * Description:
 * The menu select function is a function which receives in input a buffer containing all 
 * the items which will constitute the menu to draw. For each item is associated an ID 
 * in order to select it. In output, it will return the ID of the selected item. 
 *
 * Parameters:      I/O Description
 *   - outputHandle I   the output handle
 *   - inputHandle  I   the input handle
 *   - inputFlags   I   Defines the input mode. OR of the following available modes:
 *                      - Input Device: Indicate if the function uses the Keyboard or the 
 *                        Touch Screen device
 *                        Values:               LAF_KEYBOARD
 *                                              LAF_TOUCHSCREEN
 *                        Default Value:        LAF_KEYBOARD
 *                      - Print Key: This mode enables or no to exit the function when the
 *                        "Function Key" is pressed:
 *                        1. If it is enabled: when the "Function Key" is pressed, the menu 
 *                           function returns with idSelected  = LAF_PRINT
 *                        2. If it is not enabled: the "Function Key" has no effect
 *                        Values:               LAF_ENABLE_PRINTKEY
 *                                              LAF_DISABLE_PRINTKEY
 *                        Default Value:        LAF_DISABLE_PRINTKEY
 *                      - Numeric Keys: This mode enables the numeric keys entry:
 *                        1. If numeric keys shortcut mode is selected: when a numeric key is
 *                           pressed,the focus is moved automatically to its corresponding line:
 *                           Key 1 for Line 1
 *                           Key 2 for Line 2
 *                           ...    
 *                           Key 9 for Line 9
 *                           Shortcut numeric keys are only available for lines 1 to 9
 *                        2. If numeric keys return mode is selected: when a numeric key is 
 *                           pressed, the menu function returns with IdSelected  = 
 *                           Bit 15:    1 means Numeric key pressed
 *                           Bit 14-0:  Value of the pressed key(for 0 to 9)
 *                           Bit 15:    0 normal selection option
 *                           Bit 14-0:  ID of the selected option
 *                        3. If disable numeric keys mode is selected: then numeric keys have 
 *                           no effect
 *                        Values:               LAF_ENABLE_NUMERICKEY_SHORTCUT
 *                                              LAF_ENABLE_NUMERICKEY_RETURN
 *                                              LAF_DISABLE_NUMERICKEY
 *                        Default Value:        LAF_DISABLE_NUMERICKEY
 *                      - Input Format: Specify the format of the input buffer. Today one 
 *                        format is defined the LAF_RESORCESFILE_FORMAT, but in the future
 *                        other formats for the input buffer can be defined
 *                        Values:               LAF_RESORCESFILE_FORMAT
 *                        Default Value:        LAF_RESORCESFILE_FORMAT
 *   - menu        I      buffer containing the content of the menu to draw, in
 *                        the format returned by UC32 function "amgModuleGet()"
 *   - idStartUp   I      Index of the menu item on which the focus will be positioned at the 
 *                        start of this function
 *                        This value can be LAF_STARTUP_ID_DISABLED, which means that there
 *                        no id pre-selected, and the focus will be on the first item of the 
 *                        first menu level
 *   - timeOut      I     time in 10 ms, for which to wait between 2 key pressed, before returning
 *                        LAF_ERR_TIMEOUT. A value 0 or LAF_INFINITE_TIMEOUT causes the function 
 *                        to wait forever.
 *   - idSelected  O      Selected ID from the menu. 
 *                        Normally this value is on 16 bits. But if LAF_ENABLE_NUMERICKEY_RETURN
 *                        is set in the input parameter inputFlags, the idSelected field will 
 *                        be organized this way:
 *                        Bit 15:       1 means Numeric key pressed
 *                        Bit 14-0:     Value of the pressed key(for 0 to 9)
 *                        Bit 15:       0 normal selection option
 *                        Bit 14-0:     ID of the selected option
 *                        This value can be:
 *                          LAF_ANNUL, which means that the user quits the menu by cancel,
 *                          without any choice.
 *                          LAF_PRINT, which means that the user quits the menu by pressing 
 *                          the "Function key button.
 *
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermListSelect(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, int16 iStartUp, uint32 timeOut, int16 *iSelected);
/*****************************************************************************
 * Description:
 * The List Select function is a function which receives in input a buffer containing the
 * list of lines to draw, and in output, it will return the ID of the selected line.
 * This function displays the list:
 *  	The Title is displayed centered on the first line
 *  	The Lines are displayed on the next lines, one String for each line
 *  	By default the focus is on the String which index is given in entry (iStartUp)
 *
 * Parameters:      I/O Description
 *   - outputHandle I   the output handle
 *   - inputHandle  I   the input handle
 *   - inputFlags   I   Defines the input mode. OR of the following available modes:
 *                  	- Input Device: Indicate if the function uses the Keyboard or the 
 *                        Touch Screen device
 *                  	  Values:		      LAF_KEYBOARD
 *                                        LAF_TOUCHSCREEN
 *                  	  Default Value:		LAF_KEYBOARD
 *	                    - Print Key: This mode enables or no to exit the function when the
 *                        "Function Key" is pressed:
 *                        1. If it is enabled: when the "Function Key" is pressed, the menu 
 *                           function returns with iSelected  = LAF_PRINT
 *                        2. If it is not enabled: the "Function Key" has no effect
 *                     	  Values:		         LAF_ENABLE_PRINTKEY
 *                                              LAF_DISABLE_PRINTKEY
 *                        Default Value:		LAF_DISABLE_PRINTKEY
 *                      - Numeric Keys: This mode enables the numeric keys entry:
 *                        1. If numeric keys shortcut mode is selected: when a numeric key is
 *                           pressed,the focus is moved automatically to its corresponding line:
 *                           Key 1 for Line 1
 *                           Key 2 for Line 2
 *                           ...    
 *                           Key 9 for Line 9
 *                           Shortcut numeric keys are only available for lines 1 to 9
 *                        2. If numeric keys return mode is selected: when a numeric key is 
 *						           pressed, the menu function returns with iSelected  = 
 *                           Bit 15:	1 means Numeric key pressed
 *                           Bit 14-0:	Value of the pressed key(for 0 to 9)
 *                           Bit 15:	0 normal selection option
 *                           Bit 14-0:	ID of the selected option
 *                        3. If disable numeric keys mode is selected: then numeric keys have 
 *                           no effect
 *	                          Values:         	LAF_ENABLE_NUMERICKEY_SHORTCUT
 *                                              LAF_ENABLE_NUMERICKEY_RETURN
 *                                              LAF_DISABLE_NUMERICKEY
 *	                          Default Value:		LAF_DISABLE_NUMERICKEY
 * 	                  - Input Format: Specify the format of the input buffer. Today one 
 *                        format is defined the LAF_FORMAT1, but in the future other formats
 *                        for the input buffer can be defined
 *	                       Values:		        LAF_FORMAT1
 *	                       Default Value:		  LAF_FORMAT1
 *   - title       I      title of the list
 *   - lines       I      buffer containing the content of the lines to draw, each line is a 
 *                        null terminated string, the buffer is terminated by two null 
 *                        characters.
 *                        For example: "HELLO\0WORLD\0\0" will be displayed like this:
 *                                       HELLO
 *                                       WORLD
 *   - iStartUp    I      Index of the line on which the focus will be positioned at the start
 *                        of this function
 *                        This value can be LAF_STARTUP_ID_DISABLED, which means that there
 *                        no id pre-selected line, and the focus will be on the first line of the 
 *                        list
 *   - timeOut     I      time in 10 ms, for which to wait between 2 key pressed, before returning
 *                        LAF_ERR_TIMEOUT. A value 0 or LAF_INFINITE_TIMEOUT causes the function 
 *                        to wait forever.
 *   - iSelected   O      Selected line index 
 *                        Normally this value is on 16 bits. But if LAF_ENABLE_NUMERICKEY_RETURN
 *                        is set in the input parameter inputFlags, the iSelected field will 
 *                        be organized this way:
 *                        Bit 15:		 1 means Numeric key pressed
 *                        Bit 14-0:	    Value of the pressed key(for 0 to 9)
 *                        Bit 15:		 0 normal selection option
 *                        Bit 14-0:	    ID of the selected option
 *                        This value can be:
 *                         	LAF_ANNUL, which means that the user quits the menu by cancel,
 *                            without any choice.
 *	                           LAF_PRINT, which means that the user quits the menu by pressing 
 *                            the "Function key button.
 *
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermListDisplay( uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *lines, uint32 timeOut, int16 *response);
/*****************************************************************************
 * Description:
 * The List Display function is a function which receives in input a buffer containing the 
 * list of lines to draw. The user can visualize the list, can scroll up and down without 
 * any selection. This function will be used for example to display the configuration 
 * tickets of the System Menu.
 * This function displays the list
 *	 The Title is displayed centered on the first line
 *	 The Lines are displayed on the next lines, one String for each line
 *
 * Parameters:      I/O Description
 *   - outputHandle I   the output handle
 *   - inputHandle  I   the input handle
 *   - inputFlags   I   Defines the input mode. OR of the following available modes:
 *                  	- Input Device: Indicate if the function uses the Keyboard or the 
 *                        Touch Screen device
 *                  	  Values:		        LAF_KEYBOARD
 *                                              LAF_TOUCHSCREEN
 *                  	  Default Value:		LAF_KEYBOARD
 *	                    - Print Key: This mode enables or no to exit the function when the
 *                        "Function Key" is pressed:
 *                        1. If it is enabled: when the "Function Key" is pressed, the menu 
 *                           function returns with response  = LAF_PRINT
 *                        2. If it is not enabled: the "Function Key" has no effect
 *                     	  Values:		        LAF_ENABLE_PRINTKEY
 *                                              LAF_DISABLE_PRINTKEY
 *                        Default Value:		LAF_DISABLE_PRINTKEY
 *                      - Numeric Keys: No effect
 *  	                - Input Format: Specify the format of the input buffer. Today one 
 *                        format is defined the LAF_FORMAT1, but in the future
 *                        other formats for the input buffer can be defined
 *	                      Values:		        LAF_FORMAT1
 *	                      Default Value:		LAF_FORMAT1
 *   - title       I      title of the list
 *   - lines       I      buffer containing the content of the lines to draw, each line is a 
 *                        null terminated string, the buffer is terminated by two null 
 *                        characters.
 *                        For example: "HELLO\0WORLD\0\0" will be displayed like this:
 *                                       HELLO
 *                                       WORLD
 *   - timeOut     I      time in 10 ms, for which to wait between 2 key pressed, before returning
 *                        LAF_ERR_TIMEOUT. A value 0 or LAF_INFINITE_TIMEOUT causes the function 
 *                        to wait forever.
 *   - response    O      This value can be:
 *                         	LAF_ANNUL, which means that the user quits the menu by cancel,
 *                          without any choice.
 *	                        LAF_PRINT, which means that the user quits the menu by pressing 
 *                          the "Function key button.
 *                          LAF_VALID
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermMessageBox(uint32 outputHandle, uint32 inputHandle, uint32 inputFlags, char *title, char *message, uint32 timeOut, int16 *response);
/*****************************************************************************
 * Description:
 * The Message Box function is a function which receives in input a buffer containing a 
 * message to display. It displays the message and waits for a keyboard entry (Valid key or 
 * Cancel Key) to end. After the key entry, it clears the screen. This function will
 * be used each time an application wants to display a message. 
 * It can be an error message, a warning message, a question message or an information message. 
 *
 * Parameters:      I/O Description
 *   - outputHandle I   the output handle
 *   - inputHandle  I   the input handle
 *   - inputFlags   I   Defines the input mode. OR of the following available modes:
 *                      - Input Device: Indicate if the function uses the Keyboard or the 
 *                        Touch Screen device
 *                        Values:               LAF_KEYBOARD
 *                                              LAF_TOUCHSCREEN
 *                        Default Value:        LAF_KEYBOARD
 *                      - Print Key: No effect
 *                      - Numeric Keys: No effect
 *                      - Input Format: Specify the format of the input buffer. 
 *                        Values:               LAF_MESSAGE_QUESTION_FORMAT
 *                                              LAF_MESSAGE_INFORMATION_FORMAT
 *                                              LAF_MESSAGE_ERROR_FORMAT
 *                                              LAF_MESSAGE_WARNING_FORMAT
 *                        Default Value:        LAF_MESSAGE_QUESTION_FORMAT
 *   - title        I     the title of the message
 *   - message      I     buffer containing the message to display
 *   - timeOut      I     time in 10 ms, for which to wait between 2 key pressed, before returning
 *                        LAF_ERR_TIMEOUT. A value 0 or LAF_INFINITE_TIMEOUT causes the function 
 *                        to wait forever.
 *   - response     O     This value can be:
 *                        When Input Format is equal: LAF_MESSAGE_QUESTION_FORMAT
 *                                                    LAF_VALID or LAF_CANCEL
 *                        When Input Format is equal: LAF_MESSAGE_INFORMATION_FORMAT
 *                                                    LAF_VALID
 *                        When Input Format is equal: LAF_MESSAGE_ERROR_FORMAT
 *                                                    LAF_VALID
 *                        When Input Format is equal: LAF_MESSAGE_WARNING_FORMAT
 *                                                    LAF_VALID
 *                        When Input Format is equal: LAF_MESSAGE_QUESTION_FORMAT
 *                                                    LAF_VALID
 *
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*********************************************************************/
//int16 lafTermSecuredInput(uint32 outputHandle, uint32 inputHandle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
/**++*********************************************************************
 * Description:  tlsSecInput
 *    This function perform the secured entry
 *
 * Parameters  IN:
 *       -  pssaSecInput  : structure with parameters of the input
 *       -  pssaSecOutput : strucure for output result
 *       -  outputHandle  : output handle
 *       -  inputHandle   : input handle
 *
 * Parameters OUT:
 *       -  pssaSecOutput:  structure with  result of the input
 *
 * Returns:
 *       -  RET_OK
 *       -  ERR_USER_CANCEL_KEY
 *       -  ERR_USER_COR_KEY
 *       -  ERR_APPLICATIVE_CANCEL
 *       -  ERR_SYS_INTERNAL_ERROR_2
 *       -  ERR_TIMEOUT_INTER_KEY
 *       -  ERR_TIMEOUT_FIRST_KEY
 *       -  ERR_USER_FCT_KEY_PRESSED
 *
 *********************************************************************--*/

/**++*************************************************************************/
// int16 lafTermMessageShow(uint32 winHandle, uint32 inputFlags, char *title, char *message, uint32 timeOut);
/*****************************************************************************
 * Description:
 * The Message Show function is a function which receives in input a buffer containing a 
 * message to display. It displays the message during the given timeOut.It will be used each 
 * time an application wants to display a message. 
 * It can be an error message, a warning message or an information message. 
 *
 * Parameters:      I/O Description
 *   - winHandle    I   the HMI handle
 *   - inputFlags   I   Defines the input mode. OR of the following available modes:
 *                      - Input Device: Indicate if the function uses the Keyboard or the 
 *                        Touch Screen device
 *                        Values:               LAF_KEYBOARD
 *                                              LAF_TOUCHSCREEN
 *                        Default Value:        LAF_KEYBOARD
 *                      - Print Key: No effect
 *                      - Numeric Keys: No effect
 *                      - Input Format: Specify the format of the input buffer. 
 *                        Values:               LAF_MESSAGE_INFORMATION_FORMAT
 *                                              LAF_MESSAGE_ERROR_FORMAT
 *                                              LAF_MESSAGE_WARNING_FORMAT
 *                        Default Value:        LAF_MESSAGE_INFORMATION_FORMAT
 *   - title        I     the title of the message
 *   - message      I     buffer containing the message to display
 *   - timeOut      I     timeout of the message display in 10ms.This value can be:
 *                                              0 means "no wait"
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*********************************************************************/
// int16 lafTermBackLightOnWindow(uint32 winHandle);
/*************************************************************************
 * Description:
 *	- This function sets the back light On 
 *
 * Parameters:         I/O    Description
 *   - winHandle       I      the HMI handle
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*********************************************************************/
// int16 lafTermBackLightOffWindow(uint32 winHandle);
/*************************************************************************
 * Description:
 *	- This function sets the back light Off 
 *
 * Parameters:         I/O    Description
 *   - winHandle       I      the HMI handle
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*********************************************************************/
// int16 lafTermADDisplayText (uint32 winHandle, uint32 line, uint32 column, char *text);
/*************************************************************************
 * Description:
 *  - This function display a text on screen
 *
 * Parameters:         
 *          - line: line to display on
 *          - column: column to display on
 *          - *text: text to display
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*********************************************************************/
// int16 lafTermADClearLine(uint32 winHandle, uint16 line);
/*************************************************************************
 * Description:
 *  - This function clears the specified line, or all the display if line is equal to
 *    'LAF_ALL_LINES'
 *
 * Parameters:         I/O    Description
 *   - winHandle       I      handle of the channel
 *   - line            I      the number of the line to clear
 *                              - The first line number of the display is 0 
 *                              - When 'line' is LAF_ALL_LINES, all the display is cleared
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*************************************************************************/
// int16 lafTermWindowDim(uint32 winHandle, int16 *windowWidth, int16 *windowHeight);
/*****************************************************************************
 * Description:
 *  This function reads and returns the dimensions of the given window
 *
 * Parameters:                  I/O    Description
 *   - winHandle                I      the HMI handle
 *   - windowWidth              O      pointer on the window width
 *   - windowWidth              O      pointer on the window height
 *
 * Returns:
 *
 **************************************************************************--*/

/**++*********************************************************************/
// int16 lafTermADFont (uint32 handle, void const *font);
/*************************************************************************
 * Description:
 *  - This function sets the font. 
 *
 * Parameters:         I/O    Description
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*************************************************************************/
// int16 lafTermCfgBackLight(uint32 handle, uint8 mode, lafBackLight_t *pLafBackLight);
/*****************************************************************************
 * Description:
 *  This function allows the user to gain access to the backlight to update it. Update value 
 *  become the default value
 *
 * Parameters:                  I/O    Description
 *   - mode                     I      indicates LAF_CFG_READ_MODE or LAF_CFG_WRITE_MODE access
 *   - pLafBackLight            I/O    pointer to lafBackLight_t structure to be updated with 
 *                                     the current value in mode read, or containing the value
 *                                     of the backlight to set in mode write
 *                                     Value = %   backlight (0 to 100)
 *
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermCfgContrast(uint32 handle, uint8 mode, lafContrast_t *pLafContrast);
/*****************************************************************************
 * Description:
 *  This function allows the user to gain access to the contrast to update it. Update value 
 *  become the default value
 *
 * Parameters:                  I/O    Description
 *   - mode                     I      indicates LAF_CFG_READ_MODE or LAF_CFG_WRITE_MODE access
 *   - pLafContrast             I/O    pointer to lafContrast_t structure to be updated with 
 *                                     the current value in mode read, or containing the value
 *                                     of the contrast to set in mode write
 *                                     Value = %   contrast (0 to 100)
 *
 * Returns:
 *   - RET_OK
 *   - Error
 *
 **************************************************************************--*/

/**++*************************************************************************/
// int16 lafTermConfigRead(uint32 handle, lafConfig_t type, uint16 *plength, void *pBuffer);
/*****************************************************************************
 * Description:
 *  This function allows the user to read the configuration of the devices configuration. It can 
 *  be the keyboard, the display or the touch device.
 *
 * Parameters:              I/O    Description
 *   - handle               I      handle of the channel
 *   - type                 I      indicates which information device is required. The following
 *                                 values can be used:
 *                                      typedef enum
 *                                      {
 *                                         LAF_CFG_KEYBOARD,
 *                                         LAF_CFG_DISPLAY,
 *                                         LAF_CFG_TOUCH
 *                                      }lafConfig_t;
 *   - plength              I      the size (in bytes) of the buffer provided by the caller
 *                                 (for the data to be copied into)
 *                          O      the returned buffer size
 *
 *   - pBuffer              O      the buffe to be updated with the desired configuration. The
 *                                 type of the data pointed by 'pBuffer' depends on the value of
 *                                 'type', according to the following table:
 *           
 *
 *         |       type             |       length         |          pBuffer              | 
 *         -----------------------------------------------------------------------------
 *         |    LAF_CFG_KEYBOARD    |   LAF_KEYBOARD_SIZE  |   pointer to lafKeyboard_t    |
 *         |    LAF_CFG_DISPLAY     |   LAF_DISPLAY_SIZE   |   pointer to lafDisplay_t     |
 *         |    LAF_CFG_TOUCH       |   LAF_TOUCH_SIZE     |   pointer to lafTouch_t       |
 *
 *
 * Returns:
 *   - RET_OK
 *   - LAF_ERR_INVALID_INPUT_PARAMETERS
 *   - error returned from hmiOutputConfigRead, hmiInputConfigRead or hmiTouchConfigRead
 *
 **************************************************************************--*/

/**++*********************************************************************/
// int16 lafTermSetModeReverseVideo(uint32 handle);
/*************************************************************************
 * Description:
 *  - This function sets the reverse video mode to the HMI already opened. 
 *
 * Parameters:         I/O    Description
 *
 * Returns:
 *
 **********************************************************************--*/

/**++*********************************************************************/
// int16 lafTermSetModeNormalVideo(uint32 handle);
/*************************************************************************
 * Description:
 *  - This function sets the normal video mode to the HMI already opened. 
 *
 * Parameters:         I/O    Description
 *
 * Returns:
 *
 **********************************************************************--*/


#ifdef __cplusplus
}
#endif

#endif /* __lafFunctions_H */

/*
 * End of File lafFunctions.h
 */

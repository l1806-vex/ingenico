/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT        :    SSA application
 *  FILEMANE       :    lafTypes.h
 *  PURPOSE        :    Generic defines,structures and includes for LAF
 *
 *  HISTORY
 *  date         author     modifications
 *  2003-09-03   MAB        creation
 *  2004-06-22   AMO        add LAF_ERR_UNKNOWN_PINPAD
 *	 2005-02-09	  DHU		    add LAF_LIB_VERSION_SIZE to indicate the size of the string for "lafGetApiVersion"
 *                          add error definition
 *  2006-01-03   FCL        Re-organisation of LAFs
 *  2006-04-13   TLC        Merged with CWEI's changes on 2006-03-21.
 *  2006-11-15   ROM        LAF_DEFINE_GRAPHIC, LAF_FILL_GRAPHIC and LAF_DRAW_GRAPHIC defines added
 *  2006-11-24   FCL        Modifications to manage Font by OS
 *
 * --------------------------------------------------------------------------
 *  PLEASE USE 3 CHAR. TABULATIONS
-*/

#ifndef __lafTypes_H
#define __lafTypes_H

#ifdef __cplusplus
extern "C" {
#endif

/*+++******* INCLUDES ***********************---*/
#include <hmi.h>
#include <ssamsaCommon.h>


/*+++******* CONDITIONAL SSA/MSA DEFINE ***********************---*/
#ifdef	LAF_MSA
#define	IDS_ERROR_SUBMENU	"Too much Submenu"
#endif
#ifdef	LAF_SSA
#endif


/*+++******* INTERNAL GLOBAL #DEFINE CONSTANTS ***********************---*/

#define LAF_LIB_VERSION_SIZE					17

//Generic Defines
#define LAF_INFINITE_TIMEOUT        		PSY_INFINITE_TIMEOUT
#define LAF_ALL_LINES							HMI_ALL_LINES
#define LAF_ON										TRUE
#define LAF_OFF									FALSE
#define LAF_CANCEL_EVENT             		0x00000200

// Error Codes
#define LAF_ID										100
#define LAF_ERROR_START                   (PERIPHERAL_ERROR_START - LAF_ID*ERROR_SLOT_SIZE)
#define LAF_ERR_INVALID_INPUT_PARAMETERS  (LAF_ERROR_START - 0x00)    // 0x8C00
#define LAF_ERR_TIMEOUT                   (LAF_ERROR_START - 0x01) 	// 0x8BFF
#define LAF_ERR_UNKNOWN_PINPAD            (LAF_ERROR_START - 0x02)	// 0x8BFE
#define LAF_ERR_NO_PINPAD                 (LAF_ERROR_START - 0x03)	// 0x8BFD
#define LAF_ERR_SYS                       (LAF_ERROR_START - 0x04)	// 0x8BFC
#define LAF_ERR_PPAD_REPLY                (LAF_ERROR_START - 0x05)	// 0x8BFB
#define LAF_ERR_PARAMETERS_KEYBOARD       (LAF_ERROR_START - 0x06)	// 0x8BFA
#define LAF_ERR_PARAMETERS_PRINT_KEY      (LAF_ERROR_START - 0x07)	// 0x8BF9
#define LAF_ERR_PARAMETERS_NUMERIC_KEY    (LAF_ERROR_START - 0x08)	// 0x8BF8
#define LAF_ERR_PARAMETERS_INPUT_FORMAT   (LAF_ERROR_START - 0x09)	// 0x8BF7
#define LAF_ERR_PARAMETERS_ID_START_UP    (LAF_ERROR_START - 0x0A)	// 0x8BF6

// define for lafOpen
#define OVER_DISPLAY    						0
#define DEFAULT_DISPLAY 						1
#define ALWAYS_DISPLAY  						2

//Key Defines
#define LAF_ANNUL									0x7FFF
#define LAF_PRINT									0x7FFE
#define LAF_VALID									0x7FFD

//Input Device
#define LAF_KEYBOARD								0x00000000
#define LAF_TOUCHSCREEN							0x00000001

//Print Key
#define LAF_DISABLE_PRINTKEY					0x00000000
#define LAF_ENABLE_PRINTKEY					0x00000010

//Numeric Keys
#define LAF_DISABLE_NUMERICKEY				0x00000000
#define LAF_ENABLE_NUMERICKEY_RETURN    	0x00000100
#define LAF_ENABLE_NUMERICKEY_SHORTCUT  	0x00000200

//Input Format
#define LAF_RESOURCESFILE_FORMAT        	0x00000000
#define LAF_FORMAT1                     	0x00000000

//Input Format for lafMessageBox() and lafMessageShow()
#define LAF_MESSAGE_QUESTION_FORMAT     	0x00000000
#define LAF_MESSAGE_INFORMATION_FORMAT  	0x00001000
#define LAF_MESSAGE_ERROR_FORMAT        	0x00002000
#define LAF_MESSAGE_WARNING_FORMAT      	0x00003000

//Menu and List Select Start Up Id desactivation
#define LAF_STARTUP_ID_DISABLED         	0xFFFF


// Menu limitations
/////////////////////// LAF NAR ////////////////////////
#ifdef LAF_VIRTUAL_KEYPAD
#define LAF_MAX_ELEMENTS_MENU_LEVEL     	100		// This value matches the ssaSec value (P.B.Wischow).
// (CWEI) This is "too" short for the I6770!!!
// (CWEI) #define LAF_MAX_LENGTH_ELEMENT_MENU
#define LAF_MAX_LENGTH_ELEMENT_MENU			41  		// max length of menu items
#define LAF_MAX_MENU_LINES_NUMBER    		100  		// max number of lines in a menu level
// (CWEI) This is "too" short for the I6770!!!
// (CWEI) #define LAF_MAX_MENU_LINE_LENGTH     	   24  // max length of a line in a menu
#define LAF_MAX_MENU_LINE_LENGTH     		40  		// max length of a line in a menu
#define LAF_NB_SUB_MENU		            	5   		// max number of sub menus in a menu
/////////////////////// END LAF NAR ////////////////////////
#else
/////////////////////// LAF STANDARD ////////////////////////
#define LAF_MAX_ELEMENTS_MENU_LEVEL     	100		// This value matches the ssaSec value (P.B.Wischow).
#define LAF_MAX_LENGTH_ELEMENT_MENU			25  		// max length of menu items
#define LAF_MAX_MENU_LINES_NUMBER    		20  		// max number of lines in a menu level
#define LAF_MAX_MENU_LINE_LENGTH     		24  		// max length of a line in a menu
#define LAF_NB_SUB_MENU		            	5   		// max number of sub menus in a menu
/////////////////////// END LAF STANDARD ////////////////////////
#endif


// List limitations
/////////////////////// LAF NAR ////////////////////////
#ifdef LAF_NAR
#define LAF_MAX_LIST_LINES_NUMBER			150 		// max number of lines in a list
/////////////////////// END LAF NAR ////////////////////////
#else
/////////////////////// LAF STANDARD ////////////////////////
#define LAF_MAX_LIST_LINES_NUMBER			100 		// max number of lines in a list
/////////////////////// END LAF STANDARD ////////////////////////
#endif


// Mesage Box and Show Limitation
#define LAF_MAX_MESSAGE_LINE_SIZE			100

// Max Size for font copyright
#define LAF_MAX_FONT_COPYRIGHT_SIZE       100

//Laf Config
#define LAF_CFG_WRITE_MODE						0
#define LAF_CFG_READ_MODE						1


// BackLight and Contrast Cfg
/////////////////////// LAF NAR ////////////////////////
#ifdef LAF_COLOR_SCREEN
#define LAF_BACKLIGHT_SIZE						1  /*to be define later*/
#define LAF_CONTRAST_SIZE						1  /*to be define later*/
/////////////////////// END LAF NAR ////////////////////////
#else
/////////////////////// LAF STANDARD ////////////////////////
#define LAF_BACKLIGHT_SIZE						HMI_DISPLAY_1_BACKLIGHT_SIZE
#define LAF_CONTRAST_SIZE						HMI_DISPLAY_1_CONTRAST_SIZE
/////////////////////// END LAF STANDARD ////////////////////////
#endif


//Generic Defines
#define LAF_HIDDEN_MENU			   			0
#define LAF_MAIN_MENU      					1
#define LAF_SUB_MENU       					2
#define LAF_DISP_LIST      					3
#define LAF_APPL_LIST      					4
#define LAF_DATAENTRY1_MENU					5	// Added for SAT-1 support (PBW), see comments below.
#define LAF_DATAENTRY2_MENU					6	// Added for SAT-1 support (PBW), see comments below.
#define LAF_YESNOCANCEL_MENU	   			7	// Added for SAT-1 support (PBW), see comments below.
#define LAF_YESNO_MENU			   			8	// Added for SAT-1 support (PBW), see comments below.
#define LAF_NO_MENU              			9
#define LAF_CANCEL_MENU         				10
#define LAF_OKCANCEL_MENU       				11
#define LAF_ACKNOWLEDGE_MENU    				12
#define LAF_MENUSELECT_MENU     				13
#define LAF_LISTSELECT_MENU     				14
#define LAF_LISTDISPLAY_MENU    				15
#define LAF_KEYPAD_MENU         				16  //PINpad, used for virtual keypad data entry
#define LAF_KEYBOARD_MENU       				17  //used for
#define LAF_USERDEFINED_MENU    				18  // Used to implement "function" keys.
#define LAF_CONTRAST_MENU       				19
#define LAF_SIGCAP_MENU         				20


//Device types
#define LAF_DEVICE_TYPE_NONE					HMI_DEVICE_TYPE_NONE
#define LAF_DEVICE_TYPE_GRAPHIC_DISPLAY   HMI_DEVICE_TYPE_GRAPHIC_DISPLAY
#define LAF_DEVICE_TYPE_TEXT_DISPLAY      HMI_DEVICE_TYPE_TEXT_DISPLAY
#define LAF_DEVICE_TYPE_KEYBOARD          HMI_DEVICE_TYPE_KEYBOARD
#define LAF_DEVICE_TYPE_BUZZER            HMI_DEVICE_TYPE_BUZZER
#define LAF_DEVICE_TYPE_TOUCH_SCREEN      HMI_DEVICE_TYPE_TOUCH_SCREEN


// Exported Function for Pinpad
#define LAF_MENU_SELECT    					0x20
#define LAF_LIST_SELECT    					0x21
#define LAF_LIST_DISPLAY   					0x22
#define LAF_MESSAGE_BOX    					0x23
#define LAF_MESSAGE_SHOW   					0x24
#define LAF_AD_FONT        					0x25
#define LAF_BACKLIGHTOFFWINDOW				0x26
#define LAF_BACKLIGHTONWINDOW					0x27
#define LAF_WINDOW_DIM							0x28
#define LAF_PIN_CONFIG							0x29
#define LAF_DEFINE_GRAPHIC						0x2A
#define LAF_FILL_GRAPHIC						0x2B
#define LAF_DRAW_GRAPHIC						0x2C
#define LAF_WRITE_FONT							0x2D
#define LAF_SELECT_DIS_FONT					0x2E
#define LAF_SELECT_PRN_FONT					0x2F


//Generic key entry functions
#define LAF_INPUTDEVICE_MASK					0x0000000F
#define LAF_PRINTKEY_MASK			   		0x000000F0
#define LAF_NUMERICKEY_MASK			 		0x00000F00
#define LAF_INPUTFORMAT_MASK					0x0000F000
#define LAF_NUMERCKEY_RETURN_MASK	   	0x8000
// Mask corKeyAction byte
#define SSA_SEC_KEY_BCKSP_BIT             BIT_MASK(0)
#define SSA_SEC_KEY_CLEAR_BIT             BIT_MASK(1)
#define SSA_SEC_BCKSP_NO_KEY_BIT          BIT_MASK(2)
#define SSA_SEC_BCKSP_DISABLED_KEY_BIT    BIT_MASK(3)
// Mask parameters1 byte
#define SSA_SEC_KEY_00_PT_BIT             BIT_MASK(0)
#define SSA_SEC_KEY_CLICK_BIT             BIT_MASK(1)
// Mask endKey byte
#define SSA_SEC_KEY_ENTER_AUTH_BIT        BIT_MASK(0)
#define SSA_SEC_OTHER_KEYS_AUTH_BIT       BIT_MASK(1)
#define SSA_SEC_FIRST_FCT_KEY_BIT         BIT_MASK(2)
#define SSA_SEC_FIRST_ENTER_KEY_BIT       BIT_MASK(3)
// Mask font bytes
#define SSA_SEC_DISP_BOLD_BIT             BIT_MASK(0)
#define SSA_SEC_DISP_DOUBLE_HEIGHT_BIT    BIT_MASK(1)
#define FONT_RAM_MSK                      0x08
// Mask for direction byte
#define SSA_SEC_DIRECTION_BIT             BIT_MASK(0)


//define for Key Entry errors
#define SEC_INPUT_ERROR_START       		-1000                      //0xFC18
#define ERR_USER_CANCEL             		(SEC_INPUT_ERROR_START-1)  //0xFC17
#define ERR_USER_COR                		(SEC_INPUT_ERROR_START-2)  //0xFC16
#define ERR_APPLICATIVE_CANCEL      		(SEC_INPUT_ERROR_START-3)  //0xFC15
#define ERR_TIMEOUT_FIRST_KEY       		(SEC_INPUT_ERROR_START-4)  //0xFC14
#define ERR_TIMEOUT_INTER_KEY       		(SEC_INPUT_ERROR_START-5)  //0xFC13
#define ERR_USER_CANCEL_KEY         		(SEC_INPUT_ERROR_START-6)  //0xFC12
#define ERR_USER_COR_KEY            		(SEC_INPUT_ERROR_START-7)  //0xFC11
#define ERR_USER_FCT_KEY_PRESSED    		(SEC_INPUT_ERROR_START-8)  //0xFC10
#define ERR_SYS_INTERNAL_ERROR_1    		(SEC_INPUT_ERROR_START-9)  //0xFC0F
#define ERR_SYS_INTERNAL_ERROR_2    		(SEC_INPUT_ERROR_START-10) //0xFC0E
#define ERR_USER_ENTER_KEY_PRESSED  		(SEC_INPUT_ERROR_START-11) //0xFC0D // DO NOT ADD NEW ERRORS AFTER


// define for menu
#define LAF_END_PAGE								0
#define LAF_NO_END_PAGE_UP		  				1
#define LAF_NO_END_PAGE_DOWN					2
#define LAF_MENU									0
#define LAF_LIST									1


// define for Bitmaps
#define LAF_BMAP_WIDTH							18
#define LAF_BMAP_HEIGHT							18
#define KEY_ARROW_WIDTH         				5
#define KEY_ARROW_HEIGHT        				5


// define for beep
#define LAF_DEFAULT_KEYBEEP_STATE			TRUE
#define LAF_DEFAULT_KEYBEEP_LEN				HMI_BEEP_CLICK
#define LAF_DEFAULT_KEYBEEP_FREQ				HMI_BEEP_MIDTONE
//cwei added, define for invalid key beep
#define LAF_DEFAULT_INVALIDKEYBEEP_STATE	TRUE
#define LAF_DEFAULT_INVALIDKEYBEEP_LEN		HMI_BEEP_LONG
#define LAF_DEFAULT_INVALIDKEYBEEP_FREQ		HMI_BEEP_HIGH

// define for backlight
#ifdef  WIN32
#define LAF_BACKLITE_ALWAYS_ON				0xFFFFFFFFFFFFFFFF
#else
#define LAF_BACKLITE_ALWAYS_ON				0xFFFFFFFFFFFFFFFFull
#endif
#define LAF_BACKLITE_ALWAYS_OFF				0x00
#define LAF_DEFAULT_BACKLITE_TMO				LAF_BACKLITE_ALWAYS_ON


// macros
#define LAF_KEYPAD_MASK							0x00000001
#define LAF_TOUCH_MASK							0x00000002
#define LAF_COLOR_MASK							0x00000004
#define LAF_DEVICE_HAS_KEYPAD(deviceCharMask) ( (deviceCharMask&LAF_KEYPAD_MASK)?TRUE:FALSE )
#define LAF_DEVICE_HAS_TOUCH(deviceCharMask)  ( (deviceCharMask&LAF_TOUCH_MASK)?TRUE:FALSE )
#define LAF_DEVICE_HAS_COLOR(deviceCharMask)  ( (deviceCharMask&LAF_COLOR_MASK)?TRUE:FALSE )
#define LAF_BITSET(val,mask) ((val) |= mask)


/*+++******* GLOBAL STRUCTURES DEFINITION ***********************---*/
#define ssaSecInput_t ssaSecDispKbdInput_t
#define ssaSecInput_adv_t ssaSecDispKbdInput_adv_t
typedef struct
{
   uint32 wx;                          // X offset within device
   uint32 wy;                          // Y offset within device
   uint32 wwidth;                      // Width of window
   uint32 wheight;                     // Height of window
}lafResolution_t;

typedef struct
{
   uint32            keyboardType;     // One of LAF_DEVICE_TYPE_...
}lafKeyboard_t;

typedef struct
{
   uint32            displayType;     // One of LAF_DEVICE_TYPE_...
   lafResolution_t   displayResolution;
}lafDisplay_t;

typedef struct
{
   uint32            touchType;     // One of LAF_DEVICE_TYPE_...
   lafResolution_t   touchResolution;
}lafTouch_t;

typedef enum
{
   LAF_CFG_KEYBOARD,
   LAF_CFG_DISPLAY,
   LAF_CFG_TOUCH
}lafConfig_t;

// This solution (fixed size struct) has been choosen to avoid
// the implementation a parser for the reception and transmission
// buffer. It reduces the code size.
//
typedef struct
{
	uint32	ui32InputFlags,
			ui32TimeOut;
	int16	i16IdStartUp;
}lafMenuSelect_t;

typedef struct
{
    uint8   col;
    uint8   font;
    char    text[40];
}dispLine_t;

typedef struct
{
    uint8   backlight[LAF_BACKLIGHT_SIZE];
} lafBackLight_t;

typedef struct
{
    uint8   contrast[LAF_CONTRAST_SIZE];
} lafContrast_t;

typedef struct
{
    //Calculated fields
    uint32           inputHdle;
    uint32           outputHdle;
    Canvas           *pCanvas;
    GC               *pGc;
    uint16           nbLines;
    uint8            titlePresent;
    uint32           printKey;
    uint32           numericKey;
    int16            wwidth;          // Width of window
    int16            wheight;         // Height of window
	 uint8   			autoCentreState; // Off=FALSE, On=TRUE.
} calculatedMenuParameters_t;

typedef struct
{
    bool        initFlag;        //laf support data has been initialized or not
    //int16       nbMenuLines;
    int16       wwidth;          // Width of window
    int16       wheight;         // Height of window
    uint8       autoCentreState; // Off=FALSE, On=TRUE.
    uint32      deviceCharMask;
    uint8       deviceId[6];
    void *      fontId;
    uint8       bppSetting;      //bppSetting, HMI_BPP_1 or HMI_BPP_8
    Color       foregroundColor;
    Color       backgroundColor;
    uint8       enableBeepOnKey;
    uint32      beepLenOnKey;
    uint32      beepToneOnKey;
    uint8       enableBeepOnInvalidKey;   //enable/disable invalid key beep
    uint32      beepLenOnInvalidKey;      //invalid key beep length
    uint32      beepToneOnInvalidKey;     //invalid key beep frequency.    
    uint8       backlight;
    uint64      backlightTmo;
    uint8       contrast;
    uint8       titlePresent;    // Copied from "calculatedMenuParameters_t"
    uint32      printKey;        // for compatibility.
    uint32      numericKey;      // This one also (PBW).
    uint8       keyUp;           // These are
    uint8       keyDown;         // populated from
    uint8       keyPrint;        // the "initKeyboardKeys" function.
}lafCfgData_t;

typedef struct {
	int16 status;
	uint16 length;
	uint8 key;
} keyEntryResult_t;

//cwei added, desclare a multiple key result structure
typedef struct {
	int16 status;
	uint16 length;
	uint8 key[10];
} multiKeyEntryResult_t;

// INPUT STRUCTURE FOR ADVANCED KEYBOARD ENTRY // NEW VERSION FCL 06/03/2006
#define SSASECINPUT_ADV				1

typedef struct
{
	uint8		version;
	uint8		lineNbText1;
	uint8		fontText1;
	uint8		flagText1;
	char		text1[32];
	char		text1alt[32];
	uint8		lineNbText2;
	uint8		fontText2;
	uint8		flagText2;
	char		text2[32];
	uint8		lineNbText3;
	uint8		fontText3;
	uint8		flagText3;
	char		text3[32];
	uint8		lineNbInput;
	uint8		fontInput;
	char		textInput[32];
	uint16	inputFieldDefinition;
	uint16	inputFieldDefinition2;
	uint8		direction;
	uint8		minimumKeys;
	uint8		maximumKeys;
	uint8		endKey;
	char		echoCharacter;
	uint8		parameters1;
	uint8		corKeyAction;
	uint8		timeOutFirstKey;
	uint8		timeOutInterKey;
	char		replacementCharacter;
	char		values[16];
	uint8		beepParameter;
} ssaSecDispKbdInput_adv_t;

#define LAF_KEYBOARD_SIZE						sizeof(lafKeyboard_t)
#define LAF_DISPLAY_SIZE              		sizeof(lafDisplay_t)
#define LAF_TOUCH_SIZE                		sizeof(lafTouch_t)

// TIMER EVENT
#define SECINPUT_TIMER_EVENT_BEEP			EVENT_5
#define SECINPUT_TIMER_EVENT_KEY				EVENT_6


/*+++******* ADDITIONNAL INCLUDES ***********************---*/
#include <lafFunctions.h>
#include <lafPpadFunctions.h>
#include <lafTools.h>

#ifdef __cplusplus
}
#endif

#endif /* __lafTypes_H */


/**************************************************************************
                              Property of INGENICO
 *************************************************************************/
/*+
 *  PROJECT        :    SSA application
 *  MODULE         :
 *  FILEMANE       :    ssa.h
 *  PURPOSE        :    types for SSA
 *
 *  HISTORY
 *
 *  date         author     modifications
 *  2002-11-22   SDV         creation
 *  2002-MAR-05  SJM         Added RET_SSA_GENERIC_SECURITY status code.
 *  2003-07-21   AMO         Change uint32* to uint8* on SSA queue messages
 *  2003-09-15   AMO         Add SSA_SEC_FIRST_KEY_ENTER_BIT and
 *                           ERR_USER_ENTER_KEY_PRESSED definitions
 *  2003-10-18   FTA         add define for ssaSecDispKbdInput_t function (font selection) and a macro for RAM font selection
 *  2003-11-27   FTA         add functions to manage an I2C pin pad (EMVL2 + display + identification request)
 *  2004-06-11   AMO         add ERR_BUFFER_TOO_SMALL and clearly write error values
 *  2004-06-22   AMO         add ssaSecLafConfig function
 *  2004-07-20   AMO         add ssaDwlStartLdm
 *  2004-07-29   FTA         modification of dispLine_t structure
 *  2005-02-24   FTA        ssaConfigurePinPad implementation
 *  2006-01-26   ROM         API Function Prototypes added :
 *                           ssaSecOpenRhmi, ssaSecCloseRhmi,
 *                           ssaSecSendSyncRhmi, ssaSecSendASyncRhmi
 *  2006-10-02   TLC         API Function Prototypes added for IngeTrust:
 *                             ssaDwlTrustConnect, ssaDwlTrustDisconnect,
 *                             ssaDwlTrustDataSend, ssaDwlTrustDataReq.
 *                           Also corrected the KDS_SEND_ASYNC_RHMI define.
 *  2006-11-15   ROM         ssaSecLafDrawGraphic declaration added 
 *                           KDS_DRAW_GRAPHIC added in ssaKdsS01Function_t enum
 *  2007-01-11   ROM         Fonts definition moved here from ssaSec.h 
 * ------------------------------------------------------------------------
 *  DESCRIPTION    :    This file contains prototypes of security function
 *                      embedded in SSA application
 *
-*/

#ifndef SSA_H
#define SSA_H

#include <PSYapp.h>
#include "lafTypes.h"


#ifdef __cplusplus
extern "C" {
#endif

/*+++******* INCLUDES ************************************************---*/

/*+++******* EXPORTED #DEFINE CONSTANTS ******************************---*/
// generals
#define FREE                0x00
#define BUSY                0xFF
#define SSA_WAIT            0x00000200
// this line is equal to "#define SSA_WAIT  EVENT_9", but now, EVEN_9 is no more defined in milltypes.h

// defines for SSA sessions
#define DWL_SESSION         1
#define KDS_SESSION         2

// define of the Type of status we can have
#define START_STATUS_ERROR          -0x5000
#define ERR_SEC_NOT_IMPLEMENTED     START_STATUS_ERROR-1
#define ERR_NO_ASYNC_TASK_LAUNCHED  START_STATUS_ERROR-2
#define ERR_NOT_ENOUGH_MEMORY       START_STATUS_ERROR-3


#define MAX_SSA_MSG_SIZE    300
#define MAX_CFG_MSG_SIZE    300
#define MAX_DWL_MSG_SIZE    300
#define MAX_KDS_MSG_SIZE    300
#define MAX_SSA_BUF_SIZE    (MAX_SSA_MSG_SIZE - 24)
#define MAX_TLS_MSG_SIZE    (1024 * 4)
#define APP_BUFFER_SIZE     1100


// *****************************************************************************
// define for MNT
// *****************************************************************************
#define  RET_SSA_END_SESSION               (   16 )
#define  RET_SSA_GENERIC_ORDER             (   18 )
#define  RET_SSA_ORDER_FAILED              (   20 )
#define  RET_SSA_GENERIC_SECURITY          (   22 )
#define  ERR_SSA_NO_ORDER                  (PSY_MNT_ERROR_START)
#define  ERR_SSA_NO_REPLY                  (PSY_MNT_ERROR_START-1)


// *****************************************************************************
// define for generic key entry functions
// *****************************************************************************
// Mask corKeyAction byte
#define SSA_SEC_KEY_BCKSP_BIT             BIT_MASK(0)
#define SSA_SEC_KEY_CLEAR_BIT             BIT_MASK(1)
#define SSA_SEC_BCKSP_NO_KEY_BIT          BIT_MASK(2)
// Mask parameters1 byte
#define SSA_SEC_KEY_00_PT_BIT             BIT_MASK(0)
#define SSA_SEC_KEY_CLICK_BIT             BIT_MASK(1)
// Mask endKey byte
#define SSA_SEC_KEY_ENTER_AUTH_BIT        BIT_MASK(0)
#define SSA_SEC_OTHER_KEYS_AUTH_BIT       BIT_MASK(1)
#define SSA_SEC_FIRST_FCT_KEY_BIT         BIT_MASK(2)
#define SSA_SEC_FIRST_ENTER_KEY_BIT       BIT_MASK(3)
// Mask font bytes
#define SSA_SEC_DISP_BOLD_BIT             BIT_MASK(0)
#define SSA_SEC_DISP_DOUBLE_HEIGHT_BIT    BIT_MASK(1)
#define INT_FONT_1                        0x10
#define INT_FONT_2                        0x20
#define INT_FONT_3                        0x30
#define INT_FONT_4                        0x40
#define INT_FONT_5                        0x50
#define INT_FONT_6                        0x60
#define INT_FONT_7                        0x70
#define INT_FONT_8                        0x80
#define INT_FONT_9                        0x90
#define INT_FONT_10                       0xA0
#define FONT_RAM_MSK                      0x08
// Mask for direction byte
#define SSA_SEC_DIRECTION_BIT             BIT_MASK(0)

/////////////////////////////////////////
//  FONTS DEFINITIONS
/////////////////////////////////////////

#define NB_FONT_TYPE                  18

#define Iso8859_1                     0
#define Iso8859_1_pro_big             11

#define Iso8859_2                     1
#define Iso8859_2_6x8                 12

#define Iso8859_5                     2
#define Iso8859_34                    13      // Old define for Georgian fonts, kept for ascendant compatibility
#define IngFont_5                     13      
#define Iso8859_5_a                   17

#define Iso8859_7                     3
#define Iso8859_8                     4
#define Iso8859_9                     5

#define Iso8859_35                    6
#define Iso8859_35_b                  7
#define Iso8859_35_3                  14      // Old define for Georgian fonts, kept for ascendant compatibility
#define IngFont_35_3                  14
#define Iso8859_35_4                  15      // Old define for Georgian fonts, kept for ascendant compatibility
#define IngFont_35_4                  15
#define Iso8859_35_5                  16      // Old define for Georgian fonts, kept for ascendant compatibility
#define IngFont_35_5                  16

#define Iso8859_9_6x8                 8
#define Iso8859_9_pro_smal            9
#define Iso8859_9_pro_big             10



//define for errors
#define SEC_INPUT_ERROR_START       -1000                      //0xFC18
// DO NOT DEFINE ANYTHING before 0xFC0C, it is LAF declarations
#define ERR_NO_PINPAD               (SEC_INPUT_ERROR_START-12) //0xFC0C
#define ERR_RANDOM_NB_GENERATION    (SEC_INPUT_ERROR_START-13) //0xFC0B
#define ERR_PB                      (SEC_INPUT_ERROR_START-14) //0xFC0A
#define ERR_FONT_SELECTION          (SEC_INPUT_ERROR_START-15) //0xFC09
#define ERR_FONT_NOT_AVAILABLE      (SEC_INPUT_ERROR_START-16) //0xFC08
#define ERR_FONT_ALREADY_PRESENT    (SEC_INPUT_ERROR_START-17) //0xFC07
#define ERR_OUT_OF_RANGE            (SEC_INPUT_ERROR_START-18) //0xFC06
#define ERR_SMC_REMOVED             (SEC_INPUT_ERROR_START-19) //0xFC05
#define ERR_SMC_OPENED              (SEC_INPUT_ERROR_START-20) //0xFC04
#define ERR_BUFFER_TOO_SMALL        (SEC_INPUT_ERROR_START-21) //0xFC03
#define ERR_LDM_FIRST_TIMEOUT       (SEC_INPUT_ERROR_START-22) //0xFC02
#define ERR_LDM_MEMORY_PB           (SEC_INPUT_ERROR_START-23) //0xFC01
#define ERR_LDM_MNT_OPEN            (SEC_INPUT_ERROR_START-24) //0xFC00
#define ERR_LDM_COM_OPEN            (SEC_INPUT_ERROR_START-25) //0xFBFF
#define ERR_LDM_INTERNAL            (SEC_INPUT_ERROR_START-26) //0xFBFE
#define ERR_NO_RADIO                (SEC_INPUT_ERROR_START-27) //0xFBFD
#define ERR_RADIO_COMMAND           (SEC_INPUT_ERROR_START-28) //0xFBFC
#define ERR_NOT_AUTHORIZED          (SEC_INPUT_ERROR_START-29) //0xFBFB


#define SSA_INTERNAL_FONT_RAM(fontNumber)    (uint8) ((((uint8) fontNumber <<4)&0xF0)|0x08)

#define TERM          SSA_MERCHANT
#define TERM_SCR      SSA_MERCHANT
#define PPAD1_SCR     PPAD_1

#define SYSTEM_MENU_HW_TICKET                   1
#define SYSTEM_MENU_OS_TICKET                   2
#define SYSTEM_MENU_APP_TICKET                  3
#define SYSTEM_MENU_LIST_CFS_TICKET             4
#define SYSTEM_MENU_MEMORY_ORG_TICKET           5

#define PPAD_NONE    0
#define PPAD_COM1    1
#define PPAD_COM2    2

//Compatibility defines
#define   ssaSecLafKbdInputReq      ssaSecDispKbdInputReq
#define   ssaSecLafDisplayText      ssaSecDisDisplayText


//***************************************************************************

#define SSA_CUSTOMER_PRIMARY     PPAD_1
#define SSA_CUSTOMER_SECONDARY   PPAD_2
#define SSA_CUSTOMER_BASE        BASE

typedef struct
{
   uint8    hmiNormSlot;
   uint8    hmiBoldSlot;
} ssaFontDescr_t;

enum ssaId_t
{
TERM,
PPAD_1,
PPAD_2,
SWITCH_AUTO,
BASE,
SSA_MAX_CHANNELS
};

enum ssaFunctionality_t
{
SSA_CONFIG_FCT,
SSA_DOWNLOAD_FCT,
SSA_KDS_FCT,
SSA_MAX_FUNCTIONALITY
};

// defines for SSA sessions
#define SYNC_ASYNC_MASK         0x40
#define STD_SECU_MASK           0x80

enum ssaFunction_t
{
STANDARD_SYNC0  = 0,
STANDARD_SYNC1  = 1,
STANDARD_SYNC2  = 2,
STANDARD_SYNC3  = 3,
STANDARD_ASYNC0 = 0x40,
STANDARD_ASYNC1 = 0x41,
STANDARD_ASYNC2 = 0x42,
STANDARD_ASYNC3 = 0x43,
SECURITY_SYNC0  = 0x80,
SECURITY_SYNC1  = 0x81,
SECURITY_SYNC2  = 0x82,
SECURITY_SYNC3  = 0x83,
SECURITY_SYNC4  = 0x84,
SECURITY_SYNC5  = 0x85,
SECURITY_SYNC6  = 0x86,
SECURITY_SYNC7  = 0x87,
SECURITY_SYNC8  = 0x88,
SECURITY_SYNC9  = 0x89,
SECURITY_ASYNC0 = 0xC0,
SECURITY_ASYNC1 = 0xC1,
SECURITY_ASYNC2 = 0xC2,
SECURITY_ASYNC3 = 0xC3,
SECURITY_ASYNC4 = 0xC4,
SECURITY_ASYNC5 = 0xC5,
SECURITY_ASYNC6 = 0xC6,
SECURITY_ASYNC7 = 0xC7,
SECURITY_ASYNC8 = 0xC8,
SECURITY_ASYNC9 = 0xC9
};

enum ssaCfFunction_t
{
CFG_SSA_IDENT,
CFG_SSA_CONFIG,
CFG_SSA_IDENT2,
CFG_SYSTEM_MENU_TICKET,
CFG_PPAD_COM,
END_CFG_FCT
};

enum ssaDwlS01Function_t
{
DWL_ORDER_MEMORY,
DWL_REPLY_MEMORY,
DWL_REPLY_MEMORY_REPEAT,
DWL_GENERIC_ORDER_ENABLE,
DWL_GENERIC_ORDER_REPLY,
DWL_START_LDM,
DWL_PING
};

enum ssaDwlS02Function_t      // STANDARD_SYNC2 download functions
{
DWL_TRUST_CONNECT,
DWL_TRUST_DISCONNECT,
DWL_TRUST_DATA_SEND_TLS,
DWL_TRUST_DATA_SEND_APW
};

enum ssaDwlAS0Function_t      // STANDARD_ASYNC0 download functions
{
DWL_TRUST_DATA_REQ
};

enum ssaKdsS00Function_t
{
KDS_OPEN,
KDS_CLOSE,
KDS_CANCEL,
KDS_TEST_IN_OUT,
END_KDS_FCT
};

enum ssaKdsS01Function_t
{
KDS_DISP_TEXT,
KDS_MENU_SELECT,
KDS_LIST_SELECT,
KDS_LIST_DISPLAY,
KDS_MESSAGE_BOX,
KDS_MESSAGE_SHOW,
KDS_SEL_DISP_DEFAULT_FONT,
KDS_SEL_PRN_DEFAULT_FONT,
KDS_WRITE_FONT,
KDS_AD_CLEAR_LINE,
KDS_SEC_SIGN,
KDS_HMI_CONFIG,
KDS_DRAW_GRAPHIC
};

enum ssaKdsS02Function_t
{
   KDS_SEND_SYNC_RHMI
};

enum ssaKdsAS0Function_t
{
KDS_SEC_INPUT,
KDS_SEND_ASYNC_RHMI
};

enum ssaKdsAS1Function_t
{
KDS_EMVL2_PIN_INPUT
};

enum ssaDwlFunction_t
{
DWL_OPEN,
DWL_CLOSE,
DWL_CANCEL,
DWL_OPEN_ADD_INFO,
END_DWL_FCT
};

// SSA input messages description
typedef struct
{
    uint32  callerQid;
    uint8   physicalAdr;
    uint8   functionality;
    uint8   functionNb;
    uint8   subFunctionNb;
    uint32  type;
}ssaHeaderInMsg_t;

#define INBUFFTYPE00    0x00
typedef struct
{
    uint32  lgPtIn;                     /* input buffer length (MUST be <= 3Kb) */
    uint8   *ptIn;                      /* input buffer (for the SSA) */
    uint32  lgPtOut;                    /* output buffer length (MUST be <= 3Kb) */
    uint8   *ptOut;                     /* output buffer (for the SSA) */
} inBuffType00_t;

#define INBUFFTYPE01    0x01
typedef struct
{
    uint32  lgPtIn;                     /* input buffer length (MUST be <= 3Kb) */
    uint8   *ptIn;                      /* input buffer (for the SSA) */
} inBuffType01_t;

#define INBUFFTYPE10    0x10
typedef struct
{
    uint32      lgMsg;                      /* length of message buffer (MUST be <= 300b) */
    uint8       msg[MAX_SSA_BUF_SIZE];      /* message buffer */
    uint32      lgPtOut;                    /* output buffer length (MUST be <= 3Kb) */
    uint8       *ptOut;                     /* output buffer (for the SSA) */
} inBuffType10_t;

#define INBUFFTYPE11    0x11
typedef struct
{
    uint32      lgMsg;                      /* length of message buffer (MUST be <= 300b) */
    uint8       msg[MAX_SSA_BUF_SIZE];      /* message buffer */
} inBuffType11_t;


union ssaBufferInMsg_t {
    inBuffType00_t  inBuffType00;
    inBuffType01_t  inBuffType01;
    inBuffType10_t  inBuffType10;
    inBuffType11_t  inBuffType11;
};

typedef struct
{
    ssaHeaderInMsg_t        header;
    union ssaBufferInMsg_t  inBuffContent;
} ssaInMsg_t;

// SSA output messages description
typedef struct
{
    uint8   physicalAdr;
    uint8   functionality;
    uint8   functionNb;
    uint8   subFunctionNb;
    int16   status;
    uint32  type;
}ssaHeaderOutMsg_t;

#define OUTBUFFTYPE0    0x00
typedef struct
{
    uint32  lgWritten;                      /* length of the buffer written in the application (by SSA) (MUST be <= 3Kb) */
} outBuffType0_t;

#define OUTBUFFTYPE1    0x01
typedef struct
{
    uint32      lgMsg;                      /* length of the buffer sent (MUST be <= 300b) */
    uint8       msg[MAX_SSA_BUF_SIZE];      /* returned message to the application */
} outBuffType1_t;

union ssaBufferOutMsg_t {
    outBuffType0_t  outBuffType0;
    outBuffType1_t  outBuffType1;
};

typedef struct
{
    ssaHeaderOutMsg_t       header;
    union ssaBufferOutMsg_t outBuffContent;
} ssaOutMsg_t;


// description for identification number
typedef struct
{
    uint8       ssaId;                   // used in Open for routing purpose
    char        descriptionString[12];   // ssa filename
    uint8       serialNumber[12];        // Terminal (pin-pad) serial number

} ssaDescriptor_t;

typedef struct
{
    uint8           ssaNb;               // number of SSA connected to the current SSA
    ssaDescriptor_t descriptor[5];       // description of each SSA connected
} ssaStaticConf_t;


typedef struct
{
    uint8       ssaId;                    // used in Open for routing purpose
    char        descriptionString[12];    // ssa filename
    uint8       serialNumber[12];         // Terminal (pin-pad) serial number
    uint8       sapCode[16];              // Terminal (pin-pad) sap code

} ssaDescriptor2_t;

typedef struct
{
    uint8            ssaNb;               // number of SSA connected to the current SSA
    ssaDescriptor2_t descriptor[5];       // description of each SSA connected
} ssaStaticConf2_t;

// SSA queue Id definition
typedef struct
{
    char    *qName;
    uint32  maxNb;
    uint32  maxSize;
    uint32  qId;

}queueId_t;



typedef struct
{
    uint32  length;
    uint8   *ptr;
}ssaSig_t;

typedef struct
{
   uint8    reserved;                  // reserved for treatment
   uint8    periphType;                // Type of terminal to send the PING to
   uint16   length;                    // Length of data sent
   uint8    pingType;                  // Type of PING
   uint8    buffer[APP_BUFFER_SIZE-6]; // Buffer Sent
} ping_t;


/*
** IngeTrust status types.
*/
typedef enum
{
   SSA_TRUST_CONNECT_OK,            // TLS connection successful
   SSA_TRUST_CONNECT_FAILED_NEGO,   // TLS connect failed at negotiation
   SSA_TRUST_CONNECT_FAILED_SPONSOR,// TLS connect failed due to bad sponsor ID
   SSA_TRUST_LOGON_OK,              // Server logon successful
   SSA_TRUST_LOGON_FAILED,          // Server logon failure
   SSA_TRUST_DISCONNECT_OK,         // TLS disconnection successful
   /*-----------------*/
   SSA_TRUST_STATUS_MAX

} ssaTrustStatus_t;

/*
** IngeTrust message data types.
*/
typedef enum
{
   SSA_DATA_TYPE_STATUS,         // Status value, one of ssaTrustStatus_t
   SSA_DATA_TYPE_TLS,            // TLS encrypted message to/from server
   SSA_DATA_TYPE_APW,            // APW message frame to/from SMF
   /*-------------*/
   SSA_DATA_TYPE_MAX

} ssaDataType_t;

/*
** Structure of IngeTrust asynchronous result to be received from SSA.
*/
typedef struct_packed
{
  int16     status;        // Execution status
  uint16    length;        // Length of result data that follows
  uint32    dataSize;      // Size of output data placed in appl buffer
  uint8     dataType;      // Type of output data (ssaDataType_t)

} ssaTrustResult_t;


//Compatibility defines
#define   ssaSecLafMessageShow           ssaSecLafMessageShowTo



//***************************************************************************
//          Prototype of functions


// Functions related to SSA configuration
/////////////////////////////////////////////////////////////////////
int16   ssaIdent(ssaStaticConf_t *ssaStaticConf);
int16   ssaIdent2(ssaStaticConf2_t *ssaStaticConf);
int16   ssaCall(uint32 handle,ssaInMsg_t *inMsg,ssaOutMsg_t *outMsg);
int16   ssaConfig(void);
int16   ssaSystemMenuTicket(uint8 ticketType, uint32 sizeMax, char  *pInfoTicket, uint32 *sizeUsed);
int16   ssaConfigurePinPad (uint8 pinPadLocation);

// Functions related to SSA secured channel
/////////////////////////////////////////////////////////////////////
int16   ssaSecOpen(uint32 ssaId,uint32 *secHandle);
int16   ssaSecClose(uint32 secHandle);
int16   ssaSecCall(uint32 secHandle,ssaInMsg_t *inMsg,ssaOutMsg_t *outMsg);
int16   ssaSecResultCheck(uint32 secHandle);
int16   ssaSecResultGet(uint32 secHandle, uint32 maxLengthResult, void* result);
int16   ssaSecCancel(uint32 secHandle);

// Functions related to LAF display
/////////////////////////////////////////////////////////////////////
int16   ssaSecLafMultipleInputReq (uint32 secHandle, uint8 location, ssaSecDispKbdInput_t *pssaSecInput);
int16   ssaSecLafMultipleInputToReq (uint32 secHandle, uint8 location, ssaSecDispKbdInput_t *pssaSecInput, ssaSig_t *pssaSig);
int16   ssaSecLafKbdInputReq (uint32 secHandle, ssaSecDispKbdInput_t *pssaSecInput);
int16   ssaSecLafDisplayText(uint32 secHandle, uint8 location, dispLine_t dispDescription[4]);
int16   ssaSecLafMenuSelect(uint32 secHandle, uint8 location, uint32 inputFlags,  char *menu, int16 idStartUp, int16 *idSelected);
int16   ssaSecLafMenuSelectTo(uint32 secHandle, uint8 location, uint32 inputFlags,  char *menu, int16 idStartUp, uint32 timeOut, int16 *idSelected);
int16   ssaSecLafListSelect( uint32 secHandle, uint8 location, uint32 inputFlags, const char *title,  char *lines, int16 iStartUp, int16 *iSelected);
int16   ssaSecLafListSelectTo( uint32 secHandle, uint8 location, uint32 inputFlags, const char *title,  char *lines, int16 iStartUp, uint32 timeOut, int16 *iSelected);
int16   ssaSecLafListDisplay(uint32 secHandle, uint8 location, uint32 inputFlags, const char *title,  char *lines, int16 *response);
int16   ssaSecLafListDisplayTo(uint32 secHandle, uint8 location, uint32 inputFlags, const char *title,  char *lines, uint32 timeOut, int16 *response);
int16   ssaSecLafMessageBox(uint32 secHandle, uint8 location, uint32 inputFlags, const char *title, const char *message, int16 *response);
int16   ssaSecLafMessageBoxTo(uint32 secHandle, uint8 location, uint32 inputFlags, const char *title, const char *message, uint32 timeOut, int16 *response);
int16   ssaSecLafMessageShowTo(uint32 secHandle, uint8 location, uint32 inputFlags, const char *title, const char *message, uint32 timeOut);
int16   ssaSecLafWriteFont(uint32 secHandle, uint8 location, uint8 isoFontNb, ssaFontDescr_t *descriptor);
int16   ssaSecLafSelectDispDefaultFont(uint32 secHandle, uint8 location, void *fontId);
int16   ssaSecLafSelectPrnDefaultFont(uint32 secHandle, uint8 location, void *normalFontId, void *boldFontId);
int16   ssaSecLafConfig(uint32 secHandle, uint8 location, lafConfig_t type, uint16* plength, void *pBuffer);
int16   ssaSecEmvl2PinOfflineReq(uint32 secHandle, uint8 pinPrefix, psyPid_t *applicationPid, ssaSecDispKbdInput_t *ssaSecDispKbdInput);
int16   ssaSecPinEntryEmvl2OfflineReq(uint32 secHandle, uint8 location, uint8 pinPrefix, psyPid_t *applicationPid, ssaSecDispKbdInput_t *ssaSecDispKbdInput);
int16   ssaSecLafADClearLine(uint32 secHandle, uint8 location, uint16 line);
int16   ssaSecLafDrawGraphic(uint32 secHandle, uint16 x, uint16 y, uint16 width, uint16 height, uint16 length, void *graph);

// Functions related to download
/////////////////////////////////////////////////////////////////////
int16   ssaInternalDwlOpen(uint32 ssaId, uint32 *handle);
int16   ssaDwlOpen(uint32 ssaId, uint8 maintenanceStartOptions, uint32 *handle );
int16   ssaDwlClose(uint32 handle);
int16   ssaDwlCall(uint32 handle,ssaInMsg_t *inMsg,ssaOutMsg_t *outMsg);
int16   ssaDwlResultCheck(uint32 handle);
int16   ssaDwlResultGet(uint32 handle, uint32 maxLengthResult, void* result);
int16   ssaDwlCancel(uint32 handle);
int16   ssaDwlOrderMemory(uint32 handle, const char *orderBuffer, uint32 orderLength, uint32 *replyLength);
int16   ssaDwlReplyMemory(uint32 handle, char *replyBuffer, uint32 bufferSize, uint32 *bufferUsed );
int16   ssaDwlReplyMemoryRepeat(uint32 handle );
int16   ssaDwlGenericOrderEnable (uint32 handle, uint32 *length, uint32 *dataIndicator );
int16   ssaDwlGenericReply (uint32 handle, const char *replyBuffer, uint32 length );
int16   ssaDwlStartLdm(uint32 dwlHandle, uint32 comPort, uint32 timeOut);
int16   ssaDwlPing (uint32 dwlHandle, ping_t *ping);
int16   ssaDwlTrustConnect    (uint32 dwlHandle, uint8 *logonBuffer, uint32 logonLength, uint32 timeOut);
int16   ssaDwlTrustDisconnect (uint32 dwlHandle);
int16   ssaDwlTrustDataSend   (uint32 dwlHandle, ssaDataType_t dataType, uint8 *dataBuffer, uint32 dataLength);
int16   ssaDwlTrustDataReq    (uint32 dwlHandle, uint8 *outBuffer, uint32 bufferSize);


// Functions related to RHMI
/////////////////////////////////////////////////////////////////////
int16 ssaSecOpenRhmi(uint32 *handle);
int16 ssaSecCloseRhmi(uint32 handle);
int16 ssaSecSendSyncRhmi(uint32 ssaHandle, uint32 dataInLength, void* dataInPtr ,uint32* dataOutLength, void* dataOutPtr);
int16 ssaSecSendASyncRhmi(uint32 ssaHandle, uint32 dataInLength, void* dataInPtr ,uint32* dataOutLength, void* dataOutPtr);

#ifdef __cplusplus
}
#endif

#endif /* SSA_H */
/*
 * End of File ssa.h
*/

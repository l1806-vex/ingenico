/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT        :    SSA application
 *  MODULE         :    MainModule
 *  FILEMANE       :    lafPpadFunctions.h
 *  PURPOSE        :    Look & Feel functions for pin pad
 *
 *  HISTORY
 * 
 *  date         author     modifications
 *  2003-11-24   FTA        creation
 *  2004-06-22   AMO        change lafPadConfigRead API for routing
 *  2005-02-28   DHU        add LAF functions :
 *                              _ lafPadMenuSelect
 *                              _ lafPadListSelect
 *                              _ lafPadListDisplay
 *                              _ lafPadMessageBox 
 *                              _ lafPadMessageShow 
 *  2006-01-03   FCL			Re-organisation of LAF library
 *  2006-11-15   ROM       lafPadDefineGraphic, lafPadFillGraphic and lafPadDrawGraphic declarations added. 
 *  2006-11-24   FCL       Modifications to manage Font by OS
 * --------------------------------------------------------------------------
 *  PLEASE USE 3 CHAR. TABULATIONS
-*/

#ifndef __lafPpadFunctions_H
#define __lafPpadFunctions_H

/**++*************************************************************************/
int16		lafPpadSecuredInput(uint32 padOutputHdle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafPadSecuredInput(uint32 padOutputHdle, uint32 padInputHdle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput);
int16 	lafPadADFont (uint32 padOutputHdle, void const *font);
int16 	lafPadADDisplayText (uint32 padOutputHdle, uint32 line, uint32 column, char *text);
int16 	lafPadADClearLine(uint32 padOutputHdle, uint16 line);
int16 	lafPadConfigRead(uint32 handle, lafConfig_t type, uint16* plength, void *pBuffer);
int16 	lafPadMenuSelect(uint32 padOutputHdle, uint32 inputFlags, char *menu, int16 idStartUp, uint32 timeOut, int16 *p_i16Response);
int16 	lafPadListSelect(uint32 ui32PadOutputHdle, uint32 ui32InputFlags, char *pTitle, char *pLines, int16 i16IdStartUp, uint32 ui32TimeOut, int16 *p_i16Response);
int16 	lafPadMessageBox(uint32 ui32PadOutputHdle, uint32 ui32InputFlags, char *pTitle, char *pMessage, uint32 ui32TimeOut, int16 *p_i16Response);
int16 	lafPadListDisplay(uint32 ui32PadOutputHdle, uint32 ui32InputFlags, char *pTitle, char *pLines, uint32 ui32TimeOut, int16 *p_i16Response);
int16 	lafPadMessageShow(uint32 ui32PadOutputHdle, uint32 ui32InputFlags, char *pTitle, char *pMessage, uint32 ui32TimeOut);
int16 	lafPadBackLightOnWindow(uint32 outputHandle);
int16 	lafPadBackLightOffWindow(uint32 outputHandle);
int16 	lafPadWindowDim(uint32 outputHandle, int16 *windowWidth, int16 *windowHeight);
int16 	lafPadCfgBackLight(uint8 mode, lafBackLight_t *pLafBackLight);
int16 	lafPadCfgContrast(uint8 mode, lafContrast_t *pLafContrast);
int16 	lafPadSetModeReverseVideo(void);
int16 	lafPadSetModeNormalVideo(void);
int16 	lafPadBacklightWindow (uint8 percent);
void  	lafPadPinConfig(uint32 outputHandle, uint8 type, void *ptData);
void     lafPadDefineGraphic(uint32 outputHandle, uint16 x, uint16 y, uint16 width, uint16 height, uint16 dataLen, void *ptData);
void     lafPadFillGraphic(uint32 outputHandle, uint16 dataLen, void *ptData);
int16    lafPadDrawGraphic(uint32 outputHandle, uint16 dataLen, void *ptData);
int16		lafPadWriteFont(uint32 outputHandle, uint8 fontIsoNb, uint8 *normFontSlot, uint8 *boldFontSlot);
int16 	lafPadSelectDispDefaultFont(uint32 outputHandle, void *fontId);
int16 	lafPadSelectPrnDefaultFont(uint32 outputHandle, void *normalFontId, void *boldFontId);

/*+++******* ADDITIONNAL FUNCTIONS INFORMATIONS ***********************---*/

/**++*********************************************************************
//int16 lafPadSecuredInput(uint32 padOutputHdle, uint32 padInputHdle, ssaSecInput_t *pssaSecInput, ssaSecOutput_t *pssaSecOutput)
**++*********************************************************************
 * Description:  lafPadSecuredInput
 *    This function perform the secured entry
 *
 * Parameters  IN:
 *       -  pssaSecInput  : structure with parameters of the input
 *       -  pssaSecOutput : strucure for output result
 *       -  padOutputHdle : output handle
 *       -  padInputHdle  : input handle
 *
 * Parameters OUT:
 *       -  pssaSecOutput:  structure with  result of the input
 *
 * Returns:
 *       -  RET_OK
 *       -  ERR_USER_CANCEL_KEY
 *       -  ERR_USER_COR_KEY
 *       -  ERR_APPLICATIVE_CANCEL
 *       -  ERR_SYS_INTERNAL_ERROR_2
 *       -  ERR_TIMEOUT_INTER_KEY
 *       -  ERR_TIMEOUT_FIRST_KEY
 *       -  ERR_USER_FCT_KEY_PRESSED
 *
 *********************************************************************--*/

/*****************************************************************************
//int16 lafPadConfigRead(uint32 handle, lafConfig_t type, uint16 *plength, void *pBuffer)
*****************************************************************************
 * Description:
 *  This function allows the user to read the configuration of the devices configuration. It can 
 *  be the keyboard, or the display.
 *
 * Parameters:              I/O    Description
 *   - handle               I      handle of the channel
 *   - type                 I      indicates which information device is required. The following
 *                                 values can be used:
 *                                      typedef enum
 *                                      {
 *                                         LAF_CFG_KEYBOARD,
 *                                         LAF_CFG_DISPLAY,
 *                                         LAF_CFG_TOUCH
 *                                      }lafConfig_t;
 *                                 for pinpad touch has no sens 
 *   - plength              I      the size (in bytes) of the buffer provided by the caller
 *                                 (for the date to be copied into)
 *                          O      the returned buffer size
 *
 *   - pBuffer              O      the buffe to be updated with the desired configuration. The
 *                                 type of the data pointed by 'pBuffer' depends on the value of
 *                                 'type', according to the following table:
 *           
 *
 *         |       type             |       length         |          pBuffer              | 
 *         -----------------------------------------------------------------------------
 *         |    LAF_CFG_KEYBOARD    |   LAF_KEYBOARD_SIZE  |   pointer to lafKeyboard_t    |
 *         |    LAF_CFG_DISPLAY     |   LAF_DISPLAY_SIZE   |   pointer to lafDisplay_t     |
 *
 *
 * Returns:
 *   - RET_OK
 *   - LAF_ERR_UNKNOWN_PINPAD
 *   - LAF_ERR_INVALID_INPUT_PARAMETERS
 *   - ERR_NO_PINPAD
 *
 **************************************************************************--*/

#endif

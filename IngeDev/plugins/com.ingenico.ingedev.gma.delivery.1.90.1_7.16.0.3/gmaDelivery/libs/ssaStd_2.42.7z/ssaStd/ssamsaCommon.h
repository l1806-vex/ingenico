/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT        :    SSA/MSA application
 *  FILEMANE       :    ssamsaCommon.h
 *  PURPOSE        :    Generic and common defines,structures and includes for SSA and MSA
 *
 *  HISTORY
 *  date         author     modifications
 *  2006-01-03   FCL        CREATION
 * --------------------------------------------------------------------------
-*/


#ifndef __ssamsaCommon_H
#define __ssamsaCommon_H


/*+++******* GLOBAL STRUCTURES DEFINITION ***********************---*/

// INPUT STRUCTURE FOR ADVANCED KEYBOARD ENTRY
typedef struct
{
    uint8   lineNbText;
    uint8   fontText;
    char    text[16];
    uint8   lineNbInput;
    uint8   fontInput;
    char    textInput[16];
    uint16  inputFieldDefinition;
    uint8   direction;
    uint8   minimumKeys;
    uint8   maximumKeys;
    uint8   endKey;
    char    echoCharacter;
    uint8   parameters1;
    uint8   corKeyAction;
    uint8   timeOutFirstKey;
    uint8   timeOutInterKey;
    char    replacementCharacter;
    uint8   RFU1;
    uint8   RFU2;
    char    values[16];
} ssaSecDispKbdInput_t;

// OUTPUT STRUCTURE FOR ADVANCED KEYBOARD ENTRY
typedef struct
{
   uint8    nbKeys;
   char     keys[16];
   char     lastKey;
}ssaSecOutput_t ;




/*+++******* GLOBAL DEFINES ***********************---*/

// DEFINES SECURITY LRP FUNCTIONS
#define FCTSEC_LRP_RETRIEVE_PSC					1
#define FCTSEC_LRP_GENERATE_CODE					2
#define FCTSEC_LRP_SAVE_DATE						3
#define FCTSEC_LRP_GET_SAVE_DATE					4
#define FCTSEC_LRP_RESET_COUNTER					5
#define FCTSEC_LRP_INCREASE_COUNTER				6

// DEFINES FONTS
#define INT_FONT_1                        0x10
#define INT_FONT_2                        0x20
#define INT_FONT_3                        0x30
#define INT_FONT_4                        0x40
#define INT_FONT_5                        0x50
#define INT_FONT_6                        0x60
#define INT_FONT_7                        0x70
#define INT_FONT_8                        0x80
#define INT_FONT_9                        0x90
#define INT_FONT_10                       0xA0

#endif

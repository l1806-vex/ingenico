/*****************************************************************************
                              Property of INGENICO
 *****************************************************************************/
/*+
 *  PROJECT        :    SSA application
 *  FILEMANE       :    lafTools.h
 *  PURPOSE        :    Tools functions for LAF library
 *
 *  HISTORY
 *  date         author     	modifications
 *  2006-01-02   FCL				CREATION
 *  2006-04-13   TLC          Merged with CWEI's changes on 2006-03-21.
 *
 * --------------------------------------------------------------------------
 *  PLEASE USE 3 CHAR. TABULATIONS
-*/

#ifndef __lafTools_H
#define __lafTools_H


/*+++******* TOOLS FUNCTIONS DEFINITIONS ***********************---*/
int16		lafMessageBoxFrame (uint32 winHandle, uint32 inputFlags, char *title);
int16		lafMessageBoxText (uint32 winHandle, char *message, uint32 timeOut);
int16		lafErrMsgShowBeep(uint32 winHandle, char *title, char *message, uint32 timeOut);
int16 	menuUpDwnArrowPressed(uint32 winHandle, hmiTouchCoordResult_t touchResult, uint8 *key);
int16 	menuElementPressed(uint32 winHandle, hmiTouchCoordResult_t touchResult, uint16 numOfElements, uint8 * element);
int16 	startMenu (int16 level, char *title, int16 iStartUp, int16 *elementSelected, uint32 timeOut);
int16 	displayLineMenuAndListSelectSelected(int16 line, uint16 pointedElement, uint8 flagLine, bool flagType);
int16 	startListSelect (char *title, int16 iStartUp, int16 *elementSelected, uint32 timeOut);
int16 	startListDisplay(char *title, int16 *elementSelected, uint32 timeOut);
int16 	displayLineListDisplaySelected(uint16 pointedElement);
int16 	initParameters(uint32 outputHandle, uint32 inputHandle, char *title);
int16 	fillTableMenuAppli(uint16 level, uint16 index, char *menu, uint16 *subMenuFound);
int16 	fillTableListAppli(char *lines);
int16 	initKeyboardKeys(void);
void  	menuDispTitleXXX(uint32 winHandle, char *title);
void 		displayDirectionIcons (uint32 winHandle,uint8 menuType,int16 nbItems,int16 entryToHighlight,int16 availDisplayLines,int16 itemsDisplayed,bool * upArrowDisp,bool * dwnArrowDisp) ;
void  	lafDeviceIdGet (uint32* terminalCharMask, uint8 deviceId[5]);
void  	lafCfgGet(lafCfgData_t * lafCfg);
void 		lafScreenInit(uint32 winHandle);
void 		lafBacklightTmoSet (uint64 tmoValue);
uint64 	lafBacklightTmoGet (void);
int16 	lafFontSet (uint32 winHandle, void * font);
void * 	lafFontGet (void);
void 	lafForegroundColorSet(uint32 winHandle, Color color);
Color   lafForegroundColorGet (void);
void 	lafBackgroundColorSet (uint32 winHandle, Color color);
Color   lafBackgroundColorGet(void);
int16 	lafGraphicBppSet(uint32 winHandle, hmiBpp_t bpp);
uint8 	lafGraphicBppGet (void);
void 		lafKeypressBeep (uint32 winHandle);
uint8 	lafKeypressBeepStateGet (void);
void 		lafKeypressBeepStateSet (uint8 state);
uint32 	lafKeypressBeepLengthGet (void);
void 		lafKeypressBeepLengthSet (uint32 beepLength);
uint32 	lafKeypressBeepToneGet (void);
void 		lafKeypressBeepToneSet (uint32 beepTone);
void 		lafInvalidKeypressBeep (uint32 winHandle, bool isBeep);
uint8 	lafInvalidKeypressBeepStateGet (void);
void 		lafInvalidKeypressBeepStateSet (uint8 state);
uint32 	lafInvalidKeypressBeepLengthGet (void);
void 		lafInvalidKeypressBeepLengthSet (uint32 beepLength);
uint32 	lafInvalidKeypressBeepToneGet (void);
void 		lafInvalidKeypressBeepToneSet (uint32 beepTone);
int16 	lafClearWindow (uint32 winHandle);
bool 		lafFlushKeypadBuffer (uint32 keyHandle);
bool 		lafFlushTouchBuffer (uint32 winHandle);
uint8   	lafNumLinesInMenu(uint32 winHandle);
int16   	lafTermMenuBlkOn(uint32 winHandle);
int16   	lafTermMenuBlkOff(uint32 winHandle);
void 		lafToolBinaryToAscii (uint8* destination, uint8* source, uint8 nbBytes);
int16 	lafCheckStartupMenu (void);

#endif

#ifndef GCL_SERIAL_H_INCLUDED
#define GCL_SERIAL_H_INCLUDED

#include "gcl.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @file gcl_serial.h
 *
 *
 */

/**
 * \addtogroup serial_ serial communication
 *
 * Serial connection.
 *
 * @{
 */

#define GCL_SERIAL_FUNC_comOpen             (1)
#define GCL_SERIAL_FUNC_comChanInit         (2)
#define GCL_SERIAL_FUNC_comSendMsgWait      (3)
#define GCL_SERIAL_FUNC_comReceiveMsgWait   (4)

/**
 * store the information of the last error occurred in the gclSERIAL.
 */
typedef struct gclSerialErrorInfo_st gclSerialErrorInfo_t;

/**
 * store the information of the last error occurred in the gclSERIAL.
 */
struct gclSerialErrorInfo_st
{
	/**
	 * Function in that the error occur, one of the GCL_SERIAL_FUNC_XXX defines
	 */
	uint16 serialFunc;
	/**
	 * error returned by the function
	 */
	int16  ret;
};

/**
 * return more information about an error that happen in the last connection
 * attempt (if an error occurred).
 * 
 * @param info a pointer to a \ref gclSerialErrorInfo_t that will receive the error info.
 * 
 * @return RET_OK the last error was a SERIAL error and the information about the error
 * is inside the info structure
 * @return GCL_ERR_NO_ERROR_INFO_AVAILABLE There is no available error information
 */
int16 gclSerialGetLastErrorInfo(gclSerialErrorInfo_t *info);

/**
 * Reset the internal variable that stores the error info. Note that 
 * this function must be called before a connection attempt to have a real
 * return in the function \ref gclSerialGetLastErrorInfo
 */
void gclSerialSerrorReset(void);

/**
 * \brief Structure with the serial configuration
 */
typedef struct
{
   /* SERIAL CONFIGURATION */
   uint8                 connectionId; //!< the id that identify this connection, retrieved with the function \ref gclCurrentConfigState
   /* */
   char                  *deviceName; //!< com port name to be used, can be: COM1, COM2...

   enum comSpeed_t       speed;        //!< connection speedy, see the Unicapt documentation for more details
   enum comParity_t      parity;       //!< parity, see the Unicapt documentation for more details
   enum comDataSize_t    dataSize;     //!< data size, see the Unicapt documentation for more details
   enum comStopBits_t    stopBits;     //!< number of stop bits, see the Unicapt documentation for more details
   enum comFlowControl_t flowControl;  //!< flow control, see the Unicapt documentation for more details
   uint32                interCharTimeout;   //!> inter character timeout

   /* general config */
   uint8    retries; //!< connection attempts = retries + 1
   // timeouts
   uint32   connectTimeout;      //!< connection timeout
   uint32   communicationTimeout;//!< communication timeout
   uint32   loginTimeout;        //!< login documentation
   uint32   retryDelay;          //!< the delay before retying connection
   ///////////
} gclSerial_t;

//extraData
typedef struct
{
   char                    deviceName[GCL_MAX_DEVICE_NAME + 1]; //!< com port name to be used, can be: COM1, COM2...

   /* useful serial link config */
   enum comSpeed_t         speed;            //!< Connection Speedy
   enum comParity_t        parity;           //!< Connection Parity
   enum comStopBits_t      stopBits;         //!< Number of Stop bits
   enum comDataSize_t      dataSize;         //!< data Size
   enum comFlowControl_t   flowControl;      //!< flow control
   uint32                  interCharTimeout; //!> inter character timeout

   char                    rfu[46]; //!< RFU

} gclSerialConfig_t;

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/**
 * Retrieve the version of the library
 *
 * @param zcOut pointer to a char buffer that will receive the version of the library
 *
 * @return always RET_OK
 */
int16 gclSerialId(char *zcOut);

/**
 * This function will add an serial connection to the connection list
 * (\ref gclAddConnection).
 * \see gclAddConnection
 *
 * @param tel (I) a pointer to the configuration of the connection to add.
 * @param List (I) the callbacks of the connection type to be added.
 * @param userDataSize (I) the user data size
 * @param userData (I)     Pointer to user data,
 *                         can be used to store user data to be user during the
 *                         connection attempt. The data can be retrieved using the
 *                         function \ref gclGetUserData
 *
 * @return RET_OK if no problems occurs
 * @return GCL_ERR_INTERNAL_ERR normally when a problem with memory allocation to store
 *         the configuration occurs
 * @return the error returned by the \ref gclAddConnection function
 */
int16 gclSerialSet(gclSerial_t* tel, gclFunctionList_t *List,
                   uint32 userDataSize, void *userData);

/**
 * this function has to be called by the preDial callback when the
 * connection type is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclSerialPreDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Dial callback when the
 * connection type is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 */
int16 gclSerialDial(gclConfig_t *gcl);

/**
 * this function has to be called by the Connect callback when the
 * connection type is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclSerialConnect(gclConfig_t *gcl);

/**
 * this function has to be called by the hangUp callback when the
 * connection type is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 *
 */
int16 gclSerialHangUp(gclConfig_t *gcl);

/**
 * This function has to be called by the SEND callback if the connection type
 * is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (I) a pointer to the buffer to be sent
 * @param dataSize (I) the size of the buffer to be sent
 *
 */
int16 gclSerialSend(gclConfig_t *gcl, uint8 *data, uint32 dataSize);

/**
 * This function has to be called by the RECEIVE callback if the connection type
 * is serial connection.
 *
 * @param gcl (I) the configuration of the connection.
 * @param data (O) a pointer to the buffer where the received data will
 *                 be stored
 * @param actuallyRead (O) a pointer to a uint32 that will receive number of
 *                         bytes received
 * @param maxLen (I) the size of the buffer
 *
 */
int16 gclSerialReceive(gclConfig_t *gcl, uint8 *data,
                       uint32 *actuallyRead, uint32 maxLen);


/**
 * @}
 */

#ifdef __cplusplus
}
#endif


#endif

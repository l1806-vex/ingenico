{
	"type":"signature",
	"forecolor":0xFF784900,
	"backcolor":0xFFFFFFFF,
	"penwidth":2,
	
	"borders":{"left":2, "top":2, "right":2, "bottom":2, "unit":"px", "color":0xFFF6AC06},
}

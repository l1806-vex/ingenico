// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	"children":
	[
		{
			"type"           :"label",
			"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"item":{"column":0, "row":0},
			"grow"           : "width",
			"shrink"         : "width",
			"textalign"      : "right",
			"text"           : "",
			"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
			"shrink"         : "width",
		},

		{
			"type"       :"list",
			"id"         :0xFF000018, // GL_ID_SKIN_DIALOG_LIST
			"item":{"column":0, "row":1},
			
			"grow"       :"all",
			"shrink"     :"none",
			"expand"     :"all",
		},
		{
			"type"       :"layout",
			"id"         :0xFF000018, // GL_ID_SKIN_DIALOG_LIST
			"item"       :{"column":0, "row":2},
			
			"grow"       :"width",
			"shrink"     :"none",
			"expand"     :"width",
			"margins"    :{"left":0, "top":3, "right":0, "bottom":3, "unit":"pixel"},
			"children"   :
			[
				{
					"type":"picture",
					"source":"/images/folderUp.wgu",
					"grow": "width",
					"item" : {"column":0,"row":0},
				},
				{
					"type":"picture",
					"source":"/images/folderSelect.wgu",
					"grow": "width",
					"item" : {"column":1,"row":0},
				},
				{
					"type":"picture",
					"source":"/images/folderDown.wgu",
					"grow": "width",
					"item" : {"column":2,"row":0},
				}
			]
		},
	]
},




{
	"type":"hscrollbar",
	"expand":"width",
	"shrink":"none",
	"clickable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005, // GL_ID_SKIN_BAR
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HScrollBar(left).wgu",
					"size":{"width":12, "height":16},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HScrollBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
					"expand":"all",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HScrollBar(right).wgu",
					"size":{"width":12, "height":16},
					"forealign":"right",
				},
			]
		},

		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004, // GL_ID_SKIN_SLIDER
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HSlider(left).wgu", 
					"size":{"width":6, "height":12},
					"margins":{"left":2, "top":2, "right":0, "bottom":2},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HSlider(center).wgu",
					"margins":{"left":0, "top":2, "right":0, "bottom":2},
					"shrink":"width",
					"transformation":"repeatx",
					"expand":"all",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HSlider(right).wgu",
					"size":{"width":6, "height":12},
					"margins":{"left":0, "top":2, "right":2, "bottom":2},
					"forealign":"right",
				},
			]
		},
	]
}


{
	"type":"icon",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"clicksensitive":true,
	"children":
	[
		{
			"type":"layout",
			"item":{"column":0, "row":1},
			"children":
			[
				// Focus pictures 
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"statemask":"focused",
					"source":"/images/IcoFocus(left).wgu",
					"size":{"width":7},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"focused",
					"source":"/images/IcoFocus(center).wgu",
					"transformation":"repeatx",
					"expand":"all",
					"shrink":"all",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"focused",
					"source":"/images/IcoFocus(right).wgu",
					"size":{"width":7},
					"forealign":"right",
				},

				// Focus pictures 
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"statemask":"unfocused",
					"source":"/images/Icon(left).wgu",
					"size":{"width":7},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"unfocused",
					"source":"/images/Icon(center).wgu",
					"transformation":"repeatx",
					"expand":"all",
					"shrink":"all",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"unfocused",
					"source":"/images/Icon(right).wgu",
					"size":{"width":7},
					"forealign":"right",
				},
			]
		},

		// Icon image 
		{
			"type":"picture",
			"item":{"column":0, "row":1},
			"id":0xFF000006, // GL_ID_SKIN_ICON
			"minsize":{"width":100, "height":100},
			"maxsize":{"width":100, "height":100},
			"shrink":"all",
			"transformation":"fitall",
			"expand":"all",
		},
		
		// Label 
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"backalign":"bottom", 
			"forealign":"left",
			"forecolor":0x0000000D, // GL_COLOR_BUTTON_TEXT
			"margins":{"left":0, "top":15, "right":0, "bottom":0},
			"font":{"size":{"height":0x3FF1}},
			"shrink":"width",
		},
	]
}


{
	"type":"window",
	"backcolor":0xFF000000,
	"borders":{"left":1, "top":1, "right":1, "bottom":1, "unit":"px", "color":0xFF784900},
}

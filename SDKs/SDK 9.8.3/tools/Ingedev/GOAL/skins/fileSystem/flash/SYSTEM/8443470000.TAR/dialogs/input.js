// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	
	"children":
	[
		{
			"type"           :"scrollview",
			"item"           :{"column":0, "row":0},
			"children":
			[
				{
					"type"           :"label",
					"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
					"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
					"text"           :"",
					"grow"           :"all",
					"expand"         :"all",
					"shrink"         :"width",
					"wrap"           : true,
					"forealign"      :"left",
					"font"           :{"size":{"height":0x3FF4}},
				},
			]
		},
		{
			"type"           :"edit",
			"item"           :{"column":0, "row":1},
			"id"             :0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"mask"           :"",
			"fillchar1"      :" ",
			"text"           :"",
			"clickable"      :true,
			"expand"         :"all",
			"grow"           :"all",
			"shrink"         :"width",
			
			"children":
			[
				{
					"type"           :"layout",
					"clicksensitive" :true,
					"expand"         :"all",
					"grow"           :"all",
					"shrink"         :"none",
					
					"children":
					[
						{
							"type"           :"label",
							"item"           :{"column":1, "row":0},
							"id"             :0xFF000001, // GL_ID_SKIN_LABEL
							"font"           :{"size":{"height":0x3FF4}},
							"forealign"      :"right",
							"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
							"expand"         :"all",
							"grow"           :"all",
							"shrink"         :"width",
						},
						{
							"type"           :"label",
							"item"           :{"column":2, "row":0},
							"id"             :0xFF000016, // GL_ID_SKIN_DIALOG_UNIT
							"text"           :" EUR ",
							"font"           :{"size":{"height":0x3FF4}},
							"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
							"expand"         :"height",
							"grow"           :"height",
							"shrink"         : "width",
						}
					]
				}
			]
		},
	]
},


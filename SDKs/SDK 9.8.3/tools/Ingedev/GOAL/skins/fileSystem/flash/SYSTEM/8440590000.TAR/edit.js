{
	"type":"edit",
	"grow":"all",
	"shrink":"width",
	"expand":"width",
	"clickable":true,
	"clicksensitive":true,
	"focusable":true,
	"children":
	[
		// Focus pictures 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(left).wgu",
			"size":{"width":1},
			"forealign":"left",
		},
		{
			"type":"picture",
			"item":{"column":1, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(center).wgu",
			"minsize":{"width":0},
			"shrink":"width",
			"transformation":"repeatx",
			"expand":"all",
		},
		{
			"type":"picture",
			"item":{"column":2, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(right).wgu",
			"size":{"width":1},
			"forealign":"right",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0xFF000000,
			"forealign":"left",
		},
	]
}


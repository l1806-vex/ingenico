{
	"type":"vscrollbar",
	"expand":"height",
	"shrink":"none",
	"clickable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"height",
			"shrink":"none",
			"backalign":"top",
			"id":0xFF000005, // GL_ID_SKIN_BAR
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/VScrollBar(top).wgu",
					"size":{"width":4, "height":1},
					"forealign":"top",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":1},
					"source":"/images/VScrollBar(middle).wgu",
					"shrink":"height",
					"transformation":"repeaty",
					"expand":"all",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":2},
					"source":"/images/VScrollBar(bottom).wgu",
					"size":{"width":4, "height":1},
					"forealign":"bottom",
				},
			]
		},

		{
			"type":"layout",
			"grow":"height",
			"shrink":"none",
			"backalign":"top",
			"id":0xFF000004, // GL_ID_SKIN_SLIDER
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/VSlider(top).wgu", 
					"size":{"width":4, "height":2},
					"margins":{"left":0, "top":0, "right":0, "bottom":0},
					"forealign":"top",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":1},
					"source":"/images/VSlider(middle).wgu",
					"shrink":"height",
					"transformation":"repeaty",
					"expand":"all",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":2},
					"source":"/images/VSlider(bottom).wgu",
					"size":{"width":4, "height":2},
					"margins":{"left":0, "top":0, "right":0, "bottom":0},
					"forealign":"bottom",
				},
			]
		},
	]
}


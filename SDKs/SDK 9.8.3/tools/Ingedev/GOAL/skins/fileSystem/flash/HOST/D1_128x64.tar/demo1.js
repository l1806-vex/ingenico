{
	"type":"window",
	"position":{"x":0, "y":0, "unit":"%"},
	"size":{"width":100, "height":100, "unit":"%"},
	"FONT":
	{
		"name":"manager",
		"style":"normal",
		"size":{"width":5, "height":5, "unit":"%"}
	},
	"backcolor":0xFFf4eee2,
	"children":
	[
		{
			"type":"button",
			"position":{"x":0, "y":8, "unit":"%"},
			"backalign":"left",
			"clickable":true,
			"shortcut":"1",
			"children":
			[
				{
					"type":"layout",
					"children":
					[
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"unfocused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":8, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":0, "top":4, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFFE3220,
							"text":"ml30",
						},
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"focused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":12, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":0, "top":0, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFFE3220,
							"text":"ML30",
						},
						{
							"item":{"column":0, "row":1},
							"type":"picture",
							"shrink":"none",
							"statemask":"focused",
							
							"margins":{"left":38, "top":0, "right":0, "bottom":0, "unit":"%"},
							"source":"ml30.wgu",
							"backcolor":0xFFFF9991,
						},
					]
				},
			]
		},
		{
			"type":"button",
			"position":{"x":0, "y":8, "unit":"%"},
			"clickable":true,
			"shortcut":"2",
			"children":
			[
				{
					"type":"layout",
					"children":
					[
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"unfocused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":8, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":20, "top":4, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFFFB862,
							"text":"eft930",
						},
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"focused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":12, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":20, "top":0, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFFFB862,
							"text":"EFT930",
						},
						{
							"item":{"column":0, "row":1},
							"type":"picture",
							"shrink":"none",
							"statemask":"focused",
							
							"margins":{"left":38, "top":0, "right":0, "bottom":0, "unit":"%"},
							"source":"eft930.wgu",
							"backcolor":0xFFFFC691
						},
					]
				},
			]
		},
		{
			"type":"button",
			"position":{"x":0, "y":8, "unit":"%"},
			"clickable":true,
			"shortcut":"3",
			"children":
			[
				{
					"type":"layout",
					"children":
					[
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"unfocused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":8, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":40, "top":4, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFA39359,
							"text":"ict250",
						},
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"focused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":12, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":40, "top":0, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFFA39359,
							"text":"ICT250",
						},
						{
							"item":{"column":0, "row":1},
							"type":"picture",
							"shrink":"none",
							"statemask":"focused",
							
							"margins":{"left":38, "top":0, "right":0, "bottom":0, "unit":"%"},
							"source":"ict250.wgu",
							"backcolor":0xFFE0D0B0,
						},
					]
				},
			]
		},
		{
			"type":"button",
			"position":{"x":0, "y":8, "unit":"%"},
			"clickable":true,
			"shortcut":"4",
			"children":
			[
				{
					"type":"layout",
					"children":
					[
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"unfocused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":8, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":60, "top":4, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFF294736,
							"text":"ipp350",
						},
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"focused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":12, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":60, "top":0, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFF294736,
							"text":"IPP350",
						},
						{
							"item":{"column":0, "row":1},
							"type":"picture",
							"shrink":"none",
							"statemask":"focused",
							
							"margins":{"left":38, "top":0, "right":0, "bottom":0, "unit":"%"},
							"source":"ipp350.wgu",
							"backcolor":0xFFB9D7C6,
						},
					]
				},
			]
		},
		{
			"type":"button",
			"position":{"x":0, "y":8, "unit":"%"},
			"clickable":true,
			"shortcut":"5",
			"children":
			[
				{
					"type":"layout",
					"children":
					[
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"unfocused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":8, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":80, "top":4, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFF1D2626,
							"text":"isc350",
						},
						{
							"type":"label",
							"id":0xFF000001,
							"statemask":"focused",
							"backalign":"left",
							"font":"$FONT",
							"minsize":{"width":20, "height":12, "unit":"%"},
							"clicksensitive":true,
							"forecolor":0xFFFFFFFF,
							
							"margins":{"left":80, "top":0, "right":0, "bottom":0, "unit":"%"},
							"backcolor":0xFF1D2626,
							"text":"ISC350",
						},
						{
							"item":{"column":0, "row":1},
							"type":"picture",
							"shrink":"none",
							"statemask":"focused",
							
							"margins":{"left":38, "top":0, "right":0, "bottom":0, "unit":"%"},
							"source":"isc350.wgu",
							"backcolor":0xFFC0D0D0,
						},
					]
				},
			]
		},
		
		{
			"type":"label",   
			"position":{"x":0, "y":0, "unit":"%"}, 
			"size":{"width":100, "height":8, "unit":"%"},
			"font":"$FONT",
			"forecolor":0xFFFFFFFF,
			"backcolor":0xFF6B5629,
			"text":"Welcome to Ingenico"
		},
		
		// Bouton OK
		{
			"type":"button",
			"id":3,
			"text":"OK",
			"shortcut"       :"\uF850",
			"position":{"x":2, "y":70, "unit":"%"},
			"minsize":{"width":30, "height":0, "unit":"%"},
			"expand":"none",
			"focusable":false,
			"forealign":"right",
		},
		
		// Bouton cancel
		{
			"type":"button", 
			"id":4, 
			"text":" Cancel ",
			"shortcut"       :"\uF851",
			"position":{"x":2, "y":85, "unit":"%"},
			"minsize":{"width":30, "height":0, "unit":"%"},
			"expand":"none",
			"focusable":false,
		},
	]
}


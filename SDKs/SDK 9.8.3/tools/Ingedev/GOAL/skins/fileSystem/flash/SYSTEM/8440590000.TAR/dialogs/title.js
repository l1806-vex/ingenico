// Title
{
	"type"       :"label",
	"id"         :0xFF00000D, // GL_ID_SKIN_DIALOG_TITLE
	"item":{"column":0, "row":0},
	"grow"       :"width",
	"shrink"     :"all",
	"expand"     :"width",
	"backcolor"  :0xFF000000,
	"forecolor"  :0xFFFFFFFF,
	"text"       :"hello",
	"borders"    :{"left":0, "top":0, "right":0, "bottom":1, "unit":"px", "color":0xFFFFFFFF},
	"font":{"size":{"height":0x3FF2}},
},


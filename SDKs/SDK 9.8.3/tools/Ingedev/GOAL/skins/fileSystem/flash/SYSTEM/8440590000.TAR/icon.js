{
	"type":"icon",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"clicksensitive":true,
	"children":
	[
		// Icon image 
		{
			"type":"picture",
			"item":{"column":0, "row":1},
			"id":0xFF000006, // GL_ID_SKIN_ICON
			"minsize":{"width":32, "height":32},
			"maxsize":{"width":32, "height":32},
			"backalign":"top",
			"source":"/images/IcoFocus(center).wgu",
			"margins":{"left":0, "top":0, "right":0, "bottom":6},
			"shrink":"all",
			"transformation":"fitall",
			"expand":"all",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"backalign":"bottom", 
			"forealign":"left",
			"forecolor":0xFF000000,
			"statemask":"unfocused",
			"font":{"size":{"height":0x3FF1}},
			"margins":{"left":0, "top":0, "right":0, "bottom":1},
			"shrink":"all",
		},
		// Label 
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"backalign":"bottom", 
			"forealign":"left",
			"statemask":"focused",
			"forecolor":0xFFFFFFFF,
			"backcolor":0xFF000000,
			"font":{"size":{"height":0x3FF1}},
			"margins":{"left":0, "top":0, "right":0, "bottom":1},
			"shrink":"width",
		},
	]
}


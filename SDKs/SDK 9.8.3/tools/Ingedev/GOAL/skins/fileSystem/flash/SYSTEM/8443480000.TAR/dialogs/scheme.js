// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	"children":
	[
		{
			"type"           : "label",
			"id"             : 0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"item":{"column":0, "row":0},
			"forealign"      : "center",
			"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
			"text"           : "",
			"font"           :{"size":{"height":0x3FF4}},
			"shrink"         : "width",
		},
		{
			"type"           : "label",
			"id"             : 0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"item":{"column":0, "row":1},
			"forealign"      : "center",
			"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
			"text"           : "",
			"font"           :{"size":{"height":0x3FF4}},
			"shrink"         : "width",
		},
		
		{
			"type"           : "label",
			"id"             : 0xFF000019, // GL_ID_SKIN_DIALOG_HELP
			"grow"           : "width",
			"item":{"column":0, "row":2},
			"forealign"      : "center",
			"text"           : "",
			"font"           :{"size":{"height":0x3FF4}},
			"shrink"         : "width",
			"forecolor"      : 0x00000012, // GL_COLOR_DIALOG_HELP_TEXT
			"backcolor"      : 0x00000013, // GL_COLOR_DIALOG_HELP_TEXT_BACKGROUND
			"expand"         : "width",
		},
	]
},


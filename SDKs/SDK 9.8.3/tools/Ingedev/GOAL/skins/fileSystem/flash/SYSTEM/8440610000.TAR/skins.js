{
	"type":"skin",
	"skins":
	{
		// Widgets
		"label"               : "label.js",
		"button"              : "button.js",
		"checkbutton"         : "checkbutton.js",
		"radiobutton"         : "radiobutton.js",
		"edit"                : "edit.js",
		"vscrollbar"          : "vscrollbar.js",
		"hscrollbar"          : "hscrollbar.js",
		"progressbar"         : "progressbar.js",
		"icon"                : "icon.js",
		"iconbutton"          : "iconbutton.js",
		"list"                : "list.js",
		"dialog"              : "dialog.js",
		"palette"             : "palette.js",
		"virtualkeyboard"     : "virtualkeyboard.js",
		"key"                 : "key.js",
		"hslider"             : "hslider.js",
		"window"              : "window.js",
		"print"               : "print.js",
		"signature"           : "signature.js",
		"arrowbutton"         : "arrowbutton.js",

		// Dialogs
		"dialogs/message"     : "dialogs/message.js",
		"dialogs/title"       : "dialogs/title.js",
		"dialogs/buttons"     : "dialogs/buttons.js",
		"dialogs/input"       : "dialogs/input.js",
		"dialogs/list"        : "dialogs/list.js",
		"dialogs/color"       : "dialogs/color.js",
		"dialogs/media"       : "dialogs/media.js",
		"dialogs/picture"     : "dialogs/picture.js",
		"dialogs/keyboard"    : "dialogs/keyboard.js",
		"dialogs/slider"      : "dialogs/slider.js",
		"dialogs/progress"    : "dialogs/progress.js",
		"dialogs/file"        : "dialogs/file.js",
		"dialogs/scheme"      : "dialogs/scheme.js",
		"dialogs/signature"   : "dialogs/signature.js",

		// Images
		"images/question"     : "images/question.wgu",
		"images/information"  : "images/information.wgu",
		"images/error"        : "images/error.wgu",
		"images/warning"      : "images/warning.wgu",
		"images/correction"   : "images/correction.wgu",
		"images/cancel"       : "images/cancel.wgu",
		"images/validation"   : "images/validation.wgu",
		"images/mistake"      : "images/mistake.wgu",
		// __NEWTYPE__ 
	}
}

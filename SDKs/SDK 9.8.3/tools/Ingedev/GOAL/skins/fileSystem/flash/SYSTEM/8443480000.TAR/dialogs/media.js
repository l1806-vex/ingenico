// Content
{
	"type"       : "layout",
	"id"         : 0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item"       : {"column":0, "row":1},
	"grow"       : "all",
	"shrink"     : "none",
	"expand"     : "all",
	"children":
	[
		{
			"type"           : "label",
			"id"             : 0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"item"           : {"column":0, "row":0},
			"text"           : "",
			"grow"           : "width",
			"shrink"         : "width",
			"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
		},
		{
			"type"           : "media",
			"item"           : {"column":0, "row":1},
			"id"             : 0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"shrink"         : "all",
			"keepratio"      : true,
			"volume"         : 255,
			"loop"           : true,
		},
	]
},


// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	
	"children":
	[
		{
			"type"           :"picture",
			"item"           :{"column":0, "row":0},
			"id"             :0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"shrink"         : "all",
			"grow"           : "all",
			"transformation" :"fitall",
			"expand":"all",
		},
		{
			"type"           :"scrollview",
			"item"           :{"column":0, "row":0},
			"children":
			[
				{
					"type"           :"label",
					"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
					"forecolor"      :0x0000000E, // GL_COLOR_DIALOG_TEXT
					"backcolor"      :0x0000000F, // GL_COLOR_DIALOG_TEXT_BACKGROUND
					"text"           :"",
					"shrink"         :"width",
					"wrap"           : true,
				},
			]
		}
	]
},


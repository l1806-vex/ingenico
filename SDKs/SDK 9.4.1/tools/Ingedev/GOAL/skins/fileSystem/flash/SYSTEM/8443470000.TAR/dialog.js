{
	"type"       :"dialog",
	"id"         :0xFF00000B, // GL_ID_SKIN_DIALOG
	"grow"       :"all",
	"expand"     :"all",
	"shrink"     :"none",
	"children":
	[
		{
			"type":"layout",
			"id":0xFF000014, // GL_ID_SKIN_DIALOG_LAYOUT
			"children":
			[
			]
		}
	]
}


{
	"type"  :"list",
	"grow"  :"all",
	"expand":"all",
	"shrink":"none",
	"forealign":"left",
	"children":
	[
		{
			"type"  :"scrollview",
			"item":{"column":0, "row":0},
			"id":0xFF00000A, // GL_ID_SKIN_SCROLLVIEW
			"children":
			[
				{
					"type"  :"layout",
					"id"    :0xFF000009, // GL_ID_SKIN_LIST
					"forealign":"top",
					"children":
					[
					]
				}
			]
		},
		{
			"type":"vscrollbar",
			"item":{"column":1, "row":0},
			"id"  :0xFF000008, // GL_ID_SKIN_VSCROLLBAR
		}
	]
}


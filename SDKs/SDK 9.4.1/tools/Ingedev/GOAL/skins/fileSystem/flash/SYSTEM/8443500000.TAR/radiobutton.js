{
	"type":"radiobutton",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"clicksensitive":true,
	"focusable":true,
	"children":
	[
		// Focus pictures 
		{
			"type":"picture",
			"item":{"column":1, "row":0},
			"statemask":"focused",
			"source":"/images/ButFocus(left).wgu",
			"size":{"width":14},
			"margins":{"left":4, "top":2, "right":0, "bottom":2},
			"forealign":"left",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},
		{
			"type":"picture",
			"item":{"column":2, "row":0},
			"statemask":"focused",
			"source":"/images/ButFocus(center).wgu",
			"margins":{"left":0, "top":2, "right":0, "bottom":2},
			"transformation":"repeatxstretchy",
			"expand":"all",
			"shrink":"all",
		},
		{
			"type":"picture",
			"item":{"column":3, "row":0},
			"statemask":"focused",
			"source":"/images/ButFocus(right).wgu",
			"size":{"width":14},
			"margins":{"left":0, "top":2, "right":4, "bottom":2},
			"forealign":"right",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},

		// Button pictures 
		{
			"type":"picture",
			"item":{"column":1, "row":0},
			"statemask":"unfocused",
			"source":"/images/Button(left).wgu", 
			"size":{"width":14},
			"margins":{"left":4, "top":2, "right":0, "bottom":2},
			"forealign":"left",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},
		{
			"type":"picture",
			"item":{"column":2, "row":0},
			"statemask":"unfocused",
			"source":"/images/Button(center).wgu",
			"margins":{"left":0, "top":2, "right":0, "bottom":2},
			"transformation":"repeatxstretchy",
			"expand":"all",
			"shrink":"all",
		},
		{
			"type":"picture",
			"item":{"column":3, "row":0},
			"statemask":"unfocused",
			"source":"/images/Button(right).wgu",
			"size":{"width":14},
			"margins":{"left":0, "top":2, "right":4, "bottom":2},
			"forealign":"right",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},

		// Uncheck image 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF000003, // GL_ID_SKIN_CHECK
			"statemask":"unchecked",
			"source":"/images/RadioOff.wgu",
			"size":{"width":72},
		},
		
		// Check image 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF000003, // GL_ID_SKIN_CHECK
			"statemask":"checked",
			"source":"/images/RadioOn.wgu",
			"size":{"width":72},
		},

		// Label 
		{
			"type":"label",
			"item":{"column":2, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0x0000000D, // GL_COLOR_BUTTON_TEXT
		},
	]
}


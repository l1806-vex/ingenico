{
	"type":"key",
	"grow":"all",
	"expand":"all",
	"shrink":"none",
	"clickable":true,
	"clicksensitive":true,
	"focusable":false,
	"children":
	[
		// Label
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"expand":"all",
			"grow":"all",
			"statemask":"checked",
			"backcolor":0xFFF6AC06,
			"shrink":"all",
		},

		// Background
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"source":"/images/Key(center).wgu",
			"shrink":"all",
			"transformation":"repeatx",
			"expand":"all",
			"margins":{"left":3, "top":3, "right":3, "bottom":3, "unit":"px", },
		},
		
		// Key icon
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF00001B,  // GL_ID_SKIN_KEY_ICON
			"shrink":"all",
		},

		// Label
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001, 
			"forecolor":0xFFFFFFFF, // GL_ID_SKIN_LABEL
			"expand":"all",
			"grow":"all",
			"statemask":"unchecked,checked",
			"font":{"style":"normal","size":{"width":0x3FF2, "height":0x3FF2}} , 
			"shrink":"all",
		},
	]
}


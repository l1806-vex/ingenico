{
	"type":"virtualkeyboard",
	"grow":"all",
	"shrink":"none",
	"clickable":false,
	"focusable":true,
	"expand":"all",
	"children":
	[
		{
			"type":"layout",
			"children":
			[
				{
					"type":"edit",
					"item":{"column":0, "row":0},
					"id": 0xFF000017, // GL_ID_SKIN_EDIT_FIELD
					"focusable":false,
					"clicksensitive":false,
					"clickable":false,
					"grow":"width",
					"expand":"width",
					"shrink":"width",
					"textalign":"right",
					"children":
					[
						{
							"type":"layout",
							"grow":"width",
							"shrink":"none",
							"clicksensitive":true,
							"children":
							[
								// Focus pictures 
								{
									"type":"picture",
									"item":{"column":0, "row":0},
									"source":"/images/EditFocus(left).wgu",
									"size":{"width":1, "height":11},
									"forealign":"left",
									"margins":{"left":1, "top":0, "right":0, "bottom":0},
								},
								{
									"type":"picture",
									"item":{"column":1, "row":0},
									"source":"/images/EditFocus(center).wgu",
									"minsize":{"width":0, "height":11},
									"shrink":"width",
									"transformation":"repeatx",
									"expand":"all",
								},
								{
									"type":"picture",
									"item":{"column":2, "row":0},
									"source":"/images/EditFocus(right).wgu",
									"size":{"width":1, "height":11},
									"forealign":"right",
									"margins":{"left":0, "top":0, "right":1, "bottom":0},
								},

								// Label 
								{
									"type":"label",
									"item":{"column":1, "row":0}, 
									"id":0xFF000001, // GL_ID_SKIN_LABEL
									"font":{"size":{"height":0x3FF3}},
									"forecolor":0xFF000000,
									"forealign":"left",
									"expand":"width",
									"shrink":"width",
								},
							]
						}
					]
				},
				{
					"type":"layout",
					"item":{"column":0, "row":1},
					"id": 0xFF00001A, // GL_ID_SKIN_DIALOG_KEYBOARD
					"children":
					[
					]
				},
			]
		}
	],
	"anychar":
	[
		{"type":"page","name":"123","mapping":"1234567890+-.\n[]{}()<>=*%\\/\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDEFGHIJKLM\nNOPQRSTUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"abc","mapping":"abcdefghijklm\nnopqrstuvwxyz\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"#$%","mapping":"!?,;:\\|^~&\n`'\"#$%@.\n\uF808\uF809 \uF851\uF852\uF850"},
	],
	"alphanumeric":
	[
		{"type":"page","name":"123","mapping":"12345\n67890\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDEFGHIJKLM\nNOPQRSTUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"abc","mapping":"abcdefghijklm\nnopqrstuvwxyz\n\uF808\uF809 \uF851\uF852\uF850"},
	],
	"decimal":
	[
		{"type":"page","name":"123","mapping":"12345\n67890\n\uF851\uF852\uF850"},
	],
	"hexadecimal":
	[
		{"type":"page","name":"123","mapping":"1234567890\nABCDEF\n\uF851\uF852\uF850"},
	],
	"octal":
	[
		{"type":"page","name":"123","mapping":"12345670\n\uF851\uF852\uF850"},
	],
	"binary":
	[
		{"type":"page","name":"123","mapping":"10\n\uF851\uF852\uF850"},
	],
	"usermapping":
	[
		{"type":"page","name":"<-","mapping":"_____________\n_____________\n\uF808\uF809\uF851\uF852\uF850"},
	],
}





{
	
	// xxsmall = 0x3FF0 24 characters // Not used
	// xsmall  = 0x3FF1 24 characters
	// small   = 0x3FF2 22 characters
	// medium  = 0x3FF3 20 characters
	// large   = 0x3FF4 16 characters
	// xlarge  = 0x3FF5 12 characters // Not used
	// xxlarge = 0x3FF6 10 characters // Not used
	
	"type":"graphiclib",
	"fontname":"GOAL",
	"charset":"utf8",
	"fonts":
	[
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"default",
			"xxsmall": 5,
			"xsmall" : 5,
			"small"  : 7,
			"medium" :10,
			"large"  :16,
			"xlarge" :20,
			"xxlarge":25,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"128x64",
			"xxsmall": 5,
			"xsmall" : 5,
			"small"  : 7,
			"medium" :10,
			"large"  :16,
			"xlarge" :20,
			"xxlarge":25,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"240x320",
			"xxsmall":7,
			"xsmall" :10,
			"small"  :16,
			"medium" :20,
			"large"  :25,
			"xlarge" :30,
			"xxlarge":39,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"320x240",
			"xxsmall":10,
			"xsmall" :16,
			"small"  :20,
			"medium" :25,
			"large"  :30,
			"xlarge" :39,
			"xxlarge":49,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"320x480",
			"xxsmall":10,
			"xsmall" :16,
			"small"  :20,
			"medium" :25,
			"large"  :30,
			"xlarge" :39,
			"xxlarge":49,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"480x272",
			"xxsmall":10,
			"xsmall" :16,
			"small"  :20,
			"medium" :25,
			"large"  :30,
			"xlarge" :39,
			"xxlarge":49,
		},
		{
			"type"   :"fontscale",
			"device" :"screen",
			"size"   :"640x480",
			"xxsmall":20,
			"xsmall" :25,
			"small"  :32,
			"medium" :39,
			"large"  :49,
			"xlarge" :49,
			"xxlarge":49,
		},
		{
			"type"   :"fontscale",
			"device" :"printer",
			"size"   :"default",
			"xxsmall":10,
			"xsmall" :16,
			"small"  :20,
			"medium" :25,
			"large"  :32,
			"xlarge" :39,
			"xxlarge":49,
		}
	],
}

{
	"type":"edit",
	"grow":"all",
	"shrink":"width",
	"clickable":true,
	"clicksensitive":true,
	"focusable":true,
	"children":
	[
		// Focus pictures 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(left).wgu",
			"size":{"width":6},
			"forealign":"left",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},
		{
			"type":"picture",
			"item":{"column":1, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(center).wgu",
			"transformation":"repeatxstretchy",
			"expand":"all",
			"shrink":"all",
		},
		{
			"type":"picture",
			"item":{"column":2, "row":0},
			"statemask":"focused",
			"source":"/images/EditFocus(right).wgu",
			"size":{"width":6},
			"forealign":"right",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},

		// Button pictures 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"statemask":"unfocused",
			"source":"/images/Edit(left).wgu", 
			"size":{"width":2},
			"margins":{"left":4, "top":4, "right":0, "bottom":4},
			"forealign":"left",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},
		{
			"type":"picture",
			"item":{"column":1, "row":0},
			"statemask":"unfocused",
			"source":"/images/Edit(center).wgu",
			"margins":{"left":0, "top":4, "right":0, "bottom":4},
			"transformation":"repeatxstretchy",
			"expand":"all",
			"shrink":"all",
		},
		{
			"type":"picture",
			"item":{"column":2, "row":0},
			"statemask":"unfocused",
			"source":"/images/Edit(right).wgu",
			"size":{"width":2},
			"margins":{"left":0, "top":4, "right":4, "bottom":4},
			"forealign":"right",
			"transformation":"stretchy",
			"expand":"height",
			"shrink":"height",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF4}},
			"forecolor":0x0000000C, // GL_COLOR_EDIT_TEXT
			"forealign":"left",
			"margins":{"top":4, "bottom":4},
		},
	]
}


{
	"type":"progressbar",
	"expand":"width",
	"shrink":"none",
	"children":
	[
		// Progress bar 
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005, // GL_ID_SKIN_BAR
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/ProgressBar(left).wgu",
					"size":{"width":22, "height":44},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/ProgressBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
					"expand":"all",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/ProgressBar(right).wgu",
					"size":{"width":22, "height":44},
					"forealign":"right",
				},
			]
		},
		// Slider 
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004, // GL_ID_SKIN_SLIDER
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/ProgressSlider(left).wgu",
					"forealign":"left",
					"size":{"width":19, "height":36},
					"margins":{"left":5, "top":4, "right":0, "bottom":4, "unit":"px"},
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/ProgressSlider(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
					"expand":"all",
					"margins":{"left":0, "top":4, "right":0, "bottom":4, "unit":"px"},
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/ProgressSlider(right).wgu",
					"forealign":"right",
					"size":{"width":19, "height":36},
					"margins":{"left":0, "top":4, "right":5, "bottom":4, "unit":"px"},
				},
			]
		},
		// Label 
		{
			"type":"label",
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF2}},
			"forecolor":0x00000010, // GL_COLOR_PROGRESS_TEXT
			"backcolor":0x00000011, // GL_COLOR_PROGRESS_TEXT_BACKGROUND
			"text":"%3d%%",
		},
	]
}


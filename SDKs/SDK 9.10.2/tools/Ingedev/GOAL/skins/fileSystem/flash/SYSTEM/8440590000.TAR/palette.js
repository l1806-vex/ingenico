{
	"type"          :"palette",
	"focussize"     :100,
	"focusbackcolor":0xFFFFFFFF,
	"focusforecolor":0xFF000000,
	"bordercolor"   :0xFF000000,
	"maxcolors"     :2,
	"maxlights"     :1,
}

// Buttons
{
	"type"           :"layout",
	"id"             :0xFF00000F, // GL_ID_SKIN_DIALOG_BUTTONS
	"item"           :{"column":0, "row":2},
	"maxsize"        :{"width":0xFFFE, "height":0},
	
	"grow"           :"width",
	"shrink"         :"all",
	"expand"         :"width",
	
	"children":
	[
		{
			"type"           :"button",
			"id"             :0xFF000013, // GL_ID_SKIN_DIALOG_CANCEL
			"item"           :{"column":0, "row":0},
			"text"           :"",
			"textalign"      :"right",
			"focusable"      :false,
			"shortcut"       :"\uF851",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"picture",
			"id"             :0xFF000013, // GL_ID_SKIN_DIALOG_CANCEL
			"item"           :{"column":0, "row":0},
			"source"         :"../images/cancel.wgu",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"button",
			"id"             :0xFF000012, // GL_ID_SKIN_DIALOG_CORRECTION
			"item":{"column":1, "row":0},
			"text"           :"",
			"textalign"      :"right",
			"focusable"      :false,
			"shortcut"       :"\uF852",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"picture",
			"id"             :0xFF000012, // GL_ID_SKIN_DIALOG_CORRECTION
			"item"           :{"column":1, "row":0},
			"source"         :"../images/correction.wgu",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"button",
			"id"             :0xFF000011, // GL_ID_SKIN_DIALOG_VALID
			"item"           :{"column":2, "row":0},
			"text"           :"",
			"textalign"      :"right",
			"focusable"      :false,
			"shortcut"       :"\uF850",
			
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"picture",
			"id"             :0xFF000011, // GL_ID_SKIN_DIALOG_VALID
			"item"           :{"column":2, "row":0},
			"source"         :"../images/validation.wgu",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"button",
			"id"             :0xFF00001C, // GL_ID_SKIN_DIALOG_SHORTCUT
			"item"           :{"column":3, "row":0},
			"text"           :"",
			"textalign"      :"right",
			"focusable"      :false,
			"shortcut"       :".",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
		{
			"type"           :"picture",
			"id"             :0xFF00001C, // GL_ID_SKIN_DIALOG_SHORTCUT
			"item"           :{"column":3, "row":0},
			"source"         :"../images/shortcut.wgu",
			"grow"           :"width",
			"shrink"         :"none",
			"expand"         :"width",
			"margins"        :{"left":3, "top":1, "right":3, "bottom":3, "unit":"%"},
		},
	]
}

// Content
{
	"type"       :"list",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	"margins"        :{"left":3, "top":3, "right":3, "bottom":3, "unit":"%"},
},


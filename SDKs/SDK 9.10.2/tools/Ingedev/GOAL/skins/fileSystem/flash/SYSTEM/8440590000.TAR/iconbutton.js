{
	"type":"iconbutton",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"clicksensitive":true,
	"focusable":true,
	"children":
	[
		// Icon image 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF000006, // GL_ID_SKIN_ICON
			"size":{"width":20, "height":20},
			"source":"",
			"margins":{"left":1, "top":1, "right":1, "bottom":1},
			"shrink":"all",
			"transformation":"fitall",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0xFFFFFFFF,
			"backcolor":0xFF000000,
			"statemask":"focused",
			"expand":"width",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001,// GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0xFF000000,
			"backcolor":0xFFFFFFFF,
			"statemask":"unfocused",
		},
	]
}

{
	"type":"window",
	"backcolor":0x00000004, // GL_COLOR_WINDOW_BACKGROUND
	"borders":{"left":1, "top":1, "right":1, "bottom":1, "unit":"px", "color":0x00000005}, // GL_COLOR_WINDOW_BORDER
}

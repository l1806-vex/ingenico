// Title
{
	"type"       :"label",
	"id"         :0xFF00000D, // GL_ID_SKIN_DIALOG_TITLE
	"item":{"column":0, "row":0},
	"grow"       :"width",
	"shrink"     :"all",
	"expand"     :"width",
	"backcolor"  :0x00000005, // GL_COLOR_WINDOW_BORDER
	"forecolor"  :0x00000006, // GL_COLOR_WINDOW_TEXT
	"text"       :"hello",
	"font":{"size":{"height":0x3FF2}},
},


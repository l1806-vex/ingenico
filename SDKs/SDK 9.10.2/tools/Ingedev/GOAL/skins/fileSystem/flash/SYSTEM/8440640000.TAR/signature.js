{
	"type":"signature",
	"forecolor":0x00000007, // GL_COLOR_SIGNATURE_INK
	"backcolor":0x00000009, // GL_COLOR_SIGNATURE_BACKGROUND
	"penwidth":2,
	
	"borders":{"left":2, "top":2, "right":2, "bottom":2, "unit":"px", "color":0x00000008}, // GL_COLOR_SIGNATURE_BORDER
}

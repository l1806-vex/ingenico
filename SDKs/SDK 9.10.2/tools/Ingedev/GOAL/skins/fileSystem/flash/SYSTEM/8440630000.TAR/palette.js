{
	"type"          :"palette",
	"focussize"     :20,
	"focusbackcolor":0x0000000A, // GL_COLOR_PALETTE_FOCUS
	"focusforecolor":0x0000000B, // GL_COLOR_PALETTE_FOCUS_BORDER
	"maxcolors"     :10,
	"maxlights"     :11,
}

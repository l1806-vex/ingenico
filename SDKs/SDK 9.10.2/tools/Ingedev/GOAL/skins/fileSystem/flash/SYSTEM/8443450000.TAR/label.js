{
	"type":"label",
	"font":{"size"  :{"height":0x3FF3}},
	"paddings":{"left":1, "top":1, "right":1, "bottom":1},
	"forecolor":0xFF000000,
}

{
	"type":"virtualkeyboard",
	"grow":"all",
	"shrink":"none",
	"clickable":false,
	"focusable":true,
	"expand":"all",
	"children":
	[
		{
			"type":"layout",
			"children":
			[
				{
					"type":"edit",
					"item":{"column":0, "row":0},
					"id": 0xFF000017, // GL_ID_SKIN_EDIT_FIELD
					"focusable":false,
					"clicksensitive":false,
					"clickable":false,
					"grow":"width",
					"expand":"width",
					"shrink":"width",
					"textalign":"right",
				},
				{
					"type":"layout",
					"item":{"column":0, "row":1},
					"id": 0xFF00001A, // GL_ID_SKIN_DIALOG_KEYBOARD
					"children":
					[
					]
				},
			]
		}
	],
	"anychar":
	[
		{"type":"page","name":"123","mapping":"123\n456\n789\n.0*\n\uF808\uF809\uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDEFGHI\nJKLMNOPQR\nSTUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"abc","mapping":"abcdefghi\njklmnopqr\nstuvwxyz\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"#$%","mapping":"[]{}()<>\n=+-/\\*\"#\n!?,;:`'~\n.$%|^@_&\n\uF808\uF809 \uF851\uF852\uF850"},
	],
	"alphanumeric":
	[
		{"type":"page","name":"123","mapping":"12345\n67890\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDEFGHI\nJKLMNOPQR\nSTUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"abc","mapping":"abcdefghi\njklmnopqr\nstuvwxyz\n\uF808\uF809 \uF851\uF852\uF850"},
	],
	"decimal":
	[
		{"type":"page","name":"123","mapping":"12345\n67890\n\uF851\uF852\uF850"},
	],
	"hexadecimal":
	[
		{"type":"page","name":"123","mapping":"12345\n67890\nABCDEF\n\uF851\uF852\uF850"},
	],
	"octal":
	[
		{"type":"page","name":"123","mapping":"1234\n5670\n\uF851\uF852\uF850"},
	],
	"binary":
	[
		{"type":"page","name":"123","mapping":"10\n\uF851\uF852\uF850"},
	],
	"usermapping":
	[
		{"type":"page","name":"<-","mapping":"_________\n_________\n_________\n\uF808\uF809\uF851\uF852\uF850"},
	],
}


{
	"type":"checkbutton",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"clicksensitive":true,
	"focusable":true,
	"children":
	[
		// Uncheck image 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF000003, // GL_ID_SKIN_CHECK
			"statemask":"unchecked",
			"source":"/images/CheckOff.wgu",
			"size":{"width":10},
		},
		
		// Check image 
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF000003, // GL_ID_SKIN_CHECK
			"statemask":"checked",
			"source":"/images/CheckOn.wgu",
			"size":{"width":10},
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0xFFFFFFFF,
			"backcolor":0xFF000000,
			"statemask":"focused",
			"expand":"width",
		},

		// Label 
		{
			"type":"label",
			"item":{"column":1, "row":0},
			"id":0xFF000001, // GL_ID_SKIN_LABEL
			"font":{"size":{"height":0x3FF3}},
			"forecolor":0xFF000000,
			"backcolor":0xFFFFFFFF,
			"statemask":"unfocused",
		},
	]
}

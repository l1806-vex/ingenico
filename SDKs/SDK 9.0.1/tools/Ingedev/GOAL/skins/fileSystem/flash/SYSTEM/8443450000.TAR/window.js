{
	"type":"window",
	"backcolor":0xFFFFFFFF,
	"borders":{"left":1, "top":1, "right":1, "bottom":1, "unit":"px", "color":0xFF000000},
}

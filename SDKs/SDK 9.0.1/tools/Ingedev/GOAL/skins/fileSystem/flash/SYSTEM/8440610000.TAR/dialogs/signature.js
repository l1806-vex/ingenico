// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item"       :{"column":0, "row":1},
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	"children":
	[
		{
			"type"           :"label",
			"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"item"           :{"column":0, "row":0},
			"text"           :"",
			"grow"           :"width",
			"shrink"         :"width",
		},
		{
			"type"           :"signature",
			"item"           :{"column":0, "row":1},
			"id"             :0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"margins"        :{"left":5, "top":5, "right":5, "bottom":5, "unit":"px"},
		},
	]
},


{
	"type":"label",
	"font":
	{
		"style":"normal",
		"size"  :{"height":0x3FF3},
	},
	"paddings":{"left":1, "top":1, "right":1, "bottom":1},
	"forecolor":0x00000001, // GL_COLOR_LABEL_TEXT
}

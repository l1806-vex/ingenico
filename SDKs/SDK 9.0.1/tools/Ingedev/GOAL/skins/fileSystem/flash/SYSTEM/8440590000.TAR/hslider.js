{
	"type":"hslider",
	"grow":"width",
	"expand":"width",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HSlideBar(left).wgu",
					"size":{"width":1, "height":4},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HSlideBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HSlideBar(right).wgu",
					"size":{"width":1, "height":4},
					"forealign":"right",
				},
			]
		},

		{
			"type":"layout",
			"grow":"none",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/SliderFocus.wgu",
					"size":{"width":6, "height":10},
					"forealign":"right",
					"margins":{"left":1, "top":0, "right":1, "bottom":0},
					"statemask":"focused",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/Slider.wgu", 
					"size":{"width":6, "height":10},
					"margins":{"left":1, "top":0, "right":1, "bottom":0},
					"forealign":"left",
					"statemask":"unfocused",
				},
			]
		},
	]
}


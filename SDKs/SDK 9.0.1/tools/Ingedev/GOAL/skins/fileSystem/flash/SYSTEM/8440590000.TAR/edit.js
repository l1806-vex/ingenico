{
	"type":"edit",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"clicksensitive":true,
			"children":
			[
				/* Focus pictures */
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(left).wgu",
					"size":{"width":1, "height":11},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(center).wgu",
					"minsize":{"width":0, "height":11},
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(right).wgu",
					"size":{"width":1, "height":11},
					"forealign":"right",
				},

				/* Button pictures */
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"unfocused",
					"source":"/images/Edit(center).wgu",
					"minsize":{"width":0, "height":11},
					"shrink":"width",
					"transformation":"repeatx",
				},
				
				/* Label */
				{
					"type":"label",
					"item":{"column":1, "row":0},
					"id":0xFF000001, 
					"font":{"style":"normal","size":{"width":0x3FF3, "height":0x3FF3}} , 
					"forecolor":0xFF000000,
					"forealign":"left",
					"expand":"width",
					"statemask":"focused",
					"shrink":"width",
				},

				/* Label */
				{
					"type":"label",
					"item":{"column":1, "row":0}, "id":0xFF000001, 
					"font":{"style":"normal","size":{"width":0x3FF3, "height":0x3FF3}} , 
					"forecolor":0xFF000000,
					"forealign":"left",
					"expand":"width",
					"statemask":"unfocused",
					"shrink":"width",
				},
			]
		}
	]
}


{
	"type":"iconbutton",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"clicksensitive":true,
			"children":
			[
				/* Icon image */
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"id":0xFF000006,
					"minsize":{"width":50, "height":50},
					"maxsize":{"width":50, "height":50},
					"source":"",
					"margins":{"left":1, "top":1, "right":1, "bottom":1},
					"shrink":"all",
					"transformation":"fitall",
				},
				
				/* Focus pictures */
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"focused",
					"source":"/images/ButFocus(Left).wgu",
					"size":{"width":7, "height":32},
					"margins":{"left":3, "top":2, "right":0, "bottom":2},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"focused",
					"source":"/images/ButFocus(center).wgu",
					"minsize":{"width":0, "height":32},
					"margins":{"left":0, "top":2, "right":0, "bottom":2},
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":3, "row":0},
					"statemask":"focused",
					"source":"/images/ButFocus(right).wgu",
					"size":{"width":7, "height":32},
					"margins":{"left":0, "top":2, "right":3, "bottom":2},
					"forealign":"right",
				},

				/* Button pictures */
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"unfocused",
					"source":"/images/Button(left).wgu", 
					"size":{"width":7, "height":32},
					"margins":{"left":3, "top":2, "right":0, "bottom":2},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"unfocused",
					"source":"/images/Button(center).wgu",
					"minsize":{"width":0, "height":32},
					"margins":{"left":0, "top":2, "right":0, "bottom":2},
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":3, "row":0},
					"statemask":"unfocused",
					"source":"/images/Button(right).wgu",
					"size":{"width":7, "height":32},
					"margins":{"left":0, "top":2, "right":3, "bottom":2},
					"forealign":"right",
				},

				/* Label */
				{
					"type":"label",
					"item":{"column":2, "row":0},
					"id":0xFF000001, 
					"font":{"style":"normal","size":{"width":0x3FF3, "height":0x3FF3}} , 
					"forecolor":0x0000000D, // GL_COLOR_BUTTON_TEXT
					"expand":"width",
				},
			]
		}
	]
}


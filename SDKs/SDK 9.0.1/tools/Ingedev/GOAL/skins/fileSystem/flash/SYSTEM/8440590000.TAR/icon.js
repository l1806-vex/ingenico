{
	"type":"icon",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"clicksensitive":true,
			"children":
			[
				/* Icon image */
				{
					"type":"picture",
					"item":{"column":0, "row":1},
					"id":0xFF000006,
					"minsize":{"width":32, "height":32},
					"maxsize":{"width":32, "height":32},
					"backalign":"top",
					"source":"/images/IcoFocus(center).wgu",
					"margins":{"left":0, "top":0, "right":0, "bottom":6},
					"shrink":"all",
					"transformation":"fitall",
				},

				/* Label */
				{
					"type":"label",
					"item":{"column":0, "row":0},
					"id":0xFF000001, 
					"backalign":"bottom", 
					"forealign":"left",
					"forecolor":0xFF000000,
					"statemask":"unfocused",
					"font":{"size":{"height":0x3FF1}},
					"margins":{"left":0, "top":0, "right":0, "bottom":1},
					"shrink":"all",
				},
				/* Label */
				{
					"type":"label",
					"item":{"column":0, "row":0},
					"id":0xFF000001, 
					"backalign":"bottom", 
					"forealign":"left",
					"statemask":"focused",
					"forecolor":0xFFFFFFFF,
					"backcolor":0xFF000000,
					"font":{"size":{"height":0x3FF1}},
					"margins":{"left":0, "top":0, "right":0, "bottom":1},
					"shrink":"width",
				},
			]
		}
	]
}


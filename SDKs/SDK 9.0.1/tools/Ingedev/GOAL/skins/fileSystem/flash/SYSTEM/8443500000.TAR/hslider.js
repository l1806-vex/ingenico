{
	"type":"hslider",
	"grow":"width",
	"expand":"width",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HScrollBar(left).wgu",
					"size":{"width":12, "height":44},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HScrollBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
					"size":{"width":0x3FFF, "height":44},
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HScrollBar(right).wgu",
					"size":{"width":12, "height":44},
					"forealign":"right",
				},
			]
		},

		{
			"type":"layout",
			"grow":"none",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/SliderFocus.wgu",
					"size":{"width":44, "height":44},
					"forealign":"right",
					"statemask":"focused",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/Slider.wgu", 
					"size":{"width":44, "height":44},
					"forealign":"left",
					"statemask":"unfocused",
				},
			]
		},
	]
}


{
	"type":"edit",
	"grow":"all",
	"shrink":"none",
	"clickable":true,
	"focusable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"clicksensitive":true,
			"children":
			[
				/* Focus pictures */
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(left).wgu",
					"size":{"width":6, "height":50},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(center).wgu",
					"minsize":{"width":0, "height":50},
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"focused",
					"source":"/images/EditFocus(right).wgu",
					"size":{"width":6, "height":50},
					"forealign":"right",
				},

				/* Button pictures */
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"statemask":"unfocused",
					"source":"/images/Edit(left).wgu", 
					"size":{"width":2, "height":44},
					"margins":{"left":4, "top":4, "right":0, "bottom":4},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"statemask":"unfocused",
					"source":"/images/Edit(center).wgu",
					"minsize":{"width":0, "height":44},
					"margins":{"left":0, "top":4, "right":0, "bottom":4},
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"statemask":"unfocused",
					"source":"/images/Edit(right).wgu",
					"size":{"width":2, "height":44},
					"margins":{"left":0, "top":4, "right":4, "bottom":4},
					"forealign":"right",
				},

				/* Label */
				{
					"type":"label",
					"item":{"column":1, "row":0},
					"id":0xFF000001, 
					"font":{"style":"normal","size":{"width":0x3FF4, "height":0x3FF4}} , 
					"forecolor":0x0000000C, // GL_COLOR_EDIT_TEXT
					"forealign":"left",
					"expand":"width",
					"shrink":"width",
				},
			]
		}
	]
}


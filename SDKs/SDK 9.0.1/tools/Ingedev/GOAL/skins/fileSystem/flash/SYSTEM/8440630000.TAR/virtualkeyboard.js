{
	"type":"virtualkeyboard",
	"grow":"all",
	"shrink":"none",
	"clickable":false,
	"focusable":true,
	"expand":"all",
	"children":
	[
		{
			"type":"layout",
			"children":
			[
				{
					"type":"edit",
					"item":{"column":0, "row":0},
					"id": 0xFF000017, // GL_ID_SKIN_EDIT_FIELD
					"focusable":false,
					"clicksensitive":false,
					"clickable":false,
					"grow":"width",
					"expand":"width",
					"shrink":"width",
					"textalign":"right",
				},
				{
					"type":"layout",
					"item":{"column":0, "row":1},
					"id": 0xFF00001A, // GL_ID_SKIN_DIALOG_KEYBOARD
					"children":
					[
					]
				},
			]
		}
	],
	"anychar":
	[
		{"type":"page","name":"123","mapping":"123\n456\n789\n.0*\n\uF808\uF809\uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDE\nFGHIJ\nKLMNO\nPQRST\nUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850",},
		{"type":"page","name":"abc","mapping":"abcde\nfghij\nklmno\npqrst\nuvwxyz\n\uF808\uF809 \uF851\uF852\uF850",},
		{"type":"page","name":"#$%","mapping":"[]{}()\n<>=+-/\n!?,;:\\\n|^@_&*\n`'\"#$%\n\uF808\uF809 \uF851\uF852\uF850",},
	],
	"alphanumeric":
	[
		{"type":"page","name":"123","mapping":"123\n456\n789\n0\n\uF808\uF809 \uF851\uF852\uF850"},
		{"type":"page","name":"ABC","mapping":"ABCDE\nFGHIJ\nKLMNO\nPQRST\nUVWXYZ\n\uF808\uF809 \uF851\uF852\uF850",},
		{"type":"page","name":"abc","mapping":"abcde\nfghij\nklmno\npqrst\nuvwxyz\n\uF808\uF809 \uF851\uF852\uF850",},
	],
	"decimal":
	[
		{"type":"page","name":"123","mapping":"123\n456\n789\n0\n\uF851\uF852\uF850"},
	],
	"hexadecimal":
	[
		{"type":"page","name":"123","mapping":"123F\n456E\n789D\nA0BC\n\uF851\uF852\uF850"},
	],
	"octal":
	[
		{"type":"page","name":"123","mapping":"123\n456\n70\n\uF851\uF852\uF850"},
	],
	"binary":
	[
		{"type":"page","name":"123","mapping":"10\n\uF851\uF852\uF850"},
	],
}


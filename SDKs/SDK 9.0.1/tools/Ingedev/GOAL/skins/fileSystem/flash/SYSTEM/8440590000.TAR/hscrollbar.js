{
	"type":"hscrollbar",
	"grow":"width",
	"expand":"width",
	"shrink":"none",
	"clickable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HScrollBar(left).wgu",
					"size":{"width":0, "height":4},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HScrollBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HScrollBar(right).wgu",
					"size":{"width":0, "height":4},
					"forealign":"right",
				},
			]
		},

		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/HSlider(left).wgu", 
					"size":{"width":2, "height":4},
					"margins":{"left":1, "top":0, "right":0, "bottom":0},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/HSlider(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/HSlider(right).wgu",
					"size":{"width":2, "height":4},
					"margins":{"left":0, "top":0, "right":1, "bottom":0},
					"forealign":"right",
				},
			]
		},
	]
}


// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	"children":
	[
		{
			"type"           :"picture",
			"id"             :0xFF00000E, // GL_ID_SKIN_DIALOG_ICON
			"item"           :{"column":0, "row":0},
			"source"         :"/images/information.wgu",
			"margins"        :{"left":3, "top":0, "right":3, "bottom":0, "unit":"%"},
		},
		{
			"type"           :"label",
			"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"item"           :{"column":0, "row":1},
			"forecolor"      : 0x0000000E, // GL_COLOR_DIALOG_TEXT
			"text"           :"",
			"shrink"         :"width",
			"font"           :{"style":"normal","size":{"width":0x3FF5, "height":0x3FF5}} , 
		},
	]
},


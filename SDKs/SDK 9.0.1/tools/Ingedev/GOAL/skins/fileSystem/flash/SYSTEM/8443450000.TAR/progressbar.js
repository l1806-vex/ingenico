{
	"type":"progressbar",
	"grow":"width",
	"expand":"width",
	"shrink":"none",
	"children":
	[
		/* Progress bar */
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000005,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/ProgressBar(left).wgu",
					"size":{"width":1, "height":15},
					"forealign":"left",
				},
				{
					"type":"picture",
					"item":{"column":1, "row":0},
					"source":"/images/ProgressBar(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
				},
				{
					"type":"picture",
					"item":{"column":2, "row":0},
					"source":"/images/ProgressBar(right).wgu",
					"size":{"width":1, "height":15},
					"forealign":"right",
				},
			]
		},
		/* Slider */
		{
			"type":"layout",
			"grow":"width",
			"shrink":"none",
			"backalign":"left",
			"id":0xFF000004,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/ProgressSlider(center).wgu",
					"shrink":"width",
					"transformation":"repeatx",
					"margins":{"left":1, "top":1, "right":1, "bottom":1, "unit":"px"},
				},
			]
		},
		/* Label */
		{
			"type":"label",
			"id":0xFF000001, 
			"font":{"style":"normal","size":{"width":0x3FF2, "height":0x3FF2}},
			"forecolor":0xFF000000,
			"backcolor":0xFFFFFFFF,
			"text":"%3d%%",
		},
	]
}


// Content
{
	"type"       :"layout",
	"id"         :0xFF00000C, // GL_ID_SKIN_DIALOG_CONTENT
	"item":{"column":0, "row":1},
	
	"grow"       :"all",
	"shrink"     :"none",
	"expand"     :"all",
	
	"children":
	[
		{
			"type"           :"picture",
			"item"           :{"column":0, "row":0},
			"id"             :0xFF000015, // GL_ID_SKIN_DIALOG_VALUE
			"shrink"         : "all",
			"grow"           : "all",
		},
		{
			"type"           :"label",
			"item"           :{"column":0, "row":0},
			"id"             :0xFF000010, // GL_ID_SKIN_DIALOG_TEXT
			"text"           :"",
			"forecolor"      :0xFF000000,
			"backcolor"      :0xFFFFFFFF,
			"shrink"         :"width",
		},
	]
},


{
	"type":"vscrollbar",
	"grow":"height",
	"expand":"height",
	"shrink":"none",
	"clickable":true,
	"children":
	[
		{
			"type":"layout",
			"grow":"height",
			"shrink":"none",
			"backalign":"top",
			"id":0xFF000005,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/VScrollBar(top).wgu",
					"size":{"width":16, "height":12},
					"forealign":"top",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":1},
					"source":"/images/VScrollBar(middle).wgu",
					"shrink":"height",
					"transformation":"repeaty",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":2},
					"source":"/images/VScrollBar(bottom).wgu",
					"size":{"width":16, "height":12},
					"forealign":"bottom",
				},
			]
		},

		{
			"type":"layout",
			"grow":"height",
			"shrink":"none",
			"backalign":"top",
			"id":0xFF000004,
			"clicksensitive":true,
			"children":
			[
				{
					"type":"picture",
					"item":{"column":0, "row":0},
					"source":"/images/VSlider(top).wgu", 
					"size":{"width":12, "height":6},
					"margins":{"left":2, "top":2, "right":2, "bottom":0},
					"forealign":"top",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":1},
					"source":"/images/VSlider(middle).wgu",
					"margins":{"left":2, "top":0, "right":2, "bottom":0},
					"shrink":"height",
					"transformation":"repeaty",
				},
				{
					"type":"picture",
					"item":{"column":0, "row":2},
					"source":"/images/VSlider(bottom).wgu",
					"size":{"width":12, "height":6},
					"margins":{"left":2, "top":0, "right":2, "bottom":2},
					"forealign":"bottom",
				},
			]
		},
	]
}


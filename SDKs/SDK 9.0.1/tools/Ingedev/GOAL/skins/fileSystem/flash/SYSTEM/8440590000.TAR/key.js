{
	"type":"key",
	"grow":"all",
	"expand":"all",
	"shrink":"none",
	"clickable":true,
	"clicksensitive":true,
	"focusable":false,
	"children":
	[
		/* Label */
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001, 
			"font":{"style":"normal","size":{"width":0x3FF2, "height":0x3FF2}} ,
			"forecolor":0xFFFFFFFF,
			"backcolor":0xFF000000,
			"statemask":"checked",
			"expand":"all",
			"grow":"all",
			"size":{"height":9,"width":0x3FFF},
		},

		/* Label */
		{
			"type":"label",
			"item":{"column":0, "row":0},
			"id":0xFF000001,
			"font":{"style":"normal","size":{"width":0x3FF2, "height":0x3FF2}} , 
			"forecolor":0xFF000000,
			"backcolor":0xFFFFFFFF,
			"statemask":"unchecked",
			"expand":"all",
			"grow":"all",
			"size":{"height":9,"width":0x3FFF},
			
		},
		
		/* Key icon */
		{
			"type":"picture",
			"item":{"column":0, "row":0},
			"id":0xFF00001B,  // GL_ID_SKIN_KEY_ICON
			"shrink":"all",
			"expand":"all",
			"grow":"all",
		},
	]
}

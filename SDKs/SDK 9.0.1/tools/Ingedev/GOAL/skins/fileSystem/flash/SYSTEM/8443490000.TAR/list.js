{
	"type"  :"list",
	"grow"  :"all",
	"expand":"all",
	"shrink":"none",
	"children":
	[
		{
			"type"  :"scrollview",
			"item":{"column":0, "row":0},
			"id":0xFF00000A,
			"children":
			[
				{
					"type"  :"layout",
					"id"    :0xFF000009,
					"forealign":"top",
					"children":
					[
					]
				}
			]
		},
		{
			"type":"vscrollbar",
			"item":{"column":1, "row":0},
			"id"  :0xFF000008,
		}
	]
}

